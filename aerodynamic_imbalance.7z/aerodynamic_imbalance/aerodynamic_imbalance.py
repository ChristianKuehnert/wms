# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 08:52:05 2019

@author: w012028
"""


import pathlib
import os
import re
import sys
import gc
import math

import pandas as pd
import numpy as np
import itertools
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.formula.api as smf
import statsmodels.api as sm

import plotly
import plotly.graph_objects as go
from plotly.graph_objs import Scatter, Layout
from collections import Counter
    

from contextlib import redirect_stdout
from sklearn import datasets, linear_model
from sklearn.preprocessing import StandardScaler

import datetime as dt
from dateutil.relativedelta import *
    
from statsmodels.formula.api import ols 
import statsmodels.api as sm
from scipy import stats
from scipy.signal import savgol_filter
from scipy.signal import butter, lfilter, freqz







bHome = True


if bHome:
     sys.path.append(r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\my_functions')        # path to modules     
    
else:
    sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian')
    from wms.dbs import weadbs
    #from wms.analysis import regression
    
    sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht')
    from functions_aeroImb import store_cdef_data, myplot_aeroImb, adjust_se, collect_hd5_data_farm, get_datetime_factor_change, load_data_multiple_hd5files, collect_hd5_data_old
        
    #sys.path.append(r'Z:\bcdata\data\zzz_bitzer\pitchwinkelfehlstellung')        # path to modules  
    sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\weiterentwicklung__zzz_bitzer\pitchwinkeltest')
    import dataloader as dl

#sys.path.append(r'Z:\bcdata\data\zzz_bitzer\pitchwinkelfehlstellung')        # path to modules  
#    sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\weiterentwicklung__zzz_bitzer\pitchwinkeltest')
#    import dataloader as dl 
    sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions')        # path to modules  


import data as mfdata
from data import calc_phi_from_harmonics
from data.update_hd5 import combine_at
import monitor as mfmon
from plot import myFunctions_plot as mfplot
from plot.myFunctions_plot import myplot_fast, myplot_fast2
from kinematics import butter_lowpass, butter_lowpass_filter, get_ef
#from plot import provide_colors

#
#try:
#    import cPickle as pickle
#except ModuleNotFoundError:
#    import pickle

    
# TODO 2019-6-27: erstmal auskommentiert, da hierfuer update/Installation in conda noetig ist, was aber ohne admin-Rechte nicht geht
#import model

#sepath = pathlib.Path('D:') / 'schraeganstroemung' / 'energies'
path_data = r'C:\Users\w012028\Documents\CK\data\data__aerodynic_imbalance'
path_img = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\material'
path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht'
path_data_multiple = r'C:\Users\w012028\Documents\CK\data\data__aerodynic_imbalance\multiple_hd5'
    

band = [54, 66]
bw = band[1]-band[0]
eps = 1e-10


    
    

    

## 2020-2-19: weiter Untersuchung von Zeitreihen der Schmelz-WEA, Versuch, sin(phi) zu
## bestimmen und evtl. Auslenkung wg. Turmvorstau
if False:
   
    db = 'cmrblba_bc_t_01703'
    
    path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Blattlagerschaden\Auswertung_Schmelz_20200123'
    
    dict_periods = {'ok': 'a_t\\20181102\\33399',
                    'damaged': 'a_t\\20190301\\36783',
                    'early': 'a_t\\20180123\\22270'}
    
    # create output directory
    dtT00 = dt.datetime.now()
    sT00 = dtT00.strftime('%Y%m%d_%H%M%S')
    path_save = f'{path}\\work\\{sT00}'
    mfdata.create_folder(path_save)    
    
    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    
    res = []
    

    cols = [str(c) for c in range(6)]
          
    phi1 = (180-10)/180*np.pi
    phi2 = (180+10)/180*np.pi

    fn_log = f'{path_save}\\results.txt'
    with open (fn_log, "a+") as fh:
            
        for s_state, subpath in dict_periods.items():
    
            dict_res, critical_channels = combine_at(f'{path}\\{subpath}')
            print(f'{s_state}: {critical_channels}', file=fh)
                
            dfs = list()
            
            for c in cols:
                dfs.append(dict_res[c].set_index('time').rename(columns={'a_t': 
                                                            f'Channel-{c}'}))
                
            df = pd.concat(dfs, axis=1)
    
            ## TODO 2020-2-18: folgendes oder Teile davon in eigene Funktion(en) auslagern              
            lixs = list()
            lixe = list()
            print(f'{s_state}:', file=fh)
            print('______:', file=fh)
                    
            for col in range(3):
    
                print(f'blade {col+1}:', file=fh)  
                
                edge, flap = get_ef(df, col, wdw_size_prae)
                
                bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
                                                min_amp=4000, 
                                                min_pi_duration=1000, 
                                                apply_low_pass_filter=False, 
                                                calc_phi=True, 
                                                counterclockwise = True, 
                                                offset = 0)
                
                omega = 2 * np.pi * dict_res['f_mean']
                phi_rot = dict_res['phi']
                                     
                tmp = dict_res['zero_transitions']
                
                ## calculate the pitch angle for each cycle separately
                for idx in range(1, len(tmp)-3):
                    ixs_tmp = tmp[idx]
                    ixe_tmp = tmp[idx+2]    
      
                    phi_rot_cyc = phi_rot[ixs_tmp:ixe_tmp]
                    edge_cyc = edge[ixs_tmp:ixe_tmp]
                    flap_cyc = flap[ixs_tmp:ixe_tmp]
                    
                    # exclude around tower
                    dict_pos = {'up': (phi_rot_cyc <= phi1) | \
                                (phi_rot_cyc >= phi2),
                                'tower': (phi_rot_cyc > phi1) & \
                                (phi_rot_cyc < phi2)}
                    
#                    for spos, btmp in dict_pos.items():
                    # erstmal nur oberhalb tower
                    btmp = dict_pos['up']
                    phi_rot_tmp = phi_rot_cyc[btmp]
                    edge_tmp = edge_cyc[btmp]
                    flap_tmp = flap_cyc[btmp]                                            
                    
                    list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge_tmp, 
                                     {'color': col_map[f'e{col+1}']}),
                                    (phi_rot_tmp-np.pi*col*2/3, flap_tmp, 
                                     {'color': col_map[f'f{col+1}']})]
        
                    ## regression for edge
                    #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
                    X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                                   np.sin(phi_rot_tmp))))
        
                    model = sm.OLS(edge_tmp, X)
                    reg = model.fit()
                    #print('edge:', file=fh)
                    #print(reg.summary(), file=fh)
                    b0e, b1e, b2e = reg.params
                    list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                     {'color': 'black'}))
                
                    ## regression for flap
                    #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
                    #X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                    #                               np.sin(phi_rot_tmp))))
                    model = sm.OLS(flap_tmp, X)
                    reg = model.fit()
                    #print('flap:', file=fh)
                    #print(reg.summary(), file=fh)
                    b0f, b1f, b2f = reg.params
                    list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                         {'color': 'black'}))
                
                    ## control plots
                    fn_img = f'{path_save}\\blade{col}_cycle{idx}_regress3_{s_state}.png'
                    myplot_fast2(list_to_plot, 
                                 fn = fn_img, 
                                 s_title=f'edge, flap {s_state}, cycle {idx}, ' 
                                 + 'control plot for ' + \
                                 'regression a_t ~ cos + sin',
                                 legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 
                                           'reg flap'], 
                                 projection = 'polar')
                
                    pitch = np.arctan(-b0e/b0f)
                    pitch_grad0 = pitch * 180/np.pi
                    #print(f'b0 = {pitch_grad0}^o')
                
                    pitch = np.arctan(-b1e/b1f)
                    pitch_grad1 = pitch * 180/np.pi
                    #print(f'b1 = {pitch_grad1}^o')
        
                    pitch = np.arctan(-b2f/b2e)
                    pitch_grad2 = pitch * 180/np.pi
                    print(f'b2 = {pitch_grad2}^o', file=fh)
        
                    F0 = np.sqrt(b0e**2+b0f**2)
                    F1 = np.sqrt(b1e**2+b1f**2)
                    F2 = np.sqrt(b2e**2+b2f**2)
                    print(f'F0={F0}', file = fh)
                    print(f'F1={F1}', file = fh)
                    print(f'F2={F2}', file = fh)
            
                    phi_bend = np.arcsin(np.sqrt(F1/F2))              
                       
            
                    res.append((s_state, f'blade{col+1}', idx, pitch_grad0, 
                                pitch_grad1, pitch_grad2,
                                F0, F1, F2,
                                phi_bend,
                                b0e, b1e, b2e, b0f, b1f, b2f,
                                -b1e/b2f, -b1f/b2e))
    
    
        df_res = pd.DataFrame.from_records(res, 
                                           columns = ['state', 'blade',
                                                      'cycle',
                                                      'pitch_grad0', 
                                                      'pitch_grad1',
                                                      'pitch_grad2',
                                                      'F0', 'F1', 'F2',
                                                      'phi_bend',
                                                      'b0e', 'b1e', 'b2e',
                                                      'b0f', 'b1f', 'b2f',
                                                      'b1e/b2f*(-1)', 'b1f/b2e*(-1)'])
        
        df_res.to_csv(f'{path_save}\\result_reg3.csv', sep=';', 
                        index=False)
        
    
    
    
    
    
    

## 2020-2-19: weiter Untersuchung von Zeitreihen der Schmelz-WEA
## Idee dabei: REGRESSION A_E/F ~ COS(OMEGA) (S. HEFT), AUS SCHAETZPARAMETERN DANN PITCHWINKEL ETC. ABLEITEN, GGF. MIT DIESEN WERTEN AUSSERHALB DES TURMBEREICHS DANN DIE AUSLENKUNG IM TURMBEREICH BETRACHTEN,
#AUSSERDEM VIELL. DAMIT AUCH BLATTLAGERDEFEKTE FESTSTELLBAR (STAERKERE VARIANZ AN DEN KRIT. STELLEN ODER INSGESAMT GGUE. PERIODEN MIT NORMALER PITCHSCHWANKUNG???)
#import datetime as dt
    #print(type(tmp))
#if True:
if False:
   
    db = 'cmrblba_bc_t_01703'
    
    path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Blattlagerschaden\Auswertung_Schmelz_20200123'
    
    dict_periods = {'ok': 'a_t\\20181102\\33399',
                    'damaged': 'a_t\\20190301\\36783',
                    'early': 'a_t\\20180123\\22270'}
    
    
    # create output directory
    dtT00 = dt.datetime.now()
    sT00 = dtT00.strftime('%Y%m%d_%H%M%S')
    path_save = f'{path}\\work\\{sT00}'
    mfdata.create_folder(path_save)    
    
    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    
    res = []
    

    cols = [str(c) for c in range(6)]
          
    fn_log = f'{path_save}\\results.txt'
    with open (fn_log, "a+") as fh:
            
        for s_state, subpath in dict_periods.items():
    
            dict_res, critical_channels = combine_at(f'{path}\\{subpath}')
            print(f'{s_state}: {critical_channels}', file=fh)
                
            dfs = list()
            
            for c in cols:
                dfs.append(dict_res[c].set_index('time').rename(columns={'a_t': 
                                                            f'Channel-{c}'}))
                
            df = pd.concat(dfs, axis=1)
    
            ## TODO 2020-2-18: folgendes oder Teile davon in eigene Funktion(en) auslagern              
            lixs = list()
            lixe = list()
            print(f'{s_state}:', file=fh)
            print('______:', file=fh)
                    
            for col in range(3):
    
                print(f'blade {col+1}:', file=fh)  
                
                edge, flap = get_ef(df, col, wdw_size_prae)
                
                bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
                                                min_amp=4000, 
                                                min_pi_duration=1000, 
                                                apply_low_pass_filter=False, 
                                                calc_phi=True, 
                                                counterclockwise = True, 
                                                offset = 0)
                
                omega = 2 * np.pi * dict_res['f_mean']
                phi_rot = dict_res['phi']
                                     
                tmp = dict_res['zero_transitions']
                
                ## calculate the pitch angle for each cycle separately
                for idx in range(1, len(tmp)-3):
                    ixs_tmp = tmp[idx]
                    ixe_tmp = tmp[idx+2]    
      
                    phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
                    list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge[ixs_tmp:ixe_tmp], 
                                     {'color': col_map[f'e{col+1}']}),
                                    (phi_rot_tmp-np.pi*col*2/3, flap[ixs_tmp:ixe_tmp], 
                                     {'color': col_map[f'f{col+1}']})]
        
                    ## regression for edge
                    #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
                    X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                                   np.sin(phi_rot_tmp))))
        
                    model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)
                    reg = model.fit()
                    #print('edge:', file=fh)
                    #print(reg.summary(), file=fh)
                    b0e, b1e, b2e = reg.params
                    list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                     {'color': 'black'}))
                
                    ## regression for flap
                    #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
                    #X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                    #                               np.sin(phi_rot_tmp))))
                    model = sm.OLS(flap[ixs_tmp:ixe_tmp], X)
                    reg = model.fit()
                    #print('flap:', file=fh)
                    #print(reg.summary(), file=fh)
                    b0f, b1f, b2f = reg.params
                    list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                         {'color': 'black'}))
                
                    ## control plots
                    fn_img = f'{path_save}\\blade{col}_cycle{idx}_regress3_{s_state}.png'
                    myplot_fast2(list_to_plot, 
                                 fn = fn_img, 
                                 s_title=f'edge, flap {s_state}, cycle {idx}, ' 
                                 + 'control plot for ' + \
                                 'regression a_t ~ cos + sin',
                                 legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 
                                           'reg flap'], 
                                 projection = 'polar')
                
                    pitch = np.arctan(-b0e/b0f)
                    pitch_grad0 = pitch * 180/np.pi
                    #print(f'b0 = {pitch_grad0}^o')
                
                    pitch = np.arctan(-b1e/b1f)
                    pitch_grad1 = pitch * 180/np.pi
                    #print(f'b1 = {pitch_grad1}^o')
        
                    pitch = np.arctan(-b2f/b2e)
                    pitch_grad2 = pitch * 180/np.pi
                    print(f'b2 = {pitch_grad2}^o', file=fh)
        
                    F0 = np.sqrt(b0e**2+b0f**2)
                    F1 = np.sqrt(b1e**2+b1f**2)
                    F2 = np.sqrt(b2e**2+b2f**2)
                    print(f'F0={F0}', file = fh)
                    print(f'F1={F1}', file = fh)
                    print(f'F2={F2}', file = fh)
            
                    phi_bend = np.arcsin(np.sqrt(F1/F2))              
                                   
                    res.append((s_state, f'blade{col+1}', idx, pitch_grad0, 
                                pitch_grad1, pitch_grad2,
                                F0, F1, F2,
                                phi_bend,
                                b0e, b1e, b2e, b0f, b1f, b2f,
                                -b1e/b2f, -b1f/b2e))
    
    
        df_res = pd.DataFrame.from_records(res, 
                                           columns = ['state', 'blade',
                                                      'cycle',
                                                      'pitch_grad0', 
                                                      'pitch_grad1',
                                                      'pitch_grad2',
                                                      'F0', 'F1', 'F2',
                                                      'phi_bend',
                                                      'b0e', 'b1e', 'b2e',
                                                      'b0f', 'b1f', 'b2f',
                                                      'b1e/b2f*(-1)', 'b1f/b2e*(-1)'])
        
        df_res.to_csv(f'{path_save}\\result_reg3.csv', sep=';', 
                        index=False)
        
        
          
    
    
    
    
## 2020-2-18: Untersuchung von Zeitreihen der Schmelz-WEA
## Idee dabei: REGRESSION A_E/F ~ COS(OMEGA) (S. HEFT), AUS SCHAETZPARAMETERN DANN PITCHWINKEL ETC. ABLEITEN, GGF. MIT DIESEN WERTEN AUSSERHALB DES TURMBEREICHS DANN DIE AUSLENKUNG IM TURMBEREICH BETRACHTEN,
#AUSSERDEM VIELL. DAMIT AUCH BLATTLAGERDEFEKTE FESTSTELLBAR (STAERKERE VARIANZ AN DEN KRIT. STELLEN ODER INSGESAMT GGUE. PERIODEN MIT NORMALER PITCHSCHWANKUNG???)
#import datetime as dt
    #print(type(tmp))
if False:

    
    db = 'cmrblba_bc_t_01703'
    
    path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Blattlagerschaden\Auswertung_Schmelz_20200123'
    
    dict_periods = {'ok': 'a_t\\20181102\\33399',
                    'damaged': 'a_t\\20190301\\36783'}
    
    
    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    
    res = []
    

    cols = [str(c) for c in range(6)]


    fn_log = f'{path}\\results.txt'
    with open (fn_log, "a+") as fh:
            
        for s_state, subpath in dict_periods.items():
    
            dict_res, critical_channels = combine_at(f'{path}\\{subpath}')
            print(f'{s_state}: {critical_channels}', file=fh)
                
            dfs = list()
            
            for c in cols:
                dfs.append(dict_res[c].set_index('time').rename(columns={'a_t': 
                                                            f'Channel-{c}'}))
                
            df = pd.concat(dfs, axis=1)
    
            ## TODO 2020-2-18: folgendes oder Teile davon in eigene Funktion(en) auslagern              
            lixs = list()
            lixe = list()
            print(f'{s_state}:', file=fh)
            print('______:', file=fh)
                    
            for col in range(3):
    
                print(f'blade {col+1}:', file=fh)  
                
                edge, flap = get_ef(df, col, wdw_size_prae)
                
                bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
                                                min_amp=4000, 
                                                min_pi_duration=1000, 
                                                apply_low_pass_filter=False, 
                                                calc_phi=True, 
                                                counterclockwise = True, 
                                                offset = 0)
                
                omega = 2 * np.pi * dict_res['f_mean']
                phi_rot = dict_res['phi']
                                     
                tmp = dict_res['zero_transitions']
                
                ixs_tmp = tmp[1]
                ixe_tmp = tmp[-2]
    
      
                phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
                list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge[ixs_tmp:ixe_tmp], 
                                 {'color': col_map[f'e{col+1}']}),
                                (phi_rot_tmp-np.pi*col*2/3, flap[ixs_tmp:ixe_tmp], 
                                 {'color': col_map[f'f{col+1}']})]
    
                ## regression for edge
                #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
                X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                               np.sin(phi_rot_tmp))))
    
                model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)
                reg = model.fit()
                #print('edge:', file=fh)
                #print(reg.summary(), file=fh)
                b0e, b1e, b2e = reg.params
                list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                 {'color': 'black'}))
            
                ## regression for flap
                #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
                #X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                #                               np.sin(phi_rot_tmp))))
                model = sm.OLS(flap[ixs_tmp:ixe_tmp], X)
                reg = model.fit()
                #print('flap:', file=fh)
                #print(reg.summary(), file=fh)
                b0f, b1f, b2f = reg.params
                list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                     {'color': 'black'}))
            
                ## control plots
                fn_img = f'{path}\\blade{col}_regress3_{s_state}.png'
                myplot_fast2(list_to_plot, 
                             fn = fn_img, 
                             s_title=f'edge, flap {s_state}, control plot for ' + \
                             'regression a_t ~ cos + sin',
                             legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 
                                       'reg flap'], 
                             projection = 'polar')
            
                pitch = np.arctan(-b0e/b0f)
                pitch_grad0 = pitch * 180/np.pi
                #print(f'b0 = {pitch_grad0}^o')
            
                pitch = np.arctan(-b1e/b1f)
                pitch_grad1 = pitch * 180/np.pi
                #print(f'b1 = {pitch_grad1}^o')
    
                pitch = np.arctan(-b2f/b2e)
                pitch_grad2 = pitch * 180/np.pi
                print(f'b2 = {pitch_grad2}^o', file=fh)
    
                F0 = np.sqrt(b0e**2+b0f**2)
                F1 = np.sqrt(b1e**2+b1f**2)
                F2 = np.sqrt(b2e**2+b2f**2)
                print(f'F0={F0}', file = fh)
                print(f'F1={F1}', file = fh)
                print(f'F2={F2}', file = fh)
        
                lixs.append(ixs_tmp)
                lixe.append(ixe_tmp)
        
                phi_bend = np.arcsin(np.sqrt(F1/F2))              
            
                res.append((s_state, f'blade{col+1}', pitch_grad0, pitch_grad1,
                            pitch_grad2, F0, F1, F2, phi_bend))
    
        df_res = pd.DataFrame.from_records(res, 
                                           columns = ['state', 'blade', 
                                                      'pitch_grad0', 'pitch_grad1',
                                                      'pitch_grad2', 
                                                      'F0', 'F1', 'F2',
                                                      'bending_angle'])
        
        df_res.to_csv(f'{path}\\result_reg3_{s_state}.csv', sep=';', 
                      index=False)
        
        
        
        
        
    
    
    

## 2020-2-17: regression with phi != 0, arbeit @home 
if True:

    #from plot.myFunctions_plot import myplot_fast, myplot_fast2
    path = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\aerodynUnwucht\test_pitchwinkelfehlstellung'
    #path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\test_pitchwinkelfehlstellung'

#    dict_files = {'ok': r'ts__Wikinger_AdwenWK09__20190416_133949.csv',
#                  'test':r'ts__Wikinger_AdwenWK09__20190417_151313.csv'}
    dict_files = {#'ok': r'ts__Wikinger_AdwenWK49__20200224_232717.csv',
                  'ok2': r'ts__Wikinger_AdwenWK49__20200225_002222.csv',
                  'ok3': r'ts__Wikinger_AdwenWK49__20200225_030720.csv',
                  'test':r'ts__Wikinger_AdwenWK49__20200225_183229.csv'}

    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    
    # positions of sensors from center axis of the 3 blades
    z_pos = {0: 19,
             1: 19,
             2: 19}

    res = []
    
    ## read in files, calculate pitch angles, display results
    for s_state, fn in dict_files.items():
        print(f'{s_state}:')
        print('-----')
        
        ## read in csv data
        df = pd.read_csv(f'{path}\\{fn}', sep=',')
        #mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'Channel-{i}' for i in range(6)]])
        
        # calculate the pitch angle, reversed in order to have the finally calculated phi_rot as one signle 
        # lists for first 0 crossing points (in order to drop boundary effects)
        lixs = list()
        lixe = list()
        for col in range(3):
            
            edge, flap = get_ef(df, col, wdw_size_prae)
            
            bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
                                            min_amp=4000, 
                                            min_pi_duration=1000, 
                                            apply_low_pass_filter=False, 
                                            calc_phi=True, 
                                            counterclockwise = True, 
                                            offset = 0)
            
            omega = 2 * np.pi * dict_res['f_mean']
            phi_rot = dict_res['phi']
                                 
            tmp = dict_res['zero_transitions']
            
            ixs_tmp = tmp[1]
            ixe_tmp = tmp[-2]

  
            phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
            list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'e{col+1}']}),
                            (phi_rot_tmp-np.pi*col*2/3, flap[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'f{col+1}']})]

            ## regression for edge
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                           np.sin(phi_rot_tmp))))
            model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0e, b1e, b2e = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                             {'color': 'black'}))
        
            ## regression for flap
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                           np.sin(phi_rot_tmp))))
            model = sm.OLS(flap[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0f, b1f, b2f = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                 {'color': 'black'}))
        
            ## control plots
            fn_img = f'{path}\\blade{col}_regress3_WK49.png'
            myplot_fast2(list_to_plot, 
                         fn = fn_img, 
                         s_title=f'edge, flap {s_state}, control plot for ' + \
                         'regression a_t ~ cos + sin',
                         legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 
                                   'reg flap'], 
                         projection = 'polar')
        
            pitch = np.arctan(-b0e/b0f)
            pitch_grad0 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta0 = {pitch_grad0}^o')
        
            pitch = np.arctan(-b1e/b1f)
            pitch_grad1 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta1 = {pitch_grad1}^o')

            pitch = np.arctan(-b2f/b2e)
            pitch_grad2 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta2 = {pitch_grad2}^o')

            lixs.append(ixs_tmp)
            lixe.append(ixe_tmp)
                   
        
            res.append((s_state, f'blade{col+1}', pitch_grad0, pitch_grad1,
                        pitch_grad2))

    df_res = pd.DataFrame.from_records(res, 
                                       columns = ['state', 'blade', 
                                                  'pitch_grad0', 'pitch_grad1',
                                                  'pitch_grad2'])

    df_res.to_csv(f'{path}\\result_reg3_WK49.csv', sep=';', index=False)
#
#        ixs = max(lixs)
#        ixe = min(lixe)
#
#        df = df.iloc[ixs:ixe,:]
#
#        phi_rot = df.loc[:, 'phi_rot_0']   # take rot angle of 1st blade as rotor angle
#                
#        print(f"{s_state}: {df.loc[:, ['pitch_0', 'pitch_1', 'pitch_2']].mean(axis=0, skipna=True)}")
#        
##        fn_img = f'{path}\\{s_state}.png'
##        mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'pitch_{i}' for i in range(3)]], 
##                            fn=fn_img, s_title = s_state, legend = ['bl.1', 'bl.2', 'bl.3'])
#        
#        ## print differences between the 3 phi_rots
#        
#        
#        fn_img = f'{path}\\{s_state}_pitch_polar.png'
#        list_to_plot = [(phi_rot-np.pi*i*2/3, df.loc[:, f'pitch_{i}'], 
#                         {'color': col_map[f'e{i+1}']}) for i in range(3)]
#        myplot_fast2(list_to_plot, fn=fn_img, 
#                     s_title = f'pitch, {s_state}', 
#                     legend = ['bl.1', 'bl.2', 'bl.3'], 
#                     projection = 'polar')                            
#
#        ## plot edges and flaps
#        fn_img = f'{path}\\{s_state}_ef_polar.png'    
#        list_to_plot=[(phi_rot-np.pi*i*2/3, df.loc[:,f'edge_{i}'],
#                       {'color': col_map[f'e{i+1}']}) for i in range(3)] + \
#                        [(phi_rot-np.pi*i*2/3, df.loc[:,f'flap_{i}'],
#                          {'color': col_map[f'f{i+1}']}) for i in range(3)]
#    
#        myplot_fast2(list_to_plot, fn = fn_img, 
#                     s_title = f'edge, flap {s_state}',
#                     legend = ['e1', 'e2', 'e3', 'f1', 'f2', 'f3'], 
#                     projection = 'polar')
#        
#        
#    df_diff = res['test'].loc[:, ['pitch_0', 'pitch_1', 'pitch_2']] - \
#                res['ok'].loc[:, ['pitch_0', 'pitch_1', 'pitch_2']]
#    df_diff = df_diff.assign(epoch = res['ok'].loc[:, 'epoch'])
#    
#    fn_img = f'{path}\\diff.png'
#    myplot_fast(df_diff.loc[:, ['epoch'] + [f'pitch_{i}' for i in range(3)]], 
#                fn=fn_img, s_title = 'diff', legend = ['bl.1', 'bl.2', 'bl.3'])
#    
#    print(f"differences: {df_diff.loc[:, ['pitch_0', 'pitch_1', 'pitch_2']].mean(axis=0, skipna=True)}")


    
    
## 2020-2-17: regression with phi~0, arbeit @home 
if False:

    #from plot.myFunctions_plot import myplot_fast, myplot_fast
    #path = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\aerodynUnwucht\test_pitchwinkelfehlstellung'
    path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\test_pitchwinkelfehlstellung'

    dict_files = {'ok': r'ts__Wikinger_AdwenWK09__20190416_133949.csv',
                  'test':r'ts__Wikinger_AdwenWK09__20190417_151313.csv'}

    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    
    # positions of sensors from center axis of the 3 blades
    z_pos = {0: 19,
             1: 19,
             2: 19}

    res = []
    
    ## read in files, calculate pitch angles, display results
    for s_state, fn in dict_files.items():
        print(f'{s_state}:')
        print('-----')
        
        ## read in csv data
        df = pd.read_csv(f'{path}\\{fn}', sep=',')
        #mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'Channel-{i}' for i in range(6)]])
        
        # calculate the pitch angle, reversed in order to have the finally calculated phi_rot as one signle 
        # lists for first 0 crossing points (in order to drop boundary effects)
        lixs = list()
        lixe = list()
        for col in range(3):
            
            edge, flap = get_ef(df, col, wdw_size_prae)
            
            bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
                                            min_amp=4000, 
                                            min_pi_duration=1000, 
                                            apply_low_pass_filter=False, 
                                            calc_phi=True, 
                                            counterclockwise = True, 
                                            offset = 0)
            
            omega = 2 * np.pi * dict_res['f_mean']
            phi_rot = dict_res['phi']
                                 
            tmp = dict_res['zero_transitions']
            
            ixs_tmp = tmp[1]
            ixe_tmp = tmp[-2]

  
            phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
            list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'e{col+1}']}),
                            (phi_rot_tmp-np.pi*col*2/3, flap[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'f{col+1}']})]

            ## regression for edge
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.sin(phi_rot_tmp))
            model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)    
            reg = model.fit()
            #print(results.summary())
            b0e, b1e = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                             {'color': 'black'}))
        
            ## regression for flap
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.sin(phi_rot_tmp))
            model = sm.OLS(flap[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0f, b1f = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                 {'color': 'black'}))
        
            ## control plots
            fn_img = f'{path}\\blade{col}_regress.png'
            myplot_fast2(list_to_plot, 
                         fn = fn_img, 
                         s_title = f'edge, flap {s_state}, control plot for regression',
                         legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 'reg flap'], 
                         projection = 'polar')
        
#            pitch = np.arctan(-b1f/b1e)
            pitch = np.arctan(b1e/b1f)
            pitch_grad = pitch * 180/np.pi
            print(f'blade{col} pitch = {pitch_grad}^o')
        
#            r = (b0e*b1e+b0f*b1f)/(b1e*np.cos(pitch)-b1f*np.sin(pitch)) / omega**2
#            print(f'blade{col} radius = {r}')
#            print('')
            pitch_check = np.arctan(b0f/b0e) * 180/np.pi
            print(f'blade{col} pitch check = {pitch_check}^o')
            
            lixs.append(ixs_tmp)
            lixe.append(ixe_tmp)
                   
        
            res.append((s_state, f'blade{col+1}', pitch_grad, pitch_check))

    df_res = pd.DataFrame.from_records(res, 
                                       columns = ['state', 'blade', 
                                                  'pitch_grad', 'pitch_check'])

    df_res.to_csv(f'{path}\\result.csv', sep=';', index=False)
#
#        ixs = max(lixs)
#        ixe = min(lixe)
#
#        df = df.iloc[ixs:ixe,:]
#
#        phi_rot = df.loc[:, 'phi_rot_0']   # take rot angle of 1st blade as rotor angle
#                
#        print(f"{s_state}: {df.loc[:, ['pitch_0', 'pitch_1', 'pitch_2']].mean(axis=0, skipna=True)}")
#        
##        fn_img = f'{path}\\{s_state}.png'
##        mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'pitch_{i}' for i in range(3)]], 
##                            fn=fn_img, s_title = s_state, legend = ['bl.1', 'bl.2', 'bl.3'])
#        
#        ## print differences between the 3 phi_rots
#        
#        
#        fn_img = f'{path}\\{s_state}_pitch_polar.png'
#        list_to_plot = [(phi_rot-np.pi*i*2/3, df.loc[:, f'pitch_{i}'], 
#                         {'color': col_map[f'e{i+1}']}) for i in range(3)]
#        myplot_fast2(list_to_plot, fn=fn_img, 
#                     s_title = f'pitch, {s_state}', 
#                     legend = ['bl.1', 'bl.2', 'bl.3'], 
#                     projection = 'polar')                            
#
#        ## plot edges and flaps
#        fn_img = f'{path}\\{s_state}_ef_polar.png'    
#        list_to_plot=[(phi_rot-np.pi*i*2/3, df.loc[:,f'edge_{i}'],
#                       {'color': col_map[f'e{i+1}']}) for i in range(3)] + \
#                        [(phi_rot-np.pi*i*2/3, df.loc[:,f'flap_{i}'],
#                          {'color': col_map[f'f{i+1}']}) for i in range(3)]
#    
#        myplot_fast2(list_to_plot, fn = fn_img, 
#                     s_title = f'edge, flap {s_state}',
#                     legend = ['e1', 'e2', 'e3', 'f1', 'f2', 'f3'], 
#                     projection = 'polar')
#        
#        
#    df_diff = res['test'].loc[:, ['pitch_0', 'pitch_1', 'pitch_2']] - \
#                res['ok'].loc[:, ['pitch_0', 'pitch_1', 'pitch_2']]
#    df_diff = df_diff.assign(epoch = res['ok'].loc[:, 'epoch'])
#    
#    fn_img = f'{path}\\diff.png'
#    myplot_fast(df_diff.loc[:, ['epoch'] + [f'pitch_{i}' for i in range(3)]], 
#                fn=fn_img, s_title = 'diff', legend = ['bl.1', 'bl.2', 'bl.3'])
#    
#    print(f"differences: {df_diff.loc[:, ['pitch_0', 'pitch_1', 'pitch_2']].mean(axis=0, skipna=True)}")

  
    

## 2020-1-26: test for using pitch angle 
if False:

    #path = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\aerodynUnwucht'
    path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\test_pitchwinkelfehlstellung'
    
    dict_files = {'ok': r'ts__Wikinger_AdwenWK09__20190416_133949.csv',
                  'test':r'ts__Wikinger_AdwenWK09__20190417_151313.csv'}

    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    
    # positions of sensors from center axis of the 3 blades
    z_pos = {0: 19,
             1: 19,
             2: 19}

    res = {}
    
    ## read in files, calculate pitch angles, display results
    for s_state, fn in dict_files.items():
        
        ## read in csv data
        df = pd.read_csv(f'{path}\\{fn}', sep=',')
        #mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'Channel-{i}' for i in range(6)]])
        
        # calculate the pitch angle, reversed in order to have the finally calculated phi_rot as one signle 
        # lists for first 0 crossing points (in order to drop boundary effects)
        lixs = list()
        lixe = list()
        for col in reversed(range(3)):
            
            edge, flap = get_ef(df, col, wdw_size_prae)
            
            bOk, dict_res = mfdata.calc_phi_from_harmonics(edge, wdw_size=10001, 
                                            min_amp=4000, 
                                            min_pi_duration=1000, 
                                            apply_low_pass_filter=False, 
                                            calc_phi=True, 
                                            counterclockwise = True, 
                                            offset = 0)
            
            omega = 2 * np.pi * dict_res['f_mean']
            phi_rot = dict_res['phi']
                                 
            tmp = dict_res['zero_transitions']
            
            ixs_tmp = tmp[1]
            ixe_tmp = tmp[-2]


            phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
            list_to_plot = [(phi_rot_tmp, edge[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'e{col+1}']}),
                            (phi_rot_tmp, flap[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'f{col+1}']})]

            ## regression for edge
            X = sm.add_constant(np.cos(phi_rot_tmp))
            model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)    
            reg = model.fit()
            #print(results.summary())
            b0e, b1e = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                             {'color': 'black'}))
        
            ## regression for flap
            X = sm.add_constant(flap[ixs_tmp:ixe_tmp])
            model = sm.OLS(np.cos(phi_rot_tmp), X)    
            reg = model.fit()
            #print(results.summary())
            b0f, b1f = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                 {'color': 'black'}))
        
            ## control plots
            fn_img = f'{path}\\blade{col}_regress.png'
            mfplot.myplot_fast2(list_to_plot, fn = fn_img, 
                                s_title = f'edge, flap {s_state}, control plot for regression',
                                legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 'reg flap'], 
                                projection = 'polar')
        
            pitch = np.arctan(-b1f/b1e)
            print(f'blade{col} pitch = {pitch}')
        
            r = (b0e*b1e+b0f*b1f)/(b1e*np.cos(pitch)-b1f*np.sin(pitch)) / omega**2
            print(f'blade{col} radius = {r}')


            
            lixs.append(ixs_tmp)
            lixe.append(ixe_tmp)
                   
            y = -z_pos[col] * omega**2 + np.cos(phi_rot) * 9.81
            #y = y * 0
    #            tmp1 = flap/edge
    #            tmp2 = y / edge
    #            c_a = 1 + tmp1**2
    #            c_b = -2 * tmp1 * tmp2
    #            c_c = tmp2**2 - 1
    #            cos_phi = (-c_b + np.sqrt(c_b**2-4*c_a*c_c))/(2*c_a)
            a2 = edge*edge+flap*flap
            print(f'{s_state},{col}: {min(a2-y*y)}')     
            cos_phi = (abs(edge)*np.sqrt(a2-y*y)-flap*y)/a2
            pitch = 180/np.pi * np.arccos(cos_phi)
    
            df = df.assign(tmp = phi_rot, tmp1 = edge, tmp2 = flap, tmp3 = a2, 
                           tmp4 = cos_phi, tmp5 = pitch, )
    
    #        sin_phi = (abs(flap)*np.sqrt(a2-y*y)-edge*y)/a2
    #        df = df.assign(tmp = 180/np.pi * np.arcsin(sin_phi))
    
            df.rename(columns = {'tmp': f'phi_rot_{col}', 'tmp1': f'edge_{col}',
                                 'tmp2': f'flap_{col}', 'tmp3': f'a2_{col}',
                                 'tmp4': f'cos_phi_{col}', 
                                 'tmp5': f'pitch_{col}', }, inplace = True)

        
        res.update({s_state: df.copy()})

        ixs = max(lixs)
        ixe = min(lixe)

        df = df.iloc[ixs:ixe,:]

        phi_rot = df.loc[:, 'phi_rot_0']   # take rot angle of 1st blade as rotor angle
                
        print(f"{s_state}: {df.loc[:, ['pitch_0', 'pitch_1', 'pitch_2']].mean(axis=0, skipna=True)}")
        
#        fn_img = f'{path}\\{s_state}.png'
#        mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'pitch_{i}' for i in range(3)]], 
#                            fn=fn_img, s_title = s_state, legend = ['bl.1', 'bl.2', 'bl.3'])
        
        ## print differences between the 3 phi_rots
        
        
        fn_img = f'{path}\\{s_state}_pitch_polar.png'
        list_to_plot = [(phi_rot-np.pi*i*2/3, df.loc[:, f'pitch_{i}'], 
                         {'color': col_map[f'e{i+1}']}) for i in range(3)]
        mfplot.myplot_fast2(list_to_plot, fn=fn_img, 
                            s_title = f'pitch, {s_state}', 
                            legend = ['bl.1', 'bl.2', 'bl.3'], 
                            projection = 'polar')                            

        ## plot edges and flaps
        fn_img = f'{path}\\{s_state}_ef_polar.png'    
        list_to_plot=[(phi_rot-np.pi*i*2/3, df.loc[:,f'edge_{i}'],
                       {'color': col_map[f'e{i+1}']}) for i in range(3)] + \
                        [(phi_rot-np.pi*i*2/3, df.loc[:,f'flap_{i}'],
                          {'color': col_map[f'f{i+1}']}) for i in range(3)]
    
        mfplot.myplot_fast2(list_to_plot, fn = fn_img, 
                            s_title = f'edge, flap {s_state}',
                            legend = ['e1', 'e2', 'e3', 'f1', 'f2', 'f3'], 
                            projection = 'polar')
        
        
    df_diff = res['test'].loc[:, ['pitch_0', 'pitch_1', 'pitch_2']] - \
                res['ok'].loc[:, ['pitch_0', 'pitch_1', 'pitch_2']]
    df_diff = df_diff.assign(epoch = res['ok'].loc[:, 'epoch'])
    
    fn_img = f'{path}\\diff.png'
    mfplot.myplot_fast(df_diff.loc[:, ['epoch'] + [f'pitch_{i}' for i in range(3)]], 
                        fn=fn_img, s_title = 'diff', legend = ['bl.1', 'bl.2', 'bl.3'])
    
    print(f"differences: {df_diff.loc[:, ['pitch_0', 'pitch_1', 'pitch_2']].mean(axis=0, skipna=True)}")

    



if False:
    
    ### 2019-7-24: Untersuchung fuer Schiffweiler, Vensys 130 (s. Email von DB vom 24.7.2019)
            
    ## 1. Daten sammeln
    where_clause=r"(Windpark_WEA#Windparkname='Schiffweiler')"
        
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)            # turbines: list of dictonaries {'farm': ..., 'turbine': ..., 'db': ..., 'tickets': ..., 'last_monitored': ...}
    turbines = tmp['turbines']    
    tickets = tmp['tickets']
    count = 0
    iN = turbines.shape[0]
    
    
    dict_bands = {'54_66Hz': [54, 66]}
    name_band = '54_66Hz'
    band = dict_bands[name_band]
    bw = band[1]-band[0]
    
        
        
    period = ('1970-7-2', '2019-8-1')      # s. Ticket 201809-002
    
    dt_now = dt.datetime.now()
    
    months = range(1, 12, 2)
    
    
    for idx, tb in turbines.iterrows():
                              
        ## TODO 2019-3-13: special treatment for 'TIANHEKOU - HuBei Suizhou', because the '-' seems to be saved as non-utf-8-character,
        ## - noch eleganter machen und "richtig" die encodings etc. verwenden!
        tb['sFarm'] = tb['sFarm'].replace('\x96', '-')        
    
        count += 1          
        turbine_info, turbine_info_fn = mfmon.get_turbine_info(tb)
        print(str(count) + '/' + str(iN) + ': ' + turbine_info)
            
        db = tb['sDB']
        ok_status, fn_status = store_cdef_data(db, path_data, table = 'status', columns = None)
    
        sql = 'select min(create_time) from ba_cycle_sig_energies;'
        start_date = mfdata.query_MySQL2(db, sql)[0][0]
    
        years = range(start_date.year, dt_now.year+1, 1)
    
        start_dates = ((m, y) for m in months for y in years)
        for (month, year) in start_dates:
            
            start_date = dt.datetime(year, month,1,0,0,0)
            #end_date = start_date + dt.timedelta(months=2)
            end_date = start_date + relativedelta(months=+2)
            period = (start_date, end_date)
            
            fn_hd5 = f'{path_data}\\{db}_se_{start_date.strftime("%Y%m")}_{end_date.strftime("%Y%m")}.hd5'    
            try:
                if not os.path.isfile(fn_hd5):
                    df_sed = weadbs.SEData.from_db(db, where={'create_time': period}, hdfpath = fn_hd5)
            except:
                print(f'   problem with se data between {start_date}, {end_date}')
                    





if False:
    
    
    band = [54, 66]
    bw = band[1]-band[0]
    
    db = 'cmrblba_bc_t_01812'
    fn_hd5 = f'{path_data}\\{db}_se.hd5'
    fn_cdef = f'{path_data}\\{db}_status.pkl'
    
    
    ## Zeiträume der Experimente, eingestellter Offset und Abweichung (s. Email von D. Pika, 17.4.2019, 15:25 Uhr)
    times_exp = {1: [(dt.datetime(2019,4,17,9,39), dt.datetime(2019,4,17,10,54)), [.32, .36, .56], [-.2, -.2, -.2]],
                 2: [(dt.datetime(2019,4,17,10,59), dt.datetime(2019,4,17,11,8)), [0, 0, .26], [0, 0, -.5]],
                 3: [(dt.datetime(2019,4,17,11,12), dt.datetime(2019,4,17,11,18)), [.2, .2, .2], [.32, -.36, -.56]],                         
                 4: [(dt.datetime(2019,4,17,11,28), dt.datetime(2019,4,17,11,34)), [.52, .56, .76], [0, 0, 0]],
                 5: [(dt.datetime(2019,4,17,11,42), dt.datetime(2019,4,17,11,49)), [.72, .76, .96], [.2, .2, .2]],
                 6: [(dt.datetime(2019,4,17,12), dt.datetime(2019,4,17,12,7)), [1.02, 1.06, 1.26], [.5, .5, .5]],
                 7: [(dt.datetime(2019,4,17,12,15), dt.datetime(2019,4,17,12,21)), [1.52, 1.56, 1.76], [1, 1, 1]],
                 8: [(dt.datetime(2019,4,17,12,25), dt.datetime(2019,4,17,12,34)), [2.02, 2.06, 2.26], [1.5, 1.5, 1.5]],
                 9: [(dt.datetime(2019,4,17,12,43), dt.datetime(2019,4,17,12,49)), [2.52, 2.56, 2.76], [2, 2, 2]],
                 10: [(dt.datetime(2019,4,17,12,25), dt.datetime(2019,4,17,13,1)), [4, 4, 4], [-3.48, -3.44, -3.24]],
                 11: [(dt.datetime(2019,4,17,13,8), dt.datetime(2019,4,17,13,14)), [-.2, .2, .2], [.72, -.36, -.56]]}
    
    ## shift time by 2 hours
    d_t = dt.timedelta(hours=2)
    times_exp = {k: [(s + d_t, e + d_t), o, d] for (k, [(s, e), o, d]) in times_exp.items()}
    
    df_times_exp = pd.DataFrame.from_dict(times_exp, orient = 'index', columns = ['period', 'offset', 'deviation'])
    df_times_exp    
    
    
    ## get the 'cells' for those times:
    ## here using of 'externals' ok, because no join between externals and se data
    dict_exp_limits = {}
    cols = ['pitch', 'power', 'temperature', 'wind']
    
    for k, [(start_time, end_time), offset, deviation] in times_exp.items():
        period = (start_time, end_time)
        df = weadbs.cdef_query(db, 
                                cycle='externals', 
                                columns=['wind', 'power', 'pitch', 'temperature'],
                                where={'create_time': period})
        
        n = df.shape[0]
        dict_tmp = {'count': n, 'period': period}
        if n==0:
            df = weadbs.cdef_query(db,
                                  cycle='status',
                                  columns=['wind_mean', 'power_mean', 'pitch_mean', 'temperature_mean'],
                                  where={'create_time': period})
            
            if n==0:
                dict_tmp.update({'table': 'keine'})
                dict_tmp.update({c: (np.NaN, np.NaN) for c in cols})
    
            else:
                dict_tmp.update({'table': 'status'})
                df_stat = df.describe()
                dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
                                            
        else:
            dict_tmp.update({'table': 'ext'})
            df_stat = df.describe()
            dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
            
        dict_exp_limits.update({k: dict_tmp})
        
    df_exp = pd.DataFrame.from_dict(dict_exp_limits, orient = 'index')
    df_exp
    
    ## Bereiche ueber alle Experimente:
    dict_mm = {}
    for c in cols:
        tmp = [x for p in df_exp.loc[:, c] for x in p]
        dict_mm.update({c: (min(tmp), max(tmp))})
    dict_mm    
        
    
    
    ## get the 'cells' for those times:
    ## here using of 'externals' ok, because no join between externals and se data
    dict_exp_limits = {}
    cols = ['pitch_mean', 'power_mean', 'temperature_mean', 'wind_mean']
    
    for k, [(start_time, end_time), offset, deviation] in times_exp.items():
        period = (start_time, end_time)
        df = weadbs.cdef_query(db,
                               cycle='status',
                               columns=['wind_mean', 'power_mean', 'pitch_mean', 'temperature_mean'],
                               where={'create_time': period})
        
        n = df.shape[0]
        dict_tmp = {'count': n, 'period': period}
        if n==0:        
            dict_tmp.update({'table': 'keine'})
            dict_tmp.update({c: (np.NaN, np.NaN) for c in cols})
                                            
        else:
            dict_tmp.update({'table': 'status'})
            df_stat = df.describe()
            dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
            
        dict_exp_limits.update({k: dict_tmp})
        
    df_exp = pd.DataFrame.from_dict(dict_exp_limits, orient = 'index')
    df_exp
    
    ## Bereiche ueber alle Experimente:
    print('status:')
    dict_mm = {}
    for c in cols:
        tmp = [x for p in df_exp.loc[:, c] for x in p]
        dict_mm.update({c: (min(tmp), max(tmp))})
    dict_mm
    
   
        
    
    
    #margin = dt.timedelta(hours = 12)    
    margin = dt.timedelta(hours = .1)
    period = (min([p[0] for p in df_times_exp.period])-margin, max([p[1] for p in df_times_exp.period])+margin)

    #dict_where = {'temperature_mean': (6.5, 10),
    #              'wind_mean': (2.5, 8)}
    #cls_sed = weadbs.SEData.from_hdf2(fn_hd5, where = dict_where)
    
    dict_where = {'create_time': period}
    cls_sed_exp = weadbs.SEData.from_hdf(fn_hd5, where = dict_where)
        
    ## filter for interesting period    
    #df_se = cls_sed[0]
    #df_cdef = cls_sed[1]
    
    #df_se_band = cls_sed.agg_freq(band).se / bw
    
        
            
    fn_test_schedule = f'{path_img}\\test_schedule_bc_t_01812.csv'
    
    #axes = dl.show_signal_energies_3(db, cls_sed, [('edge', (54, 66))], fn_test_schedule,
    #        nanwhere={'power_mean': (-1000, 0)}, nanvars=['power_mean'],
    #        offsets=None, figsize=(7, 4), **normalisation)
    axes = dl.show_signal_energies_3(db, cls_sed_exp, [('edge', (54, 66)), ('flap', (54, 66))], fn_test_schedule,
            nanwhere={'power_mean': (-1000, 0)}, nanvars=['power_mean'],
            figsize=(7, 4))    
        
    
        
    #             'create_time': (period[0], period[1], 'not')}
    dict_where = {'temperature_mean': (6.5, 10),
                  #'power_mean': (150, 820),
                  'wind_mean': (2.5, 8),
                  'create_time': [(dt.datetime(2019,2,15), period[0]), (period[1],dt.datetime.now())]}
    
    cls_sed_comp = weadbs.SEData.from_hdf(fn_hd5, where = dict_where)
    
    axes = dl.show_signal_energies_3(db, cls_sed_comp, [('edge', (54, 66)), ('flap', (54, 66))], '',
            by = 'power_mean', nanwhere={'power_mean': (-1000, 0)}, nanvars=['power_mean'],
            figsize=(7, 4))
        
    
    
    ## plot points at experiment i vs. (convolute of) points outside experiments
    cls_sed_exp.plot_se((54,66), ori='edge', by='power_mean', fmt=None, axes=axes[1])
                
    
    
    
    
if False:
             
            
    db = 'cmrblba_bc_t_01812'
    band = [54, 66]
    bw = band[1]-band[0]
    eps = 1e-10    
    
    
    ## short version of db-name
    db_short = db.replace('cmrblba_', '')
    
    ## file with test schedule
    fn_test_schedule = f'{path_img}\\test_schedule_{db_short}.csv'
    df_times_exp = dl.read_test_schedule(db_short, fn_test_schedule)
    
    ## shift time by 2 hours already done in read_test_schedule
    df_times_exp
    
    fn_hd5 = f'{path_data}\\{db}_se.hd5'
    fn_cdef = f'{path_data}\\{db}_status.pkl'
    
    ## get the 'cells' for those times:
    ## here using of 'externals' ok, because no join between externals and se data
    dict_exp_limits = {}
    cols = ['pitch', 'power', 'temperature', 'wind']
    
    for k, [start_time, end_time, os1, os2, os3] in df_times_exp.iterrows():
        period = (start_time, end_time)
        df = weadbs.cdef_query(db,
                                cycle='externals', 
                                columns=['wind', 'power', 'pitch', 'temperature'],
                                where={'create_time': period})
        
        n = df.shape[0]
        dict_tmp = {'count': n, 'period': period}
        if n==0:
            df = weadbs.cdef_query(db,
                                  cycle='status',
                                  columns=['wind_mean', 'power_mean', 'pitch_mean', 'temperature_mean'],
                                  where={'create_time': period})
            
            if n==0:
                dict_tmp.update({'table': 'keine'})
                dict_tmp.update({c: (np.NaN, np.NaN) for c in cols})
    
            else:
                dict_tmp.update({'table': 'status'})
                df_stat = df.describe()
                dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
                                            
        else:
            dict_tmp.update({'table': 'ext'})
            df_stat = df.describe()
            dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
            
        dict_exp_limits.update({k: dict_tmp})
        
    df_exp = pd.DataFrame.from_dict(dict_exp_limits, orient = 'index')
    df_exp
    
    ## Bereiche ueber alle Experimente:
    dict_mm = {}
    for c in cols:
        tmp = [x for p in df_exp.loc[:, c] for x in p]
        dict_mm.update({c: (min(tmp), max(tmp))})
    dict_mm
    
    
    ## get the 'cells' for those times:
    ## here using of 'externals' ok, because no join between externals and se data
    dict_exp_limits = {}
    cols = ['pitch', 'power', 'temperature', 'wind']
    
    for k, [start_time, end_time, os1, os2, os3] in df_times_exp.iterrows():
        period = (start_time, end_time)
        df = weadbs.cdef_query(db, 
                                cycle='externals', 
                                columns=['wind', 'power', 'pitch', 'temperature'],
                                where={'create_time': period})
        
        n = df.shape[0]
        dict_tmp = {'count': n, 'period': period}
        if n==0:
            df = weadbs.cdef_query(db,
                                  cycle='status',
                                  columns=['wind_mean', 'power_mean', 'pitch_mean', 'temperature_mean'],
                                  where={'create_time': period})
            
            if n==0:
                dict_tmp.update({'table': 'keine'})
                dict_tmp.update({c: (np.NaN, np.NaN) for c in cols})
    
            else:
                dict_tmp.update({'table': 'status'})
                df_stat = df.describe()
                dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
                                            
        else:
            dict_tmp.update({'table': 'ext'})
            df_stat = df.describe()
            dict_tmp.update({c: (df_stat.loc['min', c], df_stat.loc['max', c]) for c in cols})  # store results in dict.
            
        dict_exp_limits.update({k: dict_tmp})
        
    df_exp = pd.DataFrame.from_dict(dict_exp_limits, orient = 'index')
    df_exp
    
    ## Bereiche ueber alle Experimente:
    dict_mm = {}
    for c in cols:
        tmp = [x for p in df_exp.loc[:, c] for x in p]
        dict_mm.update({c: (min(tmp), max(tmp))})
    dict_mm
    
    
    df_exp
    
    margin = dt.timedelta(hours = .1)
    period = (df_times_exp.Start.min()-margin, df_times_exp.Ende.max()+margin)
    #print(period)
    #dict_where = {'temperature_mean': (6.5, 10),
    #              'wind_mean': (2.5, 8)}
    #cls_sed = weadbs.SEData.from_hdf2(fn_hd5, where = dict_where)
    
    #dict_where = {'create_time': period,
    #              'temperature_mean': (6.5, 10),
    #              'wind_mean': (2.5, 8)}
    dict_where = {'create_time': period}
    cls_sed_exp = weadbs.SEData.from_hdf(fn_hd5, where = dict_where)
    
    
    #normalisation = dict(normhow='div', refblades=[2, 3])
    #normalisation = None
    fn_test_schedule = f'{path_img}\\test_schedule_bc_t_01812.csv'
    
    #axes = dl.show_signal_energies_3(db, cls_sed, [('edge', (54, 66))], fn_test_schedule,
    #        nanwhere={'power_mean': (-1000, 0)}, nanvars=['power_mean'],
    #        offsets=None, figsize=(7, 4), **normalisation)
    axes = dl.show_signal_energies_3(db, cls_sed_exp, [('edge', (54, 66)), ('flap', (54, 66))], fn_test_schedule,
            nanwhere={'power_mean': (-1000, 0)}, nanvars=['power_mean'],
            figsize=(7, 4))
    
    
    ## alle Daten mit aehnlichen Betriebsdaten holen und darstellen
    ## 1. Gesamt
    dict_where = {#'temperature_mean': (6.5, 10),
                  'power_mean': (150, 10000),
                  'wind_mean': (2.5, 8),
                  'create_time': [(dt.datetime(2019,2,15), period[0]), (period[1],dt.datetime.now())]}
        
    cls_sed_comp = weadbs.SEData.from_hdf(fn_hd5, where = dict_where)
        
    axes = dl.show_signal_energies_3(db, cls_sed_comp, [('edge', (54, 66)), ('flap', (54, 66))], '',
            by = 'power_mean', nanwhere={'power_mean': (-1000, 0)}, nanvars=['power_mean'],
            figsize=(7, 4))



        
    ## first get all data 
    dict_where = {#'temperature_mean': (6.5, 15),
                    'power_mean': (150,10000),
                    'wind_mean': (2.5, 25)#,
        #'create_time': (dt.datetime(2019,2,15), dt.datetime.now())
                    }
        
    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
    df_se = cls_sed.agg_freq(band).se / bw
    df_cdef = cls_sed[1]
    btmp = (df_cdef.wind_mean > dict_where['wind_mean'][0]) & \
            (df_cdef.wind_mean < dict_where['wind_mean'][1]) & \
            (df_cdef.power_mean > dict_where['power_mean'][0]) & \
            (df_cdef.power_mean < dict_where['power_mean'][1])
    
    df_cdef = df_cdef[btmp]
    df_se = df_se[btmp]    
    
    df_se.columns = df_se.columns.levels[0]
          
    df_j = pd.merge(df_cdef, df_se, on='create_time')    #  'j' for 'joined'
        
    df_comp = df_j[(df_j.index > period[0]) & (df_j.index < period[1])]
    
        
    colors = {1: 'r', 2: 'b', 3: 'g'}
    
    # for each (sub-)experiment read data with similar production data values
    for idx, row in df_exp[df_exp.loc[:,'count']>0].iterrows():
            
        pitch = row['pitch']
        power = row['power']
        temperature = row['temperature']    
        wind = row['wind']
        count = row['count']
            
        (start_time, end_time) = row['period']
            
        df = df_j[(df_j.pitch_mean >= pitch[0]) & (df_j.pitch_mean <= pitch[1]) & \
                  (df_j.power_mean >= power[0]) & (df_j.power_mean <= power[1]) & \
                  #(df_j.temperature_mean >= temperature[0]) & (df_j.temperature_mean <= temperature[1]) & \
                (df_j.wind_mean >= wind[0]) & (df_j.wind_mean <= wind[1]) & \
                ((df_j.index < start_time) | (df_j.index > end_time))]
                       
        ## if there are such data, then filter for exeperimental data too         
        if df.shape[0]>0:
                
            # TODO 2019-7-22: noch double-check ob auch die richtigen Zeitpunkte/Zeilen ausgewaehlt werden
            df_se_exp = df_comp[(df_comp.index >= start_time) & \
                                (df_comp.index <= end_time)].sort_values(
                                by='power_mean')
                            
            # plot df_se vs. wind, power, pitch for exp. and for outside exp.s
            #print(f'exp {idx}: during exp: n_ext={count}, n_joined={df_se_exp.shape[0]}, outside exp: n_joined={df.shape[0]}')
            ## find out which blade(s) are pitched
            blades = [i for i in range(1,4) if abs(df_times_exp.loc[idx, f'Offset Bl{i}'])>eps]
    
            list_plot = []
            for bl in blades:
                col = f'e_10{bl}_edge'                
                    
                list_plot.append((df.power_mean, df.loc[:, col], 
                                    {'color': colors[bl], 'ls': 'None', 'lw': 3, 
                                    'marker': '.', 'markersize': 1}))
                list_plot.append((df_se_exp.power_mean, df_se_exp.loc[:, col], 
                                    {'color': colors[bl], 'ls': '-', 'lw': 2,
                                    'marker': '+', 'markersize': 5}))
                                
#                myplot_aeroImb(list_plot, s_title = None, legend = None, y_lim = None)       



    
    ## first get all data and join cdef and se
    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
    df_se = cls_sed.agg_freq(band).se / bw
    df_cdef = cls_sed[1]
    df_se.columns = df_se.columns.levels[0]
          
    df = pd.merge(df_cdef, df_se, on='create_time').sort_values(by='power_mean')    #  'j' for 'joined'    
    
    #df_comp = df_j[(df_j.index > period[0]) & (df_j.index < period[1])]
      
    colors = {1: 'r', 2: 'b', 3: 'g'}
    list_res = []
    
    # for each (sub-)experiment read data with similar production data values
    for idx, row in df_times_exp.iterrows():
            
        start_time, end_time = row['Start'], row['Ende']

        ## select all data within this time period
        df_exp = df[(df.index >= start_time) & (df.index <= end_time)]
        
        pitch = (df_exp.pitch_mean.min(), df_exp.pitch_mean.max())
        pitch_sig = df_exp.pitch_sigma.mean()
        power = (df_exp.power_mean.min(), df_exp.power_mean.max())
        power_sig = df_exp.power_sigma.mean()
        temperature = (df_exp.temperature_mean.min(), 
                       df_exp.temperature_mean.max())
        wind = (df_exp.wind_mean.min(), df_exp.wind_mean.max())
        wind_sig = df_exp.wind_sigma.mean()
                                
        # select all data within given "rectangular" of production data        
        df_comp = df[((df.index < start_time) | \
                     (df.index > end_time)) & \
                     (df.pitch_mean >= pitch[0] - pitch_sig) & \
                     (df.pitch_mean <= pitch[1] + pitch_sig) & \
                     (df.power_mean >= power[0] - 0*power_sig) & \
                     (df.power_mean <= power[1] + 0*power_sig) & \
                     (df.temperature_mean >= temperature[0]*.5) & \
                     (df.temperature_mean <= temperature[1]*2) & \
                     (df.wind_mean >= wind[0] - wind_sig) & \
                     (df.wind_mean <= wind[1] + wind_sig)]
#        df_comp = df[(df.index < start_time) | \
#                     (df.index > end_time) & \
#                     (df.pitch_mean >= pitch[0]*.5) & \
#                     (df.pitch_mean <= pitch[1]*1.5) & \
#                     (df.power_mean >= power[0]*.5) & \
#                     (df.power_mean <= power[1]*1.5) & \
#                     (df.temperature_mean >= temperature[0]*.5) & \
#                     (df.temperature_mean <= temperature[1]*1.5) & \
#                     (df.wind_mean >= wind[0]*.5) & \
#                     (df.wind_mean <= wind[1]*1.5)]
                           
        ## if there are such data, then filter for exeperimental data too  
        n = df_comp.shape[0]
        print(f'exp {idx}: {n} data for comparison, {df_exp.shape[0]} data for exp.')
        if n>0:
            
            # plot df_se vs. wind, power, pitch for exp. and for outside exp.s
            #print(f'exp {idx}: during exp: n_ext={count}, n_joined={df_se_exp.shape[0]}, outside exp: n_joined={df.shape[0]}')
            ## find out which blade(s) are pitched
            blades = [i for i in range(1,4) if abs(df_times_exp.loc[idx, f'Offset Bl{i}'])>eps]
    
            list_plot = []
            for bl in blades:
                col = f'e_10{bl}_edge'
                    
                list_plot.append((df_comp.power_mean, df_comp.loc[:, col],
                                    {'color': 'black', 'ls': '-', 'lw': 3,
                                    'marker': '.', 'markersize': 1}))
                list_plot.append((df_exp.power_mean, df_exp.loc[:, col],
                                    {'color': colors[bl], 'ls': '-', 'lw': 2,
                                    'marker': '+', 'markersize': 5}))
                                
                myplot_aeroImb(list_plot, s_title = None, legend = None, y_lim = None)

                tmp = df_exp.loc[:, col].median()-df_comp.loc[:, col].median()
                
                list_res.append({'exp': idx,
                                 'blade': bl,
                                 'offset': df_times_exp.loc[idx, f'Offset Bl{bl}'],
                                 'diff_se': tmp,
                                 'diff_se_rel': tmp/df_comp.loc[:, 
                                                                col].median()})

    dfRes = pd.DataFrame.from_records(list_res).sort_values(by='offset')
    
    mfplot.myplot_fast((dfRes.offset, dfRes.diff_se))
    mfplot.myplot_fast((dfRes.offset, dfRes.diff_se_rel))
    
    from sklearn import datasets, linear_model
    
    dfRes.exp = 1
    X = dfRes.loc[:, ['exp', 'offset']].values
    y = dfRes.diff_se_rel.values
    
    lr = linear_model.LinearRegression().fit(X,y)
    #lr.predict(X)
    b1 = lr.coef_[1]
    b0 = lr.intercept_
    
    
## now WK27
if False:
    
    db = 'cmrblba_bc_t_01685'
    fn_hd5 = f'{path_data}\\{db}_se.hd5'
    fn_cdef = f'{path_data}\\{db}_status.pkl'    

    band = [54, 66]
    bw = band[1]-band[0]
    eps = 1e-10    
    
    power = (300, 800)
    
    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
    df_se = cls_sed.agg_freq(band).se / bw
    df_cdef = cls_sed[1]
    df_se.columns = df_se.columns.levels[0]
    
    df_cdef = df_cdef[(df_cdef.power_mean >= power[0]) & (df_cdef.power_mean <= power[1])]
          
    df = pd.merge(df_cdef, df_se, on='create_time').sort_values(by='power_mean')    #  'j' for 'joined'    
              
    colors = {1: 'r', 2: 'b', 3: 'g'}
    list_res = []
        
    start_time = dt.datetime(2018,1,10)
    end_time = dt.datetime(2018,6,18)
    
    ## select all data within this time period
    df_exp = df[(df.index >= start_time) & (df.index <= end_time)]
                                                
    # here ranges cover all possible values, so no further filter necessary
    df_comp = df[((df.index < start_time) | (df.index > end_time))]
        
    ## if there are such data, then filter for exeperimental data too  
    n = df_comp.shape[0]
    print(f'{db}: {n} data for comparison, {df_exp.shape[0]} data for exp.')
    if n>0:
                
        # plot df_se vs. wind, power, pitch for exp. and for outside exp.s
        #print(f'exp {idx}: during exp: n_ext={count}, n_joined={df_se_exp.shape[0]}, outside exp: n_joined={df.shape[0]}')
        ## find out which blade(s) are pitched
        blades = [1]
        
        list_plot = []
        for bl in blades:
            col = f'e_10{bl}_edge'
                        
            list_plot.append((df_comp.power_mean, df_comp.loc[:, col],
                              {'color': 'black', 'ls': 'None', 'lw': 3,
                               'marker': '*', 'markersize': 10}))
            list_plot.append((df_exp.power_mean, df_exp.loc[:, col],
                              {'color': colors[bl], 'ls': '-', 'marker': '*', 
                               'markersize': 10, 'mfc': colors[bl],
                               'mec': colors[bl]}))
                                    
            myplot_aeroImb(list_plot, s_title = f'WK27 ', legend = None, y_lim = None)
    
            tmp = df_exp.loc[:, col].median()-df_comp.loc[:, col].median()
                    
            list_res.append({'blade': bl,
                             'offset': 3.75,
                             'diff_se': tmp,
                             'diff_se_rel': tmp/df_comp.loc[:, col].median()})
    
    #fRes = pd.DataFrame.from_records(list_res).sort_values(by='offset')
        
    #yplot_fast((dfRes.offset, dfRes.diff_se), s_title = f'pitch offset vs. difference signal energies, {db}, edge, experiments from 2019-4-17', 
    #           sXLabel = 'pitch offset [°]', sYLabel = 'median(SE_exp)-median(SE_comparision)')
    #yplot_fast((dfRes.offset, dfRes.diff_se_rel), s_title = f'pitch offset vs. difference signal energies, {db}, edge, experiments from 2019-4-17', 
    #           sXLabel = 'pitch offset [°]', sYLabel = 'median(SE_exp) / median(SE_comparision)-1')
        
    
   
## now WK27
if False:
    
    db = 'cmrblba_bc_t_01685'
    fn_hd5 = f'{path_data}\\{db}_se.hd5'
    fn_cdef = f'{path_data}\\{db}_status.pkl'    

    band = [54, 66]
    bw = band[1]-band[0]
    eps = 1e-10    
    
    power = (4940, np.infty)
    pitch = (15, 19)
    start_time = dt.datetime(2018,1,10)
    end_time = dt.datetime(2018,6,18)
            
    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
    df_se = cls_sed.agg_freq(band).se / bw
    df_cdef = cls_sed[1]
    df_se.columns = df_se.columns.levels[0]
    
    df_cdef = df_cdef[(df_cdef.power_mean >= power[0]) & \
                      (df_cdef.power_mean <= power[1]) & \
                      (df_cdef.pitch_mean >= pitch[0]) & \
                      (df_cdef.pitch_mean <= pitch[1]) & \
                      (df_cdef.index >= start_time) & \
                      (df_cdef.index <= end_time)]
          
    df = pd.merge(df_cdef, df_se, on='create_time').sort_values(by='power_mean')    #  'j' for 'joined'    

    n = df.shape[0]
    if n>0:

        power = df.power_mean        
                  
        colors = {'e_101_edge': 'r', 'e_102_edge': 'b', 'e_103_edge': 'g'}
            
        ## select all data within this time period
        col_exp = ['e_101_edge']        
        col_comp = ['e_102_edge', 'e_103_edge']
                        
        # plot df_se vs. wind, power, pitch for exp. and for outside exp.s            
        list_plot = [(power, df.loc[:, col_exp], {'color': colors[col_exp[0]], 
                      'ls': 'None', 'lw': 3, 'marker': '*', 'markersize': 10})]
        
        for col in col_comp:
                        
            list_plot.append((power, df.loc[:, col],
                          {'color': colors[col], 'ls': '-', 'marker': '*', 
                           'markersize': 10, 'mfc': colors[col],
                           'mec': colors[col]}))
                                
        myplot_aeroImb(list_plot, s_title = f'WK27 ', legend = None, y_lim = None)

        #tmp = df.loc[:, col].median()-df.loc[:, col].median()
        denom = df.loc[:, col_comp].median().median()
        tmp = df.loc[:, col_exp].me
        
        print(f'blade: 1\n offset: 3.75\n diff_se: {tmp}\n diff_se_rel: {tmp/denom}')
    
    #fRes = pd.DataFrame.from_records(list_res).sort_values(by='offset')
        
    #yplot_fast((dfRes.offset, dfRes.diff_se), s_title = f'pitch offset vs. difference signal energies, {db}, edge, experiments from 2019-4-17', 
    #           sXLabel = 'pitch offset [°]', sYLabel = 'median(SE_exp)-median(SE_comparision)')
    #yplot_fast((dfRes.offset, dfRes.diff_se_rel), s_title = f'pitch offset vs. difference signal energies, {db}, edge, experiments from 2019-4-17', 
    #           sXLabel = 'pitch offset [°]', sYLabel = 'median(SE_exp) / median(SE_comparision)-1')
        
    

if False:
    #collect_hd5_data(path_data, 'Wikinger', period = (dt.datetime(2019,5,1),None))
    # 2019-8-19: erstmal die letzten Monate sammeln, um mit Regression beginnen zu koennen, restliche Daten spaeter nachholen
    #collect_hd5_data(path_data, 'Wikinger', (dt.datetime(2019,1,1), None))
    #collect_hd5_data_old(path_data, 'Wikinger', (dt.datetime(2019,1,1), None))
    collect_hd5_data_farm(path_data_multiple, 'Wikinger', (dt.datetime(2019,1,1), None))





## 2019-8-16: check, ob korrekt, dass nur 400 Datensaetze fuer die eine wtg
# load data

# shape
    
# filter
    
# shape
    
# ggf. stichprobenartige Pruefung
    



## 2019-8-19: build models for all turbines and blades
if False:
    
    band = [54, 66]
    bw = band[1]-band[0]
    eps = 1e-10    

    #import aerodynamic_imbalance
    where_clause = r"(Windpark_WEA#Windparkname='Wikinger') and not ((Datenbankname is NULL) or (Datenbankname = '') or (Beginn_Datenspeicherung is NULL) or (Beginn_Datenspeicherung = ''))"
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']
    tickets = tmp['tickets']

    ## build model(s)
    
#    import regression
    colors = {1: 'r', 2: 'b', 3: 'g'}
    power = (300, 800)
    temperature = (5,10)
    wind = (3,7)
    #pitch = ()
    
#    colors2 = provide_colors()
    
    dict_style = {'ls': 'None', 'lw': 3, 'marker': '*', 'markersize': 10}
    
    
    #cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 'wind_mean']
    cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma', 'cyc_status_eval']
    cols_regress = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma']
    
    cols_edge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
    all_files = os.listdir(path_data)
    
    result = []
    i=0
    y = []
    X = []
    for idx, tb in turbines.iterrows():
    #for idx, tb in turbines[turbines.sDB == 'cmrblba_bc_t_01927'].iterrows():
    
        try:
            
            # consider only channels that are ok
            db = tb.sDB
            channels = set(cols_edge) & set(mfmon.get_valid_channels(tickets[db]))
        
            # if there are channels without problems ...
            if len(channels)>0:
        
                ## get sensitivities and calculate correction factors
                ##  correction factor such that SE_true = SE_stored_in_database ./ [dFacEdge, dFacFlap] 
                sens_edge = [tb.sens_e1, tb.sens_e2, tb.sens_e3]
                sens_mean = np.mean(sens_edge)
                dict_fac_edge = {'e_101_edge': sens_edge[0]/sens_mean,
                                 'e_102_edge': sens_edge[1]/sens_mean,
                                 'e_103_edge': sens_edge[2]/sens_mean}
                            
                list_y = []
                list_X = []
            
                df = load_data_multiple_hd5files(path_data_multiple, db, 
                                                 channels, power, band)
                ## do model for each channel seperately
                for bl in channels:
                    y = df.loc[:, bl].values * dict_fac_edge[bl]
                    y = y.reshape(-1,1)
                    X = df.loc[:, cols_regress].values
                                  
                                        
                    X2 = sm.add_constant(X)
                    est = sm.OLS(y, X2)
                    est2 = est.fit()
                    print(est2.summary())                                                                                        
                    
                    
                    ## 'normal' regression (variables not scaled)
                    lr = linear_model.LinearRegression().fit(X, y[:,0])
                    #lr.coef_                    
                    dict_coeffs = {cols_regress[i]: lr.coef_[i] for i in range(len(cols_regress))}
                    #lr.intercept_
                    #r2 = lr.score(X, y)
                    #result.update({(db, bl): [lr.intercept_, lr.coef_, r2]})
                    dict_coeffs.update({'db': db, 'blade': bl, 'n': len(y),
                                        'reg_type': 'orig',
                                        'min_se': min(y), 
                                        'max_se': max(y),
                                        'b0': lr.intercept_,
                                        'r2': lr.score(X,y)})
                    result.append(dict_coeffs)

                    ## append to list of regression data
                    #list_y.append(y)
                    #list_X.append(X)


                   
                    ## regression with scaled variables
                    scaler = StandardScaler()
                    X_sc = scaler.fit_transform(X)
                    y_sc = scaler.fit_transform(y)

                    X2 = sm.add_constant(X_sc)
                    est = sm.OLS(y_sc, X2)
                    est2 = est.fit()
                    print(est2.summary())                                                                                        



                    
                    lr = linear_model.LinearRegression().fit(X_sc, y_sc[:,0])
                    #lr.coef_                    
                    dict_coeffs = {cols_regress[i]: lr.coef_[i] for i in range(len(cols_regress))}
                    #lr.intercept_
                    #r2 = lr.score(X, y)
                    #result.update({(db, bl): [lr.intercept_, lr.coef_, r2]})
                    dict_coeffs.update({'db': db, 'blade': bl, 'n': len(y),
                                        'reg_type': 'scaled', 
                                        'min_se': min(y_sc)[0], 
                                        'max_se': max(y_sc)[0],
                                        'b0': lr.intercept_,
                                        'r2': lr.score(X_sc,y_sc)})
                    result.append(dict_coeffs)

                    ## append to list of regression data
                    #list_y.append(y)
                    #list_X.append(X)
                    
#                y_tb = np.hstack(list_y).reshape(-1,1)
#                X_tb = np.vstack(list_X)
                    
                    #btmp = (X_tb[:, 8]<= 14800)
                    #myplot_fast((X_tb[:,0], y_tb), dict_style = dict_style)                
                    #myplot_fast((X_tb[btmp,0], y_tb[btmp]), dict_style = dict_style)
                    
                #print(cols_cdef)
                #lr = linear_model.LinearRegression().fit(X_tb, y_tb)
                #lr.coef_
                #lr.intercept_
                #lr.score(X_tb, y_tb)
                #result.update({(db, channel): [lr.intercept_, lr.coef_]})
                    del X
                    del y
                    del X_sc
                    del y_sc
                    
                    gc.collect()
                    
                    
                del df
                gc.collect()
        
        
        
        except:
            print(f'{db}: problems')
            
            
    df = pd.DataFrame.from_records(result, index = range(len(result)))        
    fn = f'{path_work}\\results_regression_{dt.datetime.now().strftime("%Y%m%d%H%M%S")}.csv'    
    df.to_csv(fn, 
              sep=';', 
              index=False, 
              columns = ['db', 'blade', 'n', 'reg_type', 'min_se', 'max_se', 
                         'r2', 'b0'] + cols_regress,
              encoding='cp1252')



#               
#        
#X0 = append_ones(X)
#            
#coeffs = regression.glmf(glmsed.se, glmsed.st, 'se', 'se ~ pitch_mean + power_mean').unstack('channel')
#coeffs.columns = coeffs.columns.reorder_levels(['channel', 'measure', 'variable'])
#coeffs.sort_index(axis=1, inplace=True)
#                              
## save coefficients and R2
#lres.append((db, bl, coeffs, r2))
#        
#df_res = pd.DataFrame.from_records(lres, columns = ['database', 'blade', 'omega', 'wind', 'P', 'T'])
#df_res.to_csv(fn, sep=';')
#df_res

   
    

## 2019-8-17: Model vs. imbalance fuer Tests an WK09:
if False:
            
    db = 'cmrblba_bc_t_01812'
    band = [54, 66]
    bw = band[1]-band[0]
    eps = 1e-10    
            
    colors = {1: 'r', 2: 'b', 3: 'g'}
    power = (300, 800)
    temperature = (5,10)
    wind = (3,7)


    dict_style = {'ls': 'None', 'lw': 3, 'marker': '*', 'markersize': 10}

    cols_edge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
    
    cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma', 'cyc_status_eval']
    cols_regress = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma']

    
    ## short version of db-name
    db_short = db.replace('cmrblba_', '')
    
    ## file with test schedule
    fn_test_schedule = f'{path_img}\\test_schedule_{db_short}.csv'
    df_times_exp = dl.read_test_schedule(db_short, fn_test_schedule)
    
   
    fn_hd5 = f'{path_data}\\{db}_se.hd5'
    #fn_cdef = f'{path_data}\\{db}_status.pkl'
     

    #import aerodynamic_imbalance
    where_clause = f"(Datenbankname='{db}')"
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']
    tickets = tmp['tickets']

    tb = turbines.iloc[0:1,:]
    
    
    ## consider only channels without tickets    
    # TOdO 2019-8-17: von Hand festlegen fuer den Zeitraum der Exp.e bzw. davor (sinnvoll waehlen
    # bzw. Zeitraum ausserhalb Exp. sinnvoll so waehlen, dass moeglichst viele Daten)
    channels_exp = {'e_101_edge', 'e_103_edge'}    # channels on that the experiments were conducted
    channels = list(set(cols_edge) & set(mfmon.get_valid_channels(tickets[db])) & \
                channels_exp)

    # ignore tickets
    channels = channels_exp
    # if there are channels without problems ...
    #if len(channels)>0:

    ## get sensitivities and calculate correction factors
    ##  correction factor such that SE_true = SE_stored_in_database ./ [dFacEdge, dFacFlap] 
    sens_edge = [tb.sens_e1, tb.sens_e2, tb.sens_e3]
    sens_mean = np.mean(sens_edge)
    dict_fac_edge = {'e_101_edge': sens_edge[0]/sens_mean,
                     'e_102_edge': sens_edge[1]/sens_mean,
                     'e_103_edge': sens_edge[2]/sens_mean}

   

    ## build model(s)    
    
    
  
    #margin = dt.timedelta(hours = 12)    
    margin = dt.timedelta(hours = .1)
    #period = (min([p[0] for p in df_times_exp.period])-margin, max([p[1] for p in df_times_exp.period])+margin)
    #period = (min([p[0] for p in df_times_exp.Start])-margin, max([p[1] for p in df_times_exp.End])+margin)
    period = (df_times_exp.Start.min() - margin, df_times_exp.Ende.max() + margin)


    ## prepare data for evaluation
    cls_sed = weadbs.SEData.from_hdf(fn_hd5)

    df_se = cls_sed.agg_freq(band).se.dropna() / bw
    df_se.columns = df_se.columns.levels[0]

    df_cdef = cls_sed[1].loc[:, cols_cdef].dropna()
    df_cdef = df_cdef[(df_cdef.power_mean >= power[0]) 
                    & (df_cdef.power_mean <= power[1]) 
                    & (df_cdef.cyc_status_eval <= 14500)]
        
    # append to list of df for each file
    df = pd.merge(df_cdef.loc[:, cols_regress], df_se.loc[:, channels], 
                  on='create_time')    #  'j' for 'joined'


    ## build models for all channels
    dict_models = {}
    
    df_comp = df[(df.index < period[0]) | (df.index > period[1])]
    
    for bl in channels:        
            
        fac = dict_fac_edge[bl][0]
        
        y = df_comp.loc[:, bl].values * fac
        X = df_comp.loc[:, cols_regress].values
                            
        ## 'normal' regression (variables not scaled)
        lr = linear_model.LinearRegression().fit(X, y)
        #dict_coeffs = {cols_regress[i]: lr.coef_[i] for i in range(len(cols_regress))}
        #dict_coeffs.update({'db': db, 'blade': bl, 'n': len(y),
        #                    'min_se': min(y), 'max_se': max(y),
        #                    'b0': lr.intercept_,
        #                    'r2': lr.score(X,y)})
        #result.append(dict_coeffs)
        
        #y = df_exp.loc[:, bl].values * fac
        #X = df_exp.loc[:, cols_regress].values
        
        ## predict values and compare with model, vs. pitch-offset
        dist = y - lr.predict(X)
        
        dict_models.update({bl: {'model': lr,
                                 'r2': lr.score(X, y),
                                 'min_dist': min(dist),
                                 'q05': np.percentile(dist, 5),
                                 'median_dist': np.median(dist),
                                 'q95': np.percentile(dist, 95),
                                 'max_dist': max(dist)}})
        del dist
        del X
        del y
        gc.collect()
        
        
    ## prepare data from experiment for comparing with model
    ## do model and compare with experiments for each channel seperately
    lindex = []
    dict_result = []
    for idx, row in df_times_exp.iterrows():
            
        df_exp = df[(df.index >= row['Start']) & (df.index <= row['Ende'])]

        for i in range(1,4):
            
            if (row[f'Offset Bl{i}'] != 0):
            
                bl = f'e_10{i}_edge'
            
                dm = dict_models[bl]
                lr = dm['model']
            
                fac = dict_fac_edge[bl][0]
                        
                y = df_exp.loc[:, bl].values * fac
                X = df_exp.loc[:, cols_regress].values
                                
                ## 'normal' regression (variables not scaled)            
                ## predict values and compare with model, vs. pitch-offset
                if len(y)>0:
                    dist = y - lr.predict(X)
                                
                    
#HIER WEITER 2019-8-19:
#    - geeignet darstellen
#    - bessere Metriken finden und auch darstellen
#    - Modell verbessern (r2=0.6 z.Zt.)                    
    
                    
                    dict_result.append({'idx': idx,
                                        'offset': row[f'Offset Bl{i}'],
                                        'blade': bl,
                                        'n': len(y),
                                        'distance_from_model__min': min(dist),
                                        'distance_from_model__q05': np.percentile(dist, 5),                                                                
                                        'distance_from_model__median': np.median(dist),
                                        'distance_from_model__q95': np.percentile(dist, 95),
                                        'distance_from_model__max': max(dist),
                                        'model_dist__min': dm['min_dist'],
                                        'model_dist__q05': dm['q05'],
                                        'model_dist__median': dm['median_dist'],
                                        'model_dist__q95': dm['q95'],
                                        'model_dist__max': dm['max_dist'],
                                        'model_r2': dm['r2']})
                
        
    df_res = pd.DataFrame.from_records(dict_result)
    fn = f'{path_work}\\results_regression_experiments_{dt.datetime.now().strftime("%Y%m%d%H%M%S")}.csv'    
    df_res.to_csv(fn, 
              sep=';', 
              index=False, 
              columns = ['offset', 'blade', 'n', 'distance_from_model__min', 
                         'distance_from_model__q05', 
                         'distance_from_model__median', 
                         'distance_from_model__q95',
                         'distance_from_model__max',
                         'model_dist__min',
                         'model_dist__q05',
                         'model_dist__median',
                         'model_dist__q95',
                         'model_dist__max',
                         'model_r2'],                   
              encoding='cp1252')

    
    
    
    
    
    
# 2019-8-20: pruefen, woran das liegt, dass die SE-Werte so stark streuen bzw.
# test, ob die Korrektur des Faktors 5 tatsaechlich die Streuung verringert
if False:
            
    band = [54, 66]
    bw = band[1]-band[0]
    eps = 1e-10    

    #db = 'cmrblba_bc_t_01582'
    db = 'cmrblba_bc_t_01529'
    cols_cdef = ['power_mean', 'cyc_status_eval']
    power = (300, 800)
    
    where_clause = r"(Windpark_WEA#Windparkname='Wikinger') and not ((Datenbankname is NULL) or (Datenbankname = '') or (Beginn_Datenspeicherung is NULL) or (Beginn_Datenspeicherung = ''))"
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']
    tickets = tmp['tickets']

    cols_edge = ['e_101_edge', 'e_102_edge', 'e_103_edge']

    all_files = os.listdir(path_data)
    tb = turbines[turbines.sDB == db].iloc[0,:]
    channels = set(cols_edge) & set(mfmon.get_valid_channels(tickets[db]))
    sens_edge = [tb.sens_e1, tb.sens_e2, tb.sens_e3]
    sens_mean = np.mean(sens_edge)
    dict_fac_edge = {'e_101_edge': sens_edge[0]/sens_mean,
                     'e_102_edge': sens_edge[1]/sens_mean,
                     'e_103_edge': sens_edge[2]/sens_mean}
        
    dict_style = {'ls': 'None', 'lw': 3, 'marker': '*', 'markersize': 10}
    map_cols = {'e_101_edge': 'red', 'e_102_edge': 'blue', 'e_103_edge': 'green'}
    
    list_y = []
    list_X = []
    
    #pat = re.compile(f'{db}_se_*.hd5')
    #files_se = [s for s in all_files if not(pat.match(s) is None)]
    #spat = f'(({db}_se\.hd5)$|({db}_se.+\.hd5)$)'
    spat = f'({db}_se.+\.hd5)$'
    files_se = [s for s in all_files if re.search(spat, s)]
    
    list_df = []
    for fn in files_se:
        fn_hd5 = f'{path_data}\\{fn}'
    
        cls_sed = weadbs.SEData.from_hdf(fn_hd5)
        df_se = cls_sed.agg_freq(band).se.dropna() / bw
    
        df_cdef = cls_sed[1].loc[:, cols_cdef].dropna()
        df_se.columns = df_se.columns.levels[0]
    
        df_cdef = df_cdef[(df_cdef.power_mean >= power[0]) & (df_cdef.power_mean <= power[1])]
    
        list_df.append(pd.merge(df_cdef.loc[:, cols_cdef], df_se.loc[:, channels], 
                          on='create_time'))
    
        
    df = pd.concat(list_df, ignore_index=False)
    
    # get date of changing measuring program to version with correct factor for calculation of signal energy
#    time_changed = get_datetime_factor_change(db)
    
    # correct wrongly calculated signal energy values
#HIER WEITER 2019-8-20, klappt noch nicht richtig

        
    ## plot fuer alle cyc_status_eval-Werte
    list_plot = []
    for bl in channels:
        y_tb = df.loc[:, bl].values * dict_fac_edge[bl]
        X_tb = df.power_mean
    
    #    y_tb = np.hstack(list_y).reshape(-1,1)
    #    X_tb = np.vstack(list_X)
        list_plot.append((X_tb, y_tb, {'color': map_cols[bl], 'ls': 'None', 'marker': '*', 'markersize': 8}))
        
    mfplot.myplot_fast2(list_plot)


    df = adjust_se(db, df, channels, 5)
#    if time_changed is None:
#        df.loc[:, channels] = df.loc[:, channels] / 5
#    
#    else:
#        btmp = (df.index < time_changed)        
#        df.loc[btmp, channels] = df.loc[btmp, channels] / 5
    
        
        
    ## plot fuer alle cyc_status_eval-Werte
    list_plot = []
    for bl in channels:
        y_tb = df.loc[:, bl].values * dict_fac_edge[bl]
        X_tb = df.power_mean
    
    #    y_tb = np.hstack(list_y).reshape(-1,1)
    #    X_tb = np.vstack(list_X)
        list_plot.append((X_tb, y_tb, {'color': map_cols[bl], 'ls': 'None', 'marker': '*', 'markersize': 8}))
        
    mfplot.myplot_fast2(list_plot)


    ## plot fuer alle cyc_status_eval-Werte    
    list_plot = []
    df = df[df.cyc_status_eval <= 14800]
    
    for bl in channels:
        y_tb = df.loc[:, bl].values * dict_fac_edge[bl]
        X_tb = df.power_mean
    
        #y_tb = np.hstack(list_y).reshape(-1,1)
        #X_tb = np.vstack(list_X)
        list_plot.append((X_tb, y_tb, {'color': map_cols[bl], 'ls': 'None', 'marker': '*', 'markersize': 8}))
                        
    mfplot.myplot_fast2(list_plot)
    
    



# 2019-8-22: lin. regression fuer alle WK-Anlagen, Boxplots fuer die Koeffizienten
if False:
    
    
    #import aerodynamic_imbalance
    where_clause = r"(Windpark_WEA#Windparkname='Wikinger') and not ((Datenbankname is NULL) or (Datenbankname = '') or (Beginn_Datenspeicherung is NULL) or (Beginn_Datenspeicherung = ''))"
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']
    tickets = tmp['tickets']
    
    ## build model(s)
    
    #    import regression
    colors = {1: 'r', 2: 'b', 3: 'g'}
    power = (300, 800)
    #temperature = (5,10)
    #wind = (3,7)
    #pitch = ()
    
    #    colors2 = provide_colors()
    
    dict_style = {'ls': 'None', 'lw': 3, 'marker': '*', 'markersize': 10}
    
    cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma', 'cyc_status_eval']
    
    #cols_regress = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
    #             'wind_mean', 'omega_sigma', 'power_sigma', 
    #             'pitch_sigma']
    cols_regress = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                     'wind_mean', 'pitch_sigma']
    
    
    cols_edge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
    all_files = os.listdir(path_data)
    
    list_problem_db = []
    result = []
    i=0
    list_idx = []
    list_X = []
    list_y = []
    for idx, tb in turbines.iterrows():
    
        try:
    
            # consider only channels that are ok
            db = tb.sDB
            print(db)
            
            channels = set(cols_edge) & set(mfmon.get_valid_channels(tickets[db], type_fails = 'all_rbl_related'))
            
            # if there are channels without problems ...
            if len(channels)>0:
                #print(f'    {len(channels)} channels')
                ## get sensitivities and calculate correction factors
                ##  correction factor such that SE_true = SE_stored_in_database ./ [dFacEdge, dFacFlap] 
                sens_edge = [tb.sens_e1, tb.sens_e2, tb.sens_e3]
                sens_mean = np.mean(sens_edge)
                dict_fac_edge = {'e_101_edge': sens_edge[0]/sens_mean,
                                 'e_102_edge': sens_edge[1]/sens_mean,
                                 'e_103_edge': sens_edge[2]/sens_mean}
    
                df = load_data_multiple_hd5files(path_data_multiple, db, 
                                                 channels, power, band)
    
                ## do model for each channel seperately
                for bl in channels:
                    y = df.loc[:, bl].values * dict_fac_edge[bl]
                    y = y.reshape(-1,1)
                    X = df.loc[:, cols_regress].values
    
                    ## add the data to the list of all data
                    list_X.append(X)
                    list_y.append(y)
                    list_idx.append(np.tile(idx, (len(y), 1)))
                    
    
                    if False:
                        X2 = sm.add_constant(X)
                        est = sm.OLS(y, X2)
                        est2 = est.fit()
                        print(est2.summary())                                                                                        
    
    
                        ## 'normal' regression (variables not scaled)
                        lr = linear_model.LinearRegression().fit(X, y[:,0])
                        dict_coeffs = {cols_regress[i]: lr.coef_[i] for i in range(len(cols_regress))}
                        dict_coeffs.update({'db': db, 'blade': bl, 'n': len(y),
                                            'reg_type': 'orig',
                                            'min_se': min(y), 
                                            'max_se': max(y),
                                            'b0': lr.intercept_,
                                            'r2': lr.score(X,y)})
                        result.append(dict_coeffs)
    
                    ## regression with scaled variables
                    scaler = StandardScaler()
                    X_sc = scaler.fit_transform(X)
                    y_sc = scaler.fit_transform(y)
    
                    X2 = sm.add_constant(X_sc)
                    est = sm.OLS(y_sc, X2)
                    est2 = est.fit()
                    #print(est2.summary())                                                                                        
    
                    #lr = linear_model.LinearRegression().fit(X_sc, y_sc[:,0])
                    dict_coeffs = {cols_regress[i]: est2.params[i+1] for i in range(len(cols_regress))}
                    dict_coeffs.update({'db': db, 'blade': bl, 'n': len(y),
                                        'reg_type': 'scaled', 
                                        'min_se': min(y_sc)[0], 
                                        'max_se': max(y_sc)[0],
                                        'b0': est2.params[0],
                                        'r2': est2.rsquared})
                    result.append(dict_coeffs)
    
                    del X
                    del y
                    del X_sc
                    del y_sc
    
                    gc.collect()
    
    
                del df
                gc.collect()
    
            else:
                print('    keine channels')
        except:
            #print(f'{db}: problems')
            list_problem_db.append(db)
    
    
    df = pd.DataFrame.from_records(result, index = range(len(result)))        
    #fn = f'{path_work}\\results_regression_{dt.datetime.now().strftime("%Y%m%d%H%M%S")}.csv'    
    #df.to_csv(fn, 
    #          sep=';', 
    #          index=False, 
    #          columns = ['db', 'blade', 'n', 'reg_type', 'min_se', 'max_se', 
    #                     'r2', 'b0'] + cols_regress,
    #          encoding='cp1252')
    df.describe()
    
    # create boxplots for the coefficients
    df.boxplot(column= ['b0', 'omega_mean', 'power_mean', 'temperature_mean', 'wind_mean', 'pitch_mean', 'pitch_sigma'])
    df2 = df[df.r2 >= 0.66]
    df2.describe()
    df2.boxplot(column= ['b0', 'omega_mean', 'power_mean', 'temperature_mean', 'wind_mean', 'pitch_mean', 'pitch_sigma'])



    ## lin. reg for all data
    X = pd.concat(list_X)
    y = pd.concat(list_y)
    idx = pd.concat(list_idx)

    ## combine X and idx and transform idx to dummy variable
#HIER WEITER 2019-8-22
    ## add constant

    ## optimize set of indipendent variables

    ## regress     

                    
    ## regression with scaled variables
    scaler = StandardScaler()
    X_sc = scaler.fit_transform(X)
    y_sc = scaler.fit_transform(y)

    X2 = sm.add_constant(X_sc)
    est = sm.OLS(y_sc, X2)
    est2 = est.fit()
    #print(est2.summary())                                                                                        

    #lr = linear_model.LinearRegression().fit(X_sc, y_sc[:,0])
    dict_coeffs = {cols_regress[i]: est2.params[i+1] for i in range(len(cols_regress))}
    dict_coeffs.update({'db': db, 'blade': bl, 'n': len(y),
                        'reg_type': 'scaled', 
                        'min_se': min(y_sc)[0], 
                        'max_se': max(y_sc)[0],
                        'b0': est2.params[0],
                        'r2': est2.rsquared})
    result.append(dict_coeffs)
    
 
    






#HIER WEITER 2019-8-21: JETZT KOMBINATION ALLER DATEN -> HERAUSFINDEN DES OPTIMALEN SUBSET -> REGRESSION -> VGL. MIT ABWEICHUNGEN BEI PITCHOFFSET
    
    
    
    
# 2019-8-22: Test, ob die neue Variante zur Ticketbestimmung dasselbe Ergebnis liefert wie die alte 
# 2019-8-22: ja, kam dasselbe heraus -> umbenannt: alte nach get_relevant_tickets_old, neue nach get_relevant_tickets
if False:
    
    from monitor import get_relevant_tickets, get_relevant_tickets_new
    
    #db = 'cmrblba_mb_bw_052'
    db = None
    if not(db is None):
        where_clause = f"Datenbankname='{db}'"
        tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt = where_clause)            # turbines: list of dictonaries {'farm': ..., 'turbine': ..., 'db': ..., 'tickets': ..., 'last_monitored': ...}
    else:
        tmp = mfmon.get_turbines_and_tickets_for_monitoring()            # turbines: list of dictonaries {'farm': ..., 'turbine': ..., 'db': ..., 'tickets': ..., 'last_monitored': ...}
        
    turbines = tmp['turbines']    
    tickets = tmp['tickets']
    #tickets = {db: tickets[db]}
    
    list_types = ['meas_lines', 'defekt_oder_TPV', 'all_rbl_related', 'data_fix', 'low_pass']
    lproblems = []
    cnt = len(tickets)
    i=1
    
    for k, v in tickets.items():
        print(f'{i}/{cnt}')
        i += 1
        
        for stype in list_types:
            
            try:
                df_old, dict_old = get_relevant_tickets(v, stype)
                df_new, dict_new = get_relevant_tickets_new(v, stype)
                
                if not(df_old.equals(df_new)):
                    lproblems.append((k, stype))
                
                else:
                    if not((dict_old is None) or (dict_new is None)):  # both are not None
                        if dict_old.keys()==dict_new.keys():
                            for k1, v1 in dict_old.items():
                                if v1[0]==dict_new[k1][0]:
                                    if not(v1[1].equals(dict_new[k1][1])):
                                        lproblems.append((k, stype))
        
                                else:
                                    lproblems.append((k, stype))
                                                                            
                        else:
                            lproblems.append((k, stype))
                    
                    else:
                        if not((dict_old is None) and (dict_new is None)):  # not both are none
                            lproblems.append((k, stype, 'unequal'))
            except:
                lproblems.append((k, stype, 'error'))                                            
                    
    print(len(lproblems))
    
    
    
    
# Test 2019-8-22
if False:
    
    
    db = 'cmrblba_bc_t_01646'
    where_clause = f"Datenbankname='{db}'"
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt = where_clause)            # turbines: list of dictonaries {'farm': ..., 'turbine': ..., 'db': ..., 'tickets': ..., 'last_monitored': ...}
        
    turbines = tmp['turbines']    
    tickets = tmp['tickets']
    #tickets = {db: tickets[db]}
    vc = mfmon.get_valid_channels(tickets[db], type_fails = 'all_rbl_related')
#        print(f'{db}: ')
    
    print(vc)

    
    
    
    
    
    
# 2019-8-23: kombination der Daten und pickle
# 2019-8-28: Erweiterung 2019-8-28: aggregation ueber ... min, da ansonsten zuviele
# Daten
if False:
            
    #import aerodynamic_imbalance
    where_clause = r"(Windpark_WEA#Windparkname='Wikinger') and not ((Datenbankname is NULL) or (Datenbankname = '') or (Beginn_Datenspeicherung is NULL) or (Beginn_Datenspeicherung = ''))"
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']
    tickets = tmp['tickets']
    
    del tmp
    gc.collect()
    
    ## build model(s)
    
    #    import regression
    colors = {1: 'r', 2: 'b', 3: 'g'}
    power = (300, 800)
    #temperature = (5,10)
    #wind = (3,7)
    #pitch = ()
    
    #    colors2 = provide_colors()    
    dict_style = {'ls': 'None', 'lw': 3, 'marker': '*', 'markersize': 10}
    
    cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma', 'cyc_status_eval']
    
    #cols_regress = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
    #             'wind_mean', 'omega_sigma', 'power_sigma', 
    #             'pitch_sigma']
    cols_regress = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                     'wind_mean', 'pitch_sigma']
    
    
    cols_edge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
    all_files = os.listdir(path_data)
        
    list_problem_db = []
    result = []
    i=0
    list_idx = []
    list_X = []
    list_y = []
    list_idx = []
    for idx, tb in turbines.iterrows():

        try:
    
            # consider only channels that are ok
            db = tb.sDB
            print(db)
            
            channels = set(cols_edge) & set(mfmon.get_valid_channels(tickets[db], type_fails = 'all_rbl_related'))
            
            # if there are channels without problems ...
            if len(channels)>0:
                #print(f'    {len(channels)} channels')
                ## get sensitivities and calculate correction factors
                ##  correction factor such that SE_true = SE_stored_in_database ./ [dFacEdge, dFacFlap] 
                sens_edge = [tb.sens_e1, tb.sens_e2, tb.sens_e3]
                sens_mean = np.mean(sens_edge)
                dict_fac_edge = {'e_101_edge': sens_edge[0]/sens_mean,
                                 'e_102_edge': sens_edge[1]/sens_mean,
                                 'e_103_edge': sens_edge[2]/sens_mean}
    
                df = load_data_multiple_hd5files(path_data_multiple, db, 
                                                 channels, power, band)
    
                ## do model for each channel seperately
                for bl in channels:
                    y = df.loc[:, bl].values * dict_fac_edge[bl]
                    y = y.reshape(-1,1)
                    X = df.loc[:, cols_regress].values
    
                    ## add the data to the list of all data
                    list_X.append(X)
                    list_y.append(y)
                    list_idx.append(np.tile((db,bl), (len(y), 1)))
    
        except Exception as ex:
            print(str(ex))
                
    
    ## lin. reg for all data
    tmp = np.hstack([np.vstack(list_X),
                     np.vstack(list_y)])
    
    #del list_X, list_y, tickets, turbines
    #gc.collect()
    
    df = pd.DataFrame(tmp, columns = cols_regress + ['se'])
    for col in cols_regress + ['se']:
        df[col] = df[col].astype(float)
        
    #df.index = np.vstack(list_idx)
    df.reset_index(inplace=True, drop=True)
    #df.drop(columns='index', inplace=True)
    
#    df.reset_index(inplace=True, drop=True)
    df = df.assign(wtg_blade = [(x[0], x[1]) for x in np.vstack(list_idx)],
                                index=df.index)

    #del tmp
    #gc.collect()
    
    # pickle the result
    fn = f'{path_work}\\combined_data.pkl'
    df.to_pickle(fn)
    
    

    
    
    
# 2019-8-28: use the pickled data for linear regression
if False:
    
    colors = mfplot.provideColors()

    
    fn = f'{path_work}\\combined_data.pkl'
    df = pd.read_pickle(fn)
    df = df.head(100000)
    # clean data:
    # - remove (wtg, blade) with n<=100 observations   
    df_stat = df.loc[:, ['wtg_blade', 'se']].groupby(by='wtg_blade').count()
    idx_ok = df_stat[df_stat.se > 100].index    
    df = df[df.loc[:, 'wtg_blade'].isin(idx_ok)]

    idx_removed = set(df.wtg_blade) - set(idx_ok)
    [print(f'removed: {i}' for i in idx_removed)]

    # rename columns
    df.rename(columns={'omega_mean': 'omega', 
                       'wind_mean': 'v_wind', 
                       'pitch_mean': 'pitch', 
                       'temperature_mean': 'T',
                       'power_mean': 'P'}, inplace=True)
        
    # list of regressions to be done
    list_regressions = [['P', 'T'],
                        ['P', 'v_wind', 'T'],
                        ['omega', 'pitch', 'T'],
                        ['P', 'pitch', 'T'],
                        ['v_wind', 'pitch', 'T']]
        
    col_y = ['se']


    # remove rows with na for any of the regressors or se
    all_regressors = list(np.unique([s for sublist in list_regressions for 
                                     s in sublist]))
    df.dropna(how='any', subset=all_regressors + col_y, inplace=True)

    ## create dictionary with limits (in order to display the regression lines)
    ## and dataframe with all combinations of those limits (in order to create
    ## a view data points to display the regression lines)
    dict_limits = {}
    for col in all_regressors:
        dict_limits.update({col: [df.loc[:, col].min(), df.loc[:, col].max()]})
                
    df_corners = pd.DataFrame(itertools.product(*list(dict_limits.values())),
                              columns = dict_limits.keys())
    n_cor = df_corners.shape[0]

    ## loop through regressions
    for cols_regress in list_regressions:

        # now general model with all data        
        model_str = f'{col_y[0]} ~ {"+".join(cols_regress)} + C(wtg_blade)'
        fn_part = f'{col_y[0]}_vs_{"_".join(cols_regress)}_wtg_blade'
  
        try:

            # do regression
            fit = ols(formula = model_str, data = df.loc[:, ['wtg_blade'] + cols_regress + col_y]).fit()
            
            # save results to files
            fnp = f'{path_work}\\all_data__edge__{fn_part}__params.csv'
            pd.DataFrame(fit.params, columns=['value']).to_csv(fnp, 
                                                              sep=';', 
                                                              index=True, 
                                                              encoding='cp1252')
    
            fns = f'{path_work}\\all_data__edge__{fn_part}__summary.txt'
            with open(fns, 'w+') as ft:
                #with redirect_stdout(ft):
                ft.write(str(fit.summary()))
    
    
            ## plot all single regression lines + data with and without offsets
            # plot all data and regression line in one diagram that highlights
            # those data that are hoverred by the mouse
            
            # create plot for each regressor
            #groups = pd.DataFrame.groupby(df.loc[:, cols_regress + ['se']], by=['wtg_blade'], sort=False)
            
            groups = pd.DataFrame.groupby(df.loc[:, ['wtg_blade'] + \
                                                 cols_regress + ['se']], 
                                            by=['wtg_blade'], 
                                            sort=False)

            df_tmp0 = df_corners.loc[:, cols_regress].copy()
            
            for col in cols_regress: 
                
                traces = []
                i = 0            
                
                ## get max and min of that variable
                #(x_min, x_max) = dict_limits[col]
                             
                layout = Layout(title=f'{model_str}, Plot se ~ {col}',
                                xaxis = {'range': dict_limits[col]},
                                yaxis = {'range': (0,1)})
                                

                # 2019-8-28: erster Versuch: direkte Darstellung der SE
                if False:
                    for g, dfg in groups:
    
                        # TODO 2019-8-28: weird, sauberer machen!
                        df_tmp = df_tmp0.copy()
                        df_tmp.index = np.tile((g), (n_cor,1))
                        df_tmp = df_tmp.reset_index().rename(columns={'index': 'wtg_blade'})
                        df_tmp = pd.DataFrame.assign(df_tmp, pred = fit.predict(df_tmp)).drop_duplicates(subset=[col, 'pred'])
                        
                        #pred = fit.predict(df_tmp)                                              
                                      
                        # create traces for each index (wtg x blade), one for data and one
                        # for regression fit line        
                        lg = ', '.join(g)
                        color = f'rgb{colors[i]}'
                        traces.append(dict(type='scatter',
                                           name=f'{g},{col}',
                                           legendgroup = lg,
                                           x=dfg.loc[:, col].values,
                                           y=dfg.loc[:, col_y[0]].values,
                                           #text=['mean_temperature_f'],
                                           mode='markers',
                                           marker=dict(color = color,
                                                       size=4)))
    
                        traces.append(dict(type='scatter',
                                           legendgroup = lg,
                                           name=f'reg. {g},{col}',
                                           x=df_tmp.loc[:, col].values,
                                           y=df_tmp.loc[:, 'pred'].values,
                                           #text=['mean_temperature_f'],
                                           mode='lines',
                                           line=dict(color = color,
                                                     width=2)))
                    
                        i += 1

                    fig = dict(data=traces, layout = layout)  
                    plotly.offline.plot(fig)
                    
                # 2019-8-28: neuer Versuch: Darstellung der Residuen (und auch
                # Reduzierung der Datenmenge)
                else:
                    
                    for g, dfg in groups:
    
                        # TODO 2019-8-28: weird, sauberer machen!
                        #df_tmp = df_tmp0.copy()
                        #df_tmp.index = np.tile((g), (n_cor,1))
                        #df_tmp = df_tmp.reset_index().rename(columns={'index': 'wtg_blade'})                        
                        #df_tmp = pd.DataFrame.assign(df_tmp, pred = fit.predict(df_tmp)).drop_duplicates(subset=[col, 'pred'])
                        
                        dfg = dfg.sample(n=1000)
                        res = (dfg.se - fit.predict(dfg))/dfg.se
                                     
                        # create traces for each index (wtg x blade), one for data and one
                        # for regression fit line        
                        lg = ', '.join(g)
                        color = f'rgb{colors[i]}'
                        traces.append(dict(type='scatter',
                                           name=f'{g},{col}',
                                           legendgroup = lg,
                                           x=dfg.loc[:, col].values,
                                           y=res.values,
                                           #text=['mean_temperature_f'],
                                           mode='markers',
                                           marker=dict(color = color,
                                                       size=4)))
                        
                        i += 1
                                                                        
                    fig = dict(data=traces, layout = layout)  
                    plotly.offline.plot(fig)
                        
        except Exception as ex:
            print('abbruch')
            print(str(ex))
    

    ## now find best combination of variables, best modifications of variables etc.
#    scaler = StandardScaler()
#    X_sc = scaler.fit_transform(X)
#    y_sc = scaler.fit_transform(y)
#    X = df.loc[:, ['power_mean', 'temperature_mean']]
#    X2 = sm.add_constant(X)
#    est = sm.OLS(y_sc, X2)
#    est2 = est.fit()
 

# 2019-8-27: Test, warum manche daten nicht geladen werden keonnen


    
    
    
# 2019-8-29: use the pickled data for linear regression, because of too large
# data conduct regression for each wtg x blade individuelly but combine all of
# them in the diagrams
if False:
    
    colors = mfplot.provideColors()

    
    fn = f'{path_work}\\combined_data.pkl'
    df = pd.read_pickle(fn)
    # clean data:
    # - remove (wtg, blade) with n<=100 observations   
    df_stat = df.loc[:, ['wtg_blade', 'se']].groupby(by='wtg_blade').count()
    idx_ok = df_stat[df_stat.se > 100].index    
    df = df[df.loc[:, 'wtg_blade'].isin(idx_ok)]

    idx_removed = set(df.wtg_blade) - set(idx_ok)
    [print(f'removed: {i}' for i in idx_removed)]

    # rename columns
    df.rename(columns={'omega_mean': 'omega', 
                       'wind_mean': 'v_wind', 
                       'pitch_mean': 'pitch', 
                       'temperature_mean': 'T',
                       'power_mean': 'P'}, inplace=True)
        
    # list of regressions to be done
    list_regressions = [['P', 'T'],
                        ['P', 'v_wind', 'T'],
                        ['omega', 'pitch', 'T'],
                        ['P', 'pitch', 'T'],
                        ['v_wind', 'pitch', 'T']]
        
    col_y = ['se']


    # remove rows with na for any of the regressors or se
    all_regressors = list(np.unique([s for sublist in list_regressions for 
                                     s in sublist]))
    df.dropna(how='any', subset=all_regressors + col_y, inplace=True)

    ## create dictionary with limits (in order to display the regression lines)
    ## and dataframe with all combinations of those limits (in order to create
    ## a view data points to display the regression lines)
    dict_limits = {}
    for col in all_regressors:
        dict_limits.update({col: [df.loc[:, col].min(), df.loc[:, col].max()]})
                
    df_corners = pd.DataFrame(itertools.product(*list(dict_limits.values())),
                              columns = dict_limits.keys())
    n_cor = df_corners.shape[0]

    ## loop through regressions
    for cols_regress in list_regressions:

        # now general model with all data        
        model_str = f'{col_y[0]} ~ {"+".join(cols_regress)} + C(wtg_blade)'
        fn_part = f'{col_y[0]}_vs_{"_".join(cols_regress)}_wtg_blade'
  
        try:

            # do regression
            fit = ols(formula = model_str, data = df.loc[:, ['wtg_blade'] + cols_regress + col_y]).fit()
            
            # save results to files
            fnp = f'{path_work}\\all_data__edge__{fn_part}__params.csv'
            pd.DataFrame(fit.params, columns=['value']).to_csv(fnp, 
                                                              sep=';', 
                                                              index=True, 
                                                              encoding='cp1252')
    
            fns = f'{path_work}\\all_data__edge__{fn_part}__summary.txt'
            with open(fns, 'w+') as ft:
                #with redirect_stdout(ft):
                ft.write(str(fit.summary()))
    
    
            ## plot all single regression lines + data with and without offsets
            # plot all data and regression line in one diagram that highlights
            # those data that are hoverred by the mouse
            
            # create plot for each regressor
            #groups = pd.DataFrame.groupby(df.loc[:, cols_regress + ['se']], by=['wtg_blade'], sort=False)
            
            groups = pd.DataFrame.groupby(df.loc[:, ['wtg_blade'] + \
                                                 cols_regress + ['se']], 
                                            by=['wtg_blade'], 
                                            sort=False)

            df_tmp0 = df_corners.loc[:, cols_regress].copy()
            
            for col in cols_regress: 
                
                traces = []
                i = 0            
                
                ## get max and min of that variable
                #(x_min, x_max) = dict_limits[col]
                             
                layout = Layout(title=f'{model_str}, Plot se ~ {col}',
                                xaxis = {'range': dict_limits[col]},
                                yaxis = {'range': (0,1)})
                                

                # 2019-8-28: erster Versuch: direkte Darstellung der SE
                if False:
                    for g, dfg in groups:
    
                        # TODO 2019-8-28: weird, sauberer machen!
                        df_tmp = df_tmp0.copy()
                        df_tmp.index = np.tile((g), (n_cor,1))
                        df_tmp = df_tmp.reset_index().rename(columns={'index': 'wtg_blade'})
                        df_tmp = pd.DataFrame.assign(df_tmp, pred = fit.predict(df_tmp)).drop_duplicates(subset=[col, 'pred'])
                        
                        #pred = fit.predict(df_tmp)                                              
                                      
                        # create traces for each index (wtg x blade), one for data and one
                        # for regression fit line        
                        lg = ', '.join(g)
                        color = f'rgb{colors[i]}'
                        traces.append(dict(type='scatter',
                                           name=f'{g},{col}',
                                           legendgroup = lg,
                                           x=dfg.loc[:, col].values,
                                           y=dfg.loc[:, col_y[0]].values,
                                           #text=['mean_temperature_f'],
                                           mode='markers',
                                           marker=dict(color = color,
                                                       size=4)))
    
                        traces.append(dict(type='scatter',
                                           legendgroup = lg,
                                           name=f'reg. {g},{col}',
                                           x=df_tmp.loc[:, col].values,
                                           y=df_tmp.loc[:, 'pred'].values,
                                           #text=['mean_temperature_f'],
                                           mode='lines',
                                           line=dict(color = color,
                                                     width=2)))
                    
                        i += 1

                    fig = dict(data=traces, layout = layout)  
                    plotly.offline.plot(fig)
                    
                # 2019-8-28: neuer Versuch: Darstellung der Residuen (und auch
                # Reduzierung der Datenmenge)
                else:
                    
                    for g, dfg in groups:
    
                        # TODO 2019-8-28: weird, sauberer machen!
                        #df_tmp = df_tmp0.copy()
                        #df_tmp.index = np.tile((g), (n_cor,1))
                        #df_tmp = df_tmp.reset_index().rename(columns={'index': 'wtg_blade'})                        
                        #df_tmp = pd.DataFrame.assign(df_tmp, pred = fit.predict(df_tmp)).drop_duplicates(subset=[col, 'pred'])
                        
                        dfg = dfg.sample(n=1000)
                        res = (dfg.se - fit.predict(dfg))/dfg.se
                                     
                        # create traces for each index (wtg x blade), one for data and one
                        # for regression fit line        
                        lg = ', '.join(g)
                        color = f'rgb{colors[i]}'
                        traces.append(dict(type='scatter',
                                           name=f'{g},{col}',
                                           legendgroup = lg,
                                           x=dfg.loc[:, col].values,
                                           y=res.values,
                                           #text=['mean_temperature_f'],
                                           mode='markers',
                                           marker=dict(color = color,
                                                       size=4)))
                        
                        i += 1
                                                                        
                    fig = dict(data=traces, layout = layout)  
                    plotly.offline.plot(fig)
                        
        except Exception as ex:
            print('abbruch')
            print(str(ex))
    






    

    
    
# 2019-9-2: collect data and store them into hd5
if False:
            
    fn_hd5 = f'{path_work}\\combined_data_withSens.hd5'
    if not os.path.isfile(fn_hd5):             # if no such hd5-file exists            
#    if True:                                       
        #import aerodynamic_imbalance
        where_clause = r"(Windpark_WEA#Windparkname='Wikinger') and not ((Datenbankname is NULL) or (Datenbankname = '') or (Beginn_Datenspeicherung is NULL) or (Beginn_Datenspeicherung = ''))"
        tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
        turbines = tmp['turbines']
        tickets = tmp['tickets']
        
        del tmp
        gc.collect()
        
        ## build model(s)
        
        #    import regression
        #colors = {1: 'r', 2: 'b', 3: 'g'}
        power = (300, 800)
                
        cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                     'wind_mean', 'omega_sigma', 'power_sigma', 
                     'pitch_sigma', 'cyc_status_eval']                
        
        cols = ['e_101_edge', 'e_102_edge', 'e_103_edge',
                'e_101_flap', 'e_102_flap', 'e_103_flap']

        all_files = os.listdir(path_data)
            
        list_problem_db = []
        result = []
        i=0
        list_idx = []
        list_X = []
        list_y = []
        list_wtg = []
        list_blade = []
        
        for idx, tb in turbines.iterrows():
            db = tb.sDB
            print(db)
    
            try:
        
                # consider only channels that are ok
                
                channels = set(cols) & set(mfmon.get_valid_channels(tickets[db], type_fails = 'all_rbl_related'))
                
                sens = [tb.sens_e1, tb.sens_e2, tb.sens_e3,
                        tb.sens_f1, tb.sens_f2, tb.sens_f3]
            
                dict_fac = {'e_101_edge': sens[0],
                            'e_102_edge': sens[1],
                            'e_103_edge': sens[2],
                            'e_101_flap': sens[3],
                            'e_102_flap': sens[4],
                            'e_103_flap': sens[5]}
                
                channels = [ch for ch in channels if not((dict_fac[ch] is None) or (math.isnan(dict_fac[ch])))]
                
                # if there are channels without problems ...
                if len(channels)>0:
        
                    df = load_data_multiple_hd5files(path_data_multiple, db,
                                                     channels, power, band)
         
                    ## do model for each channel seperately
                    for bl in channels:
                        y = df.loc[:, bl].values * dict_fac[bl]
#                        y = df.loc[:, bl].values
                        y = y.reshape(-1,1)
                        X = df.loc[:, cols_cdef].values
        
                        ## add the data to the list of all data
                        n = len(y)
                        list_X.append(X)
                        list_y.append(y)
                        list_wtg.append(np.tile((db), (n, 1)))
                        list_blade.append(np.tile((bl), (n, 1)))
        
            except Exception as ex:
                print(str(ex))
                    
        
        ## lin. reg for all data
        tmp = np.hstack([np.vstack(list_X),
                         np.vstack(list_y)])
        
        del list_X, list_y, tickets, turbines
        gc.collect()
        
        df = pd.DataFrame(tmp, columns = cols_cdef + ['se'])
        for col in cols_cdef + ['se']:
            df[col] = df[col].astype(float)
            
        df.reset_index(inplace=True, drop=True)
        
        df = df.assign(wtg = np.vstack(list_wtg), index=df.index)
        df = df.assign(blade = np.vstack(list_blade), index=df.index)
    
        del list_wtg, list_blade
        gc.collect()
            
        df.drop(columns = ['index'], inplace=True)
        
        # create empty hd5-file
        with pd.HDFStore(fn_hd5, mode="w", complevel=9, complib='blosc:lz4') as f:        
            f.close()
                
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:    
            f.put('data', df, format='table', data_columns=True, index=False)




    
# 2019-9-2: do regression with ONE model, identify the outliers of the 
# offsets (dummy variable constants), give overview over wtg spreads of offsets
# (to identify systematic deviations for one blade)
if False:
       
    regressors = ['P', 'T']
    col_y = ['se']
    
    fn_part = f'{col_y[0]}_vs_{"_".join(regressors)}_wtg_blade'

    #fn_hd5 = f'{path_work}\\combined_data_withSens_{fn_part}.hd5'
    fn_hd5 = f'{path_work}\\combined_data_withSens_forRegress.hd5'

    if not os.path.isfile(fn_hd5):

        with pd.HDFStore(f'{path_work}\\combined_data_withSens.hd5', 'a', complevel=9, complib='blosc:lz4') as f:    
            df = f.select(key='data').copy()
    
        # clean data:
        # - remove (wtg, blade) with n<=100 observations   
        df_stat = df.loc[:, ['wtg', 'blade', 'se']].groupby(by=['wtg', 'blade']).count()
        idx_ok = df_stat[df_stat.se > 100].index
        idx_wtg = [x[0] for x in idx_ok]
        idx_blade = [x[1] for x in idx_ok]
    
        # remove these data    
        df = df[(df.loc[:, 'wtg'].isin(idx_wtg)) & (df.loc[:, 'blade'].isin(idx_blade))]
    
        idx_removed = set(df_stat.index) - set(idx_ok)
        _tmp = [print(f'removed: {i}') for i in list(idx_removed)]
    
    
    
        # save as intermediate file
        with pd.HDFStore(fn_hd5, mode="w", complevel=9, complib='blosc:lz4') as f:        
            f.close()
                    
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:    
            f.put('data', df, format='table', data_columns=True, index=False)


    else:
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:    
            df = f.select(key='data').copy()


    # rename columns    
    df.rename(columns={'omega_mean': 'omega', 
                       'wind_mean': 'v_wind', 
                       'pitch_mean': 'pitch', 
                       'temperature_mean': 'T',
                       'power_mean': 'P'}, inplace=True)
        
    # remove rows with na for any of the regressors or se
    df.dropna(how='any', subset=regressors + col_y, inplace=True)
    gc.collect()

    ### now do regression
    cols = list(set(df.columns) - set(regressors + col_y + ['wtg', 'blade']))
    df.drop(columns = cols, inplace=True)

    # now consider directions seperately
    df = df[df.blade.isin(['e_101_edge', 'e_102_edge', 'e_103_edge'])]
    gc.collect()


    model_str = f'{col_y[0]} ~ {"+".join(regressors)} + C(wtg_blade)'

    # select subset of data to reduce data size to 60%
    #sample_info = pd.DataFrame([[1,5],[2,6]], columns = ['Group ID','Sample Size'])
    #mapper = sample_info.set_index('Group ID')['Sample Size'].to_dict()
    df2 = df
    #df2 = df.groupby(['wtg', 'blade']).apply(lambda x: x.sample(n=int(np.floor(x.shape[0]*.3)))).reset_index(drop = True)
    df2 = df2.assign(wtg_blade=list(df2[['wtg', 'blade']].itertuples(index=False, name=None)))
    fit = ols(formula = model_str, data = df2).fit()
    fit.summary()
    #fit = sm.ols(y, X).fit()

    # mit dem Resultat von df2 als starting point koennte man jetzt auch 
    # z.B. mittels gradient decent die Regressionsparameter berechnen
    # alternativ: run ueber mehrere samples und MW-Bildung o.ae.
    
    
    




  

#        # save summary
#        fns = f'{path_work}\\all_data__edge__{fn_part}__summary.txt'
#        with open(fns, 'w+') as ft:
#            ft.write(str(fit.summary()))
#            
#            
#        df_b = pd.DataFrame(fit.params, columns=['value'])
#        # save results to files
#        fnp = f'{path_work}\\all_data__edge__{fn_part}__params.csv'
#        df_b.to_csv(fnp, sep=';', index=True, encoding='cp1252')
#    
#        # get offsets
#        idx = [ix for ix in df_b.index if 'C(index)' in ix]
#        df_offsets = df_b.loc[idx,:]
#        df_offsets.reset_index()
#
#    
#    
#            ## plot all single regression lines + data with and without offsets
#            # plot all data and regression line in one diagram that highlights
#            # those data that are hoverred by the mouse
#            
#            # create plot for each regressor
#            #groups = pd.DataFrame.groupby(df.loc[:, regressors + ['se']], by=['wtg_blade'], sort=False)
#        if False:            
#            groups = pd.DataFrame.groupby(df.loc[:, ['wtg_blade'] + \
#                                                 regressors + ['se']], 
#                                            by=['wtg_blade'], 
#                                            sort=False)
#
#            df_tmp0 = df_corners.loc[:, regressors].copy()
#            
#            for col in regressors: 
#                
#                traces = []
#                i = 0            
#                
#                ## get max and min of that variable
#                #(x_min, x_max) = dict_limits[col]
#                             
#                layout = Layout(title=f'{model_str}, Plot se ~ {col}',
#                                xaxis = {'range': dict_limits[col]},
#                                yaxis = {'range': (0,1)})
#                                
#
#                # 2019-8-28: erster Versuch: direkte Darstellung der SE
#                if False:
#                    for g, dfg in groups:
#    
#                        # TODO 2019-8-28: weird, sauberer machen!
#                        df_tmp = df_tmp0.copy()
#                        df_tmp.index = np.tile((g), (n_cor,1))
#                        df_tmp = df_tmp.reset_index().rename(columns={'index': 'wtg_blade'})
#                        df_tmp = pd.DataFrame.assign(df_tmp, pred = fit.predict(df_tmp)).drop_duplicates(subset=[col, 'pred'])
#                        
#                        #pred = fit.predict(df_tmp)                                              
#                                      
#                        # create traces for each index (wtg x blade), one for data and one
#                        # for regression fit line        
#                        lg = ', '.join(g)
#                        color = f'rgb{colors[i]}'
#                        traces.append(dict(type='scatter',
#                                           name=f'{g},{col}',
#                                           legendgroup = lg,
#                                           x=dfg.loc[:, col].values,
#                                           y=dfg.loc[:, col_y[0]].values,
#                                           #text=['mean_temperature_f'],
#                                           mode='markers',
#                                           marker=dict(color = color,
#                                                       size=4)))
#    
#                        traces.append(dict(type='scatter',
#                                           legendgroup = lg,
#                                           name=f'reg. {g},{col}',
#                                           x=df_tmp.loc[:, col].values,
#                                           y=df_tmp.loc[:, 'pred'].values,
#                                           #text=['mean_temperature_f'],
#                                           mode='lines',
#                                           line=dict(color = color,
#                                                     width=2)))
#                    
#                        i += 1
#
#                    fig = dict(data=traces, layout = layout)  
#                    plotly.offline.plot(fig)
#                    
#                # 2019-8-28: neuer Versuch: Darstellung der Residuen (und auch
#                # Reduzierung der Datenmenge)
#                else:
#                    
#                    for g, dfg in groups:
#    
#                        # TODO 2019-8-28: weird, sauberer machen!
#                        #df_tmp = df_tmp0.copy()
#                        #df_tmp.index = np.tile((g), (n_cor,1))
#                        #df_tmp = df_tmp.reset_index().rename(columns={'index': 'wtg_blade'})                        
#                        #df_tmp = pd.DataFrame.assign(df_tmp, pred = fit.predict(df_tmp)).drop_duplicates(subset=[col, 'pred'])
#                        
#                        dfg = dfg.sample(n=1000)
#                        res = (dfg.se - fit.predict(dfg))/dfg.se
#                                     
#                        # create traces for each index (wtg x blade), one for data and one
#                        # for regression fit line        
#                        lg = ', '.join(g)
#                        color = f'rgb{colors[i]}'
#                        traces.append(dict(type='scatter',
#                                           name=f'{g},{col}',
#                                           legendgroup = lg,
#                                           x=dfg.loc[:, col].values,
#                                           y=res.values,
#                                           #text=['mean_temperature_f'],
#                                           mode='markers',
#                                           marker=dict(color = color,
#                                                       size=4)))
#                        
#                        i += 1
#                                                                        
#                    fig = dict(data=traces, layout = layout)  
#                    plotly.offline.plot(fig)
#                        
#    except Exception as ex:
#        print('abbruch')
#        print(str(ex))
    



    
