# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 00:00:14 2020

@author: christian_2
"""



#from os import listdir
import sys

import pandas as pd
import numpy as np
#import matplotlib.pyplot as plt
#import seaborn as sns
#import statsmodels.formula.api as smf
import statsmodels.api as sm

#import plotly.graph_objects as go
#from plotly.graph_objs import Scatter, Layout
#from collections import Counter
#from contextlib import redirect_stdout
#from sklearn import datasets, linear_model
#from sklearn.preprocessing import StandardScaler

from datetime import datetime as dt
#from dateutil.relativedelta import *
    
#from statsmodels.formula.api import ols
#from scipy import stats
#from scipy.signal import savgol_filter
#from scipy.signal import butter, lfilter, freqz

#sys.path.append(r'C:\Users\w012028\Repositories\python\my_functions)

#import kinematics.aeroimb.store_cdef_data
#from kinematics.aeroimb.store_cdef_data import store_cdef_data
from kinematics.aeroimb import myplot_aeroImb, adjust_se
from kinematics.aeroimb import get_datetime_factor_change, load_data_multiple_hd5files

#import data as mfdata

#from data import collect_hd5_data_farm  , store_cdef_data, collect_hd5_data_old
from data import calc_phi_from_harmonics
#from data.update_hd5 import combine_at
from kinematics.pitch import butter_lowpass, butter_lowpass_filter, get_ef
from kinematics.pitch import calc_pitch_period, calc_pitch_bending, calc_pitch2
from kinematics.pitch import calc_pitch_period2, calc_pitch_diff, raw2pitch
from kinematics.pitch import get_raw_data, compare_pitch_diff, calc_aoa
from kinematics.pitch import calc_aoa_period2, calc_pitch_df

#import monitor as mfmon
from plot import myFunctions_plot as mfplot
from plot.myFunctions_plot import myplot_fast, myplot_fast2
#from plot import provide_colors

#
#try:
#    import cPickle as pickle
#except ModuleNotFoundError:
#    import pickle

    
# TODO 2019-6-27: erstmal auskommentiert, da hierfuer update/Installation in conda noetig ist, was aber ohne admin-Rechte nicht geht
#import model

#sepath = pathlib.Path('D:') / 'schraeganstroemung' / 'energies'
#path_data = r'C:\Users\w012028\Documents\CK\data\data__aerodynic_imbalance'
#path_img = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\material'
#path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht'
#path_data_multiple = r'C:\Users\w012028\Documents\CK\data\data__aerodynic_imbalance\multiple_hd5'
    

band = [54, 66]
bw = band[1]-band[0]
eps = 1e-10

col_map = {'e1': 'red',
           'e2': 'blue',
           'e3': 'green',
           'f1': 'tomato',
           'f2': 'lightblue',
           'f3': 'lightgreen'}


def load_data_WK49(path, datatype='at'):
    fn1 = f'{datatype}__Wikinger_AdwenWK09__20190416_133949.csv'
    fn2 = f'{datatype}__Wikinger_AdwenWK09__20190416_111640.csv'
    fntest = f'{datatype}__Wikinger_AdwenWK09__20190417_151313.csv'
    
    df1 = pd.read_csv(f'{path}\\data\\{fn1}', sep=',', index_col = 0, parse_dates=[0])
    df2 = pd.read_csv(f'{path}\\data\\{fn2}', sep=',', index_col = 0, parse_dates=[0])
    dftest = pd.read_csv(f'{path}\\data\\{fntest}', sep=',', index_col = 0, parse_dates=[0])
    
    if datatype=='af':
        # the af data downloaded from webVis have column names edge-1, edge-2 etc., the at data Channel-0, Channel-1 etc. Since the later used functions are designed for the at data the column names of the af data are renamed according to this dictionary
        dict_rename_af = {'flap-1': 'Channel-0', 'flap-2': 'Channel-1', 'flap-3': 'Channel-2', 'edge-1': 'Channel-3', 'edge-2': 'Channel-4', 'edge-3': 'Channel-5'}
        dict_rename_af_inv = {v:k for k,v in dict_rename_af.items()}
        df1 = digits2g_df(df1.rename(columns=dict_rename_af), dict_sens=dict_sens_WK49).rename(columns=dict_rename_af_inv)
        df2 = digits2g_df(df2.rename(columns=dict_rename_af), dict_sens=dict_sens_WK49).rename(columns=dict_rename_af_inv)
        dftest = digits2g_df(dftest.rename(columns=dict_rename_af), dict_sens=dict_sens_WK49).rename(columns=dict_rename_af_inv)
    
    else:
        df1 = digits2g_df(df1, dict_sens=dict_sens_WK49)
        df1.index.name = 'time'
        df2 = digits2g_df(df2, dict_sens=dict_sens_WK49)
        df2.index.name = 'time'
        dftest = digits2g_df(dftest, dict_sens=dict_sens_WK49)
        dftest.index.name = 'time'
    
    return(df1, df2, dftest) 






if dt.now().date()==dt(2021,2,27).date():

    db = 'cmrblba_mb_bw_064'
    df_per, list_problems = calc_pitch_period(db, (dt(2021,1,1),dt(2021,2,27)))
    #df_per, list_problems = calc_pitch_period(db, (dt(2017,11,28), dt.now())
    df = add_col_pitch_deg(df_per, ['pitch1', 'pitch2', 'alpha', 'gamma1', 'gamma2'])
    df.shape








if dt.now().date()==dt(2021,2,2).date():
    from os import listdir
    import sys
    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    from collections import Counter
    from datetime import datetime as dt
    import statsmodels.api as sm
    
    sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions')        # path to modules  
    from data.kinematics import calc_pitch_bending, calc_pitch2, calc_pitch_period2, raw2pitch, get_raw_data, calc_pitch_diff, get_ef
    from data.kinematics import calc_pitch_df, get_data_from_dbs30, digits2g, digits2g_df#, digits2si
    from data.kinematics import butter_lowpass_filter
    from data import calc_phi_from_harmonics, get_preferences
    from plot.myFunctions_plot import myplot_fast, myplot_fast2, myplot_fast3

    db = 'cmrblba_bc_t_01812'
    
    dict_sens_WK49 = {0: 983, 1: 972, 2: 975, 3: 983, 4: 972, 5: 975}
    
    path = r"M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\pitch_angle_calculation\Experiment_WK09"
    df_ok1, df_ok2, df_test = load_data_WK49(path)
    
    df_res,dict_plots = calc_pitch_df(df_ok2, blades = range(1,4),
                        sample_rate = 1000, wdw_size_prae = 1001, min_amp = 1/32, 
                        idx_first = 1, idx_last = -1, single_revolutions=True)
    
    
    tmp = calc_pitch_period(db, (dt(2019,4,16),dt(2019,4,18)))
    
    


if dt.now().date()==dt(2021,1,15).date():
    path = r"M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\pitch_angle_calculation\Experiment_WK09"
    
    fn = r"ts__Wikinger_AdwenWK09__20190417_151313.csv"
    db = 'cmrblba_bc_t_01812'
    
    ## read in csv data
    df = pd.read_csv(f'{path}\\data\\{fn}', sep=',', parse_dates=[0])
    
    # calculate the pitch angel for each revolution separately
    df_res,dict_plots = calc_pitch_df(df, blades = range(1,4),
                                      sample_rate = 1000, wdw_size_prae = 101, min_amp = 1000, 
                                      idx_first = 1, idx_last = -1, single_revolutions=True, model=2)



# 2021-1-4: Pitchwinkelbestimmung fuer Kingspan, Vestas 210116, s. Email von DB,
# calculate overview, neue Variante
if dt.now().date()==dt(2021,1,8).date():
    
    path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuery20201223'
        
    dbs = ['cmrblba_bc_t_02747', 'cmrblba_bc_t_01015']
    
    blades = range(1,4)
    blade_ref = 3
    blades_remain = set(blades)-{blade_ref}
    
    #dict_style0 = {'linestyle': 'None', 'marker': '.', 'markersize': 5}
    dict_style0 = {'marker': '.', 'markersize': 8}

    # TODO 2020-3-28: Bedingung 'pitch<50' ersetzen durch
    # | ||(a1, b1)|| - g | < epsilon, oder so aehnlich
    #filters_raw = ['r2e >= 0.9', 'r2f >= 0.75', 'f_rot < 0.3']
    filters_raw = ['r2e >= 0.9', 'r2f >= 0.75', 'f_rot > 0.005']
    
    
    db = dbs[0]
    date = dt(2019,6,28,16,35,14)
    cycle_id = 182206
    
    df_res, dict_plots = calc_pitch2(db, date, cycle_id, blades = range(1,4),
                                     sample_rate = 1000, wdw_size_prae = 101, 
                                min_amp = 1000, idx_first = 1, idx_last = -1,
                                single_revolutions=False)   
    
    legend = list()
    list_plots = list()
    
    for k, list_plot in dict_plots.items():
        blade = k[0]
        cnt = k[1]
        legend_b = [f'e{blade} meas.', f'f{blade} meas.', 
                           'e{blade} pred.', 'f{blade} pred.']
        
        myplot_fast2(list_plot, 
                     fn = None, 
                     s_title=f'{db}, edge, flap control plot for ' + \
                             'regression a_t ~ cos + sin',
                     legend = legend, 
                     projection = 'polar'
                     #, theta_zero_location = 'N'
                     )
            
        list_plots = list_plots + list_plot
        legend = legend + legend_b
    
    myplot_fast2(list_plots, 
                 fn = None, 
                 s_title=f'{db}, edge, flap control plot for ' + \
                         'regression a_t ~ cos + sin',
                 legend = legend, 
                 projection = 'polar'
                 #, theta_zero_location = 'N'
                 )

    
    for db in dbs:
        print('')
        print(db)
        period = (None, dt(2021,1,3))
        #period = (dt(2019,5,1), dt(2019,7,1))
        
        
        
        kwargs = {'filters': 'omega_mean>=0.05', 'blades': blades, 'radius': 9,
                  'sample_rate': 1000, 'wdw_size_prae': 101, 
                  'min_amp': 200}

        df_raw = get_raw_data(db, path_work, period, **kwargs)
               
        df_aoa = raw2pitch(df_raw, filters_raw)
        
        df_aoa.to_csv(f'{path_work}\{db}_aoa.csv', sep=';', 
                      index=False)

        ## plot pitch vs. time and vs. pitch from scada
#        for blade in blades:
#            df = df_aoa[df_aoa.blade==blade].loc[:, ['create_time', 'pitch_mean', 'pitch', 'aoa_deg']]
#            mfplot.myplot_fast3(df, 'create_time', 'aoa_deg', 
#                                figsize = (8,5), title = f'{db}, blade {blade}',
#                                fn = f'{path_work}\{db}_blade{blade}_aoa_vs_pitch_mean.png')
#            mfplot.myplot_fast3(df, 'pitch_mean', 'pitch', 'create_time', 
#                                figsize = (8,5), title = f'{db}, blade {blade}',
#                                fn = f'{path_work}\{db}_blade{blade}_pitch_vs_pitch_mean.png')


#        df_diff = calc_pitch_diff(df_aoa, blade_ref)
        
#        df_diff.to_csv(f'{path_work}\{db}_pitch_differences.csv', sep=';', 
#                      index=False)        
    
                       
        # plot differences with colormap
        list_plot = list()
        legend = list()
        col = f'aoa_deg'
        for blade in blades:
            df = df_aoa[df_aoa.blade==blade]
            dict_style = dict_style0.copy()
            dict_style.update({'color': col_map[f'e{blade}']})
            list_plot.append((df.wind_mean, 
                              df.loc[:, col], dict_style))
            legend.append(f'blade {blade}')
                                            
#            mfplot.myplot_fast3(df_diff, 'create_time', 
#                                f'pitch_{blade}-{blade_ref}', 
#                                f'pitch_{blade_ref}', figsize = (8,5),
#                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_pitch_ref.png',
#                                title = f'{db}, blade {blade}')
#            mfplot.myplot_fast3(df_diff, f'pitch_{blade_ref}',
#                                f'pitch_{blade}-{blade_ref}',
#                                'create_time', figsize = (8,5),
#                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_time.png',
#                                title = f'{db}, blade {blade}')
#            mfplot.myplot_fast3(df_diff, 'pitch_mean',
#                                f'pitch_{blade}-{blade_ref}',
#                                'create_time', figsize = (8,5),
#                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_pitch_mean.png',
#                                title = f'{db}, blade {blade}')
                    
        mfplot.myplot_fast2(list_plot, 
                            fn= f'{path_work}\{db}_aoa.png', 
                            legend = legend, 
                    s_title = f'aoa bei {db}')





# 2020-6-27: Pitchwinkelbestimmung fuer Buchau, Vestas 210116, s. Email von DB,
# calculate overview, neue Variante
if dt.now().date()==dt(2020,6,27).date():
    
    path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuery20200324'
        
    dbs = ['cmrblba_bc_t_01505', 'cmrblba_bc_t_01485', 'cmrblba_bc_t_01487']
    
    blades = range(1,4)
    blade_ref = 3
    blades_remain = set(blades)-{blade_ref}
    
    #dict_style0 = {'linestyle': 'None', 'marker': '.', 'markersize': 5}
    dict_style0 = {'marker': '.', 'markersize': 8}

    # TODO 2020-3-28: Bedingung 'pitch<50' ersetzen durch
    # | ||(a1, b1)|| - g | < epsilon, oder so aehnlich
    filters_raw = ['r2e >= 0.9', 'r2f >= 0.75', 'f_rot < 0.3']
    
    
    for db in dbs:
        print('')
        print(db)
        period = (None, dt(2020,3,1))
        #period = (dt(2019,5,1), dt(2019,7,1))
        
        
        
        kwargs = {'filters': 'omega_mean>=0.05', 'blades': blades, 'radius': 2,
                  'sample_rate': 1000, 'wdw_size_prae': 101, 
                  'min_amp': 200}

        df_raw = get_raw_data(db, path_work, period, **kwargs)
               
        df_aoa = raw2pitch(df_raw, filters_raw)
        
        df_aoa.to_csv(f'{path_work}\{db}_aoa.csv', sep=';', 
                      index=False)

        ## plot pitch vs. time and vs. pitch from scada
#        for blade in blades:
#            df = df_aoa[df_aoa.blade==blade].loc[:, ['create_time', 'pitch_mean', 'pitch', 'aoa_deg']]
#            mfplot.myplot_fast3(df, 'create_time', 'aoa_deg', 
#                                figsize = (8,5), title = f'{db}, blade {blade}',
#                                fn = f'{path_work}\{db}_blade{blade}_aoa_vs_pitch_mean.png')
#            mfplot.myplot_fast3(df, 'pitch_mean', 'pitch', 'create_time', 
#                                figsize = (8,5), title = f'{db}, blade {blade}',
#                                fn = f'{path_work}\{db}_blade{blade}_pitch_vs_pitch_mean.png')


#        df_diff = calc_pitch_diff(df_aoa, blade_ref)
        
#        df_diff.to_csv(f'{path_work}\{db}_pitch_differences.csv', sep=';', 
#                      index=False)        
    
                       
        # plot differences with colormap
        list_plot = list()
        legend = list()
        col = f'aoa_deg'
        for blade in blades:
            df = df_aoa[df_aoa.blade==blade]
            dict_style = dict_style0.copy()
            dict_style.update({'color': col_map[f'e{blade}']})
            list_plot.append((df.wind_mean, 
                              df.loc[:, col], dict_style))
            legend.append(f'blade {blade}')
                                            
#            mfplot.myplot_fast3(df_diff, 'create_time', 
#                                f'pitch_{blade}-{blade_ref}', 
#                                f'pitch_{blade_ref}', figsize = (8,5),
#                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_pitch_ref.png',
#                                title = f'{db}, blade {blade}')
#            mfplot.myplot_fast3(df_diff, f'pitch_{blade_ref}',
#                                f'pitch_{blade}-{blade_ref}',
#                                'create_time', figsize = (8,5),
#                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_time.png',
#                                title = f'{db}, blade {blade}')
#            mfplot.myplot_fast3(df_diff, 'pitch_mean',
#                                f'pitch_{blade}-{blade_ref}',
#                                'create_time', figsize = (8,5),
#                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_pitch_mean.png',
#                                title = f'{db}, blade {blade}')
                    
        mfplot.myplot_fast2(list_plot, 
                            fn= f'{path_work}\{db}_aoa.png', 
                            legend = legend, 
                    s_title = f'aoa bei {db}')




        ## calculate differences for different periods
        #periods = [(dt(2018,9,1),dt(2018,11,1)), (dt(2019,9,1), dt(2019,11,1))]
        #cols = [f'pitch_{b}-{blade_ref}' for b in blades_remain]
        #compare_pitch_diff(df_diff, cols, periods)

    
## calculating pitch angles for step in Shanghai, 1-26 se data
if dt.now().date()==dt(2020,5,15).date():
    
    path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Monitoring\shanghai_1-26\20200515'
    
    #db = 'cmrblba_bc_t_03036'
    dict_files = {'before': r'at__20200513_095808.csv',
                  'after': r'at__20200513_100824.csv'}
    
    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    
    res = []
    
    ## read in files, calculate pitch angles, display results
    for s_state, fn in dict_files.items():
        print(f'{s_state}:')
        print('-----')
        
        ## read in csv data
        df = pd.read_csv(f'{path}\\{fn}', sep=',')
        #mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'Channel-{i}' for i in range(6)]])
        
        # calculate the pitch angle, reversed in order to have the finally calculated phi_rot as one signle 
        # lists for first 0 crossing points (in order to drop boundary effects)
        lixs = list()
        lixe = list()
        for col in range(3):
            blade = col+1
            edge, flap = get_ef(df, blade, wdw_size_prae)
            
            bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=1001, 
                                            min_amp=4000, 
                                            min_pi_duration=1000, 
                                            apply_low_pass_filter=False, 
                                            calc_phi=True, 
                                            counterclockwise = True, 
                                            offset = 0)
            
            omega = 2 * np.pi * dict_res['f_mean']
            phi_rot = dict_res['phi']
                                 
            tmp = dict_res['zero_transitions']
            
            ixs_tmp = tmp[1]
            ixe_tmp = tmp[-2]

  
            phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
            list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'e{col+1}']}),
                            (phi_rot_tmp-np.pi*col*2/3, flap[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'f{col+1}']})]

            ## regression for edge
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                           np.sin(phi_rot_tmp))))
            model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0e, b1e, b2e = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                             {'color': 'black'}))
        
            ## regression for flap
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                           np.sin(phi_rot_tmp))))
            model = sm.OLS(flap[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0f, b1f, b2f = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                 {'color': 'black'}))
        
            ## control plots
            fn_img = f'{path}\\blade{col}_{s_state}_regress.png'
            myplot_fast2(list_to_plot, 
                         fn = fn_img, 
                         s_title=f'edge, flap {s_state}, control plot for ' + \
                         'regression a_t ~ cos + sin',
                         legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 
                                   'reg flap'], 
                         projection = 'polar'
                         #, theta_zero_location = 'N'
                         )
        
            pitch = np.arctan(-b0e/b0f)
            pitch_grad0 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta0 = {pitch_grad0}^o')
        
            pitch = np.arctan(-b1e/b1f)
            pitch_grad1 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta1 = {pitch_grad1}^o')

            pitch = np.arctan(-b2f/b2e)
            pitch_grad2 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta2 = {pitch_grad2}^o')

            lixs.append(ixs_tmp)
            lixe.append(ixe_tmp)
                   
        
            res.append((s_state, f'blade{col+1}', pitch_grad0, pitch_grad1,
                        pitch_grad2))

    df_res = pd.DataFrame.from_records(res, 
                                       columns = ['state', 'blade', 
                                                  'pitch_grad0', 'pitch_grad1',
                                                  'pitch_grad2'])

    df_res.to_csv(f'{path}\\result_reg.csv', sep=';', index=False)





    
# calculate differences of the 3 turbines for different times
if False:
    
    dict_bds = {'cmrblba_bc_t_01505': {'before': dt(2019,3,1),
                                       'after': dt(2019,8,1)},
                'cmrblba_bc_t_01485': {'before': dt(2019,3,1),
                                       'after': dt(2019,8,1)},
                'cmrblba_bc_t_01487': {'before': dt(2019,3,1),
                                       'after': dt(2019,8,1)}}

    for db, dict_comp in dict_bds.items():
        pass



# 2020-3-26: Pitchwinkelbestimmung fuer Buchau, Vestas 210116, s. Email von DB,
# calculate overview, neue Variante 2020-3-26
if False:
    
    path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuery20200324'
        
    dbs = ['cmrblba_bc_t_01505', 'cmrblba_bc_t_01485', 'cmrblba_bc_t_01487']
    
    blades = range(1,4)
    blade_ref = 3
    blades_remain = set(blades)-{blade_ref}
    
    #dict_style0 = {'linestyle': 'None', 'marker': '.', 'markersize': 5}
    dict_style0 = {'marker': '.', 'markersize': 8}

    # TODO 2020-3-28: Bedingung 'pitch<50' ersetzen durch
    # | ||(a1, b1)|| - g | < epsilon, oder so aehnlich
    filters_raw = ['r2e >= 0.9', 'r2f >= 0.75', 'f_rot < 0.3', 'pitch<50']
    
    
    for db in dbs:
        print('')
        print(db)
        period = (None, dt(2020,3,1))
        #period = (dt(2019,5,1), dt(2019,7,1))
        
        
        
        kwargs = {'filters': 'omega_mean>=0.05', 'blades': blades, 
                  'sample_rate': 1000, 'wdw_size_prae': 101, 
                  'min_amp': 200}

        df_raw = get_raw_data(db, path_work, period, **kwargs)
               
        df_pitch = raw2pitch(df_raw, filters_raw)
        
        df_pitch.to_csv(f'{path_work}\{db}_pitch.csv', sep=';', 
                      index=False)

        ## plot pitch vs. time and vs. pitch from scada
        for blade in blades:
            df = df_pitch[df_pitch.blade==blade].loc[:, ['create_time', 'pitch_mean', 'pitch']]
            mfplot.myplot_fast3(df, 'create_time', 'pitch', 'pitch_mean', 
                                figsize = (8,5), title = f'{db}, blade {blade}',
                                fn = f'{path_work}\{db}_blade{blade}_pitch_vs_pitch_mean.png')
            mfplot.myplot_fast3(df, 'pitch_mean', 'pitch', 'create_time', 
                                figsize = (8,5), title = f'{db}, blade {blade}',
                                fn = f'{path_work}\{db}_blade{blade}_pitch_vs_pitch_mean.png')


        df_diff = calc_pitch_diff(df_pitch, blade_ref)
        
        df_diff.to_csv(f'{path_work}\{db}_pitch_differences.csv', sep=';', 
                      index=False)        
    
                       
        # plot differences with colormap
        list_plot = list()
        legend = list()
        for blade in blades_remain:
            col = f'pitch_{blade}-{blade_ref}'
            dict_style = dict_style0.copy()
            dict_style.update({'color': col_map[f'e{blade}']})
            list_plot.append((df_diff.create_time, 
                              df_diff.loc[:, col], 
                                          dict_style))
            legend.append(col)
                                            
            mfplot.myplot_fast3(df_diff, 'create_time', 
                                f'pitch_{blade}-{blade_ref}', 
                                f'pitch_{blade_ref}', figsize = (8,5),
                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_pitch_ref.png',
                                title = f'{db}, blade {blade}')
            mfplot.myplot_fast3(df_diff, f'pitch_{blade_ref}',
                                f'pitch_{blade}-{blade_ref}',
                                'create_time', figsize = (8,5),
                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_time.png',
                                title = f'{db}, blade {blade}')
            mfplot.myplot_fast3(df_diff, 'pitch_mean',
                                f'pitch_{blade}-{blade_ref}',
                                'create_time', figsize = (8,5),
                                fn = f'{path_work}\{db}_blade{blade}_diff_vs_pitch_mean.png',
                                title = f'{db}, blade {blade}')
                    
        mfplot.myplot_fast2(list_plot, 
                            fn= f'{path_work}\{db}_pitch_differences.png', 
                            legend = legend, 
                    s_title = f'Pseudo-Pitchwinkeldifferenzen bei {db}')




        ## calculate differences for different periods
        periods = [(dt(2018,9,1),dt(2018,11,1)), (dt(2019,9,1), dt(2019,11,1))]
        cols = [f'pitch_{b}-{blade_ref}' for b in blades_remain]
        compare_pitch_diff(df_diff, cols, periods)


# 2020-3-24: Pitchwinkelbestimmung fuer Buchau, Vestas 210116, s. Email von DB,
# 2020-3-24
# 2020-6-26
if False:
    
    boverview = False
        
    path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuery20200324'        
    db = 'cmrblba_bc_t_01577'
    date = dt(2019,7,5,1,17,40)
    cycle_id = 4257
    v_wind = 14.84

#    df_res, list_plots = calc_pitch2(db, date, cycle_id, blades = range(3), 
#                                     
#                                     sample_rate = 1000, wdw_size_prae = 101)

    df_res = calc_aoa(db, date, cycle_id, v_wind, radius = 2, 
                      blades = range(1,4),
                      sample_rate = 1000, wdw_size_prae = 101, min_amp = 1000, 
                      idx_first = 1, idx_last = -1)
    df_res.boxplot(by='blade', column = 'pitch')
    df_res.boxplot(by='blade', column = 'aoa_deg')
    
    #mfplot.myplot_fast2(list_plots, projection = 'polar')
    
    
    
    
    
    
    
    
    

# 2020-3-24: Pitchwinkelbestimmung fuer Buchau, Vestas 210116, s. Email von DB,
# 2020-3-24
if False:
    
    boverview = False
        
    path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuery20200324'
        
    dbs = ['cmrblba_bc_t_01505', 'cmrblba_bc_t_01485', 'cmrblba_bc_t_01487']
    
    # calculate overview, i.e. time series of distance
    if boverview:
        
        for db in dbs:
            print(db)
            period = (dt(2019,3,1), dt(2020,3,1))
            df_res, df_problems = calc_pitch_period(db, period,  blades = range(1,4), 
                                                    reference_blade = 1, 
                                                    sample_rate = 1000, 
                                                    wdw_size_prae = 101, 
                                                    bplot = False)
                
            df_res.to_csv(f'{path_work}\{db}_pitch_differences.csv', sep=';', index=False)
        
        
            list_plot = list()
            legend = list()
            groups = df_res.groupby('blade')
            for g, dfg in groups:
                list_plot.append((dfg.create_time, dfg.pitch_diff, {'color': col_map[f'e{g+1}'], 'linestyle': 'None', 'marker': '.', 'markersize': 10}))
                legend.append(f'blade{g+1}')
        
            df_res.set_index('create_time').groupby('blade')['pitch_diff'].plot(legend=True, linestyle='None', marker='.', markersize=5)
        
            
            mfplot.myplot_fast2(list_plot, fn = f'{path_work}\\{db}_pitch_differences.png', 
                                legend = legend, s_title = f'Pseudo-Pitchwinkeldifferenzen RBL2-RBL1 bzw. RBL3-RBL1 bei {db}')
    
    # calculate differences of the 3 turbines for different times
    else:
        
        dict_bds = {'cmrblba_bc_t_01505': {'before': dt(2019,3,1),
                                           'after': dt(2019,8,1)},
                    'cmrblba_bc_t_01485': {'before': dt(2019,3,1),
                                           'after': dt(2019,8,1)},
                    'cmrblba_bc_t_01487': {'before': dt(2019,3,1),
                                           'after': dt(2019,8,1)}}

        for db, dict_comp in dict_bds.items():
            pass



# 2020-3-16: Test fuer WK32, NUR DIESEN TEIL in scripts_pitch_calculation.py
# uebernehmen (ansonsten ist der code dort neuer)
if False:
    
    path_work = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\test_pitchwinkelfehlstellung\Anwendung_WK32'
    
    db = 'cmrblba_bc_t_01577'
    dict_checks = {'ok': [dt(2019,7,5,1,17,40), 4257],       # BAID = 10607
                   'ok2': [dt(2019,7,9,1,27,35), 8958],
                   'strange': [dt(2019,3,19,0,43,0), 1834],                   
                   'strange2': [dt(2019,3,21,19,0,59), 5065],
                   'strange3': [dt(2019,3,22,1,19,41), 5368]}  # BAID = 10277
    

#    #wdw_size_prae = 10001
#    wdw_size_prae = 101
#    wdw_size_post = 10001
#    
#    sample_rate = 1000    
#    cutoff_freq = 1
#    col_map = {'e1': 'red',
#               'e2': 'blue',
#               'e3': 'green',
#               'f1': 'tomato',
#               'f2': 'lightblue',
#               'f3': 'lightgreen'}
    

    period = (dt(2019,3,1), dt(2019,8,1))
    df_res, df_problems = calc_pitch_period(db, period,  blades = range(1,4), 
                                            reference_blade = 1, 
                                            sample_rate = 1000, 
                                            wdw_size_prae = 101, bplot = False)
        
    df_res.to_csv(f'{path_work}\{db}_pitch_differences.csv', sep=';', index=False)


    list_plot = list()
    legend = list()
    groups = df_res.groupby('blade')
    for g, dfg in groups:
        list_plot.append((dfg.create_time, dfg.pitch_diff, {'color': col_map[f'e{g+1}'], 'linestyle': 'None', 'marker': '.', 'markersize': 10}))
        legend.append(f'blade{g+1}')

    df_res.set_index('create_time').groupby('blade')['pitch_diff'].plot(legend=True, linestyle='None', marker='.', markersize=5)

    
    mfplot.myplot_fast2(list_plot, fn = f'{path_work}\\{db}_pitch_differences.png', 
                        legend = legend, s_title = f'Pseudo-Pitchwinkeldifferenzen RBL2-RBL1 bzw. RBL3-RBL1 bei {db}')


    df_ok = df_res[df_res.create_time >= dt(2019, 6,1)]
    df_strange = df_res[df_res.create_time < dt(2019, 6,1)]

    df_ok.groupby('blade').mean()
    df_strange.groupby('blade').mean()
    



if False:
                            
    #from plot.myFunctions_plot import myplot_fast, myplot_fast2
    if bHome:
        path = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\aerodynUnwucht\test_pitchwinkelfehlstellung'

    else:
        path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\test_pitchwinkelfehlstellung'

#    dict_files = {'ok': r'ts__Wikinger_AdwenWK09__20190416_133949.csv',
#                  'test':r'ts__Wikinger_AdwenWK09__20190417_151313.csv'}
    #fn = 'ts__Wikinger_AdwenWK49__20200224_232717.csv'
    #fn = 'ts__Wikinger_AdwenWK09__20190416_133949.csv'
    fn = 'ts__Wikinger_AdwenWK09__20190417_151313.csv'
    
    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    col_map = {'e1': 'red',
               'e2': 'blue',
               'e3': 'green',
               'f1': 'tomato',
               'f2': 'lightblue',
               'f3': 'lightgreen'}
    

    res = list()
    
    ## read in files, calculate pitch angles, display results
        


    ## read in csv data
    df = pd.read_csv(f'{path}\\{fn}', sep=',')
    #mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'Channel-{i}' for i in range(6)]])
    
    # calculate the pitch angle, reversed in order to have the finally calculated phi_rot as one signle 
    # lists for first 0 crossing points (in order to drop boundary effects)
    plot_pitch = list()
    plot_bend = list()
    list_df = list()
    for col in range(3):
        print(f'blade {col+1}:')
        edge, flap = get_ef(df, col, wdw_size_prae)
        
        df_res = calc_pitch_bending(edge, flap, istep=10, reg_interval = 500)
        list_df.append(df_res.assign(blade = col+1))
        plot_pitch.append((df_res.phi, df_res.pitch, {'color': col_map[f'e{col+1}'], 'linestyle': '-', 'marker': '.', 'markersize': 3}))
        plot_bend.append((df_res.phi, df_res.bending_angle, {'color': col_map[f'e{col+1}'], 'linestyle': '-', 'marker': '.', 'markersize': 3}))
        
        
        
    ## control plots
    fn_img = f'{path}\\test_pitch.png'
    myplot_fast2(plot_pitch, 
                 fn = fn_img, 
                 s_title='pitch ~ phi rot',
                 legend = ['blade 1', 'blade 2', 'blade 3'],
                 projection = 'polar')
                
    fn_img = f'{path}\\test_bend.png'
    myplot_fast2(plot_bend, 
                 fn = fn_img, 
                 s_title='bending angle ~ phi rot',
                 legend = ['blade 1', 'blade 2', 'blade 3'],
                 projection = 'polar')
    
    df_res = pd.concat(list_df, axis =0)
    #df_res.to_csv(f'{path}\\result_test.csv', sep=';', index=False)



## 2020-3-11: application of wikinger weas with problems
if False:
#    HIER WEITER 2020-3-11
#    dict_to_test = {'WK03': }
    pass



## 2020-3-5: regression with phi != 0, arbeit @home 
if False:

    #from plot.myFunctions_plot import myplot_fast, myplot_fast2
    if bHome:
        path = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\aerodynUnwucht\test_pitchwinkelfehlstellung'

    else:
        path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\test_pitchwinkelfehlstellung'

#    dict_files = {'ok': r'ts__Wikinger_AdwenWK09__20190416_133949.csv',
#                  'test':r'ts__Wikinger_AdwenWK09__20190417_151313.csv'}
    dict_files = {'ok': r'ts__Wikinger_AdwenWK49__20200224_232717.csv',
                  'ok2': r'ts__Wikinger_AdwenWK49__20200225_002222.csv',
                  'ok3': r'ts__Wikinger_AdwenWK49__20200225_030720.csv',
                  'test':r'ts__Wikinger_AdwenWK49__20200225_183229.csv'}

    #wdw_size_prae = 10001
    wdw_size_prae = 101
    wdw_size_post = 10001
    
    sample_rate = 1000    
    cutoff_freq = 1
    
    # positions of sensors from center axis of the 3 blades
    z_pos = {0: 19,
             1: 19,
             2: 19}

    res = []
    
    ## read in files, calculate pitch angles, display results
    for s_state, fn in dict_files.items():
        print(f'{s_state}:')
        print('-----')
        
        ## read in csv data
        df = pd.read_csv(f'{path}\\{fn}', sep=',')
        #mfplot.myplot_fast(df.loc[:, ['epoch'] + [f'Channel-{i}' for i in range(6)]])
        
        # calculate the pitch angle, reversed in order to have the finally calculated phi_rot as one signle 
        # lists for first 0 crossing points (in order to drop boundary effects)
        lixs = list()
        lixe = list()
        for col in range(3):
            
            edge, flap = get_ef(df, col, wdw_size_prae)
            
            bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=1001, 
                                            min_amp=4000, 
                                            min_pi_duration=1000, 
                                            apply_low_pass_filter=False, 
                                            calc_phi=True, 
                                            counterclockwise = True, 
                                            offset = 0)
            
            omega = 2 * np.pi * dict_res['f_mean']
            phi_rot = dict_res['phi']
                                 
            tmp = dict_res['zero_transitions']
            
            ixs_tmp = tmp[1]
            ixe_tmp = tmp[-2]

  
            phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]
            list_to_plot = [(phi_rot_tmp-np.pi*col*2/3, edge[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'e{col+1}']}),
                            (phi_rot_tmp-np.pi*col*2/3, flap[ixs_tmp:ixe_tmp], 
                             {'color': col_map[f'f{col+1}']})]

            ## regression for edge
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                           np.sin(phi_rot_tmp))))
            model = sm.OLS(edge[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0e, b1e, b2e = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                             {'color': 'black'}))
        
            ## regression for flap
            #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
            X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                           np.sin(phi_rot_tmp))))
            model = sm.OLS(flap[ixs_tmp:ixe_tmp], X)
            reg = model.fit()
            #print(results.summary())
            b0f, b1f, b2f = reg.params
            list_to_plot.append((phi_rot_tmp-np.pi*col*2/3, reg.predict().copy(), 
                                 {'color': 'black'}))
        
            ## control plots
            fn_img = f'{path}\\blade{col}_regress3_WK49.png'
            myplot_fast2(list_to_plot, 
                         fn = fn_img, 
                         s_title=f'edge, flap {s_state}, control plot for ' + \
                         'regression a_t ~ cos + sin',
                         legend = [f'e{col+1}', f'f{col+1}', 'reg edge', 
                                   'reg flap'], 
                         projection = 'polar'
                         #, theta_zero_location = 'N'
                         )
        
            pitch = np.arctan(-b0e/b0f)
            pitch_grad0 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta0 = {pitch_grad0}^o')
        
            pitch = np.arctan(-b1e/b1f)
            pitch_grad1 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta1 = {pitch_grad1}^o')

            pitch = np.arctan(-b2f/b2e)
            pitch_grad2 = pitch * 180/np.pi
            print(f'blade{col} pitch, beta2 = {pitch_grad2}^o')

            lixs.append(ixs_tmp)
            lixe.append(ixe_tmp)
                   
        
            res.append((s_state, f'blade{col+1}', pitch_grad0, pitch_grad1,
                        pitch_grad2))

    df_res = pd.DataFrame.from_records(res, 
                                       columns = ['state', 'blade', 
                                                  'pitch_grad0', 'pitch_grad1',
                                                  'pitch_grad2'])

    df_res.to_csv(f'{path}\\result_reg3_WK49.csv', sep=';', index=False)
