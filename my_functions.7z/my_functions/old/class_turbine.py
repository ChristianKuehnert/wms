# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 14:41:30 2018
last modified: 2019-7-30

@author: Christian Kuehnert (w012028)


Properties:
-----------
    
    sPathData :     path to the .hd5-file containing the raw data





"""

    
#from myFunctions_data import combine_filters
import pandas as pd
import numpy as np
#import datetime as dt
#import sys
import os
#import fnmatch
#import os.path


 
       
#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\functions'
#sModulePath = r'C:\Repositories\python\functions'
#sys.path.append(sModulePath)    
#import myFunctions_data as mfdata
import data.query_tableData_PIT as query_tableData_PIT
import data.query_MySQL2 as query_MySQL2
#import data.update_hd5.update_cdef as update_cdef
from data.update_hd5 import update_status
from data.update_hd5 import update_se
from data.update_hd5 import update_sda
from data.update_hd5 import update_ts
from data.update_hd5 import update_ext
import data.set_dtype_headersKey as set_dtype_headersKey
import data.setdifference_df as setdifference_df
import data.get_data as get_data




    
class turbine:

       
    sDTFmt = '%Y%m%d_%H%M%S'                 # format of datetime used in names of folders and files
         
#IDEE: in dieser Klasse festlegen, welche Spalten benoetigt werden, das dann als map nach draussen geben (koennen), damit dann PIT-Abfrage steuern, dann wieder zurueckschreiben    


    
    """
    initialization
    
    Christian Kuehnert, 2018-12-4
    """
    def __init__(self, sFarm = '', sName = '', sDB = '', dfTickets = pd.DataFrame(), sPathData = ''):

        self.sFarm = sFarm
        self.sName = sName
        self.sDB = sDB
        self.dfTickets = dfTickets
        self.sPathData = sPathData

        self.dictPreferences = {}
                    
        ## constant node names
        self.__sNode_info = 'turbine_info'
        self.__sNode_cdef = 'raw_data/cdef'
        self.__sNode_label = 'raw_data/label'
        self.__sNode_sda = 'raw_data/sda'    
        #self.__sNode_ts = 'raw_data/ts'    
        self.__sNode_ts_data = 'raw_data/ts/data'                                 # subnode with ts data
        self.__sNode_ts_startstop = 'raw_data/ts/startstop'                    # subnode with row numbers of start and stop of each ts






    """
    get the turbine info from database name via PIT
        
    Christian Kuehnert, 2018-12-4
    """
    def init_from_db(self, sDB, bTickets=False):

        self.sDB = sDB
        
#        dictMap = {'sFarm': 'Windpark_WEA#Windparkname', 
#                   'sName': 'WEA_Name',
#                   'sDB': 'Datenbankname',
#                   'id': 'CAST(o_ContainerID as varchar(8000))',
#                   'id_farm': 'CAST(Windpark_WEA# as varchar(8000))'}
        dictMap = {'sFarm': 'Windpark_WEA#Windparkname', 
                   'sName': 'WEA_Name',
                   'sDB': 'Datenbankname',
                   'id': 'o_ContainerID',
                   'id_farm': 'Windpark_WEA#'}

        listCols = [dictMap[i] + ' as ' + i for i in dictMap]
                
        sWC_wt = 'Datenbankname=\'' + sDB + '\''
        #dfTurbine = mfdata.query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)
        dfTurbine = query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)
        self.sFarm = dfTurbine.sFarm[0]
        self.sName = dfTurbine.sName[0]

        if bTickets:
            ## find all tickets
            dictMap_tickets =  {'sTitle': 'Titel',
                                'sDescription': 'Beschreibung',
                                'sStatus': 'Status',
                                'sFarm': 'Windpark#Windparkname',
                                'weasImWP': 'WEAs_im_Windpark',                            
                                'sTicketID': 'TicketID',
                                'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                                'dtCreated': 'Beginn_am',
                                'dtClosed': 'Geschlossen_am'}

            listCols_tickets = [dictMap_tickets[i] + ' as ' + i for i in dictMap_tickets]
               
            sWC_tickets = 'Windpark#=\'' + dfTurbine.id_farm[0] + '\''
            #dfTickets = mfdata.query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets);
            dfTickets = query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets);
            
            dfTickets.column_names = dictMap_tickets.keys
        
            ## prepare list of ticket IDs combined with indices of weas im Windpark
            ## in order to split tickets to single turbines
            lTickets = []
            sContainerID = dfTurbine.id[0]
            for i in range(dfTickets.shape[0]):
                dfT = dfTickets.iloc[[i],:]
                sWiW = dfT.weasImWP[0]          
                if (len(sWiW)>0):
                    lTmp = sWiW.split(',')
                    if sContainerID in lTmp:
                        lTickets.append(dfT)
                        
            self.dfTickets = pd.concat(lTickets, axis=0)
            
        return(self)





            



    """
    get basic information and combine them to strings for text and for name parts of files and folders
    
    Christian Kuehnert, 2018-12-4
    """
    def get_info(self):                     
                
        sFarm = self.sFarm.__str__()
        sName = self.sName.__str__()
        sDB = self.sDB.__str__()
    
        sInfoText = sFarm + ', ' + sName + ' (' + sDB + ')'
        sInfoFN = sFarm + '__' + sName + '__' + sDB
        sInfoFN.replace(' ', '_').replace('(','_').replace('(','_').replace(',','_')
        
        return([sInfoText, sInfoFN])
        
        
    
    
    
    """
    get preferences
    
    Christian Kuehnert, 2019-4-26
    """
    def get_preferences(self):
        
        #sSQL = 'SELECT name, value FROM preferences;'
        #tmp = mfdata.query_MySQL2(self.sDB, sSQL)
        tmp = query_MySQL2(self.sDB, 'SELECT name, value FROM preferences;')
        self.dictPreferences = dict(tmp)
        return(self)
    
    
    



    
    """
    add column with database name to the given dataframe
    
    Christian Kuehnert, 2018-12-5
    """
    def add_db_column(self, dfData, sColName='db'):

        iN = dfData.shape[0]
        
        if iN>0:         
                           
            dfDB = pd.DataFrame(np.tile(self.sDB, [iN,]), columns=['db'], index = dfData.index)        # create dataframe with database name                             
            dfRes = pd.concat([dfDB, dfData], axis=1)
        
        else:
            dfRes = pd.DataFrame(columns=['db'] + dfData.columns)
        
        return(dfRes)
    
    


    
    """
    get last time for the given node
    
    Christian Kuehnert, 2018-12-12
    """
    def get_last_time(self, sNode = 'raw_data/ts/startstop', sColTime = 'create_time'):
        sFN_hd5 = self.sPathData + '\\' + self.sDB + '.hd5'
        try:
            with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
                dfTmp = f.select(sNode, columns=[sColTime])
            
            dfTmp.dropna(subset=[sColTime], inplace=True)            
            return(dfTmp.loc[:,[sColTime]].max()[0])
            
        except Exception as ex:
            return(pd.NaT)
            
         
            



    """
    update the cdef-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    Christian Kuehnert, 2018-12-4
    """
    def update_cdef(self, time_start=None, time_end=None):
        #return(mfdata.update_cdef(self.sDB, self.sPathData, time_start, time_end))
        return(update_cdef(self.sDB, self.sPathData, time_start, time_end))




    """
    update the data from ba_cycle_status the hd5-file that contains the raw data for this turbine
    
    Christian Kuehnert, 2019-1-17
    """
    def update_status(self, time_start=None, time_end=None):
        #mfdata.update_status(self.sDB, self.sPathData, time_start, time_end)
        update_status(self.sDB, self.sPathData, time_start, time_end)



    """
    update the data from ba_cycle_sig_energies the hd5-file that contains the raw data for this turbine
    
    Christian Kuehnert, 2019-1-17
    """
    def update_se(self, time_start=None, time_end=None):
        #mfdata.update_se(self.sDB, self.sPathData, time_start, time_end)
        update_se(self.sDB, self.sPathData, time_start, time_end)






    """
    update the sda-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    Christian Kuehnert, 2019-1-17
    """
    def update_sda(self, time_start=None, time_end=None, bSloppy=True):
        #return(mfdata.update_sda(self.sDB, self.sPathData, time_start, time_end, bSloppy))
        return(update_sda(self.sDB, self.sPathData, time_start, time_end, bSloppy))




    """
    update the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    Christian Kuehnert, 2018-12-4
    """
    def update_ts(self, time_start=None, time_end=None, iCntMeasBase = 8192, bSloppy=True):
        #return(mfdata.update_ts(self.sDB, self.sPathData, time_start, time_end, iCntMeasBase, bSloppy))
        return(update_ts(self.sDB, self.sPathData, time_start, time_end, iCntMeasBase, bSloppy))




    """
    update the externals-data in the hd5-file that contains the raw data (cdef, ts, sda, ...) for this turbine
    
    Christian Kuehnert, 2019-1-21
    """
    def update_externals(self, time_start = None, time_end = None):
        #mfdata.update_ext(self.sDB, self.sPathData, time_start, time_end)
        update_ext(self.sDB, self.sPathData, time_start, time_end)



    
    
    
    
    """
    Function to import a .csv-label-file and update the label-df in
    the hd5-file with these labels. If no label file exists, the label
    node will be left untouched
    
    label==0: normal state (usually 'ok')
    label==1: failure (or sth. similar)
    label==9: unknown/not yet labelled
    
    Parameters:
    -----------
    bOverwrite:      if True, the complete label-node will be overwritten
                     by the data in the file. Otherwise only new data
                     will be appended

    Output:
    -------

    @author: Christian Kuehnert, 2018-12-12
    
    TODO 2018-11-13: nochmal ueberlegen, ob das wirklich so am besten ist - aktuell
    gibt es nur die beiden Moeglichkeiten "alles Ueberschreiben" oder "anhaengen". 
    Interessant waere vielleicht auch (oder statt einer davon) "den im file enthaltenen
    Teil ueberschreiben und den Rest unveraendert lassen" oder "die Stellen ueberschreiben,
    wo im hd5-file der label-Wert 9 ist, und den Rest so lassen"
    """
    def update_labels(self, sPathLabelFile, bOverwrite = False):
                    
        sHeadersKey = ['create_time', 'ID', 'channel']
        
        sNode_label = self.__sNode_label
        
        sSep = None
            
        sFN_hd5 = self.sPathData + '\\' + self.sDB + '.hd5'
        sFN_label = sPathLabelFile + '\\' + self.sDB + '_label.csv'
                    
        if os.path.isfile(sFN_label):
                    
            #dfLabels = pd.read_csv(sFN_label, header=[0], sep=sSep, index_col=False)
            dfLabels_file = pd.read_csv(sFN_label, header=[0], sep=sSep, engine='python')
            #dfLabels_file = mfdata.set_dtype_headersKey(dfLabels_file)
            dfLabels_file = set_dtype_headersKey(dfLabels_file)
            #dfLabels_file['create_time'] = pd.to_datetime(dfLabels_file['create_time'], errors='coerce')
            #dfLabels_file['ID'] = dfLabels_file['ID'].astype(int)
            #dfLabels_file['channel'] = dfLabels_file['channel'].astype(int)
    
            if dfLabels_file.shape[0]>0:
        
                with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
                            
                    if self.__sNode_label in f:
                                            
                        if bOverwrite:                          # if bOverwrite just replace the old node by the new dataframe
                            f.remove(sNode_label)
                            f.append(sNode_label, dfLabels_file, format = 'table', append=True, data_columns=True, index=False)
                            
                        else:                                                                                                
                            
                            dfLabels_hd5 = f.select(sNode_label)
                                        
                            #dfLabels_file = mfdata.setdifference_df(dfLabels_file, dfLabels_hd5, sHeadersKey)
                            dfLabels_file = setdifference_df(dfLabels_file, dfLabels_hd5, sHeadersKey)
                            #dfLabels_hd5.set_index(sHeadersKey, inplace=True)               # set index to combination of create_time, ID and channel
                            #dfLabels_file.set_index(sHeadersKey, inplace=True)                  # set index to combination of create_time, ID and channel                                      
                            #iIdxDiff = dfLabels_file.index - dfLabels_hd5.index                        # set difference of the indices
                            #if len(iIdxDiff)>0:                    
                            if dfLabels_file.shape[0]>0:
                                #dfLabels_file = dfLabels_file[iIdxDiff]
                                #dfLabels_file.reset_index(drop=False, inplace=True)
                                f.append(sNode_label, dfLabels_file, format = 'table', append=True, data_columns=True, index=False)
                        
                    else:
                        #f.put(sNode_label, dfLabels, format='table', append=True, data_columns=True, index=False)               
                        f.append(sNode_label, dfLabels_file, format = 'table', append=True, data_columns=True, index=False)
                                                
        else:
            print('label file ' + sFN_label + ' not found')
            





    """
    extract data (execpt ts data) from the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    use the nodes and the filters passed to the method
    
    Parameters:
    -----------
    
    list_nodes :    nodes in the .hd5-file for which the data should be retrieved and combined, together with
                    filter string to be applied in HDFStore.select-method in where-parameter
    list_columns :  list of columns required (for the final result), if empty then all columns will be returned
    how :           method to merge the data ('inner', 'left' etc.)
    
    
    
    
    Christian Kuehnert, 2018-12-5
    """
    def get_data(self, list_nodes=[], list_columns=[], how='inner'):
        
        #dfData = mfdata.get_data(self.sDB, self.sPathData, list_nodes, list_columns, how)    
        #return(dfData)
        return(get_data(self.sDB, self.sPathData, list_nodes, list_columns, how))
    
    
    
    
    

    """
    use the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine to calculate features
    with the passed function (handle)
    
    Parameters:
    -----------
    
    dfCyc :         pd.DataFrame containing the create_times/cycles for which the features should be calculated
    feat_fct :      function handle for feature-function
    feat_kwargs :   further parameters for the function handle
    
    
        
    Christian Kuehnert, 2019-1-2
    """
    def calc_features_from_ts(self, dfCyc=None, feat_fct=None, feat_kwargs=None):
        
        sHeadersKey = ['create_time', 'ID', 'channel']

        if isinstance(dfCyc, pd.DataFrame):
            
            if (dfCyc.shape[0]>0) and (set(sHeadersKey + ['start', 'stop']).issubset(dfCyc.columns)):
                
                ## now calculate and add features
                # TODO 2018-11-9: eleganter machen								
                lFeat = []
                sFN_hd5 = self.sPathData + '\\' + self.sDB + '.hd5'
                with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
                    for idx in range(dfCyc.shape[0]):
                    
                        ## TODO 2018-12-6: den Block hier kann man bestimmt auch noch schneller machen (z.B. dataframe erst NACH zusammenfuegen aller Werte)
                        ## --> ggf. modifizieren, falls (gemaess profiling) tatsaechlich bottleneck
                        tsCT, iID, iCh, iStart, iStop = dfCyc.loc[:, sHeadersKey + ['start', 'stop']].iloc[idx,:]
                        iTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t']).values[:,0]
                        #dfTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t'])
                        
                        #dfFeat = feat_fct(iTS, **kwargs['kwargs'])
                        #kwargs = feat_kwargs['kwargs']
                        kwargs = feat_kwargs
                        #dfFeat = feat_fct(iTS, **kwargs)
                        lFeat.append(feat_fct(iTS, **kwargs))
                    
#                        dfTmpF = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [dfFeat.shape[0], 1]))
#                        dfTmpF.set_index(dfFeat.index, inplace=True)                                            
#                        dfTmpF.columns = sHeadersKey
                    
                        #dfTmpF['create_time'] = pd.to_datetime(dfTmpF['create_time'], errors='coerce')                                        
                        #dfTmpF['ID'] = dfTmpF['ID'].astype(int)
                        #dfTmpF['channel'] = dfTmpF['channel'].astype(int)                                                                                            
                        
#                        lFeat.append(pd.concat([dfTmpF, dfFeat], axis=1))
                        

                dRes = np.vstack(lFeat)
                        
#                dfRes = pd.concat(lFeat, axis=0)
#                
#                dfRes['create_time'] = pd.to_datetime(dfRes['create_time'], errors='coerce')                                        
#                dfRes['ID'] = dfRes['ID'].astype(int)
#                dfRes['channel'] = dfRes['channel'].astype(int)                                                                                            
            
            else:
                print('dfCyc must not be empty and must contain the columns ' + ', '.join(sHeadersKey) + ', start, stop')
                # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
#                dfRes = pd.DataFrame(columns=sHeadersKey)
                dRes = np.array()
                                
        else:
            # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
            #dfRes = pd.DataFrame(columns=sHeadersKey)
            dRes = np.array()
            
            
        return(dRes)
        



    

    """
    use the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine to calculate features
    with the passed function (handle)
    
    Parameters:
    -----------
    
    dfKeys :    pd.DataFrame containing the create_times/cycles for which the features should be calculated
    fctHdl :    function handle for feature-function
    **kwargs :  further parameters for the function handle
    
    
        
    Christian Kuehnert, 2018-12-6
    """
    def calc_features_from_ts_old(self, dfCyc=None, feat_fct=None, feat_kwargs=None):
        
        sHeadersKey = ['create_time', 'ID', 'channel']        

        if isinstance(dfCyc, pd.DataFrame):
            
            if (dfCyc.shape[0]>0) and (set(sHeadersKey + ['start', 'stop']).issubset(dfCyc.columns)):
                
                ## now calculate and add features
                # TODO 2018-11-9: eleganter machen								
                lFeat = []
                sFN_hd5 = self.sPathData + '\\' + self.sDB + '.hd5'
                with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
                    for idx in range(dfCyc.shape[0]):
                    
                        ## TODO 2018-12-6: den Block hier kann man bestimmt auch noch schneller machen (z.B. dataframe erst NACH zusammenfuegen aller Werte)
                        ## --> ggf. modifizieren, falls (gemaess profiling) tatsaechlich bottleneck
                        tsCT, iID, iCh, iStart, iStop = dfCyc.loc[:, sHeadersKey + ['start', 'stop']].iloc[idx,:]
                        iTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t']).values[:,0]
                        #dfTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t'])
                        
                        #dfFeat = feat_fct(iTS, **kwargs['kwargs'])
                        #kwargs = feat_kwargs['kwargs']
                        kwargs = feat_kwargs
                        dfFeat = feat_fct(iTS, **kwargs)
                        #dfFeat = feat_fct(dfTS, **kwargs)
                    
                        dfTmpF = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [dfFeat.shape[0], 1]))
                        dfTmpF.set_index(dfFeat.index, inplace=True)                                            
                        dfTmpF.columns = sHeadersKey
                                            
                        lFeat.append(pd.concat([dfTmpF, dfFeat], axis=1))
                        
                        
                dfRes = pd.concat(lFeat, axis=0)
                
                dfRes['create_time'] = pd.to_datetime(dfRes['create_time'], errors='coerce')                                        
                dfRes['ID'] = dfRes['ID'].astype(int)
                dfRes['channel'] = dfRes['channel'].astype(int)                                                                                            
            
            else:
                print('dfCyc must not be empty and must contain the columns ' + ', '.join(sHeadersKey) + ', start, stop')
                # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
                dfRes = pd.DataFrame(columns=sHeadersKey)
                                
        else:
            # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
            dfRes = pd.DataFrame(columns=sHeadersKey)
            
            
        return(dfRes)
        



#
#    """
#    predict sensor state from the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
#    
#    Parameters:
#    -----------    
#        
#    Christian Kuehnert, 2018-12-6
#    """
#    def predict_sensor_state(self, sensor_classificator, sTimeStart = '', sTimeEnd = ''):
#
#        lTmp = []
#        if len(sTimeStart.strip()) == 0:
#            lTmp.append('create_time>=\'' + sTimeStart)
#        if len(sTimeEnd.strip()) == 0:
#            lTmp.append('create_time<=\'' + sTimeEnd)
#            
#        if len(lTmp)>0:
#            sFilterCDEF = ' and '.join(lTmp)
#        else:
#            sFilterCDEF = []
#                            
#                
#        dfCyc = self.get_data(list_nodes=[[self.__sNode_cdef, sFilterCDEF], [self.__sNode_ts_startstop, []]],
#                        list_columns=['create_time', 'ID', 'channel', 'omega_mean', 'wind_mean', 'power_mean', 'start', 'stop'],
#                        how='inner')
#
#        dfFeat = self.calc_features_from_ts(dfCyc=dfCyc, feat_fct=sensor_classificator.feat_fct, kwargs = sensor_classificator.feat_kwargs)
#                
#        iPred = sensor_classificator.model.predict(data=dfFeat)
#
#        return(iPred, dfCyc, dfFeat)


    """
    predict sensor state from the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    Parameters:
    -----------    
        
    Christian Kuehnert, 2018-12-17
    """
    def predict_sensor_state(self, dfCyc = None, sensor_classificator = None):
                                                   
        dfFeat = self.calc_features_from_ts(dfCyc=dfCyc, feat_fct=sensor_classificator.feat_fct, feat_kwargs = sensor_classificator.feat_kwargs)
    
        try:                
            iPred = sensor_classificator.predict(dfFeat)
        
        except:
            print('probleme mit prediction by model, perhaps not trained and no default?')
            iPred = np.tile(np.nan, [dfCyc.shape[0],1])
                    
            
        return(iPred, dfFeat)












        




    """
    get tickets by special keywords/text parts
    
    Christian Kuehnert, 2018-12-17
    """
    def get_tickets(self, sType = ''):
        
        if sType=='check_measLines':
            # TODO 2018-12-18: zunaechst 1:1-Nachbildung der Matlab-Fkt. 'getSensorStates.m', spaeter vereinfachen/eleganter/anders machen

            if self.dfTickets.shape[0]>0:
                
                sT = self.dfTickets.loc[:,'sTitle'].copy()
                sT.replace('(Eissensor Rotorblatt)(cmrbl)(100)(BLADEcontrol)(bladecontrol)(Bladecontrol)', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                
                #dfT.strip(inplace=True)
                
                sT.replace('([rR][bB][lL])', 'RBL', regex=True, inplace=True)
                sT.replace('([fF][lL][aA][pP])', 'Flap', regex=True, inplace=True)
                sT.replace('([eE][dD][gG][eE])', 'Edge', regex=True, inplace=True)
                
                sT.replace('(((vorrangig)(vor\sallem)(v\.a\.)(v\.\sa\.))(\s)*((Edge)(Flap)))', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
#                
                sT.replace('((Rotorblatt)(Blade:*))', 'RBL', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

                sT.replace('(R\-1\/2\/3)', 'RBL1,RBL2,RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                sT.replace('(((Blatt)(RBL)R)(\s|\-)?1)', 'RBL1', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                sT.replace('(((Blatt)(RBL)R)(\s|\-)?2)', 'RBL2', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                sT.replace('(((Blatt)(RBL)R)(\s|\-)?3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                #dfT.replace('([(Blatt)|(RBL)|(RBL\-)|(R)|(R\-)]\s*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

                # Reduktion des cellarray mit den Ticket-Titeln auf die
                # Elemente, die relevante strings enthalten
                bI = sT.str.contains('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', regex=True, case=False)
#
#                % Tickets mit wenigstens einem der folgenden Ausdrücke
#                % werden ignoriert:
                sTmp = '(Falscheismeldung .*Peak ung.*nstig)' \
                    + '((alle )[0-9]*.?(ECU))' \
                    + '(alle Messprogramme)' \
                    + '(alle WEA ohne Eis am RBL)' \
                    + '((ECU).*(alle) ((im WP)(im PW))?(gleichzeitig))' \
                    + '(neue Werte alle)' \
                    + '((falsche Zeit).*( alle))' \
                    + '(nach Stromabschaltung)' \
                    + '((Datenl)((ue)(ü))(cken))' \
                    + '(keine externals)' \
                    + '(geringes Signal\-Rausch)' \
                    + '((Zuordnung).*(<->).*(Firewall vertauscht))' \
                    + '((alle)n?( WEA))'
                                        
                bI2 = sT.str.contains(sTmp, case=False, regex=True)
                
                bI3 = sT.str.contains('((RBL).*(def))', case=False, regex=True)
                
                bTmp = ~(bI | bI2) & bI3
                
                dfRel = self.dfTickets[bTmp]                                     # relevant tickets
                            

        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach
        elif sType =='check_DataAvailablility':
            
            sPatternRegEx = ['(ext.*fix)|( n\.e)|( externals )|(nicht erreichbar)|(mi[(ss)|ß]t nicht)|(keine externals)|',
                             '(eingefrorene Betriebsdaten)|(Betriebsdaten eingefroren)]']
            bTmp = sT.str.contains(sPatternRegEx, regex=True, case=False)                
            dfRel = self.dfTickets[bTmp]                                     # relevant tickets
                            


        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach        
        elif sType == 'check_TPV':
            
            sPatternRegEx = '((rbl|rotorbl*).*(def|tpv|tiefpass))'        
            bTmp = sT.str.contains(sPatternRegEx, regex=True, case=False)                
            dfRel = self.dfTickets[bTmp]                                     # relevant tickets

        else:
            print('unknown check-Type for Ticket finding')
            dfRel = pd.DataFrame(columns = self.dfTickets.columns)


        return(dfRel)
        
        
        
        
    
    
    
    
    
    