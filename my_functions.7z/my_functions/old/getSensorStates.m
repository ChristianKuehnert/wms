% structRes = getSensorStates(sDB)
%
% Anhand der Eintr�ge in den PIT-Tickets wird ermittelt, welche Sensorstrecken i.O. und welche defekt sind. Dies
% wird als Vektor [edge1, edge2, edge3, flap1, flap2, flap3] zur�ckgegeben mit Wert 0, falls die Sensorstrecke defekt ist, und 
% mit Wert 1, falls kein diesbez�glicher Eintrag vorliegt
%
% Input:
%		- sDB: vollst�ndiger Name der Datenbank
%
% Output:
%		- Struktur mit folgenden Feldern:
%           - cVars = {'edge 1', 'edge 2', 'edge 3', 'flap 1', 'flap 2',
%             'flap 3'}: konstantes cellarray mit den Namen der einzelnen
%             Kan�le, damit man die Zuordnung besser nachvollziehen
%             kann
%           - bSensorStates: 1x6-Array, ein Wert f�r jede Sensorstrecke RBL x
%             {edge, flap} in der Reihenfolge wie bei cVars (edge1, edge2, edge3, 
%             flap1, flap2, flap3), = TRUE falls kein Ticket f�r diese Sensorstrecke
%             gefunden wurde, = FALSE, wenn es mindestens ein Ticket f�r diese
%             Sensorstrecke gibt (auch wenn das/die Ticket(s) schon geschlossen
%             sind)
%           - dStartFailTimes: 1x6-Array (Reihenfolge wie bei cVars) mit den Zeiten (Matlab-Zeitformat),
%             bis zu denen kein Ticket f�r die jeweilige Sensorstrecke existiert.
%             Ist kein Ticket f�r die Sensorstrecke vorhanden, wird der Wert auf
%             Inf gesetzt. Ist ein Ticket f�r die Sensorstrecke vorhanden, wird
%             der Zeitpunkt von 'Beginnt am' bzw. -falls nicht vorhanden- von 'Erstauftreten
%             des Fehlers' genommen. Sind auch hierf�r keine Zeitangaben eingetragen,
%             wird der Wert anhand der Ticket-ID bestimmt und als allerletzte M�glichkeit
%             wird der Zeitpunkt auf NaN gesetzt.
%           - cAllTickets: alle Tickets, die zu der WEA mit der �bergebenen
%             Datenbank gefunden wurden
%           - cRelevantTickets: diejenigen Tickets, die f�r die Sensorstrecken
%             als relevant betrachtet wurden
%
%
% Christian Kuehnert, 2017-8-7
%
function structRes = getSensorStates(sDB)
          
    sSC_Ticket = 'TicketID,Titel,Erstauftreten_des_Fehlers,Beginn_am,Geschlossen_am';          % select-clause f�r die Ticket-Abfrage    
    sWC_Ticket = '';                                                            % where-clause f�r die Ticket-Abfrage
    
	try
		[cTickets, bOK] = getTicketsForWT(sDB, sSC_Ticket, sWC_Ticket);         % Abfrage der Tickets f�r die WEA mit der uebergebenen Datenbank
	        
        % gefundene Tickets analysieren
        if bOK
            
            if size(cTickets,1) > 0

                cTTitles = cTickets(:,2);                                       % Tickettitel
                % TODO 2017-6-21: trotzdem auf jeden Fall noch die
                % Ticketklasse untersuchen (und gleich schon die
                % rausnehmen, wo die richtige Sensorstrecke eingetragen ist
                
                % TODO 2017-6-21: noch vereinfachen, ohne Ersetzen (evtl. auch ohne erase) gleich
                % Indizees der gefundenen Tickets bestimmen
                cTs = cellfun(@(x) erase(x, 'Eissensor Rotorblatt'), cTTitles, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'cmrbl'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, '100'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'BLADEcontrol'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'bladecontrol'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'Bladecontrol'), cTs, 'UniformOutput', false);
                 
                cTs = cellfun(@(x) strtrim(x), cTs, 'UniformOutput', false);

                cTs = cellfun(@(x) strrep(x, 'rbl', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'Rbl', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'rBl', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'rbL', 'RBL'), cTs, 'UniformOutput', false);                                
                cTs = cellfun(@(x) strrep(x, 'rBL', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'RBl', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'flap', 'Flap'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'edge', 'Edge'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'vor allem Flap'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'vor allem Edge'), cTs, 'UniformOutput', false); 
                cTs = cellfun(@(x) erase(x, 'v.a. Flap'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'v.a. Edge'), cTs, 'UniformOutput', false); 
                cTs = cellfun(@(x) erase(x, 'v. a. Flap'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'v. a. Edge'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'vorrangig Flap'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) erase(x, 'vorrangig Edge'), cTs, 'UniformOutput', false); 
                
                cTs = cellfun(@(x) strrep(x, 'Rotorblatt', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'Blade:', 'RBL'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'Blade', 'RBL'), cTs, 'UniformOutput', false);

                cTs = cellfun(@(x) strrep(x, 'Blatt 1', 'RBL1'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'Blatt 2', 'RBL2'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'Blatt 3', 'RBL3'), cTs, 'UniformOutput', false);

                cTs = cellfun(@(x) strrep(x, 'RBL 1', 'RBL1'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'RBL 2', 'RBL2'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'RBL 3', 'RBL3'), cTs, 'UniformOutput', false);

                cTs = cellfun(@(x) strrep(x, 'RBL-', 'RBL'), cTs, 'UniformOutput', false);

                cTs = cellfun(@(x) strrep(x, 'R1', 'RBL1'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'R2', 'RBL2'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'R3', 'RBL3'), cTs, 'UniformOutput', false);

                cTs = cellfun(@(x) strrep(x, 'R-1', 'RBL1'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'R-2', 'RBL2'), cTs, 'UniformOutput', false);
                cTs = cellfun(@(x) strrep(x, 'R-3', 'RBL3'), cTs, 'UniformOutput', false);
                
                cTs = cellfun(@(x) strrep(x, 'R-1/2/3', 'RBL1,RBL2,RBL3'), cTs, 'UniformOutput', false);
  
                % Reduktion des cellarray mit den Ticket-Titeln auf die
                % Elemente, die relevante strings enthalten
                bI = cell2mat(cellfun(@(x) isempty(regexp(x, '(RBL)|(alle )|( allen)|((Sensoren )*( falsch angeschlossen))|(vertausch)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false));
                cTs = cTs(~bI);
                idxRel = find(~bI);

                % Tickets mit wenigstens einem der folgenden Ausdr�cke
                % werden ignoriert:
                bI2 = all([cell2mat(cellfun(@(x) isempty(regexp(x, '(Falscheismeldung .*Peak ung.*.*nstig)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(alle )[0-9]*.?(ECU)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(alle Messprogramme)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(alle WEA ohne Eis am RBL)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(ECU).*(alle) (im WP|im PW)? (gleichzeitig)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(neue Werte alle)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(falsche Zeit).* (alle)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(nach Stromabschaltung)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(Datenl)(ue|�)(cken)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(keine externals)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(geringes Signal-Rausch)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(Zuordnung).*(<->).*(Firewall vertauscht)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
                      cell2mat(cellfun(@(x) isempty(regexp(x, '(alle)[n]? (WEA)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false))], 2);
                                
                  
                if ~any(bI2,1)                                  % wenn keines der Tickets relevant ist ...
                    
                     bOK = true(1,6);
                     cRelevantTickets = {};
                     dStartFailTimes = inf(1,6);
    
                else                                            % andernfalls ...

                    cTs = cTs(bI2);
                    cRelevantTickets = cTickets(idxRel(bI2),:);       % TODO 2017-6-23: evtl. noch weiter einschraenken auf die Tickets, die zum u.g. bOK beitragen

                    
                    %% Ableitung der Sensorstates aus den relevanten Tickets
                    % Tickets mit Teilstrings, die darauf schlie�en lassen,
                    % dass sie alle Sensorstrecken betreffen
                    bAll = ~cell2mat(cellfun(@(x) isempty(regexp(x, 'alle', 'match', 'ignorecase', 'ONCE')), cTs, 'UniformOutput', false));

                    % Tickets mit Teilstrings, die darauf schlie�en lassen,
                    % dass sie nur einzelne Rotorbl�tter betreffen
                    bRBL = ~cell2mat(cellfun(@(x) isempty(regexp(x, '( RBL)|(RBL )', 'match', 'ignorecase', 'ONCE')), cTs, 'UniformOutput', false));
                    
                    % Auswertung f�r die einzelnen Rotorbl�tter
                    b1 = ~cellfun(@(x) isempty(strfind(x, 'RBL1')), cTs);
                    b2 = ~cellfun(@(x) isempty(strfind(x, 'RBL2')), cTs);
                    b3 = ~cellfun(@(x) isempty(strfind(x, 'RBL3')), cTs);

                    bRBL = bRBL & ~(b1 | b2 | b3);                                          % wenn nur "RBL" vorkommt, z.B. "diverse RBL" in Ticket 201007-004
                    
                    % Auswertung nach Edge/Flap-Richtung
                    bEdge = ~cellfun(@(x) isempty(strfind(x, 'Edge')), cTs);
                    bFlap = ~cellfun(@(x) isempty(strfind(x, 'Flap')), cTs);

                    % weitere Pr�fung auf Tickets, die f�r alle
                    % Rotorbl�tter relevant sein k�nnten
                    bAll2 = ~cell2mat(cellfun(@(x) isempty(regexp(x, '(vertausch)', 'match', 'ignorecase', 'ONCE')), cTs, 'UniformOutput', false)) & bEdge & bFlap & ~(b1 | b2 | b3);
                    
                    % Hilfsgr��en
                    bTmp = bAll | bRBL;
                    bE = bEdge | ~bFlap;
                    bF = ~bEdge | bFlap;
                                 
                    % Bestimmung der Sensor-Zust�nde der einzelnen
                    % Messstrecken
                    b1E = ((b1 | bTmp) & bE) | bAll2;
                    b2E = ((b2 | bTmp) & bE) | bAll2;
                    b3E = ((b3 | bTmp) & bE) | bAll2;
                    b1F = ((b1 | bTmp) & bF) | bAll2;
                    b2F = ((b2 | bTmp) & bF) | bAll2;
                    b3F = ((b3 | bTmp) & bF) | bAll2;

                    bAllSensors = [b1E, b2E, b3E, b1F, b2F, b3F];           % which tickets (rows) contain information about which blades x direction (cols)
                    bOK = ~any(bAllSensors, 1);
                    
                    %% Bestimmung der Zeiten, bis zu welchen die Sensorstrecken als ok angesehen werden
                    % TODO 2017-6-23: viell. spaeter vektorisieren   
                    dStartFailTimes = inf(1,6);
                    dT = nan(size(cRelevantTickets, 1),1);
                    
                    % Schleife �ber alle relevanten Tickets
                    for iRow = 1:size(cRelevantTickets,1)

                        try
                            sTmp = cRelevantTickets{iRow,3};                            
                            
                            % 1.) Versuch, den Eintrag bei 'Beginn_am' als
                            % Zeitpunkt zu nehmen
                            if ~strcmp(sTmp, '0.0')                    
                                dT(iRow) = datenum(sTmp, 'yyyy-mm-dd HH:MM:SS');                      
                            else
                                % 2.) Versuch, den Zeitpunkt von 'Ticket
                                % erstellt am' zu verwenden
                                sTmp = cRelevantTickets{iRow,4};
                                if ~strcmp(sTmp, '0.0')                    
                                    dT(iRow) = datenum(sTmp, 'yyyy-mm-dd HH:MM:SS');                      
                                else
                                    % 3.) Versuch, Zeitpunkt aus der
                                    % 'TicketID' abzuleiten
                                    sTmp = cRelevantTickets{iRow,1};
                                    dT(iRow) = datenum(sTmp(1:4),sTmp(5:6),1)-30;       % -30 als Sicherheitspuffer
                                end
                            end
                            
                        catch ME
                            disp([ME.identifier, ': ', ME.message]); 
                        end

                    end
                                                
                    for iIdx = find(~bOK)
                        dStartFailTimes(iIdx) = min(dT(bAllSensors(:,iIdx)));
                    end
                    
                end
            else
                bOK = true(1,6);
                dStartFailTimes = inf(1,6);
                cRelevantTickets = {};
            end
        else
            
            % Wenn das Auslesen der Tickets nicht erfolgreich war, werden
            % sicherheitshalber alle Messstrecken als defekt angenommen
            bOK = false(1,6);
            dStartFailTimes = -inf(1,6);
            cTickets = {};                                
            cRelevantTickets = {};

        end
        	
    catch ME
        
        % Wenn irgendein unbekannter Fehler auftritt, werden
        % sicherheitshalber alle Messstrecken als defekt angenommen
        warning([ME.identifier, ': ', ME.message]);
        
        bOK = false(1,6);
        dStartFailTimes = -inf(1,6);
        cTickets = {};
        cRelevantTickets = {};
        
    end
    
    % R�ckgabeobjekt
    structRes.cVars = {'edge 1', 'edge 2', 'edge 3', 'flap 1', 'flap 2', 'flap 3'};
    structRes.bSensorStates = bOK;
    structRes.dStartFailTimes = dStartFailTimes;
    structRes.cAllTickets = cTickets;
    structRes.cRelevantTickets = cRelevantTickets;
    
end
