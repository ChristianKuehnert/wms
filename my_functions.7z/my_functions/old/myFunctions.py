# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 11:27:42 2018

@author: w012028
"""
    
import sys
import scipy.io
import gc
import math
import pandas as pd
import numpy as np
import os
import os.path
import fnmatch
import matplotlib.pyplot as plt  
#import seaborn as sb
import datetime as dt
import warnings

#import h5py

from os import listdir
from scipy import stats
from statsmodels.tsa.stattools import acf  #, pacf
from textwrap import wrap

from sklearn.linear_model import LinearRegression
from sklearn.metrics import precision_recall_fscore_support
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.model_selection import GridSearchCV
from sklearn.decomposition import PCA

from matplotlib.dates import date2num
    






#
# function to calculate the moving average
#
# Christian Kuehnert, 2018-9-3
# 
def movingAvg(dfTS, iSizeWdw, iAxis):
    return dfTS.rolling(iSizeWdw, center=True, axis=iAxis).mean()    # moving average



#
# function to calculate the angular speed from the time series
#
# Christian Kuehnert, 2018-9-3
#
def calcOmega(dfTS, iSizeWdw = 1000, dR2Ok = 0.9):
        
    # TODO 2018-8-31: ggf. noch die "abgeschnittenen" oberen und unteren Ausschlaege ausschliessen

    # alte Version:
    #df_maTS = dfTS.rolling(iSizeWdw, center = True, axis = 1).mean()    # moving average                       
    #df_d1_maTS = pd.DataFrame(data=np.diff(df_maTS, n=1, axis=1), columns = df_maTS.columns[1:])     # 1st derivative of mov. avg.                
    #df_d2_maTS = pd.DataFrame(data=np.diff(df_d1_maTS, n=1, axis=1), columns = df_d1_maTS.columns[1:])  # 2nd derivative of mov. avg.     
    #dfOmega = np.sqrt(-df_d2_maTS[2:] / df_maTS)            # calc. a^.. / a for omega            
    ##dfA0 = df_d1TS * df_d1TS + df_d2TS * df_d2TS

    
    #dTS0 = dTS - mean(dTS)              # move ts to mean=0    
    #dTS0 = dTS
    dTS_ma = movingAvg(dfTS, iSizeWdw, 0).values   # smoothing/low-pass filter
    #iCnt = dfTS_ma.shape[0]
    dt2dTS_ma = np.asarray(np.diff(dTS_ma, n=2, axis=0))    # calc second derivative
         
    ## regress 2nd derivative vs. original time series
    model = LinearRegression(fit_intercept = False)
    
    # TODO 2018-9-4: geht auch noch einfacher, halbe Windowsize abziehen jeweils (auch bei diff-TS, dort noch 2 zusaetzlich)
    dTS_ma = dTS_ma[2:]
    bMask = np.isfinite(dt2dTS_ma) & np.isfinite(dTS_ma)            # indicator for vector elements that are not nan
    
    dX = dt2dTS_ma[bMask,][:,np.newaxis]
    dy = dTS_ma[bMask,][:,np.newaxis]
    model.fit(dX, dy)
    dOmega = np.sqrt(-model.coef_[0][0])
    dR2 = model.coef_.score(dX, dy)
    
    # if regression is good enough return sqrt of coefficient, otherwise nan
    return {'dOmega': dOmega, 'dR2': dR2}
  

    


# einfache Nachbildung der datenum-Funktion aus Matlab, uebernommen von:
def datenum(iY, iM, iD, iHr=0, iMin=0, iSec=0, iMSec=0):
        
    dDT = dt.datetime(iY, iM, iD, iHr, iMin, iSec, iMSec) + dt.timedelta(days = 366)  
    return date2num(dDT)
    



# function that applies the tests to a time series and returns False if the ts indicates a failure and True otherwise
# input:
#       - dData: 1 row containing the production data and the time series
def isOk(dTS):
    
    iSizeWdw = 1000             # length of moving average window
    dThres_SEtot = 100              # threshold for max.value of signal energy for defect sensor line
    dThres_SEslope = 20
    dThres_SEsigmaMA = 100        
    iMaxLag = 20
    
    
    dSEtot, dSEslope, dSEsigmaMA = calcSEprop(dTS)    

    bOk = (dSEtot > dThres_SEtot) & (dSEslope < dThres_SEslope) & (dSEsigmaMA > dThres_SEsigmaMA)

    if bOk:
        dACF = np.asarray(acf(dTS, nlags=iMaxLag))
        dPACF = np.asarray(pacf(dTS, nlags=iMaxLag))
        
        bOk = predict(dACF, dPACF)
        
    return bOk






# function that applies the tests to a time series and returns False if the ts indicates a failure and True otherwise
# input:
#       - dData: 1 row containing the production data and the time series
def isOk(dTS):
    
    iSizeWdw = 1000             # length of moving average window
    dThres_SEtot = 100              # threshold for max.value of signal energy for defect sensor line
    dThres_SEslope = 20
    dThres_SEsigmaMA = 100        
    iMaxLag = 20
    
    
    dSEtot, dSEslope, dSEsigmaMA = calcSEprop(dTS)    

    bOk = (dSEtot > dThres_SEtot) & (dSEslope < dThres_SEslope) & (dSEsigmaMA > dThres_SEsigmaMA)

    if bOk:
        dACF = np.asarray(acf(dTS, nlags=iMaxLag))
        dPACF = np.asarray(pacf(dTS, nlags=iMaxLag))
        
        bOk = predict(dACF, dPACF)
        
    return bOk

    
def f(b, X, y):    
    return(np.linalg.norm(predictDiffQuant_d1(X, b)-y))




# predictor for skewness-method, input are already-calculated quantiles!
# 
# Christian Kuehnert, 2018-9-11
#
def predictDiffQuant_d1(dDiffQuant_d1, b):

    iRes = np.array([int(np.abs(dQ) > b) for dQ in dDiffQuant_d1])
    iRes = np.reshape(iRes, (len(iRes), 1))
    #iRes = int(dDiffQuant_d1^2 - np.tile(b^2, [dDiffQuant_d1.shape[0],1]))
    return(iRes)


#
# function to make it easier to find index of some boolean list
#
# Christian Kuehnert, 2018-8-13
#
def findIdx(bList):
    iIdx = [i for i, x in enumerate(bList) if x]
    return iIdx


# classificator
def iClassificator(dfTS):
	# TODO 2018-8-11: Einzelberechnungen fuer dfSEtot usw. in einzelne Funktionen auslagern, dann hier nacheinander berechenen und
	# immer sofort bewerten, um schneller zu sein (acf-Berechnung nicht notwendig, wenn schon anhand dSEtot erkannt, dass falsch)
	dfX, dSEtot, dSEvarMA, dACF_d1 = analyseData(dfTS, 50)

	if (dSEtot < dSEtot_thres) & (dSEvarMA > dSEvarMA_thres) & bPredict(dACF_d1):
		iRes = 0
	else:
		iRes = 1
	
	return(iRes)




# read in successively the data for the turbines given in sTurbineDBs and classify them, returning scores, images etc., also total score
def classifyData(sFN_hd5, mModel):

    dfData = readHD5(sFN_hd5, 'data')       # read in file
    
    dfX = dfData # ....
    dfLab = dfData.label	
    
    
    dfPred = mModel.predict(dfX)    
    dAcc = mModel.accuracy(dfPred, dfLab)
    
    return(dfPred, dAcc)
    
    
    

#
# function to compare the predicted results with the given labels
# iPred and iLabel must have the same size
#
# Christian Kuehnert, 2018-9-11
#    
def comparePrediction(iPred, iLabel):

    b00 = (iPred == 0) & (iLabel == 0)       # true negatives
    b01= (iPred == 0) & (iLabel == 1)        # false negatives
    b10 = (iPred == 1) & (iLabel == 0)       # false positives
    b11 = (iPred == 1) & (iLabel == 1)       # true positives
    iN = len(iPred)

    return([b00, b01, b10, b11, iN])
    

    

    
    
# function that takes all ts files of database sDB (not only standing but containing all time series!), calculates the features from them, adds labels
# (if available) and stores all into a new file containing the features for machine learning
#
# Christian Kuehnert, 2018-8-17
#
# TODO: Hier weiter 2018-8-17
# HIERBEI gleich so machen, dass von den "richtigen" files (die alles enthalten, zukuenftig auch die .TS-files) ausgegangen wird, 
# evtl. wird von dort ein Schritt noch in Matlab gemacht, dann aber alles hier)
def tsFile2featuresFile(sDB, sPathData, sPathSave, sPatternTS, sEndingFeat, iMaxLag, iWndwSize):
       
    
# TODO 2018-8-17: alles noch zusammenfuegen zu einer Funktion, sind erstmal die 3 Teile aus versuchePython.py hierherkopiert    
               
    sFiles = listdir(sPathData)
    #sPattern0 = '*_ts*.mat'
    sPattern0 = 'cmrblba_bc_t_01305_strain_ts.mat'
    sFiles = fnmatch.filter(sFiles, sPattern0)
       
    for sFN0 in sFiles:
    
        sFN = sPathData + '\\' + sFN0
        print(sFN)
                        
        tmp = scipy.io.loadmat(sFN)
            
        structData = tmp['structTS']
        del tmp
           
        dfData = pd.DataFrame(structData[0,0][1])            
        del structData
                        
        sFN_csv = sFN[:-4] + '_headers.csv'
        tmp = pd.read_csv(sFN_csv)
        sHeadersCDEF = list(tmp.sHeadersCDEF)
    
        iColChannel = len(sHeadersCDEF)
                                                   
        iMeasTime = dfData.shape[1] - 1- iColChannel
    
        sHeadersTS = [str(i) for i in range(iMeasTime)]
    
        dfData.columns = sHeadersCDEF + ['channel'] + sHeadersTS 
             
        # filter for standing mode (not yet by pitch, this can be done later)
        bIdx = (dfData.power_mean < 0) & (dfData.omega_mean < 0.05)
               
        dfData = dfData[bIdx]
                                                
        #hf = h5py.File(sFN_hd5, 'w')
        #hf.create_dataset('standing', data=dfData, compression="gzip", compression_opts=9)
        sFN = sFN[:-4] + '_standing.hd5'        
    
        mf.writeHD5(dfData, 'data', sFN)
        
        del(dfData)
                        
#    except Exception as ex:
        # do nothing
#        print('error occurred')
                    
    gc.collect()
        

    

    
    
    
    sHeadersChannel = 'channel'
                
    sFiles = listdir(sPathData)
    sFiles = fnmatch.filter(sFiles, sPattern)    

    for sFN0 in sFiles:
            
        sFN = sPathData + '\\' + sFN0
        
        print(sFN)
        
        sFN_hd5 = sFN[:-4] + '_SE_acf.hd5'
        
        if os.path.isfile(sFN_hd5):
            
            print('schon vorhanden!')
            
        else:
            
            dfData = mf.readHD5(sFN, 'data')	
        
            iN = dfData.shape[0]
            if iN>0:
                sTmp = list(dfData.columns)
                iColChannel = findIdx([sHeadersChannel == sStr for sStr in sTmp])[0]
                iColStartTS = iColChannel + 1
                sHeadersCDEF = sTmp[:iColChannel]
                                                             
                sDB = mf.readHD5(sFN, 'db').db.values
                                    
                dfDB = pd.DataFrame(np.tile(sDB, (iN, 1)), columns = ['db'])                  # database name
                                
                dfCDEF = dfData.loc[:,sHeadersCDEF+[sHeadersChannel]]
                                                
                dfSEtot, dfSEvarMA, dfACF_d1 = mf.analyseData(dfData.iloc[:, iColStartTS:], iMaxLag, iSizeWdw)                                
                            
                # Speichern
                dfWS = pd.DataFrame([iSizeWdw], columns=['window_size'])
                mf.writeHD5(dfWS, 'window_size', sFN_hd5)                   # Parameter abspeichern
                del(dfWS)
    
                mf.writeHD5(dfDB, 'db', sFN_hd5)
                del(dfDB)
                
                mf.writeHD5(dfCDEF, 'cdef', sFN_hd5)
                del(dfCDEF)
                
                mf.writeHD5(dfSEtot, 'SEtot', sFN_hd5)
                del(dfSEtot)
                
                mf.writeHD5(dfSEvarMA, 'SEvarMA', sFN_hd5)
                del(dfSEvarMA)
                
                mf.writeHD5(dfACF_d1, 'acf', sFN_hd5)
                del(dfACF_d1)
                
                gc.collect()

	


    #sDBs = ['cmrblba_vid_reinsdorf', 'cmrblba_bc_t_00922']          # list of turbines to be included
    #sDBs =  ['cmrblba_vid_reinsdorf']
    sDBs = ['cmrblba_bc_t_02006']

    sFN_hd5 = sPathData + '\\allWT_standingOnly_ts.hd5'
    
    # try to read
    dfData = mf.readHD5(sFN_hd5, 'data')

    # TODO 2018-8-13: hd5-Daten entsprechend umaendern
	#if os.path.isfile(sFN_hd5):
        
        #hf = h5py.File(sFN_hd5, 'r')
        ##sKey = list(hf.keys())[0]
        ##dfData = pd.read_hdf(sFN_hd5, sKey)
        #dfDB = pd.read_hdf(sFN_hd5, 'db')
        #dfData = pd.read_hdf(sFN_hd5, 'data')
        #del hf
		
    # if no file with combined standing data exists, then load separately for every turbine, update labels and 
    # combine them (and store result into new combined file)
    if not dfData:									# if file could not be read 	        

        iMaxLag = 10

        #sPattern = '_standing_SE_acf.hd5'
        
        
                
        sFilesAll = listdir(sPathData)
            
        # loop through databases
        for sDB in sDBs:
            
            print(sDB)
                                    
            sPattern = sDB + '*_standing_SE_acf.hd5'            
        
            sFiles = fnmatch.filter(sFilesAll, sPattern)       # files for this database
            sFiles.sort()                                       # TODO 2018-8-16: noch richtig sortieren, d.h. '10' NACH '9'
                        
            
            if len(sFiles)>1:
                
                lDB = []
                lCDEF = []
                lData = []                  # list of data, complete with database names and labels (in 1st col.)
                lLabel = []                    # list of 
                lSEtot = []
                lSEvarMA = []
                lACF_d1 = []        

                for sFN0 in sFiles:
                
                    sFN = sPathData + '\\' + sFN0
                
                    print(sFN)
    
                    #sDB = mf.readHD5(sFN, 'db').db.values
                           
                    # at first supervised learning, so labels are necessary
                    #if dfLab:
                         
                    dfSEtot = mf.readHD5(sFN, 'SEtot')			
                    dfSEvarMA = mf.readHD5(sFN, 'SEvarMA')
                    dfACF_d1 = mf.readHD5(sFN, 'acf')
                        
                    dfCDEF = mf.readHD5(sFN, 'cdef')
                    dfDB = mf.readHD5(sFN, 'db')
                        
                        
                        # filter for standing mode
                        #bIdx = (dfData.iloc[:,iColPowerMean] < 0) & (dfData.iloc[:, iColOmegaMean] < 0.05) & (dfData.iloc[:, iColPitchMean] > 30)
                        #bIdx = (dfData.power_mean < 0) & (dfData.omega_mean < 0.05) & (dfData.pitch_mean > 30)
                
                        #if any(bIdx):         
                                                             
                        #dfData = dfData[bIdx]   
                        
    #                    dfData, dfLab = mf.addLabelsToData(dfData, dfLab, ['create_time', 'ID', 'channel'], ['label'])                          # labels mit angehaengten dfData
    #                    iIdx = dfData.index
                        
    #                    iN = dfData.shape[0]
    #                    if (iN > 0):
                            #sDB = sFiles[i].replace(sPattern, '')
                            #lDB.append(pd.DataFrame(np.tile(sDB, (iN, 1)), columns = ['db']))                   # database name
                    lDB.append(dfDB)
                            #lData.append(dfData)
                            #lLabel.append(dfLab.label)    
                    #lLabel.append(dfLab)
                            
                            #lCDEF.append(dfData.loc[:,sHeadersCDEF+sHeadersChannel])
                    lCDEF.append(dfCDEF)
                                            
                            #dfX, dSEtot, dSEvarMA, dACF_d1 = analyseData(dfData.iloc[:, iColStartTS:], iMaxLag, iSizeWdw)                                
                            #lSEtot.append(dSEtot)
                    lSEtot.append(dfSEtot)
                            #lSEvarMA.append(dSEvarMA)
                    lSEvarMA.append(dfSEvarMA)
                            #lACF_d1.append(dACF_d1)
                    #lACF_d1.append(dfACF_d1.iloc[:,0:iMaxLag])
                    lACF_d1.append(dfACF_d1)
                    
                                 
                gc.collect()
            
            
            # now combine all findings
            #del dfData
            #del bIdx
            #del dfX
            #gc.collect()
            #dfData = pd.DataFrame(np.column_stack((np.vstack(lDB), np.vstack(lData))), columns = 'db' + sHeadersCDEF + sHeadersChannel + sHeadersTS)
        
            #dfData = pd.DataFrame(np.vstack(lData), columns = ['db'] + sHeadersCDEF + sHeadersChannel + ['label'] + sHeadersTS)
            #dfX = np.vstack(lX)
            #del lData    
            #dfDB = pd.DataFrame(np.vstack(lDB), columns = ['db'])        
            dfDB = pd.concat(lDB)
            del lDB    
            
            #dfCDEF = pd.DataFrame(np.vstack(lCDEF), columns = sHeadersCDEF + sHeadersChannel)        
            dfCDEF = pd.concat(lCDEF)
            del lCDEF
            
            #dfSEtot = pd.DataFrame(np.vstack(lSEtot), columns = ['SEtot'])
            dfSEtot = pd.concat(lSEtot)
            del lSEtot 
            
            #dfSEvarMA = pd.DataFrame(np.vstack(lSEvarMA), columns = ['SEvarMA'])
            dfSEvarMA = pd.concat(lSEvarMA)
            del lSEvarMA
            
            #sHeaders = [str(i) for i in range(iMaxLag)[1:]]
            #dfACF_d1 = pd.DataFrame(np.vstack(dACF_d1), columns = sHeaders)
            dfACF_d1 = pd.concat(lACF_d1)
            del lACF_d1
        
        #dfLabel = pd.DataFrame(np.vstack(lLabel), columns = ['label'])
        #dfLabel = pd.concat(lLabel)
        #del lLabel
        
           
        # now synchronize data with label-values        
        dfLab = mf.loadLabels(sPathData + '\\' + sDB + '_tabLabels.csv')
        
        dfCDEF.reset_index()        
        #dfCDEF, dfLab = mf.addLabelsToData(dfCDEF, dfLab, ['create_time', 'ID', 'channel'], ['label'])
        dfLab = mf.synchronizeLabels(dfCDEF, dfLab, ['create_time', 'ID', 'channel'], ['label'])
        iIdx = dfCDEF.index

        dfDB.reset_index
        dfDB.iloc[iIdx,:]
        
        dfSEtot.reset_index
        dfSEtot.iloc[iIdx,:]
        
        dfSEvarMA.reset_index
        dfSEvarMA.iloc[iIdx,:]
        
        dfACF_d1.reset_index
        dfACF_d1.iloc[iIdx,:]
                
        
        gc.collect()
        
        # Zwischenspeichern
        #with pd.HDFStore(sFN_hd5, 'w') as hf:
        #    dfDB.to_hdf(hf, 'db', complevel=9)
        #    dfData.to_hdf(hf, 'data', complevel=9) 
        mf.writeHD5(dfDB, 'db', sFN_hd5)
        mf.writeHD5(dfCDEF, 'cdef', sFN_hd5)
        mf.writeHD5(dfSEtot, 'SEtot', sFN_hd5)
        mf.writeHD5(dfSEvarMA, 'SEvarMA', sFN_hd5)
        mf.writeHD5(dfACF_d1, 'acf', sFN_hd5)
        mf.writeHD5(dfLab, 'label', sFN_hd5)
        
 

 
    




    
# function that takes ts-DataFrame and calculates the features-dataframes
#
# Christian Kuehnert, 2018-8-31
#
def ts2features_old(dfTS, iSizeWdw, iMaxLag):
                               
    iN = dfTS.shape[0]
    if iN>0:                                            
                
        dfSEtot, dfACF_d1 = analyseData2(dfTS, iSizeWdw, iMaxLag)                                
                            
    else:
        dfSEtot = pd.DataFrame()
        dfACF_d1 = pd.DataFrame()
        
    return {'dfSEtot': dfSEtot, 'dfACF_d1':dfACF_d1}
      
    
    
    
    
# function that takes data-DataFrame (including cdef-data + channels + ts) and splits it into cdef, channels and acf(ts)
#
# Christian Kuehnert, 2018-8-23
#
def data2features(sDB, dfData, sHeadersChannel, iSizeWdw, iMaxLag):
                               
    iN = dfData.shape[0]
    if iN>0:
        sTmp = list(dfData.columns)
        iColChannel = findIdx([sHeadersChannel == sStr for sStr in sTmp])[0]
        iColStartTS = iColChannel + 1
        sHeadersCDEF = sTmp[:iColChannel]
                                            
        dfDB = pd.DataFrame(np.tile(sDB, (iN, 1)), columns = ['db'])                  # database name
                                
        dfCDEF = dfData.loc[:,sHeadersCDEF+[sHeadersChannel]]
                
        #dfSEtot, dfSEvarMA, dfACF_d1 = analyseData(dfData.iloc[:, iColStartTS:], iMaxLag, iSizeWdw)                                
        dfSEtot, dfACF_d1 = analyseData(dfData.iloc[:, iColStartTS:], iMaxLag)                                
                            
    else:
        dfDB=pd.DataFrame(np.tile(sDB, (1,1)), columns = ['db'])
        dfCDEF = pd.DataFrame()
        dfSEtot = pd.DataFrame()
        #dfSEvarMA = pd.DataFrame()
        dfACF_d1 = pd.DataFrame()
        
    #return {'dfDB': dfDB, 'dfCDEF': dfCDEF, 'dfSEtot': dfSEtot, 'dfSEvarMA': dfSEvarMA ,'dfACF_d1':dfACF_d1}
    return {'dfDB': dfDB, 'dfCDEF': dfCDEF, 'dfSEtot': dfSEtot, 'dfACF_d1':dfACF_d1}
	
#
# Christian Kuehnert, 2018-8-21
#
# TODO: schneller und eleganter machen!
def ismember2(A,B):
    tmp=[any(np.isin(np.array(A), i)) for i in np.array(B)]
    return findIdx(tmp)

	
    
    
    


def analyseData_old(dfData, iColChannel, iMeasTime, iMaxLag):
    
    iColStartTS = iColChannel + 1
    iColEndTS = iMeasTime + iColChannel + 1
    #iColChannel=46
    #iColTime=4

    iCnt = dfData.shape[0]
        
    dTS = dfData.iloc[:,iColStartTS:iColEndTS]        
    #dTS = dfData.iloc[:,iColStartTS:]
        
    #iLenTS = dTS.shape[1]

    dCDEF = np.asarray(dfData.iloc[:,0:iColChannel])
        
    #dTime = dfData.iloc[:,iColTime]
    dChannel = np.asarray(dfData.iloc[:,iColChannel])
        
    dSEtot = np.asarray([np.dot(dTS.iloc[i,:], dTS.iloc[i,:]) for i in range(iCnt)])                                        # total signal energy
    dVarMA = np.asarray([np.std(np.convolve(dTS.iloc[i,:], np.ones(iSizeWdw,)/iSizeWdw, mode='valid')) for i in range(iCnt)])   # std. of moving average
    dSEslope = np.asarray([max(abs(np.diff(dTS.iloc[i,:], 1))) for i in range(iCnt)])                                       # max. slope within ts
    dSEprop = np.c_[dSEtot, dVarMA, dSEslope]
                
    #dACF = np.asarray([acf(dTS.iloc[i,:], nlags=iMaxLag) for i in range(iCnt)])
    #dPACF = np.asarray([pacf(dTS.iloc[i,:], nlags=iMaxLag) for i in range(iCnt)])
    dACF = np.asarray([acf(np.diff(dTS.iloc[i,:], n=1, axis=-1), nlags=iMaxLag) for i in range(iCnt)])
    dPACF = np.asarray([pacf(np.diff(dTS.iloc[i,:], n=1, axis=-1), nlags=iMaxLag) for i in range(iCnt)])

    return {'dCDEF': dCDEF, 'dChannel': dChannel, 'dSEprop': dSEprop, 'dACF': dACF, 'dPACF': dPACF}
    #yield dCDEF
    #yield dChannel
    #yield dSEprop
    #yield dACF
    #yield dPACF
    



#
# function to calculate the direct input into machine learning from time series
#
# 2018-8-23
#
#def analyseData(dfTS, iMaxLag, iSizeWdw):
def analyseData(dfTS, iMaxLag):    
 
    iCnt = dfTS.shape[0]
               
    dSEtot = np.asarray([np.dot(dfTS.iloc[i,:], dfTS.iloc[i,:]) for i in range(iCnt)])                                        # total signal energy
    #dSEvarMA = np.asarray([np.std(np.convolve(dfTS.iloc[i,:], np.ones(iSizeWdw,)/iSizeWdw, mode='valid')) for i in range(iCnt)])   # std. of moving average
    #dSEprop = np.c_[dSEtot, dVarMA]
                
    #dACF = np.asarray([acf(dfTS.iloc[i,:], nlags=iMaxLag) for i in range(iCnt)])
    #dPACF = np.asarray([pacf(dfTS.iloc[i,:], nlags=iMaxLag) for i in range(iCnt)])
    iIdx = range(1, iMaxLag+1)
    
    dACF_d1 = np.asarray([acf(np.diff(dfTS.iloc[i,:], n=1, axis=-1), nlags=iMaxLag)[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
    #dPACF_d1 = np.asarray([pacf(np.diff(dTS.iloc[i,:], n=1, axis=-1), nlags=iMaxLag) for i in range(iCnt)])

    sHeaders = list(['acf_d1_lag' + str(i) for i in iIdx])
    
    ##dfX = pd.DataFrame(pd.transpose(pd.vstack((dSEtot, dSEvarMA, dACF, dPACF, dACF_d1, dPACF_d1), column=['SEtot', 'SEvarMA', sHeaders])))   
    #dfX = pd.DataFrame(pd.transpose(pd.vstack((dSEtot, dSEvarMA, dACF_d1), column=['SEtot', 'SEvarMA', sHeaders])))   
    #dfX = pd.DataFrame(np.column_stack((dSEtot, dSEvarMA, dACF_d1)), columns=['SEtot', 'SEvarMA'] + sHeaders)
    #return(dfX)
    #return {'dfX': dfX, \
    #return {'dSEtot': pd.DataFrame(dSEtot, columns=['SEtot']), 'dSEvarMA': pd.DataFrame(dSEvarMA, columns=['SEvarMA']), 'dACF_d1': pd.DataFrame(dACF_d1, columns=sHeaders)}
    #return [pd.DataFrame(dSEtot, columns=['SEtot']), pd.DataFrame(dSEvarMA, columns=['SEvarMA']), pd.DataFrame(dACF_d1, columns=sHeaders)]
    return [pd.DataFrame(dSEtot, columns=['SEtot']), pd.DataFrame(dACF_d1, columns=sHeaders)]





#
# function to calculate the direct input into machine learning from time series
#
# 2018-10-11
#
def calcFeatures(dfTS, sListFeatures, iSizeWdw=100, iMaxLag=20):

    dictRes = {}
    
    iCnt = dfTS.shape[0]
    iIdx = range(1, iMaxLag+1)
    
    sHeaders_TS = list(['acf_TS_lag' + str(i) for i in iIdx])
    sHeaders_diffTS = list(['acf_diffTS_lag' + str(i) for i in iIdx])
    sHeaders_d1TS = list(['acf_d1TS_lag' + str(i) for i in iIdx])
    sHeaders_d1_diffTS = list(['acf_d1_diffTS_lag' + str(i) for i in iIdx])
    
    
    ## calc features
    if ('diffTS' in sListFeatures) or ('dACF_d1_diffTS' in sListFeatures) or ('dACF_diffTS' in sListFeatures) or ('ratioVar' in sListFeatures) or ('varTrend' in sListFeatures) or ('varResiduals' in sListFeatures):
        df_maTS = dfTS.rolling(iSizeWdw, center = True, axis = 1).mean()                            # moving average                       
        df_diffTS = dfTS - df_maTS                                                                  # difference to moving average                

    if 'SEtot' in sListFeatures:          
        dictRes['dfSEtot'] = pd.DataFrame(np.asarray([np.dot(dfTS.iloc[i,:], dfTS.iloc[i,:]) for i in range(iCnt)]), columns=['SEtot'])          # total signal energy

    if 'diffTS' in sListFeatures:
        dictRes['df_diffTS'] = df_diffTS
        
    if 'dACF_TS' in sListFeatures:
        dictRes['df_dACF_TS'] = np.asarray([acf(dfTS.iloc[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)], columns = sHeaders_TS)     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
        
    if 'dACF_d1TS' in sListFeatures:
        dictRes['dfACF_d1TS'] = pd.DataFrame(np.asarray([acf(np.diff(dfTS, n=1, axis=1)[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)]), columns=sHeaders_d1TS)         # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
        
    if 'dACF_d1_diffTS' in sListFeatures:
        dictRes['dfACF_d1_diffTS'] = pd.DataFrame(np.asarray([acf(np.diff(df_diffTS, n=1, axis=1)[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)]), columns=sHeaders_d1_diffTS)          # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
        
    if 'dACF_diffTS' in sListFeatures:
        dictRes['dfACF_diffTS'] = pd.DataFrame(np.asarray([acf(df_diffTS.iloc[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)]), columns=sHeaders_diffTS)        # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
                
    if 'ratioVar' in sListFeatures:
        d_ratioVar = np.asarray(np.var(df_diffTS, axis=1)/np.var(df_maTS, axis=1))
        dictRes['df_ratioVar'] = pd.DataFrame(d_ratioVar, columns = ['ratioVar'])

    if 'varTrend' in sListFeatures:
        d_varTrend = np.asarray(np.var(df_maTS, axis=1))
        dictRes['df_varTrend'] = pd.DataFrame(d_varTrend, columns = ['varTrend'])

    if 'varResiduals' in sListFeatures:
        d_varResiduals = np.asarray(np.var(df_diffTS, axis=1))
        dictRes['df_varResiduals'] = pd.DataFrame(d_varResiduals, columns = ['varResiduals'])

    
    return dictRes


#
# function to calculate the direct input into machine learning from time series
#
# 2018-8-31
#
#def calcFeatures_old(dfTS, iSizeWdw, iMaxLag):
#
#    iCnt = dfTS.shape[0]
#    iIdx = range(1, iMaxLag+1)
#    
#    ## calc features
#    dSEtot = np.asarray([np.dot(dfTS.iloc[i,:], dfTS.iloc[i,:]) for i in range(iCnt)])          # total signal energy
#
#    df_maTS = dfTS.rolling(iSizeWdw, center = True, axis = 1).mean()                            # moving average                       
#    df_diffTS = dfTS - df_maTS                                                                  # difference to moving average                
#
#    #dACF_d1TS = np.asarray([acf(np.diff(dfTS.iloc[i,:], n=1, axis=1), nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
#    #dACF_d1_diffTS = np.asarray([acf(np.diff(df_diffTS.iloc[i,:], n=1, axis=1), nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
#    dACF_TS = np.asarray([acf(dfTS.iloc[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
#    dACF_d1TS = np.asarray([acf(np.diff(dfTS, n=1, axis=1)[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
#    dACF_d1_diffTS = np.asarray([acf(np.diff(df_diffTS, n=1, axis=1)[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
#    dACF_diffTS = np.asarray([acf(df_diffTS.iloc[i,:], nlags=iMaxLag, missing = 'drop')[1:] for i in range(iCnt)])     # starting from column 1 (...[1:]) because acf with lag 0 is alway 1
#
#    sHeaders_TS = list(['acf_TS_lag' + str(i) for i in iIdx])
#    sHeaders_diffTS = list(['acf_diffTS_lag' + str(i) for i in iIdx])
#    sHeaders_d1TS = list(['acf_d1TS_lag' + str(i) for i in iIdx])
#    sHeaders_d1_diffTS = list(['acf_d1_diffTS_lag' + str(i) for i in iIdx])
#    
#    
#    return {'dfSEtot': pd.DataFrame(dSEtot, columns=['SEtot']), 
#            'df_diffTS': df_diffTS,
#            'dfACF_TS': pd.DataFrame(dACF_TS, columns = sHeaders_TS),
#            'dfACF_d1TS': pd.DataFrame(dACF_d1TS, columns=sHeaders_d1TS),
#            'dfACF_d1_diffTS': pd.DataFrame(dACF_d1_diffTS, columns=sHeaders_d1_diffTS),
#            'dfACF_diffTS': pd.DataFrame(dACF_diffTS, columns=sHeaders_diffTS)}





                    
#
# function to prepare Properties for later evaluation
#
# Christian Kuehnert, 2018-9-28
#
def prepareProperties(dfCDEF, sPropCols, dPropBinWidth):
    
    dfProperties = dfCDEF.loc[:, sPropCols]
    lBinEdges = []
    
    for iProp in range(len(sPropCols)):
        
        sProp = sPropCols[iProp]
        dStep = dPropBinWidth[iProp]
        
        dTmp = dfCDEF.loc[:, sProp]
        
        dMin = math.floor(min(dTmp) / dStep) * dStep
        dMax = (1+math.ceil(max(dTmp) / dStep)) * dStep
        
        lBinEdges.append(np.arange(dMin, dMax, dStep))

    
    return(dfProperties, lBinEdges)





#
# function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
# statistics over it and produces various figures etc.
#
# input:
#       - sss:          stratified shuffle split containing the splits for the several runs
#       - dfDQ_d1:      data frame containing the differences of the quantiles (i.e. q-Quantile for all positive values of d1-time series  minus  q-Quantile
#                       for all negative values of d1-time series) for several quantile-values
#                       the headers must be of format 'diff_q'+ q-Value, e.g. 'diff_q0.95'
#       - dfLabel:      labels for the data
#       - iNStepsThres: number of steps for calculating dependency of precision and recall from threshold
##       - sPathSave:    path name to store the results
##       - sDB:          database name
##       - sFilter:      name of filters
##       - sChannels:    name of channels/directions (edge, flap etc.)
#
# output:
#       - lResults:     list with result:
#           - 
#
#
# Christian Kuehnert, 2018-10-2
def learn_method_skewness(sss, dSetQs, dfDQ_d1, dfLabel, dfProperties, iNStepsThres):
    
    warnings.filterwarnings("ignore")     
    
    dEps = 1e-6       # accuracy for comparing numerical values

    ## lists of results
    lB = []
    lPrec = []
    lRec = []
    lF1 = []
    lAccVsThres = []
    lPropFail = []              # list containing the properties of the wrongly classified data
    
    ## set dfProperties to index of dfDQ_d1 if improper or not existent data frame is given
    # TODO 2018-10-3: noch umstaendlich, eleganter machen
    if dfProperties.empty:
        dfProperties = dfDQ_d1.index()
    elif dfProperties.shape[0] != dfDQ_d1.shape[0]:
        dfProperties = dfDQ_d1.index()
            
    
                 
    ## get start and end values of q
    dDQ_start = 0
    dDQ_end = max(dfDQ_d1.values.max(), abs(dfDQ_d1.values.min()))
                    
    ## get quantiles from headers  
    sQs = dfDQ_d1.columns
    dQs_cols = [float(s.replace('diff_q', '')) for s in sQs]
    
    #dQs = intersect(dQs_cols, dSetQs)
    dEps = np.max([np.finfo(type(dQs_cols[0])).eps, np.finfo(type(dSetQs[0])).eps])
    
    dQs = [x for x in dQs_cols for y in dSetQs if np.isclose(x, y, atol=3*dEps)]

    
    # TODO 2018-9-28: folgende Mengenoperationen auch noch auf Toleranz umstellen
    if len(dQs_cols)>len(dQs):
        dSetDiffQs = [x for x in dQs_cols if x not in dQs]
        print('q-values ' + ",".join([str(d) for d in dSetDiffQs]) + ' not requested')
    
    if len(dSetQs)>len(dQs):
        dSetDiffQs = [x for x in dSetQs if x not in dQs]
        print('q-values ' + ",".join([str(d) for d in dSetDiffQs]) + ' not found in data columns')
        

    if not dQs:
        print('no q-values -> no evaluation')
        
    else:
        
        dQs.sort()
        iNumberOfRuns = sss.get_n_splits()    
       
        dThres = [dDQ_start + iIdx * (dDQ_end-dDQ_start) / iNStepsThres for iIdx in range(iNStepsThres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold
            
        
        ## loop through q's                                            
        #for iQ in range(len(dQs)):
        for dQ in dQs:
                                            
            #dQ = dQs[iQ]
            #sQ = str(dQ)
            print('q=' + str(dQ))
                  
            iQ = [i for i in range(len(dQs_cols)) if np.isclose(dQs_cols[i], dQ, atol=3*dEps)]          # find column with that dQ
            
            
            ## lists of results for each value of q
            lB_q = []                            
            lPrec_q = []
            lRec_q = []
            lF1_q = []  
            lPropFail_q = []                          
    
            ## arrays for statistics of precision/recall/F1 for each threshold step and each run
            dPrec_vsThres_q = np.empty([iNStepsThres, iNumberOfRuns], dtype=np.float64)
            dRec_vsThres_q = np.empty([iNStepsThres, iNumberOfRuns], dtype=np.float64)
            dF1_vsThres_q = np.empty([iNStepsThres, iNumberOfRuns], dtype=np.float64)
            dPrec_vsThres_q[:] = np.nan
            dRec_vsThres_q[:] = np.nan
            dF1_vsThres_q[:] = np.nan
            
            
            ## loop trough the different runs
            iRun = 0     
            for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
                                
                print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                                                                                                                              
                #dDQ_d1_train, dDQ_d1_test = dfDQ_d1.values[train_idx], dfDQ_d1.values[test_idx]                                            
                #dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                dX_train, dX_test = dfDQ_d1.values[train_idx, iQ], dfDQ_d1.values[test_idx, iQ]                                
                dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                                
                # define optimization fct.
                # find optimal b
                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(predictDiffQuant_d1(dX_train, x)-dLabel_train), ranges = ((dDQ_start, dDQ_end),), Ns=100, full_output=True, finish=None)
                                                        
                dB = resMin[0]
                                            
                #lQs_r.append(dQ)
                lB_q.append(dB)
                                                
                ## calc. accuracy of the model                                                                
                iPred = predictDiffQuant_d1(dX_test, dB)                                                    
                bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data
                
                dfProperties_fail = dfProperties.iloc[test_idx[bFailClass],:]

                
                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
                                                                            
                lPrec_q.append(dAccu[0])
                lRec_q.append(dAccu[1])
                lF1_q.append(dAccu[2])
                #lPropFail_q.append(dfProperties_fail)
                lPropFail_q.append([len(bFailClass), sum(bFailClass), dfProperties_fail])           
                
                                                
                # create diagrams of precision/recall vs. threshold for each quantile
                #bSpecialDiagrams = True
                #if bSpecialDiagrams & (dQ==0.95):            
                #lThres = []
                #lPrec_vsThres = []
                #lRec_vsThres = []
                #lF1_vsThres = []
                                            
                for iIdx in range(iNStepsThres):
                    
                    #dThres = dDQ_start + iIdx * (dDQ_end-dDQ_start) / iNStepsThres
                                                
                    iPred = predictDiffQuant_d1(dX_test, dThres[iIdx])
                                                
                    dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
                                            
                    #lThres.append(dThres)                                        
                    #lPrec_vsThres.append(dAccu[0])
                    #lRec_vsThres.append(dAccu[1])
                    #lF1_vsThres.append(dAccu[2])
                    dPrec_vsThres_q[iIdx, iRun] = dAccu[0]
                    dRec_vsThres_q[iIdx, iRun] = dAccu[1]
                    dF1_vsThres_q[iIdx, iRun] = dAccu[2]                    
                    
                                         
                iRun = iRun + 1
                
                       
            #dThres = np.vstack(lThres)
            ## statistics of the accuracy measures vs. thresholds
            dStatsPrec_vsThres = stats.describe(dPrec_vsThres_q, axis=1)
            dStatsRec_vsThres = stats.describe(dRec_vsThres_q, axis=1)
            dStatsF1_vsThres = stats.describe(dF1_vsThres_q, axis=1)
            lAccVsThres.append([dQ, dStatsPrec_vsThres, dStatsRec_vsThres, dStatsF1_vsThres])       
                                            
            lB.append(np.hstack(lB_q))                                
            lPrec.append(np.hstack(lPrec_q))
            lRec.append(np.hstack(lRec_q))
            lF1.append(np.hstack(lF1_q))

            lPropFail.append([dQ, lPropFail_q])
            
        dB = np.vstack(lB)
        dPrec = np.vstack(lPrec)
        dRec = np.vstack(lRec)
        dF1 = np.vstack(lF1)    


    return(dQs, dB, dPrec, dRec, dF1, dThres, lAccVsThres, lPropFail)




#
# function that does several runs with different split of data into trainings and test data and learns parameters for acf method and calculates several 
# statistics over it and produces various figures etc.
#
# input:
#       - sss:          stratified shuffle split containing the splits for the several runs
#       - dfACF_d1:     data frame containing the acf's of d1-time series
#                       the headers must be of format 'acf_'+ lag-Value, e.g. 'acf_1'
#       - dfLabel:      labels for the data
#       - iSetMaxLags:  set with max lags to be used, all lags <= max lag will be included, TODO 20180927: spaeter umstellen auf iLags:        lags to be included
#       - sKernel:      kernel to be used
#       - dC:           value of dC for optimization
#       - dGamma:       value of gamma for optimization
#
# output:
#
#
# Christian Kuehnert, 2018-10-2
def learn_method_acf(sss, dfACF_d1, dfLabel, dfProperties, iSetMaxLags, sKernel, dC, dGamma):

    warnings.filterwarnings("ignore")
            
    dEps = 1e-6       # accuracy for comparing numerical values
           
    dACFs = np.array(iSetMaxLags)
                                                                                      
    iNumberOfRuns = sss.get_n_splits()    
               
    ## lists of results
    lPrec = []
    lRec = []
    lF1 = []
    #lModel = []
    lPropFail = []              # list containing the properties of the wrongly classified data


    model = SVC(kernel=sKernel, C=dC, gamma=dGamma)
    lModel = []
    for dLag in iSetMaxLags:                                        # beachten: (da ACF die lag=0-Werte nicht enthaelt!, d.h. Spalte 1 mit python-Index 0 entspricht lag=1                                                                
                                    
        iLag = int(dLag)
        #X = dfACF_d1.iloc[:,0:iLag].values      
    
        #sHeaders = dfACF_d1.columns[0:iLag]
        sMethod = 'acf_d1 with max(lag)=' + str(iLag)                                                        
        print(sMethod)
                  
        ## lists of results for each max lag
        lPrec_mlag = []
        lRec_mlag = []
        lF1_mlag = []    
        lPropFail_mlag = []                          
        lModel_mlag = []
                         
        ## loop trough the different runs
        iRun = 0     
        for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
                            
            print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                
            dACF_d1_train, dACF_d1_test = dfACF_d1.values[train_idx,0:iLag], dfACF_d1.values[test_idx, 0:iLag]                                                                                                                                          
            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                            
            #sSVMPars = sKernel + ', C=' + str(dC) + ', gamma=' + str(dGamma)            
            model.fit(dACF_d1_train, np.ravel(dLabel_train))
            iPred = model.predict(dACF_d1_test)
            iPred = np.reshape(iPred, (len(iPred), 1))

            bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data                
            dfProperties_fail = dfProperties.iloc[test_idx[bFailClass],:]                                        
            
            dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)            
                                                       
            lPrec_mlag.append(dAccu[0])
            lRec_mlag.append(dAccu[1])
            lF1_mlag.append(dAccu[2])
            lModel_mlag.append(model) 
            lPropFail_mlag.append([len(bFailClass), sum(bFailClass), dfProperties_fail])           
                                   
            iRun = iRun + 1
                               
        lPrec.append(np.hstack(lPrec_mlag))
        lRec.append(np.hstack(lRec_mlag))
        lF1.append(np.hstack(lF1_mlag))
        lPropFail.append([iLag, lPropFail_mlag])
        lModel.append(lModel_mlag)
        
    dPrec = np.vstack(lPrec)
    dRec = np.vstack(lRec)
    dF1 = np.vstack(lF1)    

    return(dACFs, dPrec, dRec, dF1, lPropFail, lModel)






