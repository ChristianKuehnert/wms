# -*- coding: utf-8 -*-
"""

functions for the calculation of kinematic quantities (pitch angle, bending
angle etc.) from the time series of edge/flap accelerations



Created on Fri Mar  6 00:24:17 2020

@author: christian_2
@modified: 2020-3-10

"""

#import pathlib
#import os
#import re
import sys
#import gc
#import math
#
import pandas as pd
import numpy as np
#import itertools
#import matplotlib.pyplot as plt
#import seaborn as sns
#import statsmodels.formula.api as smf
#import statsmodels.api as sm

#import plotly
#import plotly.graph_objects as go
#from plotly.graph_objs import Scatter, Layout
#from collections import Counter
    

#from contextlib import redirect_stdout
#from sklearn import datasets, linear_model
#from sklearn.preprocessing import StandardScaler

from datetime import datetime as dt
#from dateutil.relativedelta import *
    
#from statsmodels.formula.api import ols 
import statsmodels.api as sm
#from scipy import stats
from scipy.signal import savgol_filter
from scipy.signal import butter, lfilter    #, freqz


from data import calc_phi_from_harmonics, whereClause_from_timeInterval
from data import query_tableData, myprint
from data.update_hd5 import get_folder, combine_at
#from plot.myFunctions_plot import myplot_fast, myplot_fast2






## uebernommen von:
## https://stackoverflow.com/questions/25191620/creating-lowpass-filter-in-scipy-understanding-methods-and-units
def butter_lowpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return b, a

def butter_lowpass_filter(data, cutoff, fs, order=5):
    b, a = butter_lowpass(cutoff, fs, order=order)
    y = lfilter(b, a, data)
    return y




"""
set starttime or endtime to reasonable values if they are None
@modified: 2020-3-16
"""
def pars_time_tuple(per_tup):
    
    if per_tup[0] is None:
        per_tup[0] = dt(1970,1,1)
    
    
    if per_tup[1] is None:
        per_tup[1] = dt.now()
        
    return(per_tup)






"""
function to get edge and flap ts, for better readability
@modified: 2020-2-14
"""
def get_ef(df, col, wdw_size_prae):
    
    if wdw_size_prae > 2:
        flap = savgol_filter(df.loc[:, f'Channel-{col}'].values, wdw_size_prae, 2)
        edge = savgol_filter(df.loc[:, f'Channel-{col+3}'].values, wdw_size_prae, 2)            
        #edge = butter_lowpass_filter(df.loc[:,f'Channel-{col+3}'].values,
        #                             cutoff_freq, sample_rate, order=1)                
        #flap=butter_lowpass_filter(df.loc[:,f'Channel-{col}'].values,
        #                             cutoff_freq, sample_rate, order=6)
        
    else:
        flap = df.loc[:, f'Channel-{col}'].values
        edge = df.loc[:, f'Channel-{col+3}'].values
       
    return(edge, flap)
    




## 2020-2-18: Untersuchung von Zeitreihen der Schmelz-WEA
## Idee dabei: REGRESSION A_E/F ~ COS(OMEGA) (S. HEFT), AUS SCHAETZPARAMETERN DANN PITCHWINKEL ETC. ABLEITEN, GGF. MIT DIESEN WERTEN AUSSERHALB DES TURMBEREICHS DANN DIE AUSLENKUNG IM TURMBEREICH BETRACHTEN,
#AUSSERDEM VIELL. DAMIT AUCH BLATTLAGERDEFEKTE FESTSTELLBAR (STAERKERE VARIANZ AN DEN KRIT. STELLEN ODER INSGESAMT GGUE. PERIODEN MIT NORMALER PITCHSCHWANKUNG???)
#import datetime as dt
    #print(type(tmp))
    
    
    
"""
function to calculate the phi_rot-values from the given ts

parameters:
-----------

    - at:           time series that should be used for calc of phi_rot
    - idx_first:    first zero transition that should be taken into account
    - idx_last:     last zero transition that should be taken into account


@modified: 2020-3-24
"""
def calc_phi_rot(at, idx_first = 1, idx_last = -2):
                
    bOk, dict_res = calc_phi_from_harmonics(at, wdw_size=10001, 
                                            min_amp=1000, 
                                            min_pi_duration=1000, 
                                            apply_low_pass_filter=False, 
                                            calc_phi=True, 
                                            counterclockwise = True, 
                                            offset = 0)
                
    #omega = 2 * np.pi * dict_res['f_mean']
    phi_rot = dict_res['phi']
                                     
    idx_zeros = dict_res['zero_transitions']
    
    ixs = idx_zeros[idx_first]
    ixe = idx_zeros[idx_last]
    idx_zeros_tmp = idx_zeros[idx_first:idx_last]
      
    phi_rot_tmp = phi_rot[ixs:ixe]
 
    return(phi_rot, phi_rot_tmp, ixs, ixe, idx_zeros_tmp)
    
    
    
    
    
    
    
    
"""
function to do regression by a_t^e, a_t^f ~ cos(Omega) + sin(Omega)
system

@modified: 2020-3-6
"""
def regress_ef(edge, flap):
                
    phi_rot, phi_rot_tmp, ixs, ixe, idx_zeros_tmp = calc_phi_rot(edge)
    
    ## first do regression for each single rotation
    pairs_zero_idx = 
    
    
    
    ## now do regression for whole period
    
    
    
    
    ## regression for edge
    #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
    X = sm.add_constant(np.column_stack((np.cos(phi_rot_tmp), 
                                               np.sin(phi_rot_tmp))))
    
    model = sm.OLS(edge[ixs:ixe], X)
    reg_edge = model.fit()

    # TODO 2020-3-6: hier noch entstehendes Gleichungssystem loesen und 
    # Tests anschliessen (z.B. andere Parameter == g usw.), vielleicht auch nur ausserhalb
    #b0e, b1e, b2e = reg.params

    model = sm.OLS(flap[ixs:ixe], X)
    reg_flap = model.fit()
    # TODO 2020-3-6: hier noch phi, pitch usw. berechnen und 
    #Tests anschliessen (z.B. andere Parameter == g usw.)
    #b0e, b1e, b2e = reg.params

    return(reg_edge, reg_flap, phi_rot_tmp, ixs, ixe)






"""
function to do regression by ||a|| ~ cos(Omega)
system

@modified: 2020-3-6
"""
def regress_norm(edge, flap):
                
    phi_rot, phi_rot_tmp, ixs, ixe = calc_phi_rot(edge)
    
    ## regression for edge
    #X = sm.add_constant(np.cos(phi_rot_tmp-np.pi/2))
    X = sm.add_constant(np.cos(phi_rot_tmp))
    
    model = sm.OLS(edge[ixs:ixe]**2 + flap[ixs, ixe]**2, X)
    
    reg = model.fit()            
        
    # TODO 2020-3-6: hier noch phi, pitch usw. berechnen und 
    #Tests anschliessen (z.B. andere Parameter == g usw.)
    #b0e, b1e, b2e = reg.params

    return(reg, phi_rot_tmp, ixs, ixe)




"""
function to calculate pitch angle and bending angle 

parameters:
-----------
    - reg_interval: interval length used for the regression


@modified: 2020-3-15
"""
def calc_pitch_bending(edge, flap, istep=1, reg_interval = 100):

    phi_rot, phi_rot_tmp, ixs, ixe = calc_phi_rot(edge)

    X = sm.add_constant(np.column_stack((np.cos(phi_rot), 
                                         np.sin(phi_rot))))

    # now calculate the pitch angle and bending angle for each point
    lres = list()
    thres = 1
    count = 0
    interval=range(ixs, ixe-1, istep)
    for ip in interval:
        #print(ip)
        
        if count/len(interval)*100 >= thres:
            print(f'{thres} %', end='\r', flush=False)
            thres += 1
            
        ips = max(ip-reg_interval, ixs)
        ipe = min(ip+reg_interval, ixe-1)
            
        phi = phi_rot[ip]
        
        ## regression for edge and flap
        model = sm.OLS(edge[ips:ipe], X[ips:ipe,:])
        reg_e = model.fit()   
        _b0e, b1e, b2e = reg_e.params

        model = sm.OLS(flap[ips:ipe], X[ips:ipe,:])
        reg_f = model.fit()
        _b0f, b1f, b2f = reg_f.params            

#        pitch = np.arctan(-b0e/b0f)
#        pitch_grad0 = pitch * 180/np.pi
#    
#        pitch = np.arctan(-b1e/b1f)
#        pitch_grad1 = pitch * 180/np.pi
        
        pitch = np.arctan(-b2f/b2e) * 180/np.pi
    
    #        F0 = np.sqrt(b0e**2+b0f**2)
        F1 = np.sqrt(b1e**2+b1f**2)
        F2 = np.sqrt(b2e**2+b2f**2)
    
        phi_bend = np.arcsin(np.sqrt(F1/F2)) * 180/np.pi
                
        lres.append((phi, pitch, phi_bend))

        if (np.isnan(pitch) or np.isnan(phi_bend)):
            try:
                plot_sector(phi_rot_tmp, [edge[ixs:ixe], flap[ixs:ixe]], 
                            (ips-ixs, ipe-ixs), plot_params = None, 
                            fn = None, title = f'sector bei {ip}', legend = [])

            except:
                print('problem')
        count += 1
      
    df = pd.DataFrame.from_records(lres, 
                                   columns = ['phi', 'pitch', 'bending_angle'])
    
    return(df)



"""
function to plot the sector of the selected period

2020-3-15
"""
def plot_sector(phi_rot, X, interval, plot_params = None, fn = None,
                title = '', legend = []):

    # now calculate the pitch angle and bending angle for each point
    lplot = list()
    idx = range(interval[0], interval[1])
    if isinstance(X, list):
        for ic in range(len(X)):
            el = X[ic]
            if (plot_params is None):
                lplot.append((phi_rot[idx], el[idx], None))
            else:
                lplot.append((phi_rot[idx], el[idx], plot_params[ic]))
            
            ix = range(0, interval[0])            
            lplot.append((phi_rot[ix], el[ix], {'color': 'lightgrey'}))

            ix = range(interval[1], len(el)) 
            lplot.append((phi_rot[ix], el[ix], {'color': 'lightgrey'}))
        
    elif isinstance(X, np.array):
        for ic in range(X.shape[1]):
            if (plot_params is None):
                lplot.append(phi_rot[idx], X[idx, ic], None)
            else:
                lplot.append(phi_rot[idx], X[idx, ic], plot_params[ic])
                                
            ix = range(0, interval[0])            
            lplot.append((phi_rot[ix], X[ix, ic], {'color': 'lightgrey'}))

            ix = range(interval[1], len(el)) 
            lplot.append((phi_rot[ix], X[ix, ic], {'color': 'lightgrey'}))

                
    else:
        print(f'type {type(X)} not yet implemented')
    
    ## control plots    
    myplot_fast2(lplot,
                 fn = fn,
                 s_title=title,
                 legend = legend,
                 projection = 'polar')

    


"""

function to load the data for the given datetime and cycle_id, combine the ts and
calculate the (averaged) pitch angle from it

@modified: 2020-3-10

"""
def calc_pitch(db, date, cycle_id, blades = range(3), sample_rate = 1000,
               wdw_size_prae = 101, bplot = True):

    path_ts = get_folder(db, date, cycle_id)

    #wdw_size_post = 10001
        
    #cutoff_freq = 1
   
    res = []
    
    cols = [str(c) for c in range(6)]
    
    dict_res, critical_channels = combine_at(path_ts)
    #print(f'{s_state}: {critical_channels}', file=fh)
                
    dfs = list()
            
    for c in cols:
        dfs.append(dict_res[c].set_index('time').rename(columns={'a_t': 
                                                            f'Channel-{c}'}))

    if bplot:
        col_map = {'e1': 'red',
                   'e2': 'blue',
                   'e3': 'green',
                   'f1': 'tomato',
                   'f2': 'lightblue',
                   'f3': 'lightgreen'}

    df = pd.concat(dfs, axis=1)
    
    ## TODO 2020-2-18: folgendes oder Teile davon in eigene Funktion(en) auslagern              
    lixs = list()
    lixe = list()
    #print(f'{s_state}:', file=fh)
    #print('______:', file=fh)
                    
    for blade in blades:
                
        edge, flap = get_ef(df, blade, wdw_size_prae)
                        
        reg_e, reg_f, phi_rot, ixs, ixe = regress_ef(edge, flap)
        
#        bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
#                                                min_amp=4000, 
#                                                min_pi_duration=1000, 
#                                                apply_low_pass_filter=False, 
#                                                calc_phi=True, 
#                                                counterclockwise = True, 
#                                                offset = 0)
#                
#        omega = 2 * np.pi * dict_res['f_mean']
#        phi_rot = dict_res['phi']
#                                     
#        tmp = dict_res['zero_transitions']
#                
#        ixs_tmp = tmp[1]
#        ixe_tmp = tmp[-2]
#    
#      
#        phi_rot_tmp = phi_rot[ixs_tmp:ixe_tmp]

        if bplot:

            list_to_plot = [(phi_rot-np.pi*blade*2/3, edge[ixs:ixe], 
                             {'color': col_map[f'e{blade+1}']}),
                            (phi_rot-np.pi*blade*2/3, flap[ixs:ixe], 
                             {'color': col_map[f'f{blade+1}']})]
    
        #print(reg.summary(), file=fh)
        b0e, b1e, b2e = reg_e.params
        
        if bplot:
            list_to_plot.append((phi_rot-np.pi*blade*2/3, 
                                 reg_e.predict().copy(), 
                                 {'color': 'black'}))
            
        ## regression for flap
        #print(reg.summary(), file=fh)        
        b0f, b1f, b2f = reg_f.params
        
        if bplot:
            list_to_plot.append((phi_rot-np.pi*blade*2/3, 
                                 reg_f.predict().copy(), 
                                 {'color': 'black'}))
                        
        pitch = np.arctan(-b0e/b0f)
        pitch_grad0 = pitch * 180/np.pi
        #print(f'b0 = {pitch_grad0}^o')
    
        pitch = np.arctan(-b1e/b1f)
        pitch_grad1 = pitch * 180/np.pi
        #print(f'b1 = {pitch_grad1}^o')

        pitch = np.arctan(-b2f/b2e)
        pitch_grad2 = pitch * 180/np.pi
        #print(f'b2 = {pitch_grad2}^o', file=fh)

        F0 = np.sqrt(b0e**2+b0f**2)
        F1 = np.sqrt(b1e**2+b1f**2)
        F2 = np.sqrt(b2e**2+b2f**2)
        #print(f'F0={F0}', file = fh)
        #print(f'F1={F1}', file = fh)
        #print(f'F2={F2}', file = fh)

        lixs.append(ixs)
        lixe.append(ixe)

        phi_bend = np.arcsin(np.sqrt(F1/F2))              
    
        res.append((blade, pitch_grad0, pitch_grad1,
                    pitch_grad2, F0, F1, F2, phi_bend))
    
    df_res = pd.DataFrame.from_records(res, 
                                       columns = ['blade', 
                                                  'pitch_grad0', 'pitch_grad1',
                                                  'pitch_grad2', 
                                                  'F0', 'F1', 'F2',
                                                  'bending_angle'])
        
    return(res, df_res)
    
    
    
    
    



"""
function to get the create_time and cycle_id for all available time series
in the given period

@modified: 2020-3-17
"""
def get_timeseries_keys(db, period):
    
    lwhere = ['available_data>2']                            # consider only cycles where sda-files were stored
    lwhere.append(whereClause_from_timeInterval(time_start=period[0],
                                           time_end = period[1], 
                                           sFormat = '%Y%m%d%H%M%S'))
    swhere = f"({') and ('.join(lwhere)})"
    dfData, _sMsg = query_tableData(db, 'ba_cycle_measurement_cycle', 
                                    sWC = swhere)

    ## set types, if some type dictionary is given                                        
    return(dfData.loc[:, ['create_time', 'ID']])




       

"""

function to load the data for the given datetime and cycle_id, combine the ts and
calculate the (averaged) pitch angle from it by a_t^e, a_t^f ~ cos(Omega) 
+ sin(Omega)

@modified: 2020-3-25

"""
def calc_pitch2(db, date, cycle_id, blades = range(3), sample_rate = 1000,
               wdw_size_prae = 101, bplot = True):

    path_ts = get_folder(db, date, cycle_id)

    #wdw_size_post = 10001        
    #cutoff_freq = 1   
    res = list()    
    cols = [str(c) for c in range(6)]    
    dict_res, critical_channels = combine_at(path_ts)
    #print(f'{s_state}: {critical_channels}', file=fh)
                
    dfs = list()
            
    for c in cols:
        dfs.append(dict_res[c].set_index('time').rename(columns={'a_t': 
                                                            f'Channel-{c}'}))

    if bplot:
        col_map = {'e1': 'red',
                   'e2': 'blue',
                   'e3': 'green',
                   'f1': 'tomato',
                   'f2': 'lightblue',
                   'f3': 'lightgreen'}

    df = pd.concat(dfs, axis=1)
    
    res = list()
    for blade in blades:
                
        edge, flap = get_ef(df, blade, wdw_size_prae)
        
        bOk, dict_res = calc_phi_from_harmonics(edge, wdw_size=10001, 
                                                min_amp=1000, 
                                                min_pi_duration=1000, 
                                                apply_low_pass_filter=False, 
                                                calc_phi=True, 
                                                counterclockwise = True, 
                                                offset = 0)
                
        #omega = 2 * np.pi * dict_res['f_mean']
        if bOk:
            phi_rot = dict_res['phi']                                 
            idx_zeros = dict_res['zero_transitions']
            bOk = (len(idx_zeros)>2)
        
        ## first do regression for each single rotation, here overlapping rotations
        ## are used
        count = 1
        if bOk:
            for ip in zip(idx_zeros[:-2], idx_zeros_tmp[2:]):
                
                myprint(f'{count}/{len(idx_zeros)-1'})
                ixs, ixe = ip[0], ip[1]
                ed = edge[ixs:ixe]
                ft = flap[ixs:ixe]
                ph = phi_rot[ixs:ixe]
        
                ## regression for edge
                X = sm.add_constant(np.column_stack((np.cos(ph), np.sin(ph))))            
    
                #model = sm.OLS(edge[ixs:ixe], X)
                #reg = model.fit()
                #b0e, b1e, b2e = reg.params
                _b0e, b1e, b2e  = sm.OLS(ed[ixs:ixe], X).fit().params        
                _b0f, b1f, b2f  = sm.OLS(fl[ixs:ixe], X).fit().params
    
                # TODO 2020-3-25: PLOT ANFERTIGEN, alle Einzelcycles in einem diagramm, 
                # mit interaktiver Auswahllegende dafuer, ebenso die Gesamtdarstellung
                
                # TODO 2020-3-6: hier noch entstehendes Gleichungssystem loesen und 
                # Tests anschliessen (z.B. andere Parameter == g usw.), vielleicht auch nur ausserhalb
    
    #         pitch = np.arctan(-b0e/b0f)
    #         pitch_grad0 = pitch * 180/np.pi
    #    
    #         pitch = np.arctan(-b1e/b1f)
    #         pitch_grad1 = pitch * 180/np.pi
            
                pitch = np.arctan(-b2f/b2e) * 180/np.pi
        
    #         F0 = np.sqrt(b0e**2+b0f**2)
                F1 = np.sqrt(b1e**2+b1f**2)
                F2 = np.sqrt(b2e**2+b2f**2)
        
                res.append((blade, ixs, ixe, pitch))
                if not(np.isnan(pitch)):
                    try:
                        pass
                        # TODO 2020-3-25: print polar plot
                        
                    except:
                        print('problem')
                    
                count += 1
          
    df_res = pd.DataFrame.from_records(lres, columns = ['blade', 'start_idx', 
                                                        'end_idx', 'pitch'])
        
    return(df_res)



    
"""
function to calculate the pitch angles in the given periods and compare their
differences, i.e. to plot them in one diagram

TODO 2020-3-24: von vornherein nicht-drehende Zeitpunkte ausschließen

@modified: 2020-3-17
"""
def calc_pitch_period(db, period,  blades = range(1,4), reference_blade = 1,
                      sample_rate = 1000, wdw_size_prae = 101, bplot = False):
                
    # get all available ts-times and IDs from .h5-file, from database or from 
    # file system, if database is not available, not yet implemented
    df_ct_its = get_timeseries_keys(db, period)
            
    
    rb = reference_blade-1  # 0-based blade number
    
    # calculate the pitch angles for all a_t-data in the the periods and the 
    # given blades
    res = list()
    idx_problems = list()
    n = df_ct_its.shape[0]
    count = 1
    for idx, row in df_ct_its.iterrows():
        myprint(f"{count}/{n}")
        count += 1
        create_time = row['create_time']
        cycle_id = row['ID']
        
        # calculate the differences, related to the given reference_blade
        try:
            _tmp, df_res = calc_pitch(db, create_time, cycle_id, blades = range(3), 
                                     sample_rate = 1000, wdw_size_prae = 101, 
                                     bplot = bplot)
            # plot results in one diagram            
            df_diff = df_res.assign(pitch_diff = df_res.pitch_grad2.values -df_res[df_res.blade==rb].pitch_grad2.values).drop(df_res[df_res.blade==rb].index).loc[:, ['blade', 'pitch_diff']].assign(create_time = create_time, cycle_id = cycle_id)
            #res.append((create_time, cycle_id, blade, tmp_b[3]-pitch_ref))
            res.append(df_diff)

        except:
            idx_problems.append(idx)

    df_res = pd.concat(res, axis=0, ignore_index=True).reset_index(drop=True)
        
    return(df_res, df_ct_its.loc[idx_problems,:])