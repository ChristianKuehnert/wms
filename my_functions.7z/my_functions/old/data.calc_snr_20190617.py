# -*- coding: utf-8 -*-
"""

function to calculate the snr for a peak in the spectrum


Created on Thu Mar 28 08:27:44 2019

@author: christian kuehnert, following the corresponding matlab-function by Stefan Reimann
@modified: 2019-6-17, vorher war noch faelschlicherweise idx_peak = range(i_peak-len_env, i_peak+len_env) (ohne die +1 am Ende)

"""
import numpy as np

def calc_snr(spec, len_env=2):

    i_peak = spec.argmax()
    peak = spec[i_peak]
    
    idx_peak = range(i_peak-len_env, i_peak+len_env+1)
    #pwr_sig = sum(spec[idx_peak])
    mean_noise = np.mean(spec[list(set(spec.index)-set(idx_peak))])
    
    return(peak, peak/mean_noise)
    
#def calc_snr(spec, freq, band, len_env=2):    
#    bmask = (freq>= band[0]) & (freq<=band[1])
#    i_peak = np.maxarg(spec[bmask])
#    peak = spec[i_peak]    
#    idx_peak = range(i_peak-len_env, i_peak+len_env)
#    mean_noise = np.mean(spec[set(range(len(spec)))-set(idx_peak)])    
#    return(peak, peak/mean_noise)
        
    
    