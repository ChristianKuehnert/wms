# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 17:01:36 2018

    functions for retrieving and storing (raw-)data, labels etc.

@author: w012028
"""

## functions for getting and storing data
## Christian Kuehnert, 2018-11-05

import pymssql
import pymysql
import fnmatch
import os
import os.path
from os import listdir
import numpy as np
import pandas as pd
import datetime as dt
import scipy.io
import gc
import sys
import math
import warnings
#import itertools
import re

from scipy.stats import skew, kurtosis, moment
from statsmodels.tsa.stattools import acf
from sklearn.metrics import precision_recall_fscore_support
from sklearn.svm import SVC
#from sklearn.svm import LinearSVC

#try:
#    import cPickle as pickle
#except ModuleNotFoundError:
#    import pickle



sModulePath = r'C:\Repositories\python\functions'
sys.path.append(sModulePath)
from class_hd5Nodes import hd5Nodes as sNodes




    
    
    



           






#
# function that does several runs with different split of data into trainings and test data and learns parameters for acf method and calculates several 
# statistics over it and produces various figures etc.
#
# input:
#       - sss:          stratified shuffle split containing the splits for the several runs
#       - dfACF_d1:     data frame containing the acf's of d1-time series
#                       the headers must be of format 'acf_'+ lag-Value, e.g. 'acf_1'
#       - dfLabel:      labels for the data
#       - iSetMaxLags:  set with max lags to be used, all lags <= max lag will be included, TODO 20180927: spaeter umstellen auf iLags:        lags to be included
#       - sKernel:      kernel to be used
#       - dC:           value of dC for optimization
#       - dGamma:       value of gamma for optimization
#
# output:
#
#
# Christian Kuehnert, 2018-10-2
def learn_method_acf_old(sss, dfACF_d1, dfLabel, dfProperties, iSetMaxLags, sKernel, dC, dGamma):

    warnings.filterwarnings("ignore")
            
    dEps = 1e-6       # accuracy for comparing numerical values
           
    dACFs = np.array(iSetMaxLags)
                                                                                      
    iNumberOfRuns = sss.get_n_splits()    
               
    ## lists of results
    lPrec = []
    lRec = []
    lF1 = []
    #lModel = []
    lPropFail = []              # list containing the properties of the wrongly classified data


    model = SVC(kernel=sKernel, C=dC, gamma=dGamma)
    lModel = []
    for dLag in iSetMaxLags:                                        # beachten: (da ACF die lag=0-Werte nicht enthaelt!, d.h. Spalte 1 mit python-Index 0 entspricht lag=1                                                                
                                    
        iLag = int(dLag)
        #X = dfACF_d1.iloc[:,0:iLag].values      
    
        #sHeaders = dfACF_d1.columns[0:iLag]
        sMethod = 'acf_d1 with max(lag)=' + str(iLag)                                                        
        print(sMethod)
                  
        ## lists of results for each max lag
        lPrec_mlag = []
        lRec_mlag = []
        lF1_mlag = []    
        lPropFail_mlag = []                          
        lModel_mlag = []
                         
        ## loop trough the different runs
        iRun = 0     
        for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
                            
            print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                
            dACF_d1_train, dACF_d1_test = dfACF_d1.values[train_idx,0:iLag], dfACF_d1.values[test_idx, 0:iLag]                                                                                                                                          
            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                            
            #sSVMPars = sKernel + ', C=' + str(dC) + ', gamma=' + str(dGamma)            
            model.fit(dACF_d1_train, np.ravel(dLabel_train))
            iPred = model.predict(dACF_d1_test)
            iPred = np.reshape(iPred, (len(iPred), 1))

            bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data                
            dfProperties_fail = dfProperties.iloc[test_idx[bFailClass],:]                                        
            
            dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)            
                                                       
            lPrec_mlag.append(dAccu[0])
            lRec_mlag.append(dAccu[1])
            lF1_mlag.append(dAccu[2])
            lModel_mlag.append(model) 
            lPropFail_mlag.append([len(bFailClass), sum(bFailClass), dfProperties_fail])           
                                   
            iRun = iRun + 1
                               
        lPrec.append(np.hstack(lPrec_mlag))
        lRec.append(np.hstack(lRec_mlag))
        lF1.append(np.hstack(lF1_mlag))
        lPropFail.append([iLag, lPropFail_mlag])
        lModel.append(lModel_mlag)
        
    dPrec = np.vstack(lPrec)
    dRec = np.vstack(lRec)
    dF1 = np.vstack(lF1)    

    return(dACFs, dPrec, dRec, dF1, lPropFail, lModel)


    
            
"""
function to update data in hd5-file directly from database
@author: Christian Kuehnert

2019-6-2

"""
def update_hd5fromDB_now_to_be_finished(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=None, time_start=None, time_end=None, iLimit=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
       
    if not os.path.isfile(sFN_hd5):               # if no such hd5-file exists      
        initialize_hd5file(sDB, sPathData)        # create it hd5-file

    bHD5Data = False
    with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:
        
            dfData = f[sNode]
        
            if not isinstance(dfData, pd.DataFrame):
                f.remove(sNode)
            else:
                bHD5Data = True
                                
        
        sql_reader = pd.read_sql(sSC, connector, chunksize=100000)
        
        for chunk in sql_reader:
            i=7
            f.append(sNode, chunk, index=False)
            

#                dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start, iOffset=iOffset, iLimit=iLimit)
#                bContinue = dfData_sql.shape[0]>0
#                if bContinue:
#                    if bHD5Data:
#                        dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
#                    else:
#                        dfAppend = dfData_sql.reset_index(drop=True)
#                    
#                    append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)
#                iOffset += iLimit                    
#                                                
#        else:
#            
#            dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start)
#            if dfData_sql.shape[0]>0:
#                if bHD5Data:
#                    dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
#                else:
#                    dfAppend = dfData_sql.reset_index(drop=True)
#                
#                append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)

        f.close()                                                
    
#    else:       
#        dfAdd = pd.DataFrame()
#
#    return(dfAdd)
           
        
        
        

# function to collect time series as well as cdef data
# in a first version save them separately as well as combined,
# later the combined data can be dropped if suitable functions
# to combine are implemented
#
# 
# Christian Kuehnert, 2018-11-5
#
# TODO 2018-10-18: eleganter machen, nur die Daten auslesen, die wirklich benoetigt werden etc.
#
def update_cdef_ts_old(sDB, sPathData, listTimeIntervals=[-np.Infinity, np.Infinity], iCntMeasBase = 8192, bSloppy = True):

    lMsg = []
    
    sNode = 'raw_data/ts'                                           # node where the time series data are stored
    
    sHeadersKey = ['create_time', 'ID']                             # headers of the columns that relate the ts data to the cdef data
            
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    dfCDEF = update_cdef(sDB, sPathData, listTimeIntervals)         # update cdef-data and return list of all entries
        
    iCycles = dfCDEF.shape[0]                                              # number of cycles
    
    if iCycles>0:
        
        #dfCycles = dfCDEF.loc[:, sHeadersKey]                       # headers of the cdef-data available

        # TODO 2018-10-25: erstmal so implementiert, evtl. waere es sinnvoll, z.B. (und falls moeglich) mittels 
        # dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('index in [' + sIdx + '])')) die bereits
        # vorhandenen Daten auszulesen und nur die neueren CDEF-Cycles abzuarbeiten. Allerdings waren meine Versuche,
        # nach den Multiindizes zu selektieren, nicht erfolgreich, aus diesem Grunde werden erstmal alle cycles abgearbeitet
        # und dort individuell fuer jeden Cycle untersucht, ob schon Daten im .hd5-File vorhanden sind. Dadurch dauert die 
        # Bearbeitung sicher etwas laenger, der Code ist aber etwas einfacher und damit auch weniger fehleranfaellig     
        #with pd.HDFStore(sFN_hd5, 'a') as f:                        # open hd5-file
#                if sNode in f.keys():   
#
#                    # TODO 2018-10-25: Erstmal so Behelfsloesung, evtl. wenn moeglich auf den                                                                              
#                    #dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('(create_time in dfCDEF.create_time) and (ID in dfCDEF.ID)'))                   # dataframe with cycle keys
#                    sID = ','.join([str(i) for i in np.unique(dfCDEF.ID)])
#                    sIdx = ','.join([str(i) for i in np.unique(dfCycles.index)])
#                    dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('(ID in [' + sID + '])'))                   # dataframe with cycle keys
#                    dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('index in [' + sIdx + '])'))                   # dataframe with cycle keys
#                    bCycEx = (dfCycEx.shape[0]>0)
#                else:
#                    bCycEx = False
           
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe
            bCycEx = False
            iStop = -1
            #if '/'+sNode in f.keys():
            if sNode in f:
                #if (type(f[sNode]) is pd.DataFrame):
                bCycEx = True
                iStop = f.get_storer(sNode).nrows
                                                                                                                    
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
                if bSloppy:
                    dfCycEx = extract_cycleKeys_from_node(sNode, )
                                    

            iCycles = dfCDEF.shape[0]
            #iCycles = 10
            for i in range(iCycles):
            #for i in range(9950, 10100):
                    
                tsCT = dfCDEF.create_time[i]                          # current create_time
                ID = dfCDEF.ID[i]                                     # current ID
                
                if not ((ID==0) or pd.isnull(tsCT)):
                
                    sInfo = str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(ID)
                    print(sInfo)                   
                        
                    sFolder = get_folder(sDB, tsCT, ID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            print('    files exist')
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                dfCycEx = f.select(sNode, stop = iStop, columns = sHeadersKey + ['channel'], where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(ID) + ')'))                   # dataframe with cycle keys
                                    #iTmp = dfCycEx[(dfCycEx.create_time == tsCT) & (dfCycEx.ID==ID)].channels       # get channels for that they are existing                              
                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
# TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    #iTS, lOL, sMsg = combine_ts(listTS, iCntMeasBase)                        
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                        
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        df1 = pd.DataFrame(data=(np.tile([tsCT, ID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['channel', 'overlap'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(np.datetime64)                                
                                        dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')
                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['overlap'] = dfTmp['overlap'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #dfTmp.set_index(sHeadersKey)
                                        
                                        #f.append(sNode, dfTmp.set_index(sHeadersKey), format='table', data_columns = True)
                                        f.append(sNode, dfTmp, format='table', data_columns = True, index=False)                                
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        
                                    else:
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception as ex:
                                    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                                
    return(lMsg)




"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-13
"""
# TODO 2018-12-13: alte Version, ggf. spaeter loeschen
def asym(dTS, iOrderDiff, dQs):
    
    sCols = ['diffQ' + str(q) for q in dQs]
    df = np.diff(dTS, n=iOrderDiff, axis=0)
    #df = dfTS.diff(periods=iOrderDiff, axis=0)
    
    df1 = df[df>0].dropna().quantile(q=dQs, axis=0)
    df2 = -df[df<0].dropna()
    df3 = df2.quantile(q=dQs, axis=0)
                            
    dfDiff = df1 - df3
    
    dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
    dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)





"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-13
"""
# TODO 2018-12-13: so aendern, dass kein df sondern ein np.array zurueckgegeben wird, welches man direkt fuer die Klassifikation einlesen kann
def asym_feat_old(dTS, iOrderDiff, dQ):
    
    sCols = ['diff' + str(iOrderDiff) + '_q' + str(dQ)]
    d_dTS = np.diff(dTS, n=iOrderDiff, axis=0)
    
    d_dTS = d_dTS[~np.isnan(d_dTS)]
    
    d1 = np.percentile(d_dTS[d_dTS>0], dQ*100, axis=0)
    
    d2 = -d_dTS[d_dTS<0]
    d3 = np.percentile(d2, dQ*100, axis=0)
                            
    dDiff = d1 - d3
    
    #dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
    dfRes = pd.DataFrame(columns = sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dDiff.values.transpose())
    dfRes.loc[0] = dDiff
    
    #dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)
    
    
    
    
    
# old version - delete when new is working    
def merge_data_old(dfFeat, sDB, sPathData, listNodes, sHeadersKey):

    dfRes = dfFeat.set_index(sHeadersKey)
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    sListMultiIdx = dfFeat.index(sHeadersKey).index()
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
        for sNode, sCols in listNodes:
            sWhere =  ','.join(sHeadersKey) + ' isin [' + ','.join(sListMultiIdx) + ']'
            dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sHeadersKey)
            
            dfRes = pd.concat([dfRes, dfTmp], axis=1, join_axes=[dfRes.index])
                          
                                                    	  
    return(dfRes.reset_index(drop=True, inplace=False))
        
      




