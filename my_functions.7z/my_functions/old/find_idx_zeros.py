# -*- coding: utf-8 -*-
"""
Created on Wed May  8 17:45:32 2019

function to find the zeros of the given data (which are e.g. outcomes of a function)

@author: w012028
@modified: 2019-5-8
"""
import numpy as np
from scipy.signal import savgol_filter

def find_idx_zeros(val, wdw_size = None):
    
    # TODO 2019-5-8: noch generisch bestimmen
    eps = 1e-16
    
    # glaetten
    if wdw_size:
        tmp = (savgol_filter(val, wdw_size, 2)>eps)
    else:
        tmp = (val>eps)
            
    # find zeros
    indicator = [0] + list(np.diff(list(map(int, tmp))))
    return(~(indicator == 0))
    
    
    
    