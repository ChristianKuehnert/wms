# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 17:01:36 2018

    functions for retrieving and storing (raw-)data, labels etc.

@author: w012028
"""

## functions for getting and storing data
## Christian Kuehnert, 2018-11-05

import pymssql
import pymysql
import fnmatch
import os
import os.path
from os import listdir
import numpy as np
import pandas as pd
import datetime as dt
import scipy.io
import gc
import sys
import math
import warnings
#import itertools
import re

from scipy.stats import skew, kurtosis, moment
from statsmodels.tsa.stattools import acf
from sklearn.metrics import precision_recall_fscore_support
from sklearn.svm import SVC
#from sklearn.svm import LinearSVC

#try:
#    import cPickle as pickle
#except ModuleNotFoundError:
#    import pickle



sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\functions'
sys.path.append(sModulePath)
from class_hd5Nodes import hd5Nodes as sNodes







def getwd():
    return os.path.dirname(os.path.abspath(__file__))




# function to create a new folder (if it not already exists)
def createFolder(sFolderName):
    if not os.path.exists(sFolderName):
        os.makedirs(sFolderName)    
    #directory = os.path.dirname(sFolderName)
    #try:
    #    os.stat(directory)
    #except:
    #    os.mkdir(directory)   



    
# 
# from 
#       https://stackoverflow.com/questions/15864082/python-equivalent-of-matlabs-ismember-function
#
# 2018-8-13
#
def ismember(a, b):
    bind = {}
    for i, elt in enumerate(b):
        if elt not in bind:
            bind[elt] = i
    return [bind.get(itm, None) for itm in a]  # None can be replaced by any other "not in b" valu
    
    


#
# function to read from hd5-file
# 2018-8-13
#
def readHD5(sFN_hd5, sKey):		   
    
    if os.path.isfile(sFN_hd5):        
        hf = pd.HDFStore(sFN_hd5, 'r') 
        dfData = hf.get(sKey)                             
        hf.close()
        del hf

    else:
        dfData = []
		
    return dfData
		

		



# function to write the complete data file to hd5-file
#
# Christian Kuehnert, 2018-8-15
#
def writeHD5(dfData, sKey, sFN_hd5, sFormat = 'f'):

    hf = pd.HDFStore(sFN_hd5)
    hf.put(sKey, dfData, append=True)
    hf.close()    




#
# function to load and combine the data for all given databases
# data related to labels with values not in {0,1} will be removed
#
# Christian Kuehnert, 2018-10-4
#
def loadAllData(sDBs, sPathData):
    

    # define strings for title and file names
    if len(sDBs)>1:
        sDB_title = ",".join(sDBs)
        sDB_fn = str(len(sDBs)) + 'wts'
    else:
        sDB_title = sDBs[0]
        sDB_fn = sDBs[0]
        

    lData = []
        
    ## loop through all turbines to load data
    for sDB in sDBs:
              
        ## load data
        sFN_hd5 = sPathData + '\\' + sDB + '_features.hd5'

        if not os.path.isfile(sFN_hd5):

            print('file ' + sFN_hd5 + ' not found')            
            iN = 0
            
        else:                

            print('load data from ' + sFN_hd5)                                    
            dfLabel0 = readHD5(sFN_hd5, 'label')    
            iN = dfLabel0.shape[0]
        
            dfCDEF0 = readHD5(sFN_hd5, 'cdef')              # read database name DataFrame
            dfChannel0 = readHD5(sFN_hd5, 'channel')        # read database name DataFrame
            #dfACF0.append(readHD5(sFN_hd5, 'acf'))          # read database name DataFrame
            dfACF_d10 = readHD5(sFN_hd5, 'acf_d1')          # read database name DataFrame
#            dfACF_d10 = readHD5(sFN_hd5, 'acf')
            dfDQ_d10 = readHD5(sFN_hd5, 'diff_quant_d1')    # read database name DataFrame
                
            #dfDB0 = pd.DataFrame(np.tile(sDB, [iN, 1]), columns=['db'])        # create dataframe with database name
            
            print(sDB + ': ' + str(iN) + ' data sets')
            
                            
                         
            ## eliminate rows where label==nan
            bNaN = np.isnan(dfLabel0).values | (dfLabel0.values == -1)
            if any(bNaN):
            
                print(sDB_title + ': ' + str(sum(bNaN)[0]) + ' data sets with nan, will be removed')
                    
                bNotNaN = np.invert(bNaN)
                #dfDB0 = dfDB0[bNotNaN]
                dfLabel0 = dfLabel0[bNotNaN]
                dfCDEF0 = dfCDEF0[bNotNaN]
                dfChannel0 = dfChannel0[bNotNaN]
                #dfACF0 = dfACF0[bNotNaN]
                dfACF_d10 = dfACF_d10[bNotNaN]
                dfDQ_d10 = dfDQ_d10[bNotNaN]
                
                iN = dfLabel0.shape[0]
           
                    
        if iN > 0:                
            
            lData.append([sDB, dfLabel0, dfCDEF0, dfChannel0, dfDQ_d10, dfACF_d10])            
            #lData.append({'sDB': sDB, 'dfLabel0': dfLabel0, 'dfCDEF0': dfCDEF0, 'dfChannel0': dfChannel0, 'dfDQ_d10': dfDQ_d10, 'dfACF_d10': dfACF_d10})
                                         

    return sDB_title, sDB_fn, lData














# from https://gist.github.com/igniteflow/1632798
# 2018-8-21
def remove_none_elements_from_list(list):
    return [e for e in list if e is not None]
	




# function to query the PIT-Database
#
#
# received from Sebastian Bitzer at 2018-10-12
#
def query_pit(sql, params=None):
    with pymssql.connect(host=r'DR4DBS01', user='monitoring', 
                         password=r'+KLJzQDMuk3C*DGPPzrL', 
                         database='el_igus-its', as_dict=True) as conn:
        with conn.cursor() as cursor:
            if params is None:
                cursor.execute(sql)
            else:
                cursor.execute(sql, params)
                            
            #return pd.DataFrame(cursor.fetchall())
            return pd.DataFrame(data=cursor.fetchall()).infer_objects()




## function to query MySQL-Databases
## 
## TODO 2018-10-15: Funktioniert nicht richtig!!! Deshalb query_MySQL2 erstellt
##
## Christian Kuehnert, 2018-10-15
##
#def query_MySQL_old(db, sql, params=None):
##    with pymysql.connect(host=r'DR4DBS01', user='monitoring', 
##                         password=r'+KLJzQDMuk3C*DGPPzrL', 
##                         database=db, as_dict=True) as conn:    
#    #sHost = r'10.41.52.30:3306'
#    sHost = r'10.41.52.30'
#    # sHost = ''
#    with pymysql.connect(host=sHost, user='webvis-intern', port=3306,
#                         password=r'ne0Nae2Aloo0Gi1E', 
#                         database=db) as conn:        
#        with conn.cursor() as crs:
#        #crs = conn.cursor()        
#            if params is None:
#                crs.execute(sql)
#            else:
#                crs.execute(sql, params)
#            
#        return pd.DataFrame(crs.fetchall()).infer_objects()



"""
function to query the MySQL-Databases
 

Christian Kuehnert, 2018-12-10
"""        
def query_MySQL2(db, sql, params=None):
    
    sHost = r'10.41.52.30'
    conn = pymysql.connect(host=sHost, user='webvis-intern', port=3306,
                           password=r'ne0Nae2Aloo0Gi1E', database=db)
    
    crs = conn.cursor()
    
    if params is None:
        crs.execute(sql)
    else:
        crs.execute(sql, params)
            
    # TODO 2018-10-15: zumindest by tuple-Typ so machen, bei anderen Typen vielleicht das list() weglassen!?)
    #return pd.DataFrame(crs.fetchall())           
    return(crs.fetchall())








# function to return the fields of a table (in MySQL) in database db
#
# Christian Kuehnert, 2018-10-15
#
def get_fields_MySQL(sDB, sTable):
    
    tplRes = query_MySQL2(sDB, 'DESCRIBE ' + sTable)
    dfFields = pd.DataFrame(data=np.array(tplRes), columns = ['Field', 'Type', 'Null', 'Key', 'Default', 'Extra']).infer_objects()
    return dfFields
    



       
"""
function to find the last datetime with (non-fix) data in the given table in the
given database, after this date either no new data were stored or they have been fix

@author: Christian Kuehnert, 2018-12-12

Parameters:
-----------

sDB:              database name
sTabName:         table name
sColTime:         name of the column containing the time
sColNames:        columns of the table (except time)
sColsToTest:      names of the columns that should be analysed for fixed/missing data
#t0:               end time
#tAllowedDelay:    allowed time intervall

Results:
--------

bDataFix:
tLastData:
tLastDataNotFix:  
dfTimes:       DataFrame with columns 1) name, containing the names of the columns (i.e. sColsToTest), 2) bDataFix: boolean flag indicating 
                  if the data are fix/missing for this column, 3) tLastData: 
sMsg:             result/error message

"""
def getTimesLastData(sDB, sTable, sTimeStart, sTimeEnd, sColTime = 'create_time', sColsToTest = None, bExclNaN=True): 
# dfData, dfTimes, lMsg = mfdata.getTimesLastData(sDB = self.sDB, sTable = sTable, sColTime='create_time', sCols = sCols, sTimeStart = sTimeStart, sTimeEnd = sTimeEnd, bExclNaN = bExclNaN)    
    pass
    
#    sTimeFormat = '%Y%m%d%H%M%S'
#    sMsg = ''
#    sTimeFormatOutput = 'yyyy-mm-dd HH:MM:SS'              # output-Timeformat der MySQL-Abfrage in my_mysql_query
#    
#    
#    iCntColsTest = len(sColsToTest)            # number of columns to test
#	                
#    if (iCntColsTest == 0):
#        
#        dfTimes = pd.DataFrame(columns=['column','data_fix','dt_last_data','dt_last_data_not_fix'])
#                
#        sMsg = 'keine Spalten zum Testen ausgewaehlt'
#        
#    else:
#        
#        ## find out if all desired times are already in the queried data or if additional queries have to be made
#        iN = len(sColsToTest)
#        dtTmp = np.tile(pd.NaT, (iN,1))
#        bTmp = np.tile(True, (iN, 1))
#        dfTimes = pd.DataFrame(data=({'column': pd.Series(sColsToTest)}))
#        dfTmp = pd.DataFrame(data=(np.hstack((bTmp, dtTmp, dtTmp))), columns=['data_fix', 't_last_data', 't_last_not_fix'])
#        dfTimes = pd.concat((dfTimes, dfTmp), axis=1)              
#
#
#        ## Abfragen der Daten im angegebenen Zeitintervall
#        try:
#                                  
#            sQuery = 'select ' + ','.join([sColTime] + sColsToTest) + ' from ' + sTable \
#            + ' where not(create_time is NULL) and (create_time >= \'' + sTimeStart  + '\') and (create_time <= \'' + sTimeEnd + '\')'                
#            
#            dfData = pd.DataFrame(list(mfdata.query_MySQL2(self.sDB, sQuery)), columns = [sColTime] + sColsToTest)       # Abfrage innerhalb des interessierenden Zeitintervalls           
#                                
#            dfTime = dfData.loc[:, [sColTime]]
#            for s in sColsToTest:
#                                        
#                if bExclNan:
#                    dfTmp = dfData.loc[:,[s]].dropna(axis=0, subset=[s], inplace=True)
#                else:
#                    dfTmp = dfData.loc[:,[s]]
#                
#                tLastData = max(dTime[not(dfTmp.isna())])
#                if tLastData is None:
#                    sFindLastData.append(s)                 #   Namen der Spalten, fuer die nur NaNs vorhanden sind (d.h. wo der letzte Eintrag noch bestimmt werden muss)
#        
#                            
#
#        ## exclude nan-s for the columns to be tested
#        if bExclNaN and (dfData.shape[0]>0):
#            dfData = dfData.dropna(axis = 0, how='all', inplace=True)
#
#                
#        if dfData.shape[0]==0:
#            
#            sCols_findLastData = sColsToTest
#            sCols_findLastDataNotFix = sColsToTest
#                    
#            sMsg = 'keine Daten in ' + sTimeStart + '-' + sTimeEnd + ' vorhanden'
#                
#            #bFindLastData = true;
#            #bFindNotFix = true;         
#            #tLastData = nan(iCntColsTest,1);
#        else:
#            
#            # ... andernfalls ...
#            dfTime = dfData.loc[:,sColTime]
#            
#            ## for each column find max. time of entry not nan
#            #cLastData = arrayfun(@(iCol) max(dTime(~isnan(dData(:,iCol)))), iColsTest, 'UniformOutput', false);	   # for each column find max. time of entry not nan
#            sFindLastData = []
#            for s in sColsToTest:
#                dfTmp = dfData.loc[:, [s]]
#                tLastData = max(dTime[not(dfTmp.isna())])
#                if tLastData is None:
#                    sFindLastData.append(s)                 #   Namen der Spalten, fuer die nur NaNs vorhanden sind (d.h. wo der letzte Eintrag noch bestimmt werden muss)
#
##                #bNaN = cellfun(@isempty, tLastData);				# 	indicator for columns with nan only		
##                bNaN = tLastData.isna()
##                    
##                iFindLastData = iColsTest[bNaN]                    #   Indizees der Spalten, fuer die nur NaNs vorhanden sind (d.h. wo der letzte Eintrag noch bestimmt werden muss)
##                #cLastData{bNaN} = nan;	  							# 	set such times to nan			
#
##HIER WEITER 2018-12-10, VIELLEICHT MIT DICT ARBEITEN ({columnname: tLastData, tLastDataNotFix}) oder mit dataframe
#            tLastData[not bNaN] = cLastData[not bNaN]					# cast to array
#                
#            ## Jetzt letzten Zeitpunkt mit NICHT-FIXEN Daten bestimmen
#            # TODO 2018-2-4: evtl. noch ein paar Schritte einsparen, indem nur
#            # die Spalten mitgenommen werden, fuer die auch Endwerte
#            # existieren (tLastData), die anderen koennen hier sowieso kein
#            # Ergebnis liefern
#            dfTmp = np.diff(dfTS.loc[:, sColsToTest], n=1, axis=0)
#            
#            
#            dfTmp = (abs(diff(dData(:, iColsTest), 1, 1))>eps);           #     Differenz zum jeweiligen Vorgaenger bilden fuer die relevanten Spalten            
#            cLastDataNotFix = arrayfun(@(iCol) max(dTime([false; dTmp(:,iCol)])), 1:iCntColsTest, 'UniformOutput', false);	# for each column find max. time of entry not nan               
#            bNaN = cellfun(@isempty, cLastDataNotFix);	# 	indicator for columns with nan only	
#            iFindLastDataNotFix = iColsTest(bNaN);
#            #cLastDataNotFix{bNaN} = nan;	 
#                
#            tLastDataNotFix(~bNaN) = cell2mat(cLastDataNotFix(~bNaN));
#                
#                        
#        ## Zusammenstellen des SQL-Strings: Abfrage der Zeitpunkte des Eintrags fuer die einzelnen Spalten		
#        if len(sColsToTest_lastData)>0:
#            lTmp = []
#            for s in sColsToTest_lastData:
#                lTmp.append('select \'' + s + '\',max(create_time)' \
#                    + ' from ' + sTable \
#                    + ' where not (' + s + ' is NULL) and not (create_time is NULL) and (create_time<=\'' + sTimeEnd + '\')')
#            
#            sQuery = ' union '.join(lTmp) + ';'
#                        
#            try:
#                dfData = pd.DataFrame(list(mfdata.query_MySQL2(self.sDB, sQuery)), columns = [sColTime] + sColsToTest)
#                dfData = pd.DataFrame(list(mfdata.query_MySQL2(sDB, sQuery)), columns = ['col','max_time'])
#    
#                if dfData.shape[0]==0:
#                    sMsg = 'keine Daten gefunden'
#                else                    
#                    #iIdx = str2double(sTmp(:,1));
#                    #dTime = datenum(sTmp(:,3), sTimeFormatOutput);
#                    #tLastData(iIdx) = dTime;               
#                    print('hier weitermachen')
#                                                            
#            except Exception, e:
#                sMsg = 'Zugriffsproblem ' + sDB + '.' + sTable + ', ' + repr(e)
#       
#                   
#    
#        if len(sColsToTest_lastNotFix)>0:
#            		
#            ## Zusammenstellen des SQL-Strings: Abfrage der Zeitpunkte des letzten nicht-fixen Eintrags fuer die einzelnen Spalten		
#            # TODO 2018-2-14: ggf. koennte ueberall noch anstelle von sTimeInt(1,:) das jeweilige tLastData verwendet werden
#            lTmp = []
#            for s in sColsToTest_lastNotFix:
#            
#                lTmp.append('select \'' + s + '\',max(tOK) '  \
#                          + 'from (' \
#                          + '   (select min(table_outer.create_time) as tOK ' \
#                          + '    from ' + sTable + ' table_outer '           \
#                          + '    where not (table_outer.create_time is NULL) and not (table_outer.' + s + ' is NULL) and (table_outer.create_time>' \
#                          + '        (select max(create_time) as tmax '        \
#                          + '        from ' + sTable + ' t '                   \
#                          + '        where not (create_time is NULL) and not (' + s + ' is NULL) and (create_time<\'' + sTimeEnd + '\') '           \
#                          + '        group by ' + s + ' '                      \
#                          + '        order by tmax desc '                      \
#                          + '        limit 1,1))) '                            \
#                          + '    union '                                       \
#                          + '    (select min(create_time) as tOK '             \
#                          + '    from ' + sTable + ' '                         \
#                          + '    where not (create_time is NULL) and ' + s + '='    \
#                          + '        (select ' + s + ' as ' + s + '_tmax '     \
#                          + '        from ' + sTable + ' '                          \
#                          + '        where not (create_time is NULL) and not (' + s + ' is NULL) and (create_time<\'' + sTimeEnd + '\') '           \
#                          + '        order by create_time desc ' \
#                          + '        limit 0,1)) '               \
#                          + ') taux')                                              	             
#
#                sQuery = ' union '.join(lTmp)
#            
#                try
#                    dfData = pd.DataFrame(list(mfdata.query_MySQL2(self.sDB, sQuery)), columns = [sColTime] + sColsToTest)
#                    dfData = pd.DataFrame(list(mfdata.query_MySQL2(sDB, sQuery)))
#        
#                    if dfData.shape[0]==0:
#                        sMsg = 'keine Daten gefunden'
#                    else:
##                        iIdx = str2double(sTmp(:,1));
##                        dTime = datenum(sTmp(:,3), sTimeFormatOutput);
##                        tLastDataNotFix(iIdx) = dTime;                                                
#                        print('hier weitermachen')
#                                                                
#                except Exception, e:
#                    sMsg = 'Zugriffsproblem ' + sDB + '.' + sTable + ', ' + repr(e)
##       
##                    
##            end              
##        end
##             
#    end            
#            
#            
#            
#            
#            
#            
#            
#            
#            
#            
#            
#        except Exception as e:
#    	
#            dfData = pd.DataFrame(columns = sColNames)                
#            sMsg = 'Zugriffsproblem ' + sDB + '.' + sTabName + ', ' + logger.error(repr(e))
            

            
  

## function to retrieve data from a given table
##
## Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine Liste von Zeitintervallen
## angegeben werden, dann werden die Daten nur aus diesen Intervallen (als halboffen angenommen) geholt
##
##
## Input:
##       sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
##       sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
##       listTimeIntervals:  Liste der Zeitintervalle, fuer welche die Daten geholt werden
##
## 
##
## Output:
##       dfData:             pandas.DataFrame mit den geholten Daten
##
## Verwendung:
## sDB = 'cmrblba_bc_t_00835'
## sTable = 'ba_cycle_externals'
## listTimeIntervals = [ datenum(2015,1,1), now() ]
## dfCycle = query_tableData(sDB, sTable, listTimeIntervals)
##   
## ----------------------------------------------------------------------------
##
## Christian Kuehnert, 2018-10-29
##
#def query_tableData(sDB, sTable, sColFilter = 'create_time', tsTimeStart=[], tsTimeEnd=[]):
#    
#    listMsg = []
#    listTmp = get_fields_MySQL(sDB, sTable)
#    listFields = listTmp.Field
#    listTypes = listTmp.Type
#    
#    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
#         
#    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
#    dfData.columns = listFields
#
## TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
## diese jeweils category (oder was besseres?) setzen)    
#    #dfData['appendix'] = dfData['appendix'].astype('category')
#    dfData['appendix'] = dfData['appendix'].astype('str')
#    
#    ## set all timestamp-datatypes to pd.datetime
#    iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
#    sCols = listFields[iPos]
#    #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
#    for s in sCols:    
#        dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    
#
#    
#    return dfData, listMsg
#    


"""
function to retrieve data from a given table

@author: Christian Kuehnert
2019-6-2


Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden


Input:
      sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
      sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
      sWC:                where clause
      sLimit:             limit-Angaben, kann natuerlich die where clause nochmal einschraenken

Output:
      dfData:             pandas.DataFrame mit den geholten Daten

Verwendung:
sDB = 'cmrblba_bc_t_00835'
sTable = 'ba_cycle_externals'
sWC = ''
sLimit = '
dfCycle = query_tableData(sDB, sTable, sWC)
"""  
def query_tableData(sDB, sTable, sWC=None, sLimit=None):
    
    listMsg = []
    listTmp = get_fields_MySQL(sDB, sTable)
    listFields = listTmp.Field
    listTypes = listTmp.Type
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL += ' where ' + sWC.strip()
            
    if sLimit:
        if (len(sLimit.strip())>0):
            sSQL += ' limit ' + sLimit
        
    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
    
    if dfData.shape[0]>0:
        dfData.columns = listFields
    
        # TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
        # diese jeweils category (oder was besseres?) setzen)    
        #dfData['appendix'] = dfData['appendix'].astype('str')
        
        ## set all timestamp-datatypes to pd.datetime
        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
        sCols = listFields[iPos]
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in sCols:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

    else:
        listMsg.append('keine Daten gefunden')
        dfData = pd.DataFrame(columns=listFields)
    
    return dfData, listMsg
    


"""
function to generate the days in the given time interval
@author: see https://stackoverflow.com/questions/10688006/generate-a-list-of-datetimes-between-an-interval

2019-2-8
"""
def perdelta(start, end, delta):
    curr = start
    while curr < end:
        yield curr
        curr += delta
   
    

# function to retrieve data from a given table
#
# Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden
#
#
# Input:
#       sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
#       sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
#       sWC:                where clause
#
# Output:
#       dfData:             pandas.DataFrame mit den geholten Daten
#
# Verwendung:
# sDB = 'cmrblba_bc_t_00835'
# sTable = 'ba_cycle_externals'
# sWC = ''
# dfCycle = query_tableData(sDB, sTable, sWC)
#   
# ----------------------------------------------------------------------------
#
# Christian Kuehnert, 2019-1-14
#
def query_tableData_old(sDB, sTable, sWC = None):
    
    listMsg = []
    listTmp = get_fields_MySQL(sDB, sTable)
    listFields = listTmp.Field
    listTypes = listTmp.Type
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL = sSQL + ' where ' + sWC.strip()
        
    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
    
    if dfData.shape[0]>0:
        dfData.columns = listFields
    
        # TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
        # diese jeweils category (oder was besseres?) setzen)    
        #dfData['appendix'] = dfData['appendix'].astype('str')
        
        ## set all timestamp-datatypes to pd.datetime
        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
        sCols = listFields[iPos]
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in sCols:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

    else:
        listMsg.append('keine Daten gefunden')
        dfData = pd.DataFrame(columns=listFields)
    
    return dfData, listMsg
    



  

## function to retrieve data from a given table
##
## Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine Liste von Zeitintervallen
## angegeben werden, dann werden die Daten nur aus diesen Intervallen (als halboffen angenommen) geholt
##
##
## Input:
##       sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
##       sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
##       listTimeIntervals:  Liste der Zeitintervalle, fuer welche die Daten geholt werden
##
## 
##
## Output:
##       dfData:             pandas.DataFrame mit den geholten Daten
##
## Verwendung:
## sDB = 'cmrblba_bc_t_00835'
## sTable = 'ba_cycle_externals'
## listTimeIntervals = [ datenum(2015,1,1), now() ]
## dfCycle = query_tableData(sDB, sTable, listTimeIntervals)
##   
## ----------------------------------------------------------------------------
##
## Christian Kuehnert, 2018-10-29
##
#def query_tableData(sDB, sTable, sColFilter = 'create_time', tsTimeStart=[], tsTimeEnd=[]):
#    
#    listMsg = []
#    listTmp = get_fields_MySQL(sDB, sTable)
#    listFields = listTmp.Field
#    listTypes = listTmp.Type
#    
#    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
#         
#    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
#    dfData.columns = listFields
#
## TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
## diese jeweils category (oder was besseres?) setzen)    
#    #dfData['appendix'] = dfData['appendix'].astype('category')
#    dfData['appendix'] = dfData['appendix'].astype('str')
#    
#    ## set all timestamp-datatypes to pd.datetime
#    iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
#    sCols = listFields[iPos]
#    #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
#    for s in sCols:    
#        dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    
#
#    
#    return dfData, listMsg
#    


# function to retrieve data from a given table
#
# Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden
#
#
# Input:
#       sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
#       sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
#       sWC:                where clause
#
# Output:
#       dfData:             pandas.DataFrame mit den geholten Daten
#
# Verwendung:
# sDB = 'cmrblba_bc_t_00835'
# sTable = 'ba_cycle_externals'
# sWC = ''
# dfCycle = query_tableData(sDB, sTable, sWC)
#   
# ----------------------------------------------------------------------------
#
# Christian Kuehnert, 2018-12-9
#
def query_tableData_old(sDB, sTable, sWC = None):
    
    listMsg = []
    listTmp = get_fields_MySQL(sDB, sTable)
    listFields = listTmp.Field
    listTypes = listTmp.Type
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL = sSQL + ' where ' + sWC.strip()
        
    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
    
    if dfData.shape[0]>0:
        dfData.columns = listFields
    
    # TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
    # diese jeweils category (oder was besseres?) setzen)    
        #dfData['appendix'] = dfData['appendix'].astype('category')
        dfData['appendix'] = dfData['appendix'].astype('str')
        
        ## set all timestamp-datatypes to pd.datetime
        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
        sCols = listFields[iPos]
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in sCols:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

    else:
        listMsg.append('keine Daten gefunden')
        dfData = pd.DataFrame(columns=listFields)

    
    return dfData, listMsg
    


# function to retrieve data from a given table from the PIT
#
# Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden
#
#
# Input:
#       sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
#       sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
#       sWhereClause:       where clause
#
# Output:
#       dfData:             pandas.DataFrame mit den geholten Daten
#
# Verwendung:
# sDB = 'cmrblba_bc_t_00835'
# sTable = 'ba_cycle_externals'
# sWhereClause = ''  # TODO 2018-11-2: noch richtiges Bsp. machen
# query_tableData(sDB, sTable, listTimeIntervals)
#   
# ----------------------------------------------------------------------------
#
# Christian Kuehnert, 2018-11-2
#
def query_tableData_PIT(sTable, listCols = [], sWhereClause = None):   
        
    if len(listCols)>0:
        sSQL = 'select ' + ','.join(listCols) + ' from ' + sTable
    else:
        sSQL = 'select * from ' + sTable
        
    if isinstance(sWhereClause, str):
        if len(sWhereClause.strip())>0:
            sSQL = sSQL + ' where ' + sWhereClause
        
    return(query_pit(sSQL))
    











# function to transform matlab datetime to python datetime
# aus https://stackoverflow.com/questions/13965740/converting-matlabs-datenum-format-to-python
def matlab2datetime(matlab_datenum):

    day = dt.datetime.fromordinal(int(matlab_datenum))
    dayfrac = dt.timedelta(days=matlab_datenum%1) - dt.timedelta(days = 366)
    return day + dayfrac





#
# function to combine the given strings to a file name with full path (or to a path)
#
# Christian Kuehnert, 2018-10-15
#
def fullfile(listNames):
    return '\\'.join(listNames)




#
# function to find the positions of the elements of sListSearch in the list sList
#
# Christian Kuehnert, 2018-10-16
#
def find_col_idx(sListSearch, sList):

    return [sList.index(el) if el in sList else None for el in sListSearch]
        





#
# function to get the drive for the .csv-data from the date
#
# input:
#       - sDB:     database name of the turbine of interest
#       - tsCT:    create time as pandas...time stamp
#
# output:
#       - sDir:    directory containing the files with ts and sda data
#
#
# Christian Kuehnert, 2019-3-15
#
def get_BcDataPath(sDB, tsCT):

    #dTimeChange = 736760.4416666666511446237564                 # matlab date number, equals datenum( 2017,3,6,10,36,0)
    tsChange_to_bcdata2 = pd._libs.tslibs.timestamps.Timestamp('2017-03-06 10:36:00')    
    tsChange_to_bcdata3 = pd._libs.tslibs.timestamps.Timestamp('2019-03-12 17:17:00')       # todo 2019-3-15: ggf. nochmal genau von jmd. geben lassen, ist erstmal empirisch aus webAna bestimmt
#    if (sDB in ['cmrblba_vid_reinsdorf', 'cmrblba_bc_t_01761_b', 'cmrblba_bc_t_01305_strain']):
#        #sDir = '\\10.41.52.54\\bcdata'   
#        sDir = 'Z:'
#    else:
    if (tsCT > tsChange_to_bcdata2):
        if (tsCT > tsChange_to_bcdata3):
            sDir = 'Z:'
        else:
            sDir = 'X:'
    else:
        sDir = 'Y:'
                    
    return sDir





#
# function to get folder names for retrieving ts data or sda data
#
# Christian Kuehnert, 2018-10-16
#
def get_folder(sDB, tsCT, dID):

    #dTmp = matlab2datetime(dCreateTime)    
    #return fullfile(get_BcDataPath(sDB, dCreateTime), dTmp.year, dTmp.month, dTmp.day, dID)    
    #return fullfile([get_BcDataPath(sDB, tsCT), sDB, str(tsCT.year), str(tsCT.month), str(tsCT.day), str(dID)])    
    return fullfile([get_BcDataPath(sDB, tsCT), sDB.replace('cmrblba_',''), tsCT.strftime('%Y\\%m\\%d'), str(dID)])







##
## function to create the file and to add all relevant groups 
## 
## Christian Kuehnert, 2018-10-16
##
#def initialize_hd5file(sDB, sPathData):
#    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
#    sNode = 'turbine_info'
#    
#    if not os.path.isfile(sFN_hd5):             # if no such hd5-file exists            
#        with pd.HDFStore(sFN_hd5, mode="w", complevel=9, complib='blosc:lz4') as f:        # create empty hd5-file
#            f.close()
#            
#    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#
#        if not (sNode in f):
#            # retrieve relevant data (farm, turbine etc.) from pit   
#            sTmp = 'SELECT Windpark1#WP_Name as farm,WEA_Name as turbine,WEA_Typ#Name as turbine_type,Datenbank as turbine_database,Beginn_Datenspeicherung as begin_data,Inbetriebnahme_abgeschlossen_am as operational FROM VIEW_Windkraftanlagen WHERE Datenbank=\'' + sDB + '\''
#            dfTmp = query_pit(sTmp)
#            #f.append(sNode, dfTmp, format='table', data_columns = True, index=False)
#            #f.append(sNode, dfTmp, format='table', data_columns = True)
#            f.put('turbine_info', dfTmp, format='table', data_columns=True, index=False)                           
#            #f.flush()
#            
#        #f.close()
#        
#        


#
# function to create the file and to add all relevant groups 
# 
# Christian Kuehnert, 2019-1-7
#
def initialize_hd5file(sDB, sPathData):
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
    
    if not os.path.isfile(sFN_hd5):             # if no such hd5-file exists            
        with pd.HDFStore(sFN_hd5, mode="w", complevel=9, complib='blosc:lz4') as f:        # create empty hd5-file
            f.close()
            
    update_turbineInfo(sDB, sPathData) 
        



#
# function to save turbine info in hd5-file if not already there
# 
# Christian Kuehnert, 2019-1-11
#
def update_turbineInfo(sDB, sPathData):
    
    sNode = 'turbine_info'

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])    
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if not (sNode in f):
            # retrieve relevant data (farm, turbine etc.) from pit   
            sTmp = 'SELECT Windpark_WEA#Windparkname as farm,WEA_Name as turbine,WEA_Typ#Name as turbine_type,Datenbankname as turbine_database,Beginn_Datenspeicherung as begin_data,Inbetriebnahme_abgeschlossen as operational FROM VIEW_Windkraftanlagen WHERE Datenbankname=\'' + sDB + '\''
            dfTmp = query_pit(sTmp)
            #f.append(sNode, dfTmp, format='table', data_columns = True, index=False)
            #f.append(sNode, dfTmp, format='table', data_columns = True)
            f.put(sNode, dfTmp, format='table', data_columns=True, index=False)                           





"""
function to get the rows of df1 that are not in df2, regarding to the values
in columns sHeaders
 
@author: Christian Kuehnert, 2018-10-18
"""
def setdifference_df(df1, df2, sHeaders):
    
    if ((df1.shape[0]==0) or (df2.shape[0]==0)):
        return df1
    else:
        df1 = df1.set_index(sHeaders, drop=False)
        df2 = df2.set_index(sHeaders, drop=False)
        idx = df1.index.difference(df2.index)
        
        # TODO 2018-11-13: komisch, dass Unterschiedliches verhalten fuer leeren
        # und nichtleeren Index -> nochmal genau verstehen und moeglichst auf
        # identischen Code umstellen
        if len(idx)>0:
            dfDiff = df1.loc[idx,:]
        else:
            dfDiff = df1.iloc[idx,:]
        
        return dfDiff.reset_index(drop=True)




# function to get the intersection of df1 and df2, regarding to the values
# in columns sHeaders
# 
# Christian Kuehnert, 2018-11-6
#
def intersect_df(df1, df2, sHeaders):
    
    dfInter = pd.merge(df1, df2, how='inner', on=sHeaders)
    dfInter.dropna(inplace = True)
    return(dfInter)





# function to set the types of the dataframe
# TODO 2018-11-6: wenn moeglich die "asymmetrie"
# bzgl. timestamp beseitigen und alles generisch machen
# 
# Christian Kuehnert, 2018-11-6
#
def set_dtype(dfDF, listCols, listTypes):
    
    for i in range(len(listCols)):
        s = listCols[i]
        t = listTypes[i]
        #if (t == 'timestamp'):
        if (t is np.datetime64):
            dfDF[s] = pd.to_datetime(dfDF[s], errors='coerce')
        else:
            dfDF[s] = dfDF[s].astype(t)
    
    return(dfDF)
            
            
"""    
function that gets the bit at a specified position in a given string

Parameters:
-----------

varDual:  character array representing dual numbers OR the dual number 
          as integer in decimal system
iPos:     position of the interesting bit, indexing starts with 1
          (i.e. at iPos==1 is bit b0 with b0*2^0, at iPos==2 is
          bit b1 with b1*2^1 etc.)
varargin: only valid if varDual is string or character;             if 'left' it is assumed that the dual number in varDual
          starts from the left, otherwise (also if missing or empty) it is
          assumed to start from the right

 
Features:
---------

iBit:   integer vector containing the value of bit at (0-based) iPos, if 
        the rows in varDual have less than iPos characters, 
        bBit=0 is returned, if varDual can't be processed (or 
        other error occur), NaN is returned


 Christian Kuehnert, 2018-12-9

usage:
sDual = ['00110'; ...
         '11111'; ...
         '01000'];
iPos = 2;
function iBit = getBit(varDual, iPos, varargin)
"""
def getBit(varDual, iPos, bFromLeft=False):    

    if isinstance(varDual, int) or isinstance(varDual, float):
    
        try:
            #iBit = (floor(varDual/2^(iPos-1)) % 2)            
            iBit = int((int(np.floor(varDual)) & (1 << (iPos - 1)))>0)
        except:
            iBit = np.nan
    
    
    elif isinstance(varDual, str):
        try:
            iL = len(varDual)               
            if (iL < iPos):
                iBit = 0
            else:                       
                if bFromLeft:
                    iTmp = iPos
                else:
                    iTmp = iL-(iPos-1)

                iTmp = iL-(iPos-1)
                iBit = int(varDual[:,iTmp])
   
        except:
            iBit = np.nan
        

    else:
        print('Can''t process input variables of class ' + type(varDual))
        iBit = np.nan
        
    return(iBit)
        
    
    
            
# function to set specifically the headers of keys
# 
# Christian Kuehnert, 2018-11-6
#
def set_dtype_headersKey(dfDF):
    listCols = ['create_time', 'ID', 'channel']    
    listTypes = [np.datetime64, int, int]
    return(set_dtype(dfDF, listCols, listTypes))
    
    
    
    
     
 
"""
Function to read from mysql tables
@author: Christian Kuehnert
2019-2-14

"""
def read_from_table_old(sDB, sTable, sWC=None, iChunkSize=10**5):

    sHost = r'10.41.52.30'
    con = pymysql.connect(host=sHost, user='webvis-intern', port=3306,
                           password=r'ne0Nae2Aloo0Gi1E', database=sDB)
        
    listTmp = get_fields_MySQL(sDB, sTable)
    listFields = listTmp.Field
    listTypes = listTmp.Type
    
    ## set all timestamp-datatypes to pd.datetime
    iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
    sColsTimeStamp = listFields[iPos]
    
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL += ' where ' + sWC.strip()
            
    sql_reader = pd.read_sql(sSQL, con, chunksize=iChunkSize)
    
    return({'listFields': listFields,
            'sColsTimeStamp': sColsTimeStamp,
            'sql_reader': sql_reader})

    

 
"""
Function to read from mysql tables
@author: Christian Kuehnert
2019-2-14

"""
def read_from_table(sDB, sTable, sSQL, iChunkSize=10**5):

    sHost = r'10.41.52.30'
    con = pymysql.connect(host=sHost, user='webvis-intern', port=3306,
                           password=r'ne0Nae2Aloo0Gi1E', database=sDB)
        
    #listTmp = get_fields_MySQL(sDB, sTable)
    #listFields = listTmp.Field
    #listTypes = listTmp.Type
    
    ## set all timestamp-datatypes to pd.datetime
    #iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
    #sColsTimeStamp = listFields[iPos]
    
    
    #sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    #if sWC:
    #    if (len(sWC.strip())>0):
    #        sSQL += ' where ' + sWC.strip()
            
    return(pd.read_sql(sSQL, con, chunksize=iChunkSize))
    
    #return({'listFields': listFields,
    #        'sColsTimeStamp': sColsTimeStamp,
    #        'sql_reader': sql_reader})

    



"""
Function to read the data from mysql tables and store them in hd5 file node
@author: Christian Kuehnert
2019-2-7

"""
def read_mysql_toHD5(f, sNode, sDB, sTable, sWC=None, iChunkSize=10**5):

    tmp = read_from_table(sDB, sTable, sWC=None, iChunkSize=iChunkSize)

    
    dfData_hd5 = None
    if sNode in f:        
        dfData_hd5 = f[sNode]        
        if not isinstance(dfData_hd5, pd.DataFrame):
            f.remove(sNode)
            dfData_hd5 = None

            f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
            
    i=0
    for chunk in tmp['sql_reader']:
        i += 1
        print('chunk ' + str(i))
        dfData = pd.DataFrame(data=np.array(chunk)).infer_objects()            
        dfData.columns = tmp['listFields']
        
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in tmp['sColsTimeStamp']:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

        dfAdd = setdifference_df(dfData, dfData_hd5, sHeadersKey).reset_index(drop=True)
 
        if dfAdd.shape[0]>0:
            if sNode in f:
                f.append(sNode, dfAdd, index=False)
            else:
                f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)                        

    
          
#TODO 2019-2-7: evtl. zu einem zusammenfassen (mit Option bUpdateHD5 oder mit sDestination
#                                              = 'hd5', 'df', 'both' und den entsprechenden
#                                              weiteren Variablen)  
    
   

"""
Function to read from mysql tables and store it to dataframe
@author: Christian Kuehnert
2019-2-7

TODO 2019-2-7: pruefen, ob auch synchron mit update of hd5 und anschliessendem Auslesen

"""
# TODO 2019-2-7: hier noch function uebergeben mit kwargs, und auf die einzelnen chunks anwenden (wenn nicht ==None)
def read_mysql_toDF(sDB, sTable, sWC=None, iChunkSize=10**5):

    #tmp = read_from_table(sDB, sTable, sWC=sWC, iChunkSize=iChunkSize)
    tmp = read_from_table_old(sDB, sTable, sWC=sWC, iChunkSize=iChunkSize)
            
    i=0
    lData = []
    for chunk in tmp['sql_reader']:
        i += 1
        print('chunk ' + str(i))
        dfData = pd.DataFrame(data=np.array(chunk)).infer_objects()            
        dfData.columns = tmp['listFields']
        
        for s in tmp['sColsTimeStamp']:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

        lData.append(dfData)
    
    dfData = pd.concat(lData, axis=0).reset_index(drop=True)
        
    return(dfData)
    
    
    

    
    
    
    
    
    
#    
#"""
#Function to retrieve the data from the database
#@author: Christian Kuehnert
#
#
#2019-2-6
#
#"""    
#def get_data_fromDB_new_to_be_completed(sDB, sTable, dictTypes=None, listCols=None, time_start=None, time_end=None, iOffset=None, iLimit=None):
#    
#    sWC = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = '%Y%m%d%H%M%S')    # retrieve all data in the given time interval        
#    
#    # if some limit is given:
#    if iLimit:
#        if iOffset:
#            sLimit = str(iOffset) + ',' + str(iLimit)
#        else:            
#            sLimit = str(iLimit)
#    else:
#        sLimit = None
#        
#        
#    dfData, sMsg = query_tableData(sDB, sTable, sWC, sLimit)    
#
#    ## set types, if some type dictionary is given                                        
#    if dictTypes:    
#        for sField, tType in dictTypes.items():
#            dfData[sField] = dfData[sField].astype(tType)
#        
#    ## return wanted columns only        
#    if listCols:
#        return(dfData.loc[:, listCols])
#        
#    else:
#        return(dfData)

    
          
   
    
"""
Function to retrieve the data from the database
@author: Christian Kuehnert


2019-1-28

"""    
def get_data_fromDB(sDB, sTable, dictTypes=None, listCols=None, time_start=None, time_end=None):
    
    sWC = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = '%Y%m%d%H%M%S')    # retrieve all data in the given time interval        
    dfData, sMsg = query_tableData(sDB, sTable, sWC)    

    ## set types, if some type dictionary is given                                        
    if dictTypes:    
        for sField, tType in dictTypes.items():
            dfData[sField] = dfData[sField].astype(tType)
        
    ## return wanted columns only        
    if listCols:
        return(dfData.loc[:, listCols])
        
    else:
        return(dfData)

    
            
    


"""
function that updates the node sNode in hdfstore HDFStore with the data dfData_sql that are (regarding the keys sHeadersKey) not already in this node-table
@author Christian Kuehnert
2019-6-2

Input:
------
    f:   hdfstore, must be opened with mode 'a' and complevel '9' and complib 'blosc:lz4'
    sNode: node in f
    dfData_sql: pandas.DataFrame containing the data
    

Output:
-------
    None

"""
def update_hd5Table(f, sNode, dfData_sql, sHeadersKey):
        ## if there are any data then append them to cdef data already in hd5 file

    if sNode in f:
        
        dfData = f[sNode]
        
        if isinstance(dfData, pd.DataFrame):
                                
            # add new cdef-data to current cdef-data  
            # TODO 2018-10-17: evtl. schneller machen - nicht erst alles auslesen sondern gleich nur die, die fuer die Auswahl
            # der neu hinzukommenden gebraucht werden                    
            #dfData = dfData.set_index(sHeadersKey, drop=False)                    
            #dfData_sql = dfData_sql.set_index(sHeadersKey, drop=False)
            #dfAdd = dfData_sql.loc[dfData_sql.index.difference(dfData.index)]                    
            dfAdd = setdifference_df(dfData_sql, dfData, sHeadersKey)
 
            if dfAdd.shape[0]>0:
                # der Zweig unter bNew funtioniert nicht richtig, deshalb der etwas (beim Ausfuehren) aufwaendigere
                # andere Zweig aktiviert
                bNew = True
                if bNew:                        
                    # TODO 2018-10-17: ggf. noch sortieren
                    f.append(sNode, dfAdd.reset_index(drop=True), index=False)
                else:
                    if dfAdd.shape[0] > 0:
                        dfComb = pd.concat((dfData, dfAdd), axis=0, ignore_index=True, sort=False)
                        # TODO 2018-11-2: noch eleganter machen, ist eigentlich unnoetig wenn dfAdd=0 ist, ggf. reicht auch reset innerhalb der .hd5-Datei                            
                        f.remove(sNode)
                        f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
                        #f.put(sNode, dfComb, format='table', append=True, data_columns=True)    
                    #else:
                    #    dfComb = dfData

        else:
#            dfAdd = dfData_sql.reset_index(drop=True)
            f.remove(sNode)
#            f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
            f.put(sNode, dfData_sql.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)
                        
    else:
#        dfAdd = dfData_sql.reset_index(drop=True)
#        f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
        f.put(sNode, dfData_sql.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)









"""
function that appends the given data dfAppend to the node sNode in hdfstore HDFStore
@author Christian Kuehnert
2019-6-2

Input:
------
    f:   hdfstore, must be opened with mode 'a' and complevel '9' and complib 'blosc:lz4'
    sNode: node in f, must contain dataframe to which the data in dfAppend are appendable
    dfAppend: pandas.DataFrame containing the data, must be appendable to the data in node sNode in f
                The synchronisation with the data in the node must have been done BEFORE calling this function
    

Output:
-------
    None

"""
def append_to_hd5Table(f, sNode, dfAppend, sHeadersKey):

    if sNode in f:
                
        if dfAppend.shape[0]>0:
            f.append(sNode, dfAppend, index=False)
            
    else:
        f.put(sNode, dfAppend, format='table', append=True, data_columns=True, index=False)



    
    
    
    
            
"""
function to update data in hd5-file directly from database
@author: Christian Kuehnert

2019-6-2

"""
def update_hd5fromDB_now_to_be_finished(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=None, time_start=None, time_end=None, iLimit=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
       
    if not os.path.isfile(sFN_hd5):               # if no such hd5-file exists      
        initialize_hd5file(sDB, sPathData)        # create it hd5-file

    bHD5Data = False
    with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:
        
            dfData = f[sNode]
        
            if not isinstance(dfData, pd.DataFrame):
                f.remove(sNode)
            else:
                bHD5Data = True
                                
        
        sql_reader = pd.read_sql(sSC, connector, chunksize=100000)
        
        for chunk in sql_reader:
            i=7
            f.append(sNode, chunk, index=False)
            

#                dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start, iOffset=iOffset, iLimit=iLimit)
#                bContinue = dfData_sql.shape[0]>0
#                if bContinue:
#                    if bHD5Data:
#                        dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
#                    else:
#                        dfAppend = dfData_sql.reset_index(drop=True)
#                    
#                    append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)
#                iOffset += iLimit                    
#                                                
#        else:
#            
#            dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start)
#            if dfData_sql.shape[0]>0:
#                if bHD5Data:
#                    dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
#                else:
#                    dfAppend = dfData_sql.reset_index(drop=True)
#                
#                append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)

        f.close()                                                
    
#    else:       
#        dfAdd = pd.DataFrame()
#
#    return(dfAdd)
           
  
    
            
"""
function to update data in hd5-file directly from database
@author: Christian Kuehnert

2019-6-2

"""
def update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=None, time_start=None, time_end=None, iLimit=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
       
    if not os.path.isfile(sFN_hd5):               # if no such hd5-file exists      
        initialize_hd5file(sDB, sPathData)        # create it hd5-file

    bHD5Data = False
    with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:
        
            dfData = f[sNode]
        
            if not isinstance(dfData, pd.DataFrame):
                f.remove(sNode)
            else:
                bHD5Data = True
                                
        if iLimit:
            
            iOffset=0
            bContinue=True
            while bContinue:  
                print('offset=' + str(iOffset))                     
                dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_end, iOffset=iOffset, iLimit=iLimit)
                bContinue = dfData_sql.shape[0]>0
                if bContinue:
                    if bHD5Data:
                        dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
                    else:
                        dfAppend = dfData_sql.reset_index(drop=True)
                    
                    append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)
                iOffset += iLimit                    
                                                
        else:
            
            dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_end)
            if dfData_sql.shape[0]>0:
                if bHD5Data:
                    dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
                    # NOTE 2019-4-10: the try-catch became necessary because it appeared that e.g. for updating cdef the timezone column first was 3 letters long ('CET'), but when trying to
                    # add a 4-letter word (*gg) ('CEST') it failed of course
                    try:
                        append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)
    
                    except:
                        f.remove(sNode)
                        append_to_hd5Table(f, sNode, pd.concat((dfData, dfAppend), axis=0, ignore_index=True), sHeadersKey)                
                    
                else:
                    append_to_hd5Table(f, sNode, dfData_sql.reset_index(drop=True), sHeadersKey)
                    
                
        f.close()                                                
    
   
#            
#"""
#function to update data in hd5-file directly from database
#@author: Christian Kuehnert
#
#2019-1-28
#
#"""
#def update_hd5fromDB_old(sDB, sPathData, sTable, sNode, dictTypes=None, sHeadersKey = None, time_start=None, time_end=None):
#
#    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
#    
#    #sHeadersKey = ['create_time', 'ID']
#       
#    # if no such hd5-file exists
#    if not os.path.isfile(sFN_hd5):                        
#        initialize_hd5file(sDB, sPathData)        # create it hd5-file
#
#    dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start)
##    sWC = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = '%Y%m%d%H%M%S')    # retrieve all data in the given time interval        
##    dfData_sql, sMsg = query_tableData(sDB, sTable, sWC)    
##
##    ## set types, if some type dictionary is given                                        
##    if dictTypes:
##    
##        for sField, tType in dictTypes.items():
##            dfData_sql[sField] = dfData_sql[sField].astype(tType)
#            
#    ## if there are any data then append them to cdef data already in hd5 file
#    if dfData_sql.shape[0] > 0:
#        
#        with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:
#
#            if sNode in f:
#                
#                dfData = f[sNode]
#                
#                if isinstance(dfData, pd.DataFrame):
#                                        
#                    # add new cdef-data to current cdef-data  
#                    # TODO 2018-10-17: evtl. schneller machen - nicht erst alles auslesen sondern gleich nur die, die fuer die Auswahl
#                    # der neu hinzukommenden gebraucht werden                    
#                    #dfData = dfData.set_index(sHeadersKey, drop=False)                    
#                    #dfData_sql = dfData_sql.set_index(sHeadersKey, drop=False)
#                    #dfAdd = dfData_sql.loc[dfData_sql.index.difference(dfData.index)]                    
#                    dfAdd = setdifference_df(dfData_sql, dfData, sHeadersKey)
# 
#                    # der Zweig unter bNew funtioniert nicht richtig, deshalb der etwas (beim Ausfuehren) aufwaendigere
#                    # andere Zweig aktiviert
#                    bNew = False
#                    if bNew:                        
#                        # TODO 2018-10-17: ggf. noch sortieren
#                        f.append(sNode, dfAdd.reset_index(drop=True), index=False)
#                    else:
#                        if dfAdd.shape[0] > 0:
#                            dfComb = pd.concat((dfData, dfAdd), axis=0, ignore_index=True, sort=False)
#                            # TODO 2018-11-2: noch eleganter machen, ist eigentlich unnoetig wenn dfAdd=0 ist, ggf. reicht auch reset innerhalb der .hd5-Datei                            
#                            f.remove(sNode)
#                            f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
#                            #f.put(sNode, dfComb, format='table', append=True, data_columns=True)    
#                        #else:
#                        #    dfComb = dfData
#
#                else:
#                    dfAdd = dfData_sql.reset_index(drop=True)
#                    f.remove(sNode)
#                    f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
#                                
#            else:
#                dfAdd = dfData_sql.reset_index(drop=True)
#                f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
#                
#            f.close()                                                
#    
#    else:       
#        dfAdd = pd.DataFrame()
#
#    return(dfAdd)
#           


       
# function to update cdef data
# 
# Christian Kuehnert, 2019-2-6
#
def update_cdef(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cdef
    sTable = 'ba_cycle_measurement_cycle'
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int, 'appendix': str}
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
           

# function to update data in table 'ba_cycle_status'
# 
# Christian Kuehnert, 2019-2-6
#
def update_status(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cycle_status
    sTable = 'ba_cycle_status'
    #dictTypes={'ID': int, 'appendix': str}
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int}
    iLimit = 500000

    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)

    #return(dfData)
 

       
# function to update data in table 'ba_cycle_measurement'
# 
# Christian Kuehnert, 2019-2-6
#
def update_meas(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cycle_measurement
    sTable = 'ba_cycle_measurement'
    #dictTypes={'ID': int, 'appendix': str}
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int}
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
 
       
# function to update cdef data
# 
# Christian Kuehnert, 2019-2-6
#
def update_ext(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.externals
    sTable = 'ba_cycle_externals'
    sHeadersKey = ['create_time']
    dictTypes=None
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
           
    
    
       
# function to update cdef data
# 
# Christian Kuehnert, 2019-2-6
#
def update_se(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.sig_energy
    #sTable = 'sig_energies'
    sTable = 'ba_cycle_sig_energies'
    sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
    dictTypes={'cycle_id': int}
    iLimit = 500000
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)

    #return(dfData)
        





"""
function to update one the hd5-file of the given turbine
@author: Christian Kuehnert

2019-2-6

Example:
--------
sDB = 'cmrblba_bc_t_mb_bw48'
sPathData = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\data\hd5_files'
update_all_hd5(sDB, sPathData)


"""
def update_all_hd5(sDB, sPathData, time_start=None, time_end=None):
    
    print('updating ' + sDB + ':')
    
    print('       update cdef')
    update_cdef(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update status')
    update_status(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update se')
    update_se(sDB, sPathData, time_start=time_start, time_end=time_end)        
    
    print('       update sda')
    update_sda(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update ts')
    update_ts(sDB, sPathData, time_start=time_start, time_end=time_end)
         



     
## function to update dyn loads data
## 
## Christian Kuehnert, 2019-1-22
##
#def update_dynloads(sDB, sPathData, time_start=None, time_end=None):
#    
#    sNode = sNodes.dyn_loads
#    #sTable = 'sig_energies'
#    sTable = 'ba_cycle_dyn_loads'
#    dictTypes={'cycle_id': int}
#    sHeadersKey = ['create_time', 'object_id', 'direction', 'freq', 'amp']
#
#    dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, dictTypes=dictTypes, sHeadersKey = sHeadersKey, time_start=time_start, time_end=time_end)
#
#    return(dfData)
      



       
# function to update cdef data
# 
# Christian Kuehnert, 2018-12-4
#
# TODO 2018-10-19: bei HDFStore ist das Problem, dass die files immer groesser werden, selbst wenn ein node geloescht wird 
# (da der Speicherplatz dabei nicht freigegeben wird) -> dieses Problem noch loesen! Trotzdem erstmal so gemacht, um  erstmal
# zu starten -> vielleicht spaeter mit Patricks tools sowieso obsolet/geloest
#
#def update_cdef(sDB, sPathData, listTimeIntervals=[-np.Infinity, np.Infinity]):
def update_cdef_old(sDB, sPathData, time_start=None, time_end=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
    
    sHeadersKey = ['create_time', 'ID']
    
    sNode = 'raw_data/cdef'
    
    # if no such hd5-file exists
    if not os.path.isfile(sFN_hd5):                        
        initialize_hd5file(sDB, sPathData)        # create it hd5-file


    # retrieve all cdef-data in the given time interval
    sWC = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = '%Y%m%d%H%M%S')
    #sWC = ''

        
    dfCDEF_sql, sMsg = query_tableData(sDB, 'ba_cycle_measurement_cycle', sWC)    
                                        
    #dfCDEF_sql['create_time'] = pd.to_datetime(dfCDEF_sql['create_time'], errors='coerce')
    dfCDEF_sql['ID'] = dfCDEF_sql['ID'].astype(int)    

    # if there are any data then append them to cdef data already in hd5 file
    if dfCDEF_sql.shape[0] > 0:
        
        #with h5py.File(sFN_hd5, 'a') as f:
        with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

            #if ('/' + sNode in f.keys()):
            if sNode in f:
                
                dfCDEF = f[sNode]
                #if dfCDEF:
                
                if isinstance(dfCDEF, pd.DataFrame):
                                        
                    # add new cdef-data to current cdef-data  
                    # TODO 2018-10-17: evtl. schneller machen - nicht erst alles auslesen sondern gleich nur die, die fuer die Auswahl
                    # der neu hinzukommenden gebraucht werden                    
                    #dfCDEF = dfCDEF.set_index(sHeadersKey, drop=False)                    
                    #dfCDEF_sql = dfCDEF_sql.set_index(sHeadersKey, drop=False)
                    #dfAdd = dfCDEF_sql.loc[dfCDEF_sql.index.difference(dfCDEF.index)]                    
                    dfAdd = setdifference_df(dfCDEF_sql, dfCDEF, sHeadersKey)
 
                    # der Zweig unter bNew funtioniert nicht richtig, deshalb der etwas (beim Ausfuehren) aufwaendigere
                    # andere Zweig aktiviert
                    bNew = False
                    if bNew:                        
                        # TODO 2018-10-17: ggf. noch sortieren
                        f.append(sNode, dfAdd.reset_index(drop=True), index=False)
                    else:
                        if dfAdd.shape[0] > 0:
                            dfComb = pd.concat((dfCDEF, dfAdd), axis=0, ignore_index=True)
                            # TODO 2018-11-2: noch eleganter machen, ist eigentlich unnoetig wenn dfAdd=0 ist, ggf. reicht auch reset innerhalb der .hd5-Datei                            
                            f.remove(sNode)
                            f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
                            #f.put(sNode, dfComb, format='table', append=True, data_columns=True)    
                        #else:
                        #    dfComb = dfCDEF

                else:
                    dfAdd = dfCDEF_sql.reset_index(drop=True)
                    f.remove(sNode)
                    f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
                                
            else:
                dfAdd = dfCDEF_sql.reset_index(drop=True)
                f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
                
            f.close()                                                
    
    else:       
        dfAdd = pd.DataFrame()

    return(dfAdd)
           

# 
#            
## function to update cdef data
## 
## Christian Kuehnert, 2018-12-4
##
## TODO 2018-10-19: bei HDFStore ist das Problem, dass die files immer groesser werden, selbst wenn ein node geloescht wird 
## (da der Speicherplatz dabei nicht freigegeben wird) -> dieses Problem noch loesen! Trotzdem erstmal so gemacht, um  erstmal
## zu starten -> vielleicht spaeter mit Patricks tools sowieso obsolet/geloest
##
##def update_cdef(sDB, sPathData, listTimeIntervals=[-np.Infinity, np.Infinity]):
#def update_externals(sDB, sPathData, time_start=None, time_end=None):
#
#    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
#    
#    sHeadersKey = ['create_time', 'ID']
#    
#    #sNode = 'raw_data/cdef'
#    sNode = sNodes.externals
#    
#    # if no such hd5-file exists
#    if not os.path.isfile(sFN_hd5):                        
#        initialize_hd5file(sDB, sPathData)        # create it hd5-file
#
#
#    # retrieve all cdef-data in the given time interval
#    sWC = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = '%Y%m%d%H%M%S')
#    #sWC = ''
#
#        
#    dfExt_sql, sMsg = query_tableData(sDB, 'ba_cycle_measurement_cycle', sWC)    
#                                        
#    #dfCDEF_sql['create_time'] = pd.to_datetime(dfCDEF_sql['create_time'], errors='coerce')
#    dfCDEF_sql['ID'] = dfCDEF_sql['ID'].astype(int)    
#
#    # if there are any data then append them to cdef data already in hd5 file
#    if dfCDEF_sql.shape[0] > 0:
#        
#        #with h5py.File(sFN_hd5, 'a') as f:
#        with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:
#
#            #if ('/' + sNode in f.keys()):
#            if sNode in f:
#                
#                dfCDEF = f[sNode]
#                #if dfCDEF:
#                
#                if isinstance(dfCDEF, pd.DataFrame):
#                                        
#                    # add new cdef-data to current cdef-data  
#                    # TODO 2018-10-17: evtl. schneller machen - nicht erst alles auslesen sondern gleich nur die, die fuer die Auswahl
#                    # der neu hinzukommenden gebraucht werden                    
#                    #dfCDEF = dfCDEF.set_index(sHeadersKey, drop=False)                    
#                    #dfCDEF_sql = dfCDEF_sql.set_index(sHeadersKey, drop=False)
#                    #dfAdd = dfCDEF_sql.loc[dfCDEF_sql.index.difference(dfCDEF.index)]                    
#                    dfAdd = setdifference_df(dfCDEF_sql, dfCDEF, sHeadersKey)
# 
#                    # der Zweig unter bNew funtioniert nicht richtig, deshalb der etwas (beim Ausfuehren) aufwaendigere
#                    # andere Zweig aktiviert
#                    bNew = False
#                    if bNew:                        
#                        # TODO 2018-10-17: ggf. noch sortieren
#                        f.append(sNode, dfAdd.reset_index(drop=True), index=False)
#                    else:
#                        if dfAdd.shape[0] > 0:
#                            dfComb = pd.concat((dfCDEF, dfAdd), axis=0, ignore_index=True)
#                            # TODO 2018-11-2: noch eleganter machen, ist eigentlich unnoetig wenn dfAdd=0 ist, ggf. reicht auch reset innerhalb der .hd5-Datei                            
#                            f.remove(sNode)
#                            f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
#                            #f.put(sNode, dfComb, format='table', append=True, data_columns=True)    
#                        #else:
#                        #    dfComb = dfCDEF
#
#                else:
#                    dfAdd = dfCDEF_sql.reset_index(drop=True)
#                    f.remove(sNode)
#                    f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
#                                
#            else:
#                dfAdd = dfCDEF_sql.reset_index(drop=True)
#                f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
#                
#            f.close()                                                
#    
#    else:       
#        dfAdd = pd.DataFrame()
#
#    return(dfAdd)
#           


#----
# test
#sDB = 'cmrblba_bc_t_02019'
#sPathData = 'C:\\Users\\w012028\\Desktop\\test'
#
#dfCDEF0 = update_cdef(sDB, sPathData)
#
#sFN = sPathData + '\\' + sDB + '.hd5'
#with pd.HDFStore(sFN, mode='a') as f:
#    sNode = f.keys()[1]
#    dfTmp = f[sNode][:]
#    dfTmp = dfTmp[2:7]
#    f.remove(sNode)
#    f.put(sNode, dfTmp, format='table')
#    f.close()
#
#dfCDEF1 = update_cdef(sDB, sPathData)





#
# function to read in the ts-data from the gz-files
#
# Christian Kuehnert, 2018-10-23
#
def read_gz(sFN, tType = np.int32):
    dRes = pd.read_csv(sFN, compression='gzip', header=None, sep=';', quotechar='"', 
                       index_col=False, usecols=[0], squeeze = True, dtype=tType)
    return dRes




#
# function to combine the ts-data from the single gz-files for one channel into 
# one time series
# search for overlapping parts of the time series and combine there, if no such parts are found than 
# just append the time series from the single files
# if the series have different lengths then return error message
#
# input:
#       - listTS:           list of series of integers (i.e. time series of the sensors)
#       - iCntMeasBase:     integer, base lenght of measurement
#
# output:
#
#
#
# Christian Kuehnert, 2018-11-1
#
def combine_ts(listTS, iCntMeasBase):                     
    
    # TODO 2018-11-1: Fall abfangen, dass eine Sensorstrecke (streckenweise) konstant ist, dann vielleicht an den iOLs der 
    # anderen Sensoren orientieren
    # am besten aber vielleicht doch alle Teilabschnitte EINZELN abspeichern und dann nur mit gemeinsamen gruppenindizes versehen, 
    # die im fail-Fall = None oder so sind
    
    
    iTS = []
    lOL = []                                # list of numbers of overlapping values
    #bOk = False
#    lMsg = []
    
    ## test if all parts have the same length that must be integer multiple of measurement length
    # TODO 2018-10-30: die ZRn liessen sich wohl auch dann zuammenfuegen, wenn diese Tests entfallen wuerden, ggf. muesste
    # man dafuer noch testen, ob die verwendeten Indizes nicht die Anzahl der Werte uebersteigen
    iN = [len(iV) for iV in listTS]
    if (len(np.unique(iN))==1) & all([iNn % iCntMeasBase == 0 for iNn in iN]):

        ## first try simple approach: assume 50% overlap of subsequent sub-ts, if this is not correct than do full search        
        iL = iN[0]
        iOL = int(iL/2)            
        bOk = True
        i = 0
        while bOk & (i<len(listTS)-1):
            #iDiff=np.asarray(listTS[i][iOL:iL])-np.asarray(listTS[i+1][0:iOL])
            iDiff=listTS[i][iOL:iL].values-listTS[i+1][0:iOL].values
            bOk = bOk & all(iDiff==0)
            i=i+1
        
        
        if bOk:                                                         # if overlap is 50% ...
            #iTS = pd.concat(listTS[0::2], ignore_index = True)          #   ... combine every second element
            if (len(listTS) % 2 ==0):                                   # if number of ts in list is not odd ...
                listTS.append(listTS[-1][iOL:iL])                       #    ... add last part of the last ts in the list
#                lMsg.append('info: even number of ts parts')
              
            iTS = pd.concat(listTS[0::2], ignore_index = True)
            #iTS = np.concatenate(listTS[0::2])          #   ... take only every second element in the list
          
              
        else:                                                           # otherwise - here comes the cavalry:
            
            iTS = listTS[0]
            i=1
            lOL = []                                                    # list of overlap-lengths
            while (i<len(listTS)):
                                                    
                iNext = listTS[i]
                iNext.index = range(len(iNext))
                # find all positions of last element of iTS in iNext
                listPos = iNext[iNext == iTS.iloc[-1]].index                
                listPos = [i for i in listPos if math.gcd(i+1, 8192) > 100]       # keep only those positions where overlap is at least 100ms
                #listPos = [i for i in range(len(iNext)) if iNext[i]==iTS[-1]]
                
                if len(listPos)>0:

                    ## now test for all positions if remaining elements in iTS agree with elements in iNext
                    bOk2 = False
                    iIdx = len(listPos)-1
                    while (not bOk2) & (iIdx >=0):
                                   
                        iOL = listPos[iIdx] + 1                                 # position where overlap starts (= overlap length)
                        #iDiff = np.asarray(iTS[len(iTS)-iOL:]) - np.asarray(iNext[0:iOL]) # calculate differences of overlap region
                        iDiff = iTS[len(iTS)-iOL:].values - iNext[0:iOL].values # calculate differences of overlap region
                        bOk2 = all(iDiff == 0)                                  # check if all are 0
                        iIdx = iIdx - 1                                         # set index of next position
                
                    ## if such a position is found, cut the value in listTS[i+1] until this point and append it to the iTS
                    if (not bOk2):                                              # if no overlap was found ...
                        iOL = 0                                               #   ... set it to 0 (appending the ts parts without overlap)
                                            
                else:
                    iOL = 0
                
                ## now combine parts up to here and append to lists                
                iTS = pd.concat((iTS, iNext[iOL:]), ignore_index = True)
                #iTS = np.concatenate((iTS, iNext[iOL:]))
                iTS.index = range(len(iTS))
                
                lOL.append(iOL)
                    
                i = i+1                                                         # next part of the ts
            
            ## assume that sth. is incorrect if not all overlap lengths are the same
            ## one could also return the combination, but only give a warning!
            # TODO 2018-10-30: nochmal ueberlegen, ob diese Variante die beste Loesung ist            
            if (len(np.unique(lOL))>1):
#                lMsg.append('overlap lengths not unique')                
                iTS = []
                iOL = []
            else:
                iOL = lOL[0]
                                                            
    #return iTS, lOL, ', '.join(lMsg)
    return iTS, iOL




#
# function to combine the ts-data from the single gz-files for one channel into 
# one time series
# search for overlapping parts of the time series and combine there, if no such parts are found than 
# just append the time series from the single files
# if the series have different lengths then return error message
#
# input:
#       - listTS:           list of series of integers (i.e. time series of the sensors)
#       - iCntMeasBase:     integer, base lenght of measurement
#
# output:
#
#
#
# Christian Kuehnert, 2018-11-1
#
def combine_ts_new(listTS, iCntMeasBase):                     
    
    # TODO 2018-11-1: Fall abfangen, dass eine Sensorstrecke (streckenweise) konstant ist, dann vielleicht an den iOLs der 
    # anderen Sensoren orientieren
    # am besten aber vielleicht doch alle Teilabschnitte EINZELN abspeichern und dann nur mit gemeinsamen gruppenindizes versehen, 
    # die im fail-Fall = None oder so sind
    
    
    iTS = []
    lOL = []                                # list of numbers of overlapping values
    #bOk = False
#    lMsg = []
    
    ## test if all parts have the same length that must be integer multiple of measurement length
    # TODO 2018-10-30: die ZRn liessen sich wohl auch dann zuammenfuegen, wenn diese Tests entfallen wuerden, ggf. muesste
    # man dafuer noch testen, ob die verwendeten Indizes nicht die Anzahl der Werte uebersteigen
    iN = [len(iV) for iV in listTS]
    if (len(np.unique(iN))==1) & all([iNn % iCntMeasBase == 0 for iNn in iN]):

        ## first try simple approach: assume 50% overlap of subsequent sub-ts, if this is not correct than do full search        
        iL = iN[0]
        iOL = int(iL/2)            
        bOk = True
        i = 0
        while bOk & (i<len(listTS)-1):
            #iDiff=np.asarray(listTS[i][iOL:iL])-np.asarray(listTS[i+1][0:iOL])
            iDiff=listTS[i][iOL:iL].values-listTS[i+1][0:iOL].values
            bOk = bOk & all(iDiff==0)
            i=i+1
        
        
        if bOk:                                                         # if overlap is 50% ...
            #iTS = pd.concat(listTS[0::2], ignore_index = True)          #   ... combine every second element
            if (len(listTS) % 2 ==0):                                   # if number of ts in list is not odd ...
                listTS.append(listTS[-1][iOL:iL])                       #    ... add last part of the last ts in the list
#                lMsg.append('info: even number of ts parts')
              
            iTS = pd.concat(listTS[0::2], ignore_index = True)
            #iTS = np.concatenate(listTS[0::2])          #   ... take only every second element in the list
          
              
        else:                                                           # otherwise - here comes the cavalry:
            
            iTS = listTS[0]
            i=1
            lOL = []                                                    # list of overlap-lengths
            while (i<len(listTS)):
                                                    
                iNext = listTS[i]
                iNext.index = range(len(iNext))

                # find all positions of last element of iTS in iNext
                listPos = iNext[iNext == iTS.iloc[-1]].index                
                #listPos = [i for i in range(len(iNext)) if iNext[i]==iTS[-1]]
                
                if len(listPos)>0:

                    ## now test for all positions if remaining elements in iTS agree with elements in iNext
                    bOk2 = False
                    iIdx = len(listPos)-1
                    while (not bOk2) & (iIdx >=0):
                                   
                        iOL = listPos[iIdx] + 1                                 # position where overlap starts (= overlap length)
                        #iDiff = np.asarray(iTS[len(iTS)-iOL:]) - np.asarray(iNext[0:iOL]) # calculate differences of overlap region
                        iDiff = iTS[len(iTS)-iOL:].values - iNext[0:iOL].values # calculate differences of overlap region
                        bOk2 = all(iDiff == 0)                                  # check if all are 0
                        iIdx = iIdx - 1                                         # set index of next position
                
                    ## if such a position is found, cut the value in listTS[i+1] until this point and append it to the iTS
                    if (not bOk2):                                              # if no overlap was found ...
                        iOL = 0                                                 #   ... set it to 0 (appending the ts parts without overlap)
                                            
                else:
                    iOL = 0
                
                ## now combine parts up to here and append to lists                
                iTS = pd.concat((iTS, iNext[iOL:]), ignore_index = True)
                #iTS = np.concatenate((iTS, iNext[iOL:]))
                iTS.index = range(len(iTS))
                
                lOL.append(iOL)
                    
                i = i+1                                                         # next part of the ts
            
            ## assume that sth. is incorrect if not all overlap lengths are the same
            ## one could also return the combination, but only give a warning!
            # TODO 2018-10-30: nochmal ueberlegen, ob diese Variante die beste Loesung ist            
            if (len(np.unique(lOL))>1):
#                lMsg.append('overlap lengths not unique')                
                iTS = []
                iOL = []
            else:
                iOL = lOL[0]
                                                            
    #return iTS, lOL, ', '.join(lMsg)
    return iTS, iOL





# function to get the day only from the timeseries tsCT
# 
# Christian Kuehnert, 2018-12-2
#
def get_day(tsCT):
    tsCD = tsCT.day()
    return(tsCD)




"""
function to transform the given time (which can be of different types) into string

Note: in case of dt is a string already, it just will be returned without changes
(even if its format differs from sFormat)


Christian Kuehnert, 2018-12-7
"""
def time_to_string(dt, sFormat='%Y%m%d%H%M%S'):
    
    if dt is pd.NaT:
        return('')
        
    elif isinstance(dt, str):
        return(dt)
        
    elif isinstance(dt, pd.datetime):
        return(dt.strftime(sFormat))
        
    elif isinstance(dt, pd.Timestamp):
        return(dt.dt.strftime(sFormat))
        
    else:
        return(None)
                



"""
function to create a where clause for the 'where=' in hdfstore.select-method or SQL-Query
from the given datetimes for start and stop


Christian Kuehnert, 2019-3-7
"""
def whereClause_from_timeInterval(time_start=None, time_end=None, sFormat='%Y%m%d%H%M%S', sTimeCol='create_time'):
        
    # TODO 2018-12-21: den Zweig, dass time_start oder time_end strings sind, noch mit nach time_to_string auslagern, 
    # dort allerdings dann parsen und ggf. auf gewuenschtes Format umschreiben
    if isinstance(time_start, str):
        sTimeStart = time_start
    else:
        sTimeStart = time_to_string(time_start, sFormat)
        
    if isinstance(time_end, str):
        sTimeEnd = time_end
    else:
        sTimeEnd = time_to_string(time_end, sFormat)


    lWhere = []        
    if sTimeStart:
        lWhere.append(sTimeCol + '>=\'' + sTimeStart + '\'')            
        
    if sTimeEnd:
        lWhere.append(sTimeCol + '<=\'' + sTimeEnd + '\'')            

    if (len(lWhere)>0):
        return(' and '.join(lWhere))
    else:
        return(None)
    





"""
function to get the turbines and related tickets from PIT
        
Christian Kuehnert, 2018-12-7
"""
#def get_turbines_and_tickets(dictWT, sWC_wt, dictTickets, sWC_tickets):
#def get_turbines_and_tickets(dictWT, sWC_wt=None, dictTickets, sWC_tickets=None):
#def get_turbines_and_tickets(sWC_wt=None, sWC_tickets=None):
def get_turbines_and_tickets(dictCols_wt=None, sWC_wt=None, dictCols_tickets=None, sWC_tickets=None):
    
    dictWTsTickets = {}
    dEps = 1e-6
    ## get all turbines
    # TODO 2019-1-24: hier noch pruefen, ob in den uebergebenen column names auch die hier benoetigten enthalten sind, falls nein, dann diese temporaer hinzufuegen (und bei der Ergebnisrueckgabe wieder entfernen)
    if not dictCols_wt:
#        # alter Version, noch mit CASE(...)
#        dictCols_wt = {'sFarm': 'Windpark_WEA#Windparkname', 
#                       'sName': 'WEA_Name',
#                       'sDB': 'Datenbank',
#                       'id': 'CAST(o_ContainerID as varchar(8000))',
#                       'id_farm': 'CAST(Windpark# as varchar(8000))'}
        dictCols_wt = {'sFarm': 'Windpark_WEA#Windparkname', 
                       'sName': 'WEA_Name',
                       'sDB': 'Datenbank',
                       'id': 'o_ContainerID',
                       'id_farm': 'Windpark#'}
    
    
    listCols = [dictCols_wt[i] + ' as ' + i for i in dictCols_wt]
                
    dfWTs = query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)



    ## get all tickets
    if not dictCols_tickets:
#        dictCols_tickets =  {'sTitle': 'Titel',
#                            'sDescription': 'Beschreibung',
#                            'sStatus': 'Status',
#                            'sFarm': 'CAST(Windpark#WP_Name as varchar(8000))',
#                            'weasImWP': 'CAST(WEAs_im_Windpark as varchar(8000))',                            
#                            'sTicketID': 'TicketID',
#                            'dtFirstOcc': 'Erstauftreten_des_Fehlers',
#                            'dtCreated': 'Beginn_am',
#                            'dtClosed': 'Geschlossen_am',
#                            'id_farm': 'Windpark#'}

#        # alte Version, noch mit CAST(...)
#        dictCols_tickets =  {'sTitle': 'Titel',
#                            'sDescription': 'Beschreibung',
#                            'sStatus': 'Status',
#                            'sFarm': 'CAST(Windpark#Windparkname as varchar(8000))',
#                            'weasImWP': 'CAST(WEAs_im_Windpark as varchar(8000))',                            
#                            'sTicketID': 'TicketID',
#                            'dtFirstOcc': 'Erstauftreten_des_Fehlers',
#                            'dtCreated': 'Beginn_am',
#                            'dtErrorFixed': 'Behebung_des_Fehlers',
#                            'dtClosed': 'Geschlossen_am',
#                            'id_farm': 'Windpark#'}
                       
        dictCols_tickets =  {'sTitle': 'Titel',
                            'sDescription': 'Beschreibung',
                            'sStatus': 'Status',
                            'sFarm': 'Windpark#Windparkname',
                            'weasImWP': 'WEAs_im_Windpark', 
                            'sTicketID': 'TicketID',
                            'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                            'dtCreated': 'Beginn_am',
                            'dtErrorFixed': 'Behebung_des_Fehlers',
                            'dtClosed': 'Geschlossen_am',
                            'id_farm': 'Windpark#'}

    listCols_tickets = [dictCols_tickets[i] + ' as ' + i for i in dictCols_tickets]    
    
    dfTickets = query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets);
    #dfTickets.column_names = dictCols_tickets.keys


    ## loop through turbines to find and assign the tickets    
    for idx, row in dfWTs.iterrows():
        
        #sFarm = row['sFarm']
        #sName = row['sName']
        sDB = row['sDB']
        id_farm = row['id_farm']
        id_wt = row['id']            
        
        ## now find tickets for that wt
        dfTmp = dfTickets[abs(dfTickets.id_farm-id_farm)<3*dEps]        ## consider only tickets referring to the same wind farm
        lTicketsWT = []        
        for idx2, dfT in dfTmp.iterrows():
            sWiW = dfT.weasImWP
            if (len(sWiW)>0):
                lTmp = sWiW.split(',')
                if str(id_wt) in lTmp:
                    lTicketsWT.append(idx2)
            
        dfTicketsWT = dfTmp.loc[lTicketsWT,:]
        dfTicketsWT.drop(columns=['id_farm'], inplace=True)
        dfTicketsWT['dtCreated'] = pd.to_datetime(dfTicketsWT['dtCreated'], errors='coerce')
        dfTicketsWT['dtFirstOcc'] = pd.to_datetime(dfTicketsWT['dtFirstOcc'], errors='coerce')
        dfTicketsWT['dtErrorFixed'] = pd.to_datetime(dfTicketsWT['dtErrorFixed'], errors='coerce')
        dfTicketsWT['dtClosed'] = pd.to_datetime(dfTicketsWT['dtClosed'], errors='coerce')

 
        dictWTsTickets.update({sDB: dfTicketsWT})
        
        
    return({'tickets': dictWTsTickets, 'turbines': dfWTs})





"""
function to get the turbines and related tickets from PIT
        
Christian Kuehnert, 2019-2-21
"""
#def get_turbines_and_tickets(dictWT, sWC_wt, dictTickets, sWC_tickets):
#def get_turbines_and_tickets(dictWT, sWC_wt=None, dictTickets, sWC_tickets=None):
#def get_turbines_and_tickets(sWC_wt=None, sWC_tickets=None):
def get_turbines_and_tickets_for_monitoring(sWC_wt=None, sWC_tickets=None):
        
    dictWTsTickets = {}
    dEps = 1e-6
    
    ## query turbine data
    dictCols_wt = {'sName': 'WEA_Name',
                   'sFarm': 'Windpark_WEA#Windparkname',
                   'sDB': 'Datenbankname',
                   'sType': 'WEA_Typ#Name',
                   'sManufacturer': 'WEA_Typ#Hersteller#Firmenname',
                   'dtLastMonitoring': 'Monitoring_zuletzt_durchgeführt',
                   'dtStartCollectData': 'Beginn_Datenspeicherung',
                   'dtOperational': 'Inbetriebnahme_abgeschlossen',
                   'ssh_port': 'ssh_port',
                   'email_customer': 'Ansprechpartner_Kunde#E_Mail_Adresse',
                   'monitoring_type': 'Systemart#Bezeichnung',
                   'monitoring_short': 'Systemart#Kürzel_Monitor',
                   'turbine_in_monitoring': 'Anlage_im_Monitoring',
                   'contract_status': 'Gesamtstatus_Überwachungsaufträge',
                   'id': 'o_ContainerID',
                   'id_farm': 'Windpark_WEA#'}
        
    listCols = [dictCols_wt[i] + ' as ' + i for i in dictCols_wt]
                
    dfWTs = query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)

    
    ## query ticket data
    dictCols_tickets =  {'sTitle': 'Titel',
                         'sDescription': 'Beschreibung',
                         'sStatus': 'Status',
                         'sFarm': 'Windpark#Windparkname',
                         'weasImWP': 'WEAs_im_Windpark', 
                         'sTicketID': 'TicketID',
                         'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                         'dtCreated': 'Beginn_am',
                         'dtErrorFixed': 'Behebung_des_Fehlers',
                         'dtClosed': 'Geschlossen_am',
                         'id_farm': 'Windpark#'}

    listCols_tickets = [dictCols_tickets[i] + ' as ' + i for i in dictCols_tickets]    
    
    dfTickets = query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets);
    #dfTickets.column_names = dictCols_tickets.keys


    ## loop through turbines to find and assign the tickets    
    for idx, row in dfWTs.iterrows():
        
        #sFarm = row['sFarm']
        #sName = row['sName']
        sDB = row['sDB']
        id_farm = row['id_farm']
        id_wt = row['id']            
        
        ## now find tickets for that wt
        dfTmp = dfTickets[abs(dfTickets.id_farm-id_farm)<3*dEps]        ## consider only tickets referring to the same wind farm
        lTicketsWT = []        
        for idx2, dfT in dfTmp.iterrows():
            sWiW = dfT.weasImWP
            if (len(sWiW)>0):
                lTmp = sWiW.split(',')
                if str(id_wt) in lTmp:
                    lTicketsWT.append(idx2)
            
        dfTicketsWT = dfTmp.loc[lTicketsWT,:]
        dfTicketsWT.drop(columns=['id_farm'], inplace=True)
        dfTicketsWT['dtCreated'] = pd.to_datetime(dfTicketsWT['dtCreated'], errors='coerce')
        dfTicketsWT['dtFirstOcc'] = pd.to_datetime(dfTicketsWT['dtFirstOcc'], errors='coerce')
        dfTicketsWT['dtErrorFixed'] = pd.to_datetime(dfTicketsWT['dtErrorFixed'], errors='coerce')
        dfTicketsWT['dtClosed'] = pd.to_datetime(dfTicketsWT['dtClosed'], errors='coerce')
 
        dictWTsTickets.update({sDB: dfTicketsWT})
        
        
    return({'tickets': dictWTsTickets, 'turbines': dfWTs})







# function to collect sda series and store them to .hd5-file
# NOTE: the ts-data (data and startstop) contain create_day (not create_time) which only contains the day!
#
# 
# Christian Kuehnert, 2019-1-10
#
#
def update_sda(sDB, sPathData, time_start=None, time_end=None, bSloppy=True):

    lRes = []
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef  #'raw_data/cdef'
    #sNode_sda = 'raw_data/sda'                                           # node where the sda data are stored
    sNode_sda_data = sNodes.sda_data     # sNode_sda + '/data'                                 # subnode with sda data
    sNode_sda_startstop = sNodes.sda_startstop     # sNode_sda + '/startstop'                        # subnode with row numbers of start and stop of each sda series
       
    #sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                      # full hd5-file name
    
    
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

#TODO 2018-12-16: klaeren, ob die TS-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!            
            lWhere = ['available_data>=2']                            # consider only cycles where sda-files were stored
            sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                
            if sWhere:
                lWhere.append(sWhere)
                
            sWhere = ' and '.join(lWhere)
                        
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                            
            iCycles = dfCDEF.shape[0]                                          # number of cycles
    
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2018-12-2: assume that always both sNode_ts and sNode_ts_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_sda_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                #bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_sda_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the ts-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=True - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                #bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'filename', 'blade', 'direction', 'start','stop'])
            
                                    
            iCycles = dfCDEF.shape[0]

            for i in range(iCycles):
                
                #tsCT = dfCDEF.create_time[i]                                       # current create_time
                #iID = dfCDEF.ID[i]                                                 # current ID
                tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                                    
                if (i % 20 == 0):
                    #                        print(sInfo)                   
                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID))


                if not ((iID==0) or pd.isnull(tsCT)):
                                    
#                    sInfo = sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                        
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        # TODO 2019-1-10: evtl. mit regex noch genauer spezifizieren
                        sFiles = fnmatch.filter(listdir(sFolder), 'af_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
        
                        for sFN in sFiles:
                            
                            sFN_short = sFN.replace('af_', '').replace('.csv.gz', '')       # remove 'af_' and ending from file name
                            
                            ## check if already stored in the .hd5-file
                            #if bCycEx:                                              # if there are already existing time series
                                
                            # if there is no entry for this cycle and channel:
                            if (dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID) & (dfCycTSEx.filename==sFN_short)].shape[0]==0):
                        
                                parts = sFN_short.split('_')      # split (short) file name by '_'
                        
                                iBlade = int(parts[-1])-100
                                sDirection = parts[0]
                                #if (parts[1]=='axial') and not((sDirection=='edge') or (sDirection == 'flap')):
                                #if (parts[1]=='axial'):
                                if parts[1].isalpha():
                                    sDirection = sDirection + '_' + parts[1]
                                
                                    
                                               
                                create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                                                                                          
                                try:    

                                    ## now aggregate the remaining files                                
                                    dSDA = read_gz(fullfile((sFolder, sFN)), tType=np.float64)                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                                                     
                                    iCnt = len(dSDA)
                                    if iCnt>0:  
                                    
                                        #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df1 = pd.DataFrame(data=(np.tile([create_day, iID, sFN_short], [iCnt,1])), columns = ['create_day', 'ID', 'filename'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCnt)), dSDA), axis=1)))
                                        df2.columns = ['idx', 'a_f']
                                        dfTmp = pd.concat((df1,df2), axis=1)

                                        dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        #dfTmp['filename'] = dfTmp['filename'].astype(string)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        #dfTmp['a_f'] = dfTmp['a_f'].astype(float)
                                        
                                        #iStart = f.get_storer(sNode_ts_data).nrows
                                        f.append(sNode_sda_data, dfTmp, format='table', data_columns = True, index=False, min_itemsize={'filename': 40})
                                        
                                        # now add row numbers for start and stop for this time series
                                        iStop = f.get_storer(sNode_sda_data).nrows
                                        iStart = iStop - dfTmp.shape[0]
                                        
                                        dfMap = pd.DataFrame(data=[[tsCT, iID, sFN_short, iBlade, sDirection, iStart, iStop]], columns = ['create_time','ID','filename','blade', 'direction','start','stop'])
                                        dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                        dfMap['ID'] = dfMap['ID'].astype(int)
                                        dfMap['blade'] = dfMap['blade'].astype(int)
                                        #dfMap['filename'] = dfMap['filename'].astype(str)
                                        #dfMap['direction'] = dfMap['direction'].astype(str)
                                        dfMap['start'] = dfMap['start'].astype(np.int64)
                                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                        f.append(sNode_sda_startstop, dfMap, format='table', data_columns = True, index=False, min_itemsize={'filename': 40})    
                                        
                                        lRes.append(dfMap)

                                                                        
                                except Exception as ex:
                                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', file ' + sFN + ': Probleme mit Entpacken oder Einlesen')

                 
    if len(lRes)==0:
        return(pd.DataFrame(columns=['create_time', 'ID', 'filename', 'blade', 'direction', 'start','stop']))
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        return(dfRes)


    #return(lMsg)









# function to collect time series as well as cdef data
# NOTE: the ts-data (data and startstop) contain create_day (not create_time) which only contains the day!
#
# 
# Christian Kuehnert, 2019-1-11
#
#
#def update_cdef_ts(sDB, sPathData, listTimeIntervals=[-np.Infinity, np.Infinity], iCntMeasBase = 8192, bSloppy = True):
# TODO 2018-12-4: aufspalten in update_ts_fromCDEF(sDB, sPathData, dfCDEF) wo nur die in dfCDEF uebergebenen cycles upgedatet werden, und update_ts() wo die dfCDEF-cycles
# wie hier implementiert bestimmt werden, und dann darauf update_ts_fromCDEF anwenden. D.h. 
# TODO 2018-12-7: hier noch so implementieren, dass entweder 1) die sNode_ts_startstop eine Spalte enthaelt, ob ein folder ueberhaupt ts-daten enthaelt, der zugehoerige dataframe
# ist dann bzgl. der Keys eine Kopie von dfCDEF, bei sloppy=True werden dann wirklich nur noch neue cycles durchsucht, oder 2) einen weitere node sNode_cycles anlegen, welche
# eben alle cycles von dfCDEF enthaelt und jeweils eine spalte mit true/false oder 1/0 fuer ts-Daten und eine entsprechend fuer sda-Daten, dann mit dieser entsprechend arbeiten
def update_ts(sDB, sPathData, time_start=None, time_end=None, iCntMeasBase = 8192, bSloppy=True):

    #lMsg = []
    lRes = []
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef               #  'raw_data/cdef'
    #sNode_ts = 'raw_data/ts'                                           # node where the time series data are stored
    sNode_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
       
    sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                      # full hd5-file name
    
    
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

#TODO 2018-12-16: klaeren, ob die TS-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!            
            lWhere = ['available_data>2']                            # consider only cycles where sda-files were stored
            sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                
            if sWhere:
                lWhere.append(sWhere)
                
            sWhere = ' and '.join(lWhere)
                        
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                
            iCycles = dfCDEF.shape[0]                                          # number of cycles                

    
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2018-12-2: assume that always both sNode_ts and sNode_ts_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_ts_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_ts_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the ts-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=True - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'channel', 'overlap', 'start','stop'])
            
                                    
            iCycles = dfCDEF.shape[0]

            for i in range(iCycles):
                
                #tsCT = dfCDEF.create_time[i]                                       # current create_time
                #iID = dfCDEF.ID[i]                                                 # current ID
                tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                                    
                if (i % 20 == 0):
                    #                        print(sInfo)                   
                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID))


                if not ((iID==0) or pd.isnull(tsCT)):
                                    
#                    sInfo = sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                        
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            #if (i % 20 > 0):
                            #    print(sInfo)
                            
                            #print('    files exist')
                            create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                #dfCycEx = f.select(sNode_ts, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                #dfCycEx = dfCycTSEx[(dfCycTSEx.create_day==create_day) & (dfCycTSEx.ID==iID)]
                                dfCycEx = dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID)]

                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    #print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
                            # TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            lChAdded = []
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                        
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        
                                        #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df1 = pd.DataFrame(data=(np.tile([create_day, iID, iCh], [iCntTS,1])), columns = sHeadersKey)
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)

                                        dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #iStart = f.get_storer(sNode_ts_data).nrows
                                        f.append(sNode_ts_data, dfTmp, format='table', data_columns = True, index=False)    
                                        
                                        # now add row numbers for start and stop for this time series
                                        iStop = f.get_storer(sNode_ts_data).nrows
                                        iStart = iStop - dfTmp.shape[0]
                                        
                                        dfMap = pd.DataFrame(data=[[tsCT, iID, iCh, iOL, iStart, iStop]], columns = ['create_time','ID','channel','overlap','start','stop'])
                                        dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                        dfMap['ID'] = dfMap['ID'].astype(int)
                                        dfMap['channel'] = dfMap['channel'].astype(int)
                                        dfMap['overlap'] = dfMap['overlap'].astype(int)
                                        dfMap['start'] = dfMap['start'].astype(np.int64)
                                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                        f.append(sNode_ts_startstop, dfMap, format='table', data_columns = True, index=False)    
                                        
                                        lRes.append(dfMap)
                                        
                                        #lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        #print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        lChAdded.append(str(iCh))
                    
                                    #else:
                                    #    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception as ex:
                                    #lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
                                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                            # information if time series were added
                            #if len(lChAdded)>0:
                            #    print(sInfo + ': ts for channels ' + ','.join(lChAdded) + ' added')
                 
    if len(lRes)==0:
        return(pd.DataFrame(columns=['create_time','ID','channel','overlap','start','stop']))
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        return(dfRes)


    #return(lMsg)





"""
function to check hd5-ts-data for consistency of data

Christian Kuehnert, 2019-1-7
"""
# TODO 2019-1-7: noch auf gleichzeitige Konsistenz mit den CDEF-Daten pruefen
def check_consistency(sFN_hd5):

    bConsistent = True
    
    #sNode_cdef = 'raw_data/cdef'
    sNode_ts = 'raw_data/ts'                                           # node where the time series data are stored
    sNode_ts_data = sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
                   
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
    
        dfSS = f[sNode_ts_startstop]

        bConsistent = (dfSS.loc[:,['start','stop']].values.min()>=0) \
                        and (dfSS.loc[:,['start','stop']].values.max() == f.get_storer(sNode_ts_data).nrows) \
                        and (len(np.unique(dfSS.loc[:,['start']].values))==dfSS.shape[0]) \
                        and (len(np.unique(dfSS.loc[:,['stop']].values))==dfSS.shape[0])

        if bConsistent:
            # dfSS durchgehen
            for idx, row in dfSS.iterrows():
            
                # zugehoerige dfTS laden
                dtDate = row['create_time']
                iID = row['ID']
                iCh = row['channel']
                iStart = row['start']
                iStop = row['stop']
                
                bConsistent = bConsistent and (iStart>=0) and (iStop>0)    
    
                if bConsistent:
                    dfTS = f.select(sNode_ts_data, start=iStart, stop=iStop)
                                     
                    dfTmp = dfTS.drop_duplicates(subset=['create_day','ID','channel'], inplace=False)
                    bConsistent = bConsistent and (dfTmp.shape[0]==1) and (dfTmp.iloc[0,:].loc['create_day'] == pd.to_datetime(dtDate.date())) and (dfTmp.iloc[0,:].loc['ID']==iID) and (dfTmp.iloc[0,:].loc['channel']==iCh) and (dfTS.shape[0] % 8192 == 0)
                
                
    return(bConsistent)        










"""
function to find out the start and end times of the given ticket

Anhand der Zeiten des Tickets werden Start- und Endzeitpunkt ermittelt

Input:
		- dfTicket: pandas.DataFrame with tickets, must contain the fields
            - sTitle
            - sDescription
            - sStatus
            - sFarm
            - weasImWP
            - sTicketID
            - dtFirstOcc
            - dtCreated
            - dtClosed                      
            - id_farm
                                    
		- dtBuffer: 'safety period', datetime to make sure that, if thet start time is derived from ticket id    

 Output:
     - dictTimes with keys 'start' for start time and 'end' for end time


Christian Kuehnert, 2019-1-21
"""
def get_ticket_times(dfTickets, dtBuffer = dt.timedelta(days=30)):

    lTimes = []
    
    # TODO 2018-12-18: noch eleganter und vektorisiert machen!, jetzt erstmal
    # schnelle Variante
    for idx, row in dfTickets.iterrows():
                
        bCont = True
        try:
            # 1.) Versuch, den Eintrag bei 'Beginn_am' als Zeitpunkt zu nehmen        
            dtStart = row['dtFirstOcc']
            #if isinstance(dtStart, dt.datetime):
#HIER WEITER 2018-12-18 - DATENTYP NOCH NICHT RICHTIG (WIRD OFFENBAR BEIM EINLESEN DER TICKETS TROTZ EXPLIZITER UMWANDLUNG NICHT RICHTIG GEMACHT)
            if isinstance(dtStart, pd.datetime) or isinstance(dtStart, pd.Timestamp):
                bCont = (dtStart is pd.NaT)
    
            # 2.) Versuch, den Zeitpunkt von 'Ticket erstellt am ...' zu verwenden
            if bCont:
                dtStart = row['dtCreated']
                if isinstance(dtStart, pd.datetime) or isinstance(dtStart, pd.Timestamp):
                    bCont = (dtStart is pd.NaT)
                            
            # 3.) Versuch, Zeitpunkt aus der 'TicketID' abzuleiten
            if bCont:
                sTmp = row['sTicketID'][0:5]
                dtStart = dt.strptime(sTmp, '%Y%m') - dtBuffer


        except Exception as e:
            dtStart = pd.NaT
                
    
        ## jetzt auslesen End-Zeit aus 'Geschlossen_am'
        try:
            bCont = True
            dtEnd = row['dtErrorFixed']
            if isinstance(dtEnd, pd.datetime) or isinstance(dtEnd, pd.Timestamp):
                bCont = (dtEnd is pd.NaT)
            
            if bCont:
                # ii) try to use starting time of 'ticket geschlossen'
                # TODO 2019-1-21: Beachten, dass manchmal Tickets geschlossen werden, obwohl der Fehler noch besteht!!! 
                # das auch bei diesen Fehlertypen vorkommt und diesen Fall ggf. abfangen            
                dtEnd = row['dtClosed']
                #if dtEnd is None:
#                if not(isinstance(dtEnd, pd.datetime) or isinstance(dtEnd, pd.Timestamp)):
#                    dtEnd = pd.NaT

        except Exception as e:
            dtEnd = pd.NaT
                    

        lTimes.append([dtStart, dtEnd])
        del dtStart
        del dtEnd
        
    #dfTmp = pd.DataFrame((dfTickets.sTicketID, np.vstack(lTimes)), columns =['sTicketID', 'start', 'end'])
#HIER WEITER 2018-12-19        
    dfTmp = pd.DataFrame(np.vstack(lTimes), columns =['start', 'end'])
    dfRes = pd.concat([dfTickets['sTicketID'], dfTmp.set_index(dfTickets.index)], axis=1)
    
    return(dfRes)





#
#
#"""
#function to find out the start and end times of the given ticket
#
#Anhand der Zeiten des Tickets werden Start- und Endzeitpunkt ermittelt
#
#Input:
#		- dfTicket: pandas.DataFrame with tickets, must contain the fields
#            - sTitle
#            - sDescription
#            - sStatus
#            - sFarm
#            - weasImWP
#            - sTicketID
#            - dtFirstOcc
#            - dtCreated
#            - dtClosed                      
#            - id_farm
#                                    
#		- dtBuffer: 'safety period', datetime to make sure that, if thet start time is derived from ticket id    
#
# Output:
#     - dictTimes with keys 'start' for start time and 'end' for end time
#
#
#Christian Kuehnert, 2019-1-21
#"""
## TODO 2019-1-21: vektorisieren/auf input-vektor erweitern
#def getTicketTimes(dfTicket, dtBuffer = pd.DataTime(days=30)):
#    
#    ## 1) get start time
#    # i) try to use 'Beginn_am' entry as starting time
#    dtStart = dfRelTickets.dtFirstOcc
#
#    # ii) if this is empty, try to use time point of 'Ticket erstellt am'
#    if (dtStart == '0.0') | (dtStart is None):
#        dtStart = dfTicket.dtCreated
#            
#        # iii) if this is not valid too, try to derive time from ticket id but use buffer time to be on safe side
#        if (dtStart == '0.0'):
#            sTmp = dfTicket.sTicketID
#            dtStart = datenum(sTmp[0:5], '%y%m')-dtBuffer
#
#
#
#    # 2) get end time
#    # i) try to use time of 'Behebung des Fehlers'
#    dtEnd = dfRelTickets.dtErrorFixed
#    if (dtEnd is None):
#        # ii) try to use starting time of 'ticket geschlossen'
#        # TODO 2019-1-21: Beachten, dass manchmal Tickets geschlossen werden, obwohl der Fehler noch besteht!!! 
#        # das auch bei diesen Fehlertypen vorkommt und diesen Fall ggf. abfangen            
#        dtEnd = dfRelTickets.dtClosed
#        if (dtEnd is None):
#            dtEnd = np.NaT                      
#        end
#    end
#
#    return({'start': dtStart, 'end': dtEnd})






"""
function to find out the channels the given tickets are related

Anhand der Einträge in den PIT-Tickets wird ermittelt, welche Sensorstrecken i.O. und welche defekt sind. Dies
wird als Vektor [edge1, edge2, edge3, flap1, flap2, flap3] zurückgegeben mit Wert 0, falls die Sensorstrecke defekt ist, und 
mit Wert 1, falls kein diesbezüglicher Eintrag vorliegt

Input:
		- tabTickets: pandas.DataFrame with tickets, must contain the fields
						- Ticket_TicketID
						- Ticket_Titel
						- Ticket_Beschreibung
						- Ticket_Status
						- Ticket_Beginn_am
						- Ticket_Erstauftreten_des_Fehlers
						- Ticket_Behebung_des_Fehlers
						- Ticket_Geschlossen_am

		- bOnlyOpenTickets: if True, only tickets that are not in state 'erledigt' will be included, otherwise all tickets


 Output:
		- dictionary with relevant tickets:
           - dictRelTickets = {'f1': dfRelTicket_f1, 'f2': dfRelTickets_f2, 'f3': dfRelTickets_f3, 'e1': dfRelTickets_e1, ...}
           - dfStates: dataframe with states for the several channels, i.e. dataframe with columns:
               - channel_name ('f1', 'f2', 'f3', 'e1', ...)
               - sensor_state: True if open ticket(s) exist for that channel, False if not
               - ticketIDs: IDs of the relevant tickets
               - start_time: 1x9-Array (Reihenfolge wie bei cVars) mit den Zeiten (Matlab-Zeitformat),
                             bis zu denen kein Ticket für die jeweilige Sensorstrecke existiert.
                             Ist kein Ticket für die Sensorstrecke vorhanden, wird der Wert auf
                             Inf gesetzt. Ist ein Ticket für die Sensorstrecke vorhanden, wird
                             der Zeitpunkt von 'Beginnt am' bzw. -falls nicht vorhanden- von 'Erstauftreten
                             des Fehlers' genommen. Sind auch hierfür keine Zeitangaben eingetragen,
                             wird der Wert anhand der Ticket-ID bestimmt und als allerletzte Möglichkeit
                             wird der Zeitpunkt auf NaN gesetzt.
               - end_time: 1x9-Array (Reihenfolge wie bei cVars) mit den Zeiten (Matlab-Zeitformat),
                           ab denen kein offenes Ticket für die jeweilige Sensorstrecke existiert.
                           Ist kein Ticket für die Sensorstrecke vorhanden, wird der Wert auf
                           -Inf gesetzt. Ist ein Ticket für die Sensorstrecke vorhanden, wird
                           der Zeitpunkt von 'Behebung_des_Fehlers' bzw. -falls nicht vorhanden- von 'Geschlossen_am' 
                           Sind auch hierfür keine Zeitangaben eingetragen,
                           wird der Zeitpunkt auf Inf gesetzt.


Christian Kuehnert, 2019-1-21
"""
def get_sensorStates_from_tickets(dfTickets, bOnlyOpenTickets = True):                            
    
    sChannelNames = ['f1','f2','f3','e1','e2','e3']
    try:
        
        # falls entsprechende Option gewaehlt, dann nur offene Tickets einbeziehen
        if bOnlyOpenTickets:
            dfTickets = dfTickets[dfTickets.sStatus == 'erledigt']
                                    
            
        if dfTickets.shape[0]==0:
            dfRes = pd.DataFrame.from_dict({'channel_name': sChannelNames, 'status': np.tile(True, (6,)), 'ticketIDs': np.tile('', (6,)), 'start_time': np.tile(pd.NaT, (6,)), 'end_time': np.tile(pd.NaT, (6,))})
            dictRes = {'f1': None, 'f2': None, 'f3': None, 'e1': None, 'e2': None, 'e3': None}
                                            
        else:
    
            sTicketStrings = dfTickets.sTitle
                            
            # TODO 5-7: pruefen, wie am besten auch die Beschreibung einbezogen werden kann. Vielleicht wie naechste Zeile, mit Anpassung der weiteren Bearbeitungsschritte
            # cTTitles = [tabTickets.Ticket_Titel, tabTickets.Ticket_Beschreibung];		% Kombination aus Titel und Beschreibung
        
            # TODO 2017-6-21: noch vereinfachen, ohne Ersetzen (evtl. auch ohne erase) gleich
            # Indizees der gefundenen Tickets bestimmen
            # TODO 2019-1-21: alles nochmal ueberarbeiten, besser machen mit bewaehrten Textmining-Methoden, ausserdem mit geeigneteren regex-Ausdruecken weniger Zeilen benoetigen
            sT = [s.replace('Eissensor Rotorblatt', '') for s in sTicketStrings]
            sT = [s.replace('cmrbl', '') for s in sT]
            sT = [s.replace('100', '') for s in sT]

            sT = [re.sub('bladecontrol', '', s, flags=re.IGNORECASE) for s in sT]

            sT = [s.strip() for s in sT]
            
            sT = [re.sub('rbl', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('flap', 'Flap', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('edge', 'Edge', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('(vor allem |v.a. |v. a. |vorrangig)(Edge|Flap)', '', s, flags=re.IGNORECASE) for s in sT]
            
            #                cTs = cellfun(@(x) erase(x, 'vor allem Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'vor allem Edge'), cTs, 'UniformOutput', false); 
            #                cTs = cellfun(@(x) erase(x, 'v.a. Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'v.a. Edge'), cTs, 'UniformOutput', false); 
            #                cTs = cellfun(@(x) erase(x, 'v. a. Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'v. a. Edge'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'vorrangig Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'vorrangig Edge'), cTs, 'UniformOutput', false); 
            
            sT = [re.sub('Rotorblatt', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blade', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blade:', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('Blatt 1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blatt 2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blatt 3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('RBL 1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('RBL 2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('RBL 3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('RBL-', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('R1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('R-1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R-2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R-3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('R-1/2/3', 'RBL1,RBL2,RBL3', s, flags=re.IGNORECASE) for s in sT]
    
            # now find relevant search patterns in modified ticket strings             
            #bI = cell2mat(cellfun(@(x) isempty(regexp(x, '(RBL)|(alle )|( allen)|((Sensoren )*( falsch angeschlossen))|(vertausch)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false));
            #cTs = cTs(~bI);
            #idxRel = find(~bI);        
            #bI = [not(re.match('(.*?)(RBL)|(alle )|( allen)|((Sensoren )*( falsch angeschlossen))|(vertausch)(.*?)', s) is None) for s in sT]
            bI = [not(re.match('(.*?)(RBL|alle | allen|(Sensoren )*( falsch angeschlossen)|vertausch)(.*?)', s) is None) for s in sT]
            idxRel = [i for i, x in enumerate(bI) if x]     # index of relevant tickets (related to dfTickets)
            sT = list(pd.Series(sT)[bI])
            
            # Tickets mit wenigstens einem der folgenden Ausdrücke werden ignoriert:
    #        bI2 = all([cell2mat(cellfun(@(x) isempty(regexp(x, '(Falscheismeldung .*Peak ung.*.*nstig)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle )[0-9]*.?(ECU)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle Messprogramme)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle WEA ohne Eis am RBL)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(ECU).*(alle) (im WP|im PW)? (gleichzeitig)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(neue Werte alle)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(falsche Zeit).* (alle)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(nach Stromabschaltung)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(Datenl)(ue|ü)(cken)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(keine externals)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(geringes Signal-Rausch)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(Zuordnung).*(<->).*(Firewall vertauscht)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle)[n]? (WEA)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(Ticket aus Versehen erstellt)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(schadensbericht)', 'match', 'ignorecase','ONCE')), cTs, 'UniformOutput', false))], 2);
    
            # create regex-pattern for search, tickets containing one of those patterns will be ignored because they are not related to measure line defects
            lPattern = []
            lPattern.append('Falscheismeldung .*Peak ung.*.*nstig')
            lPattern.append('(alle )[0-9]*.?(ECU)')
            lPattern.append('alle Messprogramme')
            lPattern.append('alle WEA ohne Eis am RBL')
            lPattern.append('(ECU).*(alle) (im WP|im PW)? (gleichzeitig)')
            lPattern.append('neue Werte alle')
            lPattern.append('(falsche Zeit).* (alle)')
            lPattern.append('nach Stromabschaltung')
            lPattern.append('(Datenl)(ue|ü)(cken)')        
            lPattern.append('keine externals')
            lPattern.append('geringes Signal-Rausch')
            lPattern.append('(Zuordnung).*(<->).*(Firewall vertauscht)')
            lPattern.append('(alle)[n]? (WEA)')
            lPattern.append('Ticket aus Versehen erstellt')
            lPattern.append('schadensbericht')
            sPatternRegEx = re.compile('(.*?)(' + ')|('.join(lPattern) + ')(.*?)', re.IGNORECASE)
    
            bI2 = [not(re.match(sPatternRegEx, s) is None) for s in sT]
            
            if all(bI2):                                  # wenn keines der Tickets relevant ist ...
    
                #print('no relevant tickets found')        
                dfRes = pd.DataFrame.from_dict({'channel_name': sChannelNames, 'status': np.tile(True, (6,)), 'ticketIDs': np.tile('', (6,)), 'start_time': np.tile(pd.NaT, (6,)), 'end_time': np.tile(pd.NaT, (6,))})
                dictRes = {'f1': None, 'f2': None, 'f3': None, 'e1': None, 'e2': None, 'e3': None}
    
            else:                                            # andernfalls ...
                bI3 = [not(b) for b in bI2]
                sT = list(pd.Series(sT)[bI3])
                            
                idxRel = [i for i, x in enumerate(bI) if x]     # index of relevant tickets (related to dfTickets)

                dfRelTickets = dfTickets.iloc[pd.Series(idxRel)[bI3],:]       # TODO 2017-6-23: evtl. noch weiter einschraenken auf die Tickets, die zum u.g. bOK beitragen
    					
#                iRelTickets = dfRelTickets.shape[0]
    					
                #cRelevantTickets = table2cell(dfRelTickets);
           
                ## Ableitung der Sensorstates aus den relevanten Tickets
                # Tickets mit Teilstrings, die darauf schließen lassen, dass sie alle Sensorstrecken betreffen
                serT = pd.Series(sT)
                bAll = serT.str.contains('alle', case=False, regex=False)
        
                # Tickets mit Teilstrings, die darauf schließen lassen, dass sie nur einzelne Rotorblätter betreffen
#HIER WEITER 2019-1-21, NOCH 'def', 'defekt' ODER SO MIT ABFRAGEN!
                bRBL = serT.str.contains('( RBL)(RBL )', case=False, regex=True)
                            
                b1 = serT.str.contains('RBL1', case=False, regex=False)
                b2 = serT.str.contains('RBL2', case=False, regex=False)
                b3 = serT.str.contains('RBL3', case=False, regex=False)

                bRBL = bRBL & ~(b1 | b2 | b3)                                          # wenn nur "RBL" vorkommt, z.B. "diverse RBL" in Ticket 201007-004
                
                # Auswertung nach Edge/Flap-Richtung
                bEdge = serT.str.contains('Edge', case=False, regex=False)
                bFlap = serT.str.contains('Flap', case=False, regex=False)
        
                # weitere Prüfung auf Tickets, die für alle Rotorblätter relevant sein könnten
                bAll2 = serT.str.contains('vertausch', case=False, regex=False) & bEdge & bFlap & ~(b1 | b2 | b3)
                            
                # Hilfsgrößen
                bTmp = bAll | bRBL
                bE = bEdge | ~(bFlap)
                bF = ~(bEdge) | bFlap
                                         
                # Bestimmung der Sensor-Zustände der einzelnen Messstrecken
                b1E = ((b1 | bTmp) & bE) | bAll2
                b2E = ((b2 | bTmp) & bE) | bAll2
                b3E = ((b3 | bTmp) & bE) | bAll2
                b1F = ((b1 | bTmp) & bF) | bAll2
                b2F = ((b2 | bTmp) & bF) | bAll2
                b3F = ((b3 | bTmp) & bF) | bAll2
        
                #bAllSensors = [b1F, b2F, b3F, b1E, b2E, b3E]           # which tickets (rows) contain information about which blades x direction (cols)
                bAllSensors = pd.concat((b1F, b2F, b3F, b1E, b2E, b3E), axis=1).values           # which tickets (rows) contain information about which blades x direction (cols)
                bRes = bAllSensors.any(axis=0)
            
                #iChannels = list(itertools.compress([0,1,2,3,4,5], bAllSensors))
                # create dictionary with relevant tickets for each channel
                dictRes = {}
                lTmp = []
                for iCh in range(6):
                    sCh = sChannelNames[iCh]
                    bTmp = bAllSensors[:,iCh]
                    if any(bTmp):
                        dfRT = dfRelTickets[bTmp]
                        dictRes.update({str(iCh): dfRT})
                        sIDs = ','.join(dfRT.sTicketID)
                        # TODO 2019-1-21: spaeter noch verfeinern, alle Zeiten beruecksichtigen, jetzt erstmal Anfangszeit vom letzten Ticket verwendet                    
                        dtStart = get_ticket_times(dfRT).start.max()
                        dtEnd = get_ticket_times(dfRT).end.max()
                    else:
                        sIDs = ''
                        dtStart = pd.NaT
                        dtEnd = pd.NaT
                        
                    lTmp.append([sCh, bRes[iCh], sIDs, dtStart, dtEnd])
                    
                dfRes = pd.DataFrame(lTmp, columns=['channel_name', 'status', 'ticketIDs', 'start_time', 'end_time'])
                                     
    # Wenn irgendein unbekannter Fehler auftritt, werden
    # sicherheitshalber alle Messstrecken als defekt angenommen
    except:

        #warning([ME.identifier, ': ', ME.message]);
        print('unknown error, assume that no relevant tickets exist, so user should check manually for problems')
        dfRes = pd.DataFrame.from_dict({'channel_name': sChannelNames, 'status': np.tile(True, (6,)), 'ticketIDs': np.tile('', (6,)), 'start_time': np.tile(pd.NaT, (6,)), 'end_time': np.tile(pd.NaT, (6,))})
        dictRes = {'f1': None, 'f2': None, 'f3': None, 'e1': None, 'e2': None, 'e3': None}
	
#    # Rückgabeobjekt
#    structRes.cVars = {'edge 1', 'edge 2', 'edge 3', 'flap 1', 'flap 2', 'flap 3', 'temp 1', 'temp 2', 'temp 3'};
#    structRes.bSensorStates = bOK;
#    structRes.dStartFailTimes = dStartFailTimes;
#    structRes.dEndFailTimes = dEndFailTimes;
#    structRes.bAllSensors = bAllSensors;
#    structRes.dFailTimes = dFailTimes;
#    structRes.cAllTickets = cAllTickets;
#    structRes.cRelevantTickets = cRelevantTickets;
           
    return([dictRes, dfRes])


                  





"""
function to find out the channels the given tickets are related

Parameters:
-----------

dfTickets:       relevant tickets, must contain column 'sTitle' with title strings    

Christian Kuehnert, 2018-12-20
"""
def get_channels_from_tickets(dfTickets):                            

    if dfTickets.shape[0]==0:
        
        bRes = [False, False, False, False, False, False]
        dfTmp = pd.DataFrame(columns= dfTickets.columns)
        dictRes = {}
        for iCh in range(6):
            dictRes.update({str(iCh): dfTmp})
                                    
        
        
    else:

        sTicketStrings = dfTickets.sTitle
            
        ## Ableitung der Sensorstates aus den relevanten Tickets
        # Tickets mit Teilstrings, die darauf schließen lassen, dass sie alle Sensorstrecken betreffen
        bAll = sTicketStrings.str.contains('alle', case=False, regex=False)

        # Tickets mit Teilstrings, die darauf schließen lassen, dass sie nur einzelne Rotorblätter betreffen
        bRBL = sTicketStrings.str.contains('( RBL)(RBL )', case=False, regex=True)
                    
        # Auswertung für die einzelnen Rotorblätter
#HIER WEITER 2019-1-18, ERKENNT Z.B. TICKET 201811-284 NICHT, DORT "Rbl 3 edge ... ztw. def."
        b1 = sTicketStrings.str.contains('RBL1', case=False, regex=False)
        b2 = sTicketStrings.str.contains('RBL2', case=False, regex=False)
        b3 = sTicketStrings.str.contains('RBL3', case=False, regex=False)

        bRBL = bRBL & ~(b1 | b2 | b3);                                          # wenn nur "RBL" vorkommt, z.B. "diverse RBL" in Ticket 201007-004
                    
        # Auswertung nach Edge/Flap-Richtung
        bEdge = sTicketStrings.str.contains('Edge', case=False, regex=False)
        bFlap = sTicketStrings.str.contains('Flap', case=False, regex=False)

        # weitere Prüfung auf Tickets, die für alle Rotorblätter relevant sein könnten
        bAll2 = sTicketStrings.str.contains('vertausch', case=False, regex=False) & bEdge & bFlap & ~(b1 | b2 | b3)
                    
        # Hilfsgrößen
        bTmp = bAll | bRBL
        bE = bEdge | ~bFlap
        bF = ~bEdge | bFlap
                                 
        # Bestimmung der Sensor-Zustände der einzelnen Messstrecken
        b1E = ((b1 | bTmp) & bE) | bAll2
        b2E = ((b2 | bTmp) & bE) | bAll2
        b3E = ((b3 | bTmp) & bE) | bAll2
        b1F = ((b1 | bTmp) & bF) | bAll2
        b2F = ((b2 | bTmp) & bF) | bAll2
        b3F = ((b3 | bTmp) & bF) | bAll2

        #bAllSensors = [b1F, b2F, b3F, b1E, b2E, b3E]           # which tickets (rows) contain information about which blades x direction (cols)
        bAllSensors = np.array(pd.concat((b1F, b2F, b3F, b1E, b2E, b3E), axis=1))           # which tickets (rows) contain information about which blades x direction (cols)
        bRes = bAllSensors.any(axis=0)
        
        #iChannels = list(itertools.compress([0,1,2,3,4,5], bAllSensors))
        dictRes = {}
        for iCh in range(6):
            dictRes.update({str(iCh): dfTickets[bAllSensors[:,iCh]]})
                                            
    #return(bAllSensors)
    #return([iChannels, bAllSensors])
    return([dictRes, bRes])
    








"""
function to retrieve data from database

@author: Christian Kuehnert
@modified: 2019-3-13
"""
def get_data_from_db(db, table, where_clause=None, columns=None):
        
    # TODO 2019-3-13: Fall abfangen, dass Spalten aus columns nicht enthalten sind    
    if not(columns):
        columns = get_fields_MySQL(db, table).Field

    select_clause = ','.join(columns)                
    
    if where_clause:
        tmp = f" where {where_clause}"
    else:
        tmp=''
    
    query = f"select {select_clause} from {table}{tmp};"

    dfData = pd.DataFrame(data=np.array(query_MySQL2(db, query, params=None)), columns = columns).infer_objects()
    
    return(dfData)
    #if dfData.shape[0]>0:
    #    dfData.columns = columns
    










"""
function to get the cycles for a given period with given where clause for a certain database

input:
------
    
- db:            string, database name including 'cmrblba_'
- start_time:    datetime, start time (included) of desired cycles
- end_time:      datetime, end time (included) of desired cycles
- columns:       list of strings, columns that should be retrieved from table ba_cycle_status
- where:         string, where clause to be applied for MySQL-request
- power_min:     float, minimum value of power for cycles to be included


@author: Christian Kuehnert
@modified: 2019-3-13

"""
def get_cycles(db, table='ba_cycle_measurement_cycle', start_time=None, end_time=None, columns=['create_time', 'ID', 'power_mean'], where='available_data>1', power_min=None):
    
    # create where clause
    lw = []
            
    if where:
        lw.append(where)
        
    if power_min:
        lw.append('power_mean>=' + str(power_min))
                
    tmp = whereClause_from_timeInterval(time_start=start_time, time_end=end_time)
    if tmp:
        lw.append(tmp)
        
    ## now combine to string        
    if len(lw)>1:
        where_clause = '(' + ') and ('.join(lw) + ')'
    elif len(lw)==1:
        where_clause = lw[0]
    else:
        where_clause=None
                           
    dfCDEF = get_data_from_db(db, table, where_clause=where_clause, columns=columns)

    return(dfCDEF)






"""
function to get the time series (and the overlap length) for a the given cycle

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channels:         list of integers, list of channel numbers, if None then all found channels will be returned
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-3-13

"""
def get_ts(db, create_time, iID, channels=None, count_meas_base=8192):
                   
    dict_res = {}
                     
    sFolder = get_folder(db, create_time, iID)                     # get folder for this create_time and ID
                                        
    if os.path.isdir(sFolder):
        
        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
        if len(sFiles)>0:
            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
            if channels:
                set_ic = set(iChannels)
                set_c = set(channels)
                
                iChannels = list(set.intersection(set_ic, set_c))
                
                ## add None for missing channels
                for cm in list(set_c-set_ic):
                    dict_res.update({cm: None})
                    

            for iCh in iChannels:
                        
                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel

                ## sort files by the measure-number
                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                         
                try:    

                    ## now aggregate the remaining files                                
                    listTS = []
                    for sFN0 in sFilesCh:                    
                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                     
                    ## combine the measurements if possible
                    iTS, iOL = combine_ts(listTS, count_meas_base)                        
                        
                    #dict_res.update({iCh:(iTS, iOL)})
                    
                    if len(iTS)>0:  
                        dict_res.update({iCh:(iTS, iOL)})
                        
                    else:
                    #if len(iTS)==0:
                        print(f'channel {iCh}: Einzelzeitreihen ungleich lang oder keine Vielfachen von {count_meas_base}')
                        dict_res.update({iCh: None})

                except Exception:
                    print(f'channel {iCh}: Probleme mit Entpacken oder Zusammenfuegen')
                    dict_res.update({iCh: None})
                                        
  
    return(dict_res)







"""
function to get the time series (and the overlap length) for a the given cycle

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channels:         list of integers, list of channel numbers, if None then all found channels will be returned
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-3-13

"""
def get_sda(db, create_time, iID, channels=None, count_meas_base=8192, dict_channels={''}):
#HIER WEITER 2019-4-9                   
    dict_res = {}
                     
    sFolder = get_folder(db, create_time, iID)                     # get folder for this create_time and ID
                                        
    if os.path.isdir(sFolder):
        
        sFiles = fnmatch.filter(listdir(sFolder), 'af_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
        if len(sFiles)>0:
            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
            if channels:
                set_ic = set(iChannels)
                set_c = set(channels)
                
                iChannels = list(set.intersection(set_ic, set_c))
                
                ## add None for missing channels
                for cm in list(set_c-set_ic):
                    dict_res.update({cm: None})
                    

            for iCh in iChannels:
                        
                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel

                ## sort files by the measure-number
                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                         
                try:    

                    ## now aggregate the remaining files                                
                    listTS = []
                    for sFN0 in sFilesCh:                    
                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                     
                    ## combine the measurements if possible
                    iTS, iOL = combine_ts(listTS, count_meas_base)                        
                        
                    #dict_res.update({iCh:(iTS, iOL)})
                    
                    if len(iTS)>0:  
                        dict_res.update({iCh:(iTS, iOL)})
                        
                    else:
                    #if len(iTS)==0:
                        print(f'channel {iCh}: Einzelzeitreihen ungleich lang oder keine Vielfachen von {count_meas_base}')
                        dict_res.update({iCh: None})

                except Exception:
                    print(f'channel {iCh}: Probleme mit Entpacken oder Zusammenfuegen')
                    dict_res.update({iCh: None})
                                        
  
    return(dict_res)





"""
function to get the time series for a the given cycle and (single) channel

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channel:          integer, channel number
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-3-14

"""
def get_ts_one_channel(db, create_time, iID, channel, count_meas_base=8192):
                   
    iTS = None
                     
    sFolder = get_folder(db, create_time, iID)                     # get folder for this create_time and ID

    pattern = f'at_*_{channel}.csv.gz'                         
               
    if os.path.isdir(sFolder):
        
        sFilesCh = fnmatch.filter(listdir(sFolder), pattern)    # find files in folder that match the time-series-files-format and the channel number
                                
        if len(sFilesCh)>0:

            ## sort files by the measure-number
            iMeas = [int(s.replace('at_', '').replace('_' + str(channel) + '.csv.gz', '')) for s in sFilesCh]
            sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
            
            iTS = get_ts_from_files(sFolder, sFilesCh, count_meas_base=count_meas_base)
  
    return(iTS)




#"""
#function to get the time series for a the given cycle and (single) channel
#
#input:
#------
#- db:               string, database name including 'cmrblba_'    
#- create_time:      timestamp, create_time of the time series
#- iID:              integer, cycle-id
#- channel:          integer, channel number
#- count_meas_base:  integer, base length for measurement
#
#
#@author: Christian Kuehnert
#@modified: 2019-3-13
#
#"""
#def get_ts_one_channel_old(db, create_time, iID, channel, count_meas_base=8192):
#                   
#    iTS = None
#                     
#    sFolder = get_folder(db, create_time, iID)                     # get folder for this create_time and ID
#
#    pattern = f'at_*_{channel}.csv.gz'                         
#               
#    if os.path.isdir(sFolder):
#        
#        sFilesCh = fnmatch.filter(listdir(sFolder), pattern)    # find files in folder that match the time-series-files-format and the channel number
#                                
#        if len(sFilesCh)>0:
#
#            ## sort files by the measure-number
#            iMeas = [int(s.replace('at_', '').replace('_' + str(channel) + '.csv.gz', '')) for s in sFilesCh]
#            sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
#                         
#            try:    
#
#                ## now aggregate the remaining files                                
#                listTS = []
#                for sFN0 in sFilesCh:                    
#                    listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
#                                                                                 
#                ## combine the measurements if possible
#                iTS, iOL = combine_ts(listTS, count_meas_base)
#            
#                if len(iTS)==0:
#                    print(f'channel {channel}: Einzelzeitreihen ungleich lang oder keine Vielfachen von {count_meas_base}')
#                    iTS = None # TODO 2019-3-13: noch function 'combine_ts' so umstellen, dass automatisch None rauskommt, wenn irgendwas schief laeuft
#
#            except Exception:                
#                print(f'channel {channel}: Probleme mit Entpacken oder Zusammenfuegen')
#                                    
#  
#    return(iTS)
#






"""
function to get the time series for a the list of files (these must be the 
complete files for a channel in the right order, 
there will be no test on this within this function)

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channel:          integer, channel number
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-3-14

"""
def get_ts_from_files(folder, files, count_meas_base=8192):
                   
    iTS = None
                                              
    try:    

        ## aggregate the files
        listTS = []
        for sFN0 in files:
            listTS.append(read_gz(fullfile((folder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                 
        ## combine the measurements if possible
        iTS, iOL = combine_ts(listTS, count_meas_base)
            
        if len(iTS)==0:
            print(f'Einzelzeitreihen ungleich lang oder keine Vielfachen von {count_meas_base}')
            iTS = None # TODO 2019-3-13: noch function 'combine_ts' so umstellen, dass automatisch None rauskommt, wenn irgendwas schief laeuft

    except Exception:                
        print(f'Probleme mit Entpacken oder Zusammenfuegen')
                                    
  
    return(iTS)









# function to collect time series as well as cdef data, and collect
# and store the features calculated from the time series
# in a first version save them separately as well as combined,
# later the combined data can be dropped if suitable functions
# to combine are implemented
#
# 
# Christian Kuehnert, 2018-11-9
#
# TODO 2018-10-18: eleganter machen, nur die Daten auslesen, die wirklich benoetigt werden etc.
#
def update_cdef_ts_features(sDB, sPathData, listFeatures, listTimeIntervals=[-np.Infinity, np.Infinity], iCntMeasBase = 8192, bSloppy = True):

    lMsg = []
    
    sNode = 'raw_data/ts'                                           # node where the time series data are stored
    
    sHeadersKey = ['create_time', 'ID', 'channel']                             # headers of the columns that relate the ts data to the cdef data
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    dfCDEF = update_cdef(sDB, sPathData, listTimeIntervals)         # update cdef-data and return list of all entries
        
    iCycles = dfCDEF.shape[0]                                              # number of cycles
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe
            bCycEx = False
            iStop = -1
            #if '/'+sNode in f.keys():
            if sNode in f:
                #if (type(f[sNode]) is pd.DataFrame):
                bCycEx = True
                iStop = f.get_storer(sNode).nrows
                               

# TODO 2018-11-9: complete implementation of this part                                                                                     
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
                if bSloppy:
                    dfCycEx = extract_cycleKeys_from_node(f, sNode, sHeadersKey)
                                    


            # find lists cycles for which the features already exist
            listCycFeatEx = []
            for i in range(len(listFeatures)):
                sNodeFeat = listFeatures[i][2]
            
                if sNodeFeat in f:
                    listCycFeatEx.append(extract_cycleKeys_from_node(f, sNodeFeat, sHeadersKey))
			
                else:		# perhaps here otherwise create this node with empty set but correct columns
                    #listCycEx.append([])
                    listCycFeatEx.append(pd.DataFrame(columns=sHeadersKey))                



            iCycles = dfCDEF.shape[0]
            #iCycles = 10
            for i in range(iCycles):
            #for i in range(2382, 2500):

                tsCT = dfCDEF.create_time[i]                          # current create_time
                iID = dfCDEF.ID[i]                                     # current ID
                
                if not ((iID==0) or pd.isnull(tsCT)):
                
                    sInfo = str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                    print(sInfo)                   
                        
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            print('    files exist')
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                dfCycEx = f.select(sNode, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                    #iTmp = dfCycEx[(dfCycEx.create_time == tsCT) & (dfCycEx.ID==iID)].channels       # get channels for that they are existing                              
                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
# TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    #iTS, lOL, sMsg = combine_ts(listTS, iCntMeasBase)                        
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                        
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(np.datetime64)                                
                                        dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')
                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['overlap'] = dfTmp['overlap'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #dfTmp.set_index(sHeadersKey)
                                        
                                        #f.append(sNode, dfTmp.set_index(sHeadersKey), format='table', data_columns = True)
                                        f.append(sNode, dfTmp, format='table', data_columns = True, index=False)                                
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        
                                        
                                        ## now calculate and add features
                                        for j in range(len(listFeatures)):
                                            feat_fct, kwargs, sNodeFeat = listFeatures[j]

                                            # TODO 2018-11-9: eleganter machen								
                                            dfCyc = pd.DataFrame(data=([[tsCT, iID, iCh]]), columns = sHeadersKey)

                                            dfCyc['create_time'] = pd.to_datetime(dfCyc['create_time'], errors='coerce')                                        
                                            dfCyc['ID'] = dfCyc['ID'].astype(int)
                                            dfCyc['channel'] = dfCyc['channel'].astype(int)
                                            
                                            if (intersect_df(dfCyc, listCycFeatEx[j], sHeadersKey).shape[0] == 0):								# if the current cycle is NOT in the cycles for which the current feature is already calculated                                            

                                                dfFeat = feat_fct(iTS, **kwargs)
                                            
                                                iN = dfFeat.shape[0]
                                                dfTmpF = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [iN, 1]))
                                                dfTmpF.set_index(dfFeat.index, inplace=True)                                            
                                                dfTmpF.columns = sHeadersKey                                                                
                                            
                                                dfTmpF['create_time'] = pd.to_datetime(dfTmpF['create_time'], errors='coerce')                                        
                                                dfTmpF['ID'] = dfTmpF['ID'].astype(int)
                                                dfTmpF['channel'] = dfTmpF['channel'].astype(int)                                                                                            
                                                
                                                dfTmpF = pd.concat([dfTmpF, dfFeat], axis=1)
                        
                                                f.append(sNodeFeat, dfTmpF, format='table', ignore_index=True, index=False, data_columns=True)
                    
                                                
                                                #print(sInfo + ', ch ' + str(iCh) + ': feature ' + sNodeFeat + ' added')

                    
                                    else:
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception as ex:
                                    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                                
    return(lMsg)





# function to collect time series as well as cdef data
# in a first version save them separately as well as combined,
# later the combined data can be dropped if suitable functions
# to combine are implemented
#
# 
# Christian Kuehnert, 2018-11-5
#
# TODO 2018-10-18: eleganter machen, nur die Daten auslesen, die wirklich benoetigt werden etc.
#
def update_cdef_ts_old(sDB, sPathData, listTimeIntervals=[-np.Infinity, np.Infinity], iCntMeasBase = 8192, bSloppy = True):

    lMsg = []
    
    sNode = 'raw_data/ts'                                           # node where the time series data are stored
    
    sHeadersKey = ['create_time', 'ID']                             # headers of the columns that relate the ts data to the cdef data
            
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    dfCDEF = update_cdef(sDB, sPathData, listTimeIntervals)         # update cdef-data and return list of all entries
        
    iCycles = dfCDEF.shape[0]                                              # number of cycles
    
    if iCycles>0:
        
        #dfCycles = dfCDEF.loc[:, sHeadersKey]                       # headers of the cdef-data available

        # TODO 2018-10-25: erstmal so implementiert, evtl. waere es sinnvoll, z.B. (und falls moeglich) mittels 
        # dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('index in [' + sIdx + '])')) die bereits
        # vorhandenen Daten auszulesen und nur die neueren CDEF-Cycles abzuarbeiten. Allerdings waren meine Versuche,
        # nach den Multiindizes zu selektieren, nicht erfolgreich, aus diesem Grunde werden erstmal alle cycles abgearbeitet
        # und dort individuell fuer jeden Cycle untersucht, ob schon Daten im .hd5-File vorhanden sind. Dadurch dauert die 
        # Bearbeitung sicher etwas laenger, der Code ist aber etwas einfacher und damit auch weniger fehleranfaellig     
        #with pd.HDFStore(sFN_hd5, 'a') as f:                        # open hd5-file
#                if sNode in f.keys():   
#
#                    # TODO 2018-10-25: Erstmal so Behelfsloesung, evtl. wenn moeglich auf den                                                                              
#                    #dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('(create_time in dfCDEF.create_time) and (ID in dfCDEF.ID)'))                   # dataframe with cycle keys
#                    sID = ','.join([str(i) for i in np.unique(dfCDEF.ID)])
#                    sIdx = ','.join([str(i) for i in np.unique(dfCycles.index)])
#                    dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('(ID in [' + sID + '])'))                   # dataframe with cycle keys
#                    dfCycEx = f.select(sNode, columns = sHeadersKey + ['channel'], where=('index in [' + sIdx + '])'))                   # dataframe with cycle keys
#                    bCycEx = (dfCycEx.shape[0]>0)
#                else:
#                    bCycEx = False
           
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe
            bCycEx = False
            iStop = -1
            #if '/'+sNode in f.keys():
            if sNode in f:
                #if (type(f[sNode]) is pd.DataFrame):
                bCycEx = True
                iStop = f.get_storer(sNode).nrows
                                                                                                                    
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
                if bSloppy:
                    dfCycEx = extract_cycleKeys_from_node(sNode, )
                                    

            iCycles = dfCDEF.shape[0]
            #iCycles = 10
            for i in range(iCycles):
            #for i in range(9950, 10100):
                    
                tsCT = dfCDEF.create_time[i]                          # current create_time
                ID = dfCDEF.ID[i]                                     # current ID
                
                if not ((ID==0) or pd.isnull(tsCT)):
                
                    sInfo = str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(ID)
                    print(sInfo)                   
                        
                    sFolder = get_folder(sDB, tsCT, ID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            print('    files exist')
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                dfCycEx = f.select(sNode, stop = iStop, columns = sHeadersKey + ['channel'], where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(ID) + ')'))                   # dataframe with cycle keys
                                    #iTmp = dfCycEx[(dfCycEx.create_time == tsCT) & (dfCycEx.ID==ID)].channels       # get channels for that they are existing                              
                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
# TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    #iTS, lOL, sMsg = combine_ts(listTS, iCntMeasBase)                        
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                        
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        df1 = pd.DataFrame(data=(np.tile([tsCT, ID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['channel', 'overlap'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(np.datetime64)                                
                                        dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')
                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['overlap'] = dfTmp['overlap'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #dfTmp.set_index(sHeadersKey)
                                        
                                        #f.append(sNode, dfTmp.set_index(sHeadersKey), format='table', data_columns = True)
                                        f.append(sNode, dfTmp, format='table', data_columns = True, index=False)                                
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        
                                    else:
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception as ex:
                                    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                                
    return(lMsg)






#
# function to append new data sets from ts (and later - to be implemented - from sda) to label-dataframe
#
#
# Christian Kuehnert, 2019-1-21
#
# TODO 2018-11-19: eigentlich noch Spalte einfuehren, ob zu dem cycle auch TS-Daten vorhanden sind (einfaches 0-1-flag),
# um spaeter das gleiche Labelfile fuer sda- und ts-Daten verwenden zu koennen aber gleichzeitig auch z.B. nur die TS-Daten
# labeln zu koennen. Erstmal aber damit warten und nur implementieren, wenn es relevant wird
def update_label_intern(sDB, sPathData):
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])

    sNodeLabel = 'raw_data/label'
    sNode_ts = 'raw_data/ts'    

    sHeadersKey = ['create_time', 'ID', 'channel']

    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        dfLabel_ts = extract_cycleKeys_from_node(f, sNode_ts, sHeadersKey)                
        dfLabel_ts = set_dtype_headersKey(dfLabel_ts)
        
        ## if there are already labels in the hd5-store, then only take new labels (and append them later to the existing labels)
        if sNodeLabel in f:
            dfLabel_ex = f.select(sNodeLabel)
            
            if dfLabel_ex.shape[0]>0:                      
                dfLabel_ex = set_dtype_headersKey(dfLabel_ex)
                dfLabel_ts = setdifference_df(dfLabel_ts, dfLabel_ex, sHeadersKey)      # newly found ts-keys
                                
        ## add datebase and last-changed-time                                        
        # TODO 2019-1-21: nochmal pruefen, ob alles so richtig!
        iN = dfLabel_ts.shape[0]
        if iN>0:
            iIdx = dfLabel_ts.index
            dfLabel_ts['database'] = pd.Series(np.tile(sDB, [iN,]), index=iIdx)
            dfLabel_ts['label'] = pd.Series(np.tile(9, [iN,]), index=iIdx, dtype=int)
            dfLabel_ts['last_changed'] = pd.Series(np.tile(dt.datetime.now(), [iN,]), index=iIdx)          # Spalte mit dem Zeitpunkt der letzten Aenderung
    
            dfLabel_ts['last_changed'] = pd.to_datetime(dfLabel_ts['last_changed'], errors='coerce')

            f.append(sNodeLabel, dfLabel_ts, format='table', ignore_index=True, index=False, data_columns=True)
            
        dfLabel = f[sNodeLabel]
        
    return(dfLabel)
        

    
    


# function to create a .csv-label-file
# 
# label==0: normal state (usually 'ok')
# label==1: failure (or sth. similar)
# label==9: unknown/not yet labelled
#
# 
# Christian Kuehnert, 2018-10-28
#
def label_to_csv(sDB, sPathData, sPathLabelFile):
        
    dfLabel = update_label_intern(sDB, sPathData)
        
    sFN_label = sPathLabelFile + '\\' + sDB + '_label.csv'            

    dfLabel.to_csv(sFN_label, sep=',', columns=['database', 'ID', 'create_time', 'channel', 'label', 'last_changed'], index=False)
 
    return(dfLabel)
        






# function to import a .csv-label-file and update the label-df in
# the hd5-file with these labels
# 
# label==0: normal state (usually 'ok')
# label==1: failure (or sth. similar)
# label==9: unknown/not yet labelled
#
# 
# Christian Kuehnert, 2018-10-25
#
def label_from_csv(sDB, sPathData, sPathLabelFile):
        
    sNodeLabel = 'raw_data/label'

    sHeadersKey = ['create_time', 'ID', 'channel']

    sFN_label = sPathLabelFile + '\\' + sDB + '_label.csv'
    
    if os.path.isfile(sFN_label):
        
        dfLabel = pd.read_csv(sFN_label, header=[0], sep=';', index_col=False)
            
        if dfLabel.shape[0]>0:
    
            sFN_hd5 = fullfile(sPathData, sDB + '.hd5')
            with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
                        
                #if '/'+ sNodeLabel in f.keys():
                if sNodeLabel in f:
                    f.put(sNodeLabel, dfLabel, format='table', append=True, data_columns=True, index=False)                        
                    
                else:
                    
                    dfLabel_ex = f.select(sNodeLabel)
                                    
                    dfLabel_ex.set_index(sHeadersKey)               # set index to combination of create_time, ID and channel
                    dfLabel.set_index(sHeadersKey)                  # set index to combination of create_time, ID and channel
#HIER WEITER 2018-10-26                   
                    ## if there are entries in dfLabel that are not in dfLabel_ex so 
                    ## just add them to dfLabel_ex but print a warning
                    iIdxDiff = dfLabel.index - dfLabel_ex.index                        # set difference of the indices
                    if len(iIdxDiff)>0:
                        print(sFN_label + ' has entries not in ' + sFN_label + ', this may indicate inconsistencies regarding the labels - please check!')                
                        f.append(sNodeLabel, dfLabel[iIdxDiff], format='table', ignore_index=True, index=False, data_columns=True)

                    ## TODO 2018-10-25: Testen, ob im .csv-file Eintraege mit 9 sind, die im
                    ## hd5-file einen anderen Wert haben, dann warning geben
#                    idx = dfLabel_ex.index[dfLabel_ex['label'] != 9].tolist()      # find index of already existing labels (i.e. that not equal 9)
                    #dfLabel[idx].label = dfLabel_ex[idx].label      # set labels of new label file to these indices
                    #dfLabel[idx].last_changed = dfLabel_ex[idx].last_changed
                    f[sNodeLabel][dfLabel.index]
     
    return(dfLabel)
    






# function to read cdef-, ts- and label-data from hd5-file and combine all
# to 1 dataframe
#
# 
# Christian Kuehnert, 2018-10-25
#
def read_ts_from_hd5(sDB, sPathData, tsCreateTime, iID, iChannel):
        
    sNodeCDEF = 'raw_data/cdef'
    sNodeLabel = 'raw_data/label'
    sNodeTS = 'raw_data/ts'                                           # node where the time series data are stored
    
    #sHeadersKey = ['create_time', 'ID']                             # headers of the columns that relate the ts data to the cdef data
            
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        sCT = 'Timestampe("' + tsCreateTime + '")'
        sID = str(iID)
        sCh = str(iChannel)
        
        # TODO 2018-10-25: spaeter Filter einbauen, s. auskommentierte uebernaechste Zeile!
        #dfTS = f[sNodeTS]        
        dfTS = f.select(sNodeTS, where=('(create_time==' + sCT + ') and (ID==' + sID + ') and (channel==' + sCh + ')'))

        #dfCDEF = f[sNodeCDEF]
        dfCDEF = f.select(sNodeCDEF, where=('(create_time==' + sCT + ') and (ID==' + sID + ') and (channel==' + sCh + ')'))
        dfLabel = f.select(sNodeLabel, where=('(create_time==' + sCT + ') and (ID==' + sID + ') and (channel==' + sCh + ')'))

# TODO 2018-10-25: hier noch richtig machen!
        dfTS_short = np.reshape(dfTS)
        
        return(pd.concat((dfLabel, dfCDEF, dfTS_short), axis=1))
        


    
    
    
# function to check if the file exists and if it contains the given node
#
# Christian Kuehnert, 2018-11-13
#
def check_node(sFN, sNodeFeat):

    bRes = False                    
    if os.path.isfile(sFN):
        with pd.HDFStore(sFN, 'a', complevel=9, complib='blosc:lz4') as f:                    
            if sNodeFeat in f:                
                bRes = True

    return(bRes)
    
    
    





    
    
##
## Function to import a .csv-label-file and update the label-df in
## the hd5-file with these labels. If no label file exists, the label
## node will be left untouched
## 
## label==0: normal state (usually 'ok')
## label==1: failure (or sth. similar)
## label==9: unknown/not yet labelled
##
## input:
## 
##       - bOverwrite:      if True, the complete label-node will be overwritten
##                          by the data in the file. Otherwise only new data
##                          will be appended
##
## output:
##
## 
## Christian Kuehnert, 2018-11-13
##
## TODO 2018-11-13: nochmal ueberlegen, ob das wirklich so am besten ist - aktuell
## gibt es nur die beiden Moeglichkeiten "alles Ueberschreiben" oder "anhaengen". 
## Interessant waere vielleicht auch (oder statt einer davon) "den im file enthaltenen
## Teil ueberschreiben und den Rest unveraendert lassen" oder "die Stellen ueberschreiben,
## wo im hd5-file der label-Wert 9 ist, und den Rest so lassen"
#def update_labels(sDB, sPathData, sPathLabelFile, bOverwrite = False):
#        
#    sNode_label = 'raw_data/label'
#    
#    sHeadersKey = ['create_time', 'ID', 'channel']
#    
#    sSep = None
#        
#    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
#    sFN_label = sPathLabelFile + '\\' + sDB + '_label.csv'
#        
#    if os.path.isfile(sFN_label):
#                
#        #dfLabels = pd.read_csv(sFN_label, header=[0], sep=sSep, index_col=False)
#        dfLabels_file = pd.read_csv(sFN_label, header=[0], sep=sSep, engine='python')
#        dfLabels_file = set_dtype_headersKey(dfLabels_file)
#        #dfLabels_file['create_time'] = pd.to_datetime(dfLabels_file['create_time'], errors='coerce')
#        #dfLabels_file['ID'] = dfLabels_file['ID'].astype(int)
#        #dfLabels_file['channel'] = dfLabels_file['channel'].astype(int)
#
#        if dfLabels_file.shape[0]>0:
#    
#            with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#                        
#                if sNode_label in f:
#                                        
#                    if bOverwrite:                          # if bOverwrite just replace the old node by the new dataframe
#                        f.remove(sNode_label)
#                        f.append(sNode_label, dfLabels_file, format = 'table', append=True, data_columns=True, index=False)
#                        
#                    else:                                                                                                
#                        
#                        dfLabels_hd5 = f.select(sNode_label)
#                                    
#                        dfLabels_file = setdifference_df(dfLabels_file, dfLabels_hd5, sHeadersKey)
#                        #dfLabels_hd5.set_index(sHeadersKey, inplace=True)               # set index to combination of create_time, ID and channel
#                        #dfLabels_file.set_index(sHeadersKey, inplace=True)                  # set index to combination of create_time, ID and channel                                      
#                        #iIdxDiff = dfLabels_file.index - dfLabels_hd5.index                        # set difference of the indices
#                        #if len(iIdxDiff)>0:                    
#                        if dfLabels_file.shape[0]>0:
#                            #dfLabels_file = dfLabels_file[iIdxDiff]
#                            #dfLabels_file.reset_index(drop=False, inplace=True)
#                            f.append(sNode_label, dfLabels_file, format = 'table', append=True, data_columns=True, index=False)
#                    
#                else:
#                    #f.put(sNode_label, dfLabels, format='table', append=True, data_columns=True, index=False)               
#                    f.append(sNode_label, dfLabels_file, format = 'table', append=True, data_columns=True, index=False)
#                    
#






# function to extract the cycle-keys (create_time and cycle-ID) from
# the data in node sNode in the hd5-file. This node must contain the
# columns in sHeadersKey
#
# 
# Christian Kuehnert, 2018-11-6
#
# TODO 2018-10-26: ist noch sehr langsam - schnellere Variante finden (am besten gleich nur DISTINCT-Datensaetze aus dem 
# hd5-file auslesen, wenn das irgendwie geht)
#
def extract_cycleKeys_from_node(f, sNode, sHeadersKey, iChunkSize = 1000000):
    
    lCycKeys = []
        
    iterator = f.select(sNode, chunksize=iChunkSize, columns=sHeadersKey)
        
    for i, dfChunk in enumerate(iterator):  
        #print('    chunk ' + str(i))                      
        lCycKeys.append(dfChunk.drop_duplicates())
            
    if lCycKeys:
        dfCycKeys = pd.concat(lCycKeys, axis=0)
        dfCycKeys.drop_duplicates(subset=sHeadersKey, inplace=True)                             # necessary again, because different chunks can contain the same keys
    else:
        dfCycKeys = []
        #dfCycKeys = pd.DataFrame(columns=sHeadersKey)
                        
    return(dfCycKeys)






#
# function to calculate the mean and variance of the (differentiated) time series 
# as well as the mean of the absolute values
#
# input:
#       - dfTS:             ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
#       - iMaxOrderDiff:    max. order of differencing, i.e. how often differences are calculated
#       - iMaxMoment:       max. moment to calculate
#
# output:
#       - dfRes:        dataframe with columns ['mean_d...', 'mean_abs_d...', 'var_d...'] containing the 
#                       respective values for the respective values
#
#
# Christian Kuehnert, 2018-12-12
#
def stats(dTS, iMaxOrderDiff, iMaxMoment):

    rD = range(iMaxOrderDiff+1)
    rM = range(1,iMaxMoment+1)
    
    sCols = list(['d'+str(d) + '_m' + str(k) for d in rD for k in rM])
    dMoments = [moment(np.diff(dTS, n=d), moment=k, axis=0, nan_policy='omit') for d in rD for k in rM]
    
    dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)    
    dfRes.loc[0] = dMoments
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    return(dfRes)



#
# function to calculate the mean and variance of the (differentiated) time series 
# as well as the mean of the absolute values
#
# input:
#       - dfTS:         ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
#       - iOrderDiff:   order of differencing, i.e. how often differences are calculated
#
# output:
#       - dfRes:        dataframe with columns ['mean_d...', 'mean_abs_d...', 'var_d...'] containing the 
#                       respective values for the respective values
#
#
# Christian Kuehnert, 2018-12-12
#
def stats_old(dfTS, iOrderDiff):
    
    # TODO 2018-12-12: vielleicht allgemein bis zum n-ten Moment berechnen und damit weiterklassifizieren!?
    sCols = list(['mean', 'mean_abs', 'std_dev', 'skewness', 'kurtosis'])

    d_dTS = np.diff(dfTS, n=iOrderDiff)
    
    dMean = np.asarray(np.mean(d_dTS))
    dMeanAbs = np.asarray(np.mean(abs(d_dTS)))
    dVar = np.asarray(np.var(d_dTS, ddof=1))
    dSk = skew(d_dTS, axis=0, nan_policy = 'omit')
    dKurt = kurtosis(d_dTS, axis=0, nan_policy = 'omit')

    dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)    
    dfRes.loc[0] = [iOrderDiff, dMean, dMeanAbs, dVar, dSk, dKurt]
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)





"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-13
"""
# TODO 2018-12-13: alte Version, ggf. spaeter loeschen
def asym(dTS, iOrderDiff, dQs):
    
    sCols = ['diffQ' + str(q) for q in dQs]
    df = np.diff(dTS, n=iOrderDiff, axis=0)
    #df = dfTS.diff(periods=iOrderDiff, axis=0)
    
    df1 = df[df>0].dropna().quantile(q=dQs, axis=0)
    df2 = -df[df<0].dropna()
    df3 = df2.quantile(q=dQs, axis=0)
                            
    dfDiff = df1 - df3
    
    dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
    dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)





"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-13
"""
# TODO 2018-12-13: so aendern, dass kein df sondern ein np.array zurueckgegeben wird, welches man direkt fuer die Klassifikation einlesen kann
def asym_feat_old(dTS, iOrderDiff, dQ):
    
    sCols = ['diff' + str(iOrderDiff) + '_q' + str(dQ)]
    d_dTS = np.diff(dTS, n=iOrderDiff, axis=0)
    
    d_dTS = d_dTS[~np.isnan(d_dTS)]
    
    d1 = np.percentile(d_dTS[d_dTS>0], dQ*100, axis=0)
    
    d2 = -d_dTS[d_dTS<0]
    d3 = np.percentile(d2, dQ*100, axis=0)
                            
    dDiff = d1 - d3
    
    #dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
    dfRes = pd.DataFrame(columns = sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dDiff.values.transpose())
    dfRes.loc[0] = dDiff
    
    #dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)
    
    

"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-14
"""
# TODO 2018-12-13: so aendern, dass kein df sondern ein np.array zurueckgegeben wird, welches man direkt fuer die Klassifikation einlesen kann
def asym_feat(dTS, iOrderDiff, dQ):
    
    #sCols = ['diff' + str(iOrderDiff) + '_q' + str(dQ)]
    d_dTS = np.diff(dTS, n=iOrderDiff, axis=0)
    
    d_dTS = d_dTS[~np.isnan(d_dTS)]
    d_dTS = d_dTS / np.linalg.norm(d_dTS, ord=2, axis=0)
    
    d1 = np.percentile(d_dTS[d_dTS>0], dQ*100, axis=0)
    
    d2 = -d_dTS[d_dTS<0]
    d3 = np.percentile(d2, dQ*100, axis=0)
                            
    dDiff = d1 - d3
    
    #dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
    #dfRes = pd.DataFrame(columns = sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dDiff.values.transpose())
    #dfRes.loc[0] = dDiff
    
    #dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    #for s in sCols:
    #    dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    #return(dfRes)
    return(dDiff)
    
    


"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-13
"""
def asym_predict(dDiffQ = None, dThreshold = None):
    
    iPred = (abs(dDiffQ) > dThreshold).astype(int)   
    return(iPred)
    #bPred = (abs(dDiffQ) > dThreshold)  
    #return(bPred)






#
# function to calculate the ratio of the variances of trend and residuals of the time series
#
# input:
#       - dTS:          ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
#       - iOrderDiff:   order of differencing, i.e. how often differences are calculated
#       - iWdwSize:     size of moving-average-window
#
# output:
#       - dfRes:        dataframe with columns ['varTrend', 'varRes', 'ratioVar'] containing the 
#                       respective values for the respective values
#
#
# Christian Kuehnert, 2018-11-8
#
def ratio_variances(dTS, iOrderDiff, iWdwSize):

    sCols = list(['std_dev_trend', 'std_dev_res', 'ratio'])

    d_dTS = np.diff(dTS, n=iOrderDiff)
    d_maTS = d_dTS.rolling(iWdwSize, center = True, axis = 0).mean()                            # moving average                       
    d_diffTS = d_dTS - d_maTS                                                                  # difference to moving average                

    dVarTrend = np.asarray(np.var(d_maTS, axis=0, ddof=1))
    dVarRes = np.asarray(np.var(d_diffTS, axis=0, ddof=1))
    dRatioVar = np.asarray(dVarTrend/dVarRes)

    dfRes = pd.DataFrame(columns = ['order_diff', 'window_size'] + sCols)
    dfRes.loc[0] = [iOrderDiff, iWdwSize, dVarTrend, dVarRes, dRatioVar]
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    dfRes['window_size'] = dfRes['window_size'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)





"""
function to calculate the skewness of the differentiated time series data

@author: Christian Kuehnert, 2018-12-12
"""
def skewness(dTS, iOrderDiff):

#    df = dfTS.diff(periods=iOrderDiff, axis=0)
    dTmp = np.diff(dTS, n=iOrderDiff)
    dSk = skew(dTmp, axis=0, nan_policy = 'omit')

    dfRes = pd.DataFrame(columns=['order_diff', 'skewness'])
    dfRes.loc[0] = np.append(iOrderDiff, dSk)
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    dfRes['skewness'] = dfRes['skewness'].astype(float)

    return(dfRes)
    



def my_process(dfTS):
    return(None)




#
# function to calculate the acf of diff-ed time series up to lag iMaxLag
#
# input:
#       - dfTS:         ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
#       - iOrderDiff:   order of differencing, i.e. how often differences are calculated
#       - iMaxLag:      max. lag up to which the acf is calculated
#       - bWide:        if true, a wide-table representation is returned (i.e. one column for each lag), otherwise
#                       the returned dataframe has an extra column with the lag as value
#
# output:
#       - dfRes:        dataframe with columns ['order_diff', 'acf'] and (if bWide) 'lag' containing the lag and the
#                       acf of the iOrderDiff-times differenced time series
##
#
# Christian Kuehnert, 2018-12-6
#
def my_acf(dTS, iOrderDiff, iMaxLag, bWide=False):

    iLags = [i for i in range(iMaxLag+1)]
    dACF = acf(np.diff(dTS, n=iOrderDiff), nlags=iMaxLag)
    
    if bWide:         
        sCols = ['acf_lag' + str(i) for i in iLags]
        df1 = pd.DataFrame(data=[iOrderDiff], columns = ['order_diff'], dtype=int)
        df2 = pd.DataFrame(data=dACF[None], columns = sCols, dtype=float)
        dfRes  = pd.concat((df1, df2), axis=1)      

    else:
        iN = dACF.shape[0]
        df1 = pd.DataFrame(data=np.tile(iOrderDiff, [iN, ]), columns = ['order_diff'], dtype=int)
        df2 = pd.DataFrame(data=iLags, columns=['lag'], dtype=int)
        df3 = pd.DataFrame(data=dACF, columns=['acf'], dtype=float)
        dfRes = pd.concat((df1, df2, df3), axis=1)

    return(dfRes)
    



    

    
    
    


# function that takes ts-DataFrame containing ONE time series and calculates the features of it
#
# Christian Kuehnert, 2018-11-6
#
#def ts2features(dfTS, sHeadersKey, sColTime, feat_fct, *args, **kwargs):
#def ts2features(sDB, sPathData, sHeadersKey, sColTime, listFeatures):
def ts2features(sDB, sPathData, sHeadersKey, listFeatures):
		
    sMsg = []
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    sNodeTS = 'raw_data/ts'    
    
    listCycEx = []

    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
        print('    find new cycles')
        #dfCycles = extract_cycleKeys_from_node(f, sNodeTS, sHeadersKey, 500000)
        dfCycles = extract_cycleKeys_from_node(f, sNodeTS, sHeadersKey)

        ## remove all elements from dfCycles for which already all features are calculated
        ## Note: of course this could be done more sophisticated in order to avoid duplicate 
        ## calculations if the different features have different keys they are existing, but
        ## this code here is at least a cheap and easy starting point        

        #for feat_fct, kwargs, sNodeFeat in listFeatures:			
        for i in range(len(listFeatures)):
            sNodeFeat = listFeatures[i][2]
            
            if sNodeFeat in f:
                listCycEx.append(extract_cycleKeys_from_node(f, sNodeFeat, sHeadersKey))
			
            else:		# perhaps here otherwise create this node with empty set but correct columns
                #listCycEx.append([])
                listCycEx.append(pd.DataFrame(columns=sHeadersKey))
                

    ## combine the found existing cycles and substract them from dfCycles
    #listTmp = [s for s in listCycEx if isinstance(s, pd.DataFrame)]
    #if listTmp:
    #    dfCycEx = listTmp[0]
    #    i=1
    #    while i<len(listTmp):
    #        dfCycEx = intersect_df(dfCycEx, listTmp[i], sHeadersKey)
    #        i=i+1
    dfCycEx = listCycEx[0]
    i=1
    while i<len(listCycEx):
        dfCycEx = intersect_df(dfCycEx, listCycEx[i], sHeadersKey)
        i=i+1
                    
    dfCycles = setdifference_df(dfCycles, dfCycEx, sHeadersKey)
    dfCycles.reset_index(drop=True, inplace=True)

    print('    ' + str(dfCycles.shape[0]) + ' new cycles found')
		
    if dfCycles.shape[0]>0:												# if there are cycles left ...
		
        sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name

        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
           			
            ## use first cycle to create new feature if it not already exists
            dfCyc = dfCycles.iloc[[0],:]
			
            tsCT = dfCyc.create_time[0]
            iID = dfCyc.ID[0]
            iCh = dfCyc.channel[0]
												
            dfTS = f.select(sNodeTS, columns=['idx','at'], where=('(create_time=Timestamp("' + str(tsCT) + '")) and (ID=' + str(iID) + ') and (channel=' + str(iCh) + ')'))
            dfTS.sort_values(by=['idx'], inplace=True)
            
            ## now calculate the features
            for i in range(len(listFeatures)):
                feat_fct, kwargs, sNodeFeat = listFeatures[i]
								
                #if not (dfCyc in listCycEx[i]):								# if the current cycle is NOT in the cycles for which the current feature is already calculated
                if (intersect_df(dfCyc, listCycEx[i], sHeadersKey).shape[0] == 0):
                    dfFeat = feat_fct(dfTS.loc[:,'at'], **kwargs)

                    #dfTmp = pd.concat([dfCyc, dfFeat], axis=1)                        
                    iN = dfFeat.shape[0]
                    dfTmp = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [iN, 1]))
                    dfTmp.set_index(dfFeat.index, inplace=True)                                        
                    dfTmp.columns = sHeadersKey                                                                
                        
                    for s in sHeadersKey:
                        dfTmp[s] = dfTmp[s].astype(dfCycles[s].dtype)

                    dfTmp = pd.concat([dfTmp, dfFeat], axis=1)

                    if sNodeFeat in f:
                        f.append(sNodeFeat, dfTmp, format='table', ignore_index=True, index=False, data_columns=True)
                    else:
                        f.put(sNodeFeat, dfTmp, format='table', append=True, ignore_index=True, index=False, data_columns=True)
            
            
            
            ## loop through all remaining cycles, now all feature nodes must exist
            for i in range(1, dfCycles.shape[0]):
			
                if (i % 10 == 0):
                    print('    ' + str(i) + '/' + str(dfCycles.shape[0]))
                
                dfCyc = dfCycles.iloc[[i],:]
			
                #tsCT = dfCyc.iloc[i].create_time
                #iID = dfCyc.iloc[i].ID
                #iCh = dfCyc.iloc[i].channel
                tsCT = dfCyc.create_time[i]
                iID = dfCyc.ID[i]
                iCh = dfCyc.channel[i]
												
                dfTS = f.select(sNodeTS, columns=['idx','at'], where=('(create_time=Timestamp("' + str(tsCT) + '")) and (ID=' + str(iID) + ') and (channel=' + str(iCh) + ')'))
                dfTS.sort_values(by=['idx'], inplace=True)
            
                ## now calculate the features
                #for feat_fct, args, sNodeFeat, sCols in listFeatures:
                #for feat_fct, kwargs, sNodeFeat in listFeatures:
                for j in range(len(listFeatures)):
                    feat_fct, kwargs, sNodeFeat = listFeatures[j]
								
                    if (intersect_df(dfCyc, listCycEx[j], sHeadersKey).shape[0] == 0):								# if the current cycle is NOT in the cycles for which the current feature is already calculated
                        dfFeat = feat_fct(dfTS.loc[:,'at'], **kwargs)
                        
                        iN = dfFeat.shape[0]
                        dfTmp = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [iN, 1]))
                        dfTmp.set_index(dfFeat.index, inplace=True)                                            
                        dfTmp.columns = sHeadersKey                                                                
                        
                        for s in sHeadersKey:
                            dfTmp[s] = dfTmp[s].astype(dfCycles[s].dtype)
                        
                        #dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')                                        
                        #dfTmp['ID'] = dfTmp['ID'].astype(int)
                        #dfTmp['channel'] = dfTmp['channel'].astype(int)                        
                        
                        dfTmp = pd.concat([dfTmp, dfFeat], axis=1)

                        f.append(sNodeFeat, dfTmp, format='table', ignore_index=True, index=False, data_columns=True)
                                   
    
    return(sMsg)
      

	  	                
	  
	  
# function to extract features from the hd5-file 
#
# input:
#
# output:
# 
# Christian Kuehnert, 2018-11-13
# 
def extract_feature_fromHD5(sDB, sPathData, sNodeFeat, sHeadersKey, listFilters):
    
    dfRes = []
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if sNodeFeat in f:
            #lWhere = [] 
            #for sName, vals in dictFilters.items():
            #    lWhere.append(sName + ' in [' + ','.join([str(i) for i in vals]) + ']')            
            #sWhere = '(' + ') and ('.join(lWhere) + ')'            
            sWhere = '(' + ') and ('.join(listFilters) + ')'            
                            
            dfRes = f.select(sNodeFeat, where=sWhere)       
            	  
    return(dfRes)
        
      
    
    
    
    
    
  
# function to reformat the acf-data from long to short table 
#
# input:
#
# output:
# 
# Christian Kuehnert, 2018-11-22
# 
def reformat_acf(dfACF):             
    
    sCols = set(dfACF.columns) - set(['lag', 'acf'])
    dfRes = dfACF.pivot_table(index=list(sCols), columns=['lag'], values=['acf']).reset_index()
    dfRes.rename(columns = {'lag': 'index', 'acf': 'lag_'}, inplace=True)
    dfRes.columns = dfRes.columns.map('{0[0]}{0[1]}'.format)

    return(dfRes)
    
    
    
    
    
	    
	  
# function to extract data from a node in the hd5-file 
#
# input:
#
# output:
# 
# Christian Kuehnert, 2018-11-22
# 
def extract_data_fromNode(sDB, sPathData, sNode, sCols=None, listFilters=[]):
    
    sNode_acf = 'features/dfACF_d1TS'              

    
    dfRes = pd.DataFrame(columns = sCols)
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:

            if (sNode==sNode_acf):
# TODO 2018-11-22: hier gleich aus den uebergebenen columns (lag_1, lag_2, ...) die benoetigten lags 
# herausziehen und beim Auslesen aus dem hd5-file mit where danach filtern (ggf. zum where-clause in listFilters hinzufuegen)
                #iLags = [int(s.replace('lag_','')) for s in sCols  if (s.find('lag_')>-1)]
                #sW2= '(lag==' + ') or (lag=='.join([str(i) for i in iLags]) + ')'
                sLags = [s.replace('lag_','') for s in sCols  if (s.find('lag_')>-1)]
                sWhere = '(lag=[' + ','.join(sLags) + '])'
                
                if len(listFilters)>0:
                    sWhere = '(' + sWhere + ' and (' + ') and ('.join(listFilters) + '))'
                    
                dfRes = f.select(sNode, where=sWhere)
                
                ## reformat acf-data            
                if (dfRes.shape[0]>0):        
                    dfRes = reformat_acf(dfRes)
                    dfRes = dfRes.loc[:, sCols]
            
            else:                
                if len(listFilters)>0:
                    sWhere = '(' + ') and ('.join(listFilters) + ')'
                    dfRes = f.select(sNode, where=sWhere, columns=sCols)
                else:
                    dfRes = f.select(sNode, columns=sCols)
                                
                
    return(dfRes)
       
	  
# function to merge the features with other nodes from the hd5-file 
#
# input:
#           - listNodes: list with nodes and columns that should be merged to dfFeat
#    
# output:
# 
# Christian Kuehnert, 2018-11-16
# 
def merge_data(dfFeat, sDB, sPathData, listNodes):

    bNew = False
    
    ## combine with production data                                                               
    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
    
    bOk = True
    # neue Variante, funktioniert aber noch nicht richtig, ausserdem unklar, ob sie
    # prinzipiell mit vielen Feature-Daten (d.h. vielen Indices) funktioniert
    # --> deshalb erstmal die "alte" Variante unten verwendet    
    if bNew:                
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
            for sNode, sCols, sKeyCols, sHow in listNodes:            
                sListMultiIdx = np.unique(dfFeat.set_index(sKeyCols).index)
                sWhere =  ','.join(sKeyCols) + ' in [' + ','.join(sListMultiIdx) + ']'                                    
                dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sKeyCols)                                                                        
                dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)

    else:
            
        ## combine with production data                                           
        lTmp = []
#        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#            for sNode, sCols, sKeyCols, sHow in listNodes:            
#                        
#                if sNode in f:
#                    dfTmp = f.select(sNode, columns=sKeyCols + sCols)
#                    dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)            

        ## combine with production data                                           
        lTmp = []
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
            for sNode, sCols, sKeyCols, sHow in listNodes:            
                        
                if sNode in f:
                    lTmp.append([f.select(sNode, columns=sKeyCols + sCols), sCols, sKeyCols])
                else:
                    bOk = False
                
        if bOk:
            i=0
            dfRes = dfFeat.copy()
            while (dfRes.shape[0]>0) & (i < len(lTmp)):
                dfTmp, sCols, sKeyCols = lTmp[i]
                i += 1
                if dfTmp.shape[0]>0:                        
                    dfRes = pd.merge(dfRes, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)
                else:
                    dfRes = pd.DataFrame()                                          
                    
        else:
            dfRes = pd.DataFrame()                     

    return dfRes
    
    
    
    
    
    
    
# old version - delete when new is working    
def merge_data_old(dfFeat, sDB, sPathData, listNodes, sHeadersKey):

    dfRes = dfFeat.set_index(sHeadersKey)
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    sListMultiIdx = dfFeat.index(sHeadersKey).index()
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
        for sNode, sCols in listNodes:
            sWhere =  ','.join(sHeadersKey) + ' isin [' + ','.join(sListMultiIdx) + ']'
            dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sHeadersKey)
            
            dfRes = pd.concat([dfRes, dfTmp], axis=1, join_axes=[dfRes.index])
                          
                                                    	  
    return(dfRes.reset_index(drop=True, inplace=False))
        
      





"""
function to get the combined data from several nodes in the file, applying filters
while retrieving

Parameters:
-----------

list_nodes : list containing pairs of strings like [name_of_node, filter_criteria],
i.e. the name of the node combined with a filter string, e.g. [['cdef', 'omega_mean>0 and 'pitch_sigma<5', ['power_mean', 'create_time', ']], ['label', 'label in [0,1]']]
The filter string must be in a format which can be directly used as value for the hdfstore.select-where-parameter

Example:
    sDB = 'cmrblba_bc_t_02758'
    sNode_cdef = 'cdef'
    sNode_ts_startstop = 'raw_data/ts/startstop'
    listNodes = [[sNode_cdef, []], 
                 [sNode_ts_startstop, ['channel in [0,1,2]']]]
    listCols = ['create_time', 'ID', 'channel', 'omega_mean', 'std_dev', 'std_dev_abs']
    dfData = get_data(list_nodes = listNodes, list_columns = listCols)                      # get (filtered) cdef-data

Christian Kuehnert, 2019-1-11
"""
def get_data(sDB, sPathData, listNodes, listColumns, sHow = 'inner'):
    
    ## combine with production data                                                               
    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
    
    bOk = True
    # neue Variante, funktioniert aber noch nicht richtig, ausserdem unklar, ob sie
    # prinzipiell mit vielen Feature-Daten (d.h. vielen Indices) funktioniert
    # --> deshalb erstmal die "alte" Variante unten verwendet    
    #bNew = False
    #if bNew:                
        #with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
            #for sNode, sCols, sKeyCols, sHow in listNodes:            
            #    sListMultiIdx = np.unique(dfFeat.set_index(sKeyCols).index)
            #    sWhere =  ','.join(sKeyCols) + ' in [' + ','.join(sListMultiIdx) + ']'                                    
            #    dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sKeyCols)                                                                        
            #    dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)

    #else:
            
    ## combine with production data                                           
    # TODO 2018-12-5: im folgenden koennte man auch erst die Spalten aller interessierenden nodes abfragen mit
    # f.get_storer('df').attrs['non_index_axes'], dann daraus diejenigen bestimmen, die fuer das Merging relevant
    # sind, sie mit den in listColumns angeforderten Spalten kombineren und dann erst die Daten auslesen (und 
    # dabei in "select(...)" entsprechend nur die benoetigten columns abfragen. Waere vielleicht hinsichtlich des
    # Auslesens aus hdfstore eleganter und evtl. schneller, hier aber aus Gruenden der einfacheren Implementierung
    # erstmal nicht umgesetzt

    ## first read in all nodes (if they exist)    
    lData = []
    i=0
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        while bOk and (len(listNodes)>i):
            
            sNode, sFilter = listNodes[i]
            i += 1
                
            if sNode in f:
                if len(sFilter)==0:
                    lData.append(f.select(key=sNode))                
                else:
                    lData.append(f.select(key=sNode, where=sFilter))
            else:
                bOk = False
        
        
                
    ## combine the found nodes
    if bOk and (len(lData)>0):    
        dfRes = lData[0]
        i=1
        while bOk and (len(lData)>i):
            dfTmp = lData[i]            
            i += 1
            #if dfTmp.shape[0]>0:               
            sKeyCols = list(set(dfRes.columns).intersection(set(dfTmp.columns)))
            dfRes = pd.merge(dfRes, dfTmp, how=sHow, on=sKeyCols)
            #else:
            #    dfRes = pd.DataFrame()                                          
                
            bOk = (dfRes.shape[0]>0) & (i < len(lData))
            
        if (dfRes.shape[0]>0) and (len(listColumns)>0):
            dfRes = dfRes.loc[:, listColumns]  
                
    else:
        if len(listColumns)>0:
            dfRes = pd.DataFrame(columns=listColumns)
        else:
            dfRes = pd.DataFrame()


    return dfRes
    
    




#
#
#"""
#function to get the combined data from several nodes in the file, applying filters
#while retrieving
#
#Parameters:
#-----------
#
#list_nodes : list containing pairs of strings like [name_of_node, filter_criteria],
#i.e. the name of the node combined with a filter string, e.g. [['cdef', 'omega_mean>0 and 'pitch_sigma<5', ['power_mean', 'create_time', ']], ['label', 'label in [0,1]']]
#The filter string must be in a format which can be directly used as value for the hdfstore.select-where-parameter
#
#
#Christian Kuehnert, 2018-12-5
#""" 
#def get_data_v2(sDB, sPathData, listNodes, sHow = 'inner'):
#    
#    ## combine with production data                                                               
#    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
#    
#    bOk = True
#    # neue Variante, funktioniert aber noch nicht richtig, ausserdem unklar, ob sie
#    # prinzipiell mit vielen Feature-Daten (d.h. vielen Indices) funktioniert
#    # --> deshalb erstmal die "alte" Variante unten verwendet    
#    #bNew = False
#    #if bNew:                
#        #with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
#            #for sNode, sCols, sKeyCols, sHow in listNodes:            
#            #    sListMultiIdx = np.unique(dfFeat.set_index(sKeyCols).index)
#            #    sWhere =  ','.join(sKeyCols) + ' in [' + ','.join(sListMultiIdx) + ']'                                    
#            #    dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sKeyCols)                                                                        
#            #    dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)
#
#    #else:
#            
#    ## combine with production data                                           
#    # TODO 2018-12-5: im folgenden koennte man auch erst die Spalten aller interessierenden nodes abfragen mit
#    # f.get_storer('df').attrs['non_index_axes'], dann daraus diejenigen bestimmen, die fuer das Merging relevant
#    # sind, sie mit den in listColumns angeforderten Spalten kombineren und dann erst die Daten auslesen (und 
#    # dabei in "select(...)" entsprechend nur die benoetigten columns abfragen. Waere vielleicht hinsichtlich des
#    # Auslesens aus hdfstore eleganter und evtl. schneller, hier aber aus Gruenden der einfacheren Implementierung
#    # erstmal nicht umgesetzt
#
#    ## first read in all nodes (if they exist)    
#    lData = []
#    lColumns = []
#    i=0
#    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#        while bOk:     
#            
#            sNode, sFilter, listColumns = listNodes[i]
#            i += 1
#                
#            if sNode in f:                
#                dfTmp = f.select(sNode)
#                lData.append(dfTmp)
#                
#                ## if  no desired columns are given, take all in the dataframe
#                if len(listColumns==0):
#                    lColumns.append(dfTmp.columns)
#                else:
#                    lColumns.append(listColumns)
#                                        
#            else:
#                bOk = False
#        
#                
#    ## combine the found nodes
#    del dfTmp
#    if bOk and (len(lData)>0):         
#        dfRes = lData[0]
#        i=1
#        while bOk:
#            dfTmp = lData[i]
#            listColumns = lColumns[i]
#            i += 1
#            if dfTmp.shape[0]>0:               
#                sKeyCols = list(set(dfRes.columns).intersection(set(listColumns)))
#                dfRes = pd.merge(dfRes, dfTmp, how=sHow, on=sKeyCols)
#            else:
#                dfRes = pd.DataFrame()                                          
#                
#            bOk = (dfRes.shape[0]>0) & (i < len(lData))
#            
#        if (dfRes.shape[0]>0):
#            dfRes = dfRes.loc[:, list(set(itertools.chain(*lColumns)))]            
#                
#    else:
#        dfRes = pd.DataFrame()                     
#
#
#    return dfRes
#    
#    
#












# function to update all data in the given list with all features in the given list
#
# Christian Kuehnert, 2018-11-13
#
def update_all_data(sDBs, sPathData, listFeatures):
                       
    for sDB in sDBs:                         
        print('update data for turbine: ' + sDB)            
        update_cdef_ts_features(sDB, sPathData, listFeatures, listTimeIntervals=[-np.Infinity, np.Infinity], bSloppy = False)
        
            

    
# function to update all data in the given list with all features in the given list
#
# Christian Kuehnert, 2019-1-21
#  
def update_all_labels(sDBs, sPathData, sPathLabels):

    for sDB in sDBs:                         
        print('update labels for turbine: ' + sDB)            
#        update_labels(sDB, sPathData, sPathLabels)
    
    
    
    
    

# function to filter the data by the given conditions
#
# input:
#       - dfData:                 pandas.DataFrame to be filtered
#       - listFilterConditions:   list with filter conditions as strings, the columns
#                                 and types must correspond with the columns
#                                 and types in dfData
#                                 the condition must start with the column name, followed by
#                                 the criterion
#                                 if there are more than 1 conditions they will be 
#                                 combined using 'and'
#                                 only elementary conditions (like 'a<5' or 'v isin [1,2,3]') 
#                                 are allowed, combinations will terminate the function
#                                 or return incorrect results
#
# output:
#       - dfRes:                  pandas.DataFrame with data that meet the conditions
#
# Christian Kuehnert, 2018-11-22
#
# exampls: listFilterConditons = ['v_wind<10', 'v_wind>=2', 'channel isin [0,1,2]']
def filter_data(dfData, listFilterConditions):

    if (len(listFilterConditions)>0):
        dfRes = pd.DataFrame() 
        if dfData.shape[0]>0:
            bFilterOS = np.full((dfData.shape[0]), True)                                                     # boolean index of true, OS - 'operational state'
            if listFilterConditions:   
                for sFilter in listFilterConditions:        
                    bTmp = eval('dfData.' + sFilter.strip())
                    bFilterOS = bFilterOS & bTmp
                
                dfRes = dfData[bFilterOS]
                    
        return(dfRes)
        
    else:
        return(dfData)

    
                            


# function to retrieve turbine information
#
# input:
#
# output:
#
# Christian Kuehnert, 2018-11-16
#           
def get_turbine_info(sDB, sPathData):                        
    
    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
    sNode_info = 'turbine_info'
    sCols = ['farm', 'turbine', 'turbine_database']
    
    dfInfo = pd.DataFrame(columns = sCols)    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
        if sNode_info in f:
            dfInfo = f.select(sNode_info, columns=sCols)
            
    return(dfInfo)    






                    
#
# function to prepare Properties for later evaluation
#
# Christian Kuehnert, 2018-9-28
#
def prepareProperties(dfCDEF, sPropCols, dPropBinWidth):
    
    dfProperties = dfCDEF.loc[:, sPropCols]
    lBinEdges = []
    
    for iProp in range(len(sPropCols)):
        
        sProp = sPropCols[iProp]
        dStep = dPropBinWidth[iProp]
        
        dTmp = dfCDEF.loc[:, sProp]
        
        dMin = math.floor(min(dTmp) / dStep) * dStep
        dMax = (1+math.ceil(max(dTmp) / dStep)) * dStep
        
        lBinEdges.append(np.arange(dMin, dMax, dStep))

    
    return(dfProperties, lBinEdges)






#
# function that does several runs with different split of data into trainings and test data and learns parameters for acf method and calculates several 
# statistics over it and produces various figures etc.
#
# input:
#       - sss:          stratified shuffle split containing the splits for the several runs
#       - dfACF_d1:     data frame containing the acf's of d1-time series
#                       the headers must be of format 'acf_'+ lag-Value, e.g. 'acf_1'
#       - dfLabel:      labels for the data
#       - iSetMaxLags:  set with max lags to be used, all lags <= max lag will be included, TODO 20180927: spaeter umstellen auf iLags:        lags to be included
#       - sKernel:      kernel to be used
#       - dC:           value of dC for optimization
#       - dGamma:       value of gamma for optimization
#
# output:
#
#
# Christian Kuehnert, 2018-11-23
def learn_method_acf(sss, dfACF_d1, dfLabel, dfProperties, sKernel, dC, dGamma):

    warnings.filterwarnings("ignore")
            
    dEps = 1e-6       # accuracy for comparing numerical values
           
    #dACFs = np.array(iSetMaxLags)
                                                                                      
    iNumberOfRuns = sss.get_n_splits()    
               
    ## lists of results
    lPrec = []
    lRec = []
    lF1 = []
    #lModel = []
    lPropFail = []              # list containing the properties of the wrongly classified data


    model = SVC(kernel=sKernel, C=dC, gamma=dGamma)
   
    lModel = []
    
    ## lists of results for the several runs
    lPrec = []
    lRec = []
    lF1 = []    
    lPropFail = []                          
    lModel = []
                         
    ## loop trough the different runs
    iRun = 0     
    for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
         
        if ((iRun+1) % 10 == 0):                   
            print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                
        dACF_d1_train, dACF_d1_test = dfACF_d1.values[train_idx,:], dfACF_d1.values[test_idx, :]                                                                                                                                          
        dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                            
        #sSVMPars = sKernel + ', C=' + str(dC) + ', gamma=' + str(dGamma)            
        model.fit(dACF_d1_train, np.ravel(dLabel_train))
        iPred = model.predict(dACF_d1_test)
        iPred = np.reshape(iPred, (len(iPred), 1))

        bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data                
        dfProperties_fail = dfProperties.iloc[test_idx[bFailClass],:]                                        

        dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)            
                                                       
        lPrec.append(dAccu[0])
        lRec.append(dAccu[1])
        lF1.append(dAccu[2])
        lModel.append(model) 
        lPropFail.append([len(bFailClass), sum(bFailClass), dfProperties_fail])           
                                   
        iRun = iRun + 1
                               
    dPrec = np.hstack(lPrec)
    dRec = np.hstack(lRec)
    dF1 = np.hstack(lF1)

    return(dPrec, dRec, dF1, lPropFail, lModel)





#
# function that does several runs with different split of data into trainings and test data and learns parameters for acf method and calculates several 
# statistics over it and produces various figures etc.
#
# input:
#       - sss:          stratified shuffle split containing the splits for the several runs
#       - dfACF_d1:     data frame containing the acf's of d1-time series
#                       the headers must be of format 'acf_'+ lag-Value, e.g. 'acf_1'
#       - dfLabel:      labels for the data
#       - iSetMaxLags:  set with max lags to be used, all lags <= max lag will be included, TODO 20180927: spaeter umstellen auf iLags:        lags to be included
#       - sKernel:      kernel to be used
#       - dC:           value of dC for optimization
#       - dGamma:       value of gamma for optimization
#
# output:
#
#
# Christian Kuehnert, 2018-10-2
def learn_method_acf_old(sss, dfACF_d1, dfLabel, dfProperties, iSetMaxLags, sKernel, dC, dGamma):

    warnings.filterwarnings("ignore")
            
    dEps = 1e-6       # accuracy for comparing numerical values
           
    dACFs = np.array(iSetMaxLags)
                                                                                      
    iNumberOfRuns = sss.get_n_splits()    
               
    ## lists of results
    lPrec = []
    lRec = []
    lF1 = []
    #lModel = []
    lPropFail = []              # list containing the properties of the wrongly classified data


    model = SVC(kernel=sKernel, C=dC, gamma=dGamma)
    lModel = []
    for dLag in iSetMaxLags:                                        # beachten: (da ACF die lag=0-Werte nicht enthaelt!, d.h. Spalte 1 mit python-Index 0 entspricht lag=1                                                                
                                    
        iLag = int(dLag)
        #X = dfACF_d1.iloc[:,0:iLag].values      
    
        #sHeaders = dfACF_d1.columns[0:iLag]
        sMethod = 'acf_d1 with max(lag)=' + str(iLag)                                                        
        print(sMethod)
                  
        ## lists of results for each max lag
        lPrec_mlag = []
        lRec_mlag = []
        lF1_mlag = []    
        lPropFail_mlag = []                          
        lModel_mlag = []
                         
        ## loop trough the different runs
        iRun = 0     
        for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
                            
            print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                
            dACF_d1_train, dACF_d1_test = dfACF_d1.values[train_idx,0:iLag], dfACF_d1.values[test_idx, 0:iLag]                                                                                                                                          
            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                            
            #sSVMPars = sKernel + ', C=' + str(dC) + ', gamma=' + str(dGamma)            
            model.fit(dACF_d1_train, np.ravel(dLabel_train))
            iPred = model.predict(dACF_d1_test)
            iPred = np.reshape(iPred, (len(iPred), 1))

            bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data                
            dfProperties_fail = dfProperties.iloc[test_idx[bFailClass],:]                                        
            
            dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)            
                                                       
            lPrec_mlag.append(dAccu[0])
            lRec_mlag.append(dAccu[1])
            lF1_mlag.append(dAccu[2])
            lModel_mlag.append(model) 
            lPropFail_mlag.append([len(bFailClass), sum(bFailClass), dfProperties_fail])           
                                   
            iRun = iRun + 1
                               
        lPrec.append(np.hstack(lPrec_mlag))
        lRec.append(np.hstack(lRec_mlag))
        lF1.append(np.hstack(lF1_mlag))
        lPropFail.append([iLag, lPropFail_mlag])
        lModel.append(lModel_mlag)
        
    dPrec = np.vstack(lPrec)
    dRec = np.vstack(lRec)
    dF1 = np.vstack(lF1)    

    return(dACFs, dPrec, dRec, dF1, lPropFail, lModel)


# 2018-11-13: Class anlegen mit den Trainingsdaten und dann nur die Methoden aufrufen (Daten einlesen, Labels hinzufuegen, lernen, darstellen)
            
# methods:
# learnData.import(listDBs)
# learnData.update_labels()
# learnData.filter(listFilterCrit)
# learnData.ml(model, parameters)
# learnData.prognose(...)
# learnData.visualize(...)