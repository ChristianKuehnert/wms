# -*- coding: utf-8 -*-
"""

function that calculates the spectrum like the messprogram does, at present
with fixed decomposition parameters (5 pieces)

parameters:
-----------

- data:             time series to be transformed
- sampling_rate:    sampling rate
- n_parts:          integer, number of parts the ts is decomposed into (not counted the overlapping parts between two adjacent parts,
                    i.e. the total number of sub-ts the fft is carried out on is 2*n_parts - 1

Created on Thu Mar 28 15:25:50 2019

@author: Christian Kuehnert
@modified: 2019-4-2

"""
import numpy as np
import pandas as pd

def fft_messprogram(data, sampling_rate=1000, n_parts = 3):

    iL = int(len(data)/ n_parts)
    
    # hier Zerlegung in die Anteile, falls mehr als 1
    if n_parts==1:
        spec = pd.Series(np.abs(np.fft.rfft(data)*2/iL))
        freq = np.fft.rfftfreq(iL)*sampling_rate                                       # frequencies
    
    else:        
            
        lspec = []
        iShift = int(iL/2)
        for n in range(2*n_parts-1):
            idx = range(n*iShift, n*iShift + iL)
            data_part = data[idx]
            lspec.append(pd.Series(np.abs(np.fft.rfft(data_part))*2/iL))
                            
        spec = pd.concat(lspec, axis=1).mean(axis=1)
        freq = np.fft.rfftfreq(iL)*sampling_rate                                       # frequencies


    return(freq, spec)

