# -*- coding: utf-8 -*-
"""
function that updates the node sNode in hdfstore HDFStore with the data 
dfData_sql that are (regarding the keys sHeadersKey) not already in this 
node-table


@author Christian Kuehnert
2019-6-2

Input:
------
    f:          hdfstore, must be opened with mode 'a' and complevel '9' and 
                complib 'blosc:lz4'
    sNode:      node in f
    dfData_sql: pandas.DataFrame containing the data
    

Output:
-------
    None

"""
import pandas as pd

from data import setdifference_df



def update_hd5Table(f, sNode, dfData_sql, sHeadersKey):
        ## if there are any data then append them to cdef data already in hd5 file

    if sNode in f:
        
        dfData = f[sNode]
        
        if isinstance(dfData, pd.DataFrame):
                                
            # add new cdef-data to current cdef-data  
            # TODO 2018-10-17: evtl. schneller machen - nicht erst alles auslesen sondern gleich nur die, die fuer die Auswahl
            # der neu hinzukommenden gebraucht werden                    
            #dfData = dfData.set_index(sHeadersKey, drop=False)                    
            #dfData_sql = dfData_sql.set_index(sHeadersKey, drop=False)
            #dfAdd = dfData_sql.loc[dfData_sql.index.difference(dfData.index)]                    
            dfAdd = setdifference_df(dfData_sql, dfData, sHeadersKey)
 
            if dfAdd.shape[0]>0:
                # der Zweig unter bNew funtioniert nicht richtig, deshalb der etwas (beim Ausfuehren) aufwaendigere
                # andere Zweig aktiviert
                bNew = True
                if bNew:                        
                    # TODO 2018-10-17: ggf. noch sortieren
                    f.append(sNode, dfAdd.reset_index(drop=True), index=False)
                else:
                    if dfAdd.shape[0] > 0:
                        dfComb = pd.concat((dfData, dfAdd), axis=0, ignore_index=True, sort=False)
                        # TODO 2018-11-2: noch eleganter machen, ist eigentlich unnoetig wenn dfAdd=0 ist, ggf. reicht auch reset innerhalb der .hd5-Datei                            
                        f.remove(sNode)
                        f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
                        #f.put(sNode, dfComb, format='table', append=True, data_columns=True)    
                    #else:
                    #    dfComb = dfData

        else:
#            dfAdd = dfData_sql.reset_index(drop=True)
            f.remove(sNode)
#            f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
            f.put(sNode, dfData_sql.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)
                        
    else:
#        dfAdd = dfData_sql.reset_index(drop=True)
#        f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
        f.put(sNode, dfData_sql.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)

