# -*- coding: utf-8 -*-
"""
Created on Thu Nov  1 15:22:31 2018

    obsolete functions, but perhaps useful on some occations

@author: w012028
"""


import sys
import scipy.io
import gc
import math
import pandas as pd
import numpy as np
import os
import os.path
import fnmatch
import matplotlib.pyplot as plt  
#import seaborn as sb
import datetime as dt
import warnings

#import h5py

from os import listdir
from scipy import stats
from statsmodels.tsa.stattools import acf  #, pacf
from textwrap import wrap

from sklearn.linear_model import LinearRegression
from sklearn.metrics import precision_recall_fscore_support
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.model_selection import GridSearchCV
from sklearn.decomposition import PCA

from matplotlib.dates import date2num
    



#
# function that reads in the data from a .mat-time-series-file and from the related header-.csv-file
# optional result is stored in a to a hd5-files
# if the output file already exists a warning is thrown but the data are taken from the mat-file anyway, 
# but no saving to the already existing file (when option bSaveResult==true) will be done
#
# input:
#       - sDB:                  database name
#       - sFN_data_mat:         full name of file containing the data    (.mat)
#       - sFN_headersData_cv:   full name of file containing the headers (.csv)
#       - sSep:                 csv-separator in the header files
#       - bSaveResult:          if true the resulting dataFrame will be saved in the file with name like sFN_data_mat
#                               but with different type ending (.hd5 instead of .mat)                        
#       
#       the headers in the header files must be consistent with the columns of the data in the .mat-files,
#
# output:
#       dfData:                 read-in data as pandas.DataFrame with columns
#       if bSaveResult==True and this file not exists before then also a file containing the data (.hd5)
#
#
#
# Christian Kuehnert, 2018-9-10
def loadMatData_old(sDB, sFN_data_mat, sFN_header_csv, sSep = ';', bSaveResult = False):
        
    if (sDB in sFN_data_mat) and (sDB in sFN_header_csv):
        
        try:
                    
            tmp = scipy.io.loadmat(sFN_data_mat)                
            structData = tmp['structTS']
            del tmp              
            dfData = pd.DataFrame(structData[0,0][1])            
            del structData
                                    
            #TODO 2018-8-23: hier noch pruefen, ob auch vorhanden!
            tmp = pd.read_csv(sFN_header_csv, sep=sSep)
            sHeadersData = list(tmp.sHeadersData)
            dfData.columns = sHeadersData
            
            #iColChannel = len(sHeadersCDEF)                                                      
            #iMeasTime = dfData.shape[1] - 1- iColChannel        
            #sHeadersTS = [str(i) for i in range(iMeasTime)]
            
            #dfData.columns = sHeadersCDEF + ['channel'] + sHeadersTS 
                            
            if bSaveResult:                    
                sFN_hd5 = sFN_data_mat[:-4] + '.hd5'
                if os.path.isfile(sFN_hd5):
                    print('file ' + sFN_hd5 + ' already exists - I will not overwrite it. Data are taken from .mat-file nevertheless')
                else:                
                    writeHD5(dfData, 'data', sFN_hd5)                                       # store data in file
                    writeHD5(pd.DataFrame([sDB], columns = ['db']), 'db', sFN_hd5)           # store database name in DataFrame in file
                                   
        except Exception as ex:
            # do nothing
            print('error occurred')
            dfData = pd.DataFrame()
                        
        gc.collect()
        
    else:
                        
        print('database name in ' + sFN_data_mat + ' differs from ' + sDB + ' -> I will not write .hd5-file, please fix this before')
        dfData = pd.DataFrame()        
    
    return dfData
 



#
# function that reads in the data from a .mat-time-series-file and from the related header-.csv-file
# optional result is stored in a to a hd5-files
# if the output file already exists a warning is thrown but the data are taken from the mat-file anyway, 
# but no saving to the already existing file (when option bSaveResult==true) will be done
#
# input:
#       - sDB:              database name
#       - sFN_data_mat:     full name of file containing the data    (.mat)
#       - sFN_headers_cv:   full name of file containing the headers (.csv)
#       - sSep:             csv-separator in the header files
#       - bSaveResult:      if true the resulting dataFrame will be saved in the file with name like sFN_data_mat
#                           but with different type ending (.hd5 instead of .mat)                        
#       
#       the headers in the header files must be consistent with the first columns of the data in the .mat-files,
#       the last column of this consistent part must be the column BEFORE the channel-column, after this the 
#       channel and then the time series data must follow (for them both the headers will be set automatically
#       within this function)
#
# output:
#       dfData:              read-in data as pandas.DataFrame with columns
#       if bSaveResult==True and this file not exists before then also a file containing the data (.hd5)
#
#
#
# Christian Kuehnert, 2018-8-23
def loadMatData_old(sDB, sFN_data_mat, sFN_header_csv, sSep = ';', bSaveResult = False):
        
    if (sDB in sFN_data_mat) and (sDB in sFN_header_csv):
        
        try:
                    
            tmp = scipy.io.loadmat(sFN_data_mat)                
            structData = tmp['structTS']
            del tmp              
            dfData = pd.DataFrame(structData[0,0][1])            
            del structData
                                    
            #TODO 2018-8-23: hier noch pruefen, ob auch vorhanden!
            tmp = pd.read_csv(sFN_header_csv, sep=sSep)
            sHeadersCDEF = list(tmp.sHeadersCDEF)
            
            iColChannel = len(sHeadersCDEF)                                                      
            iMeasTime = dfData.shape[1] - 1- iColChannel        
            sHeadersTS = [str(i) for i in range(iMeasTime)]
            
            dfData.columns = sHeadersCDEF + ['channel'] + sHeadersTS 
                            
            if bSaveResult:                    
                sFN_hd5 = sFN_data_mat[:-4] + '.hd5'
                if os.path.isfile(sFN_hd5):
                    print('file ' + sFN_hd5 + ' already exists - I will not overwrite it. Data are taken from .mat-file nevertheless')
                else:                
                    writeHD5(dfData, 'data', sFN_hd5)                                       # store data in file
                    writeHD5(pd.DataFrame([sDB], columns = ['db']), 'db', sFN_hd5)           # store database name in DataFrame in file
                                   
        except Exception as ex:
            # do nothing
            print('error occurred')
            dfData = pd.DataFrame()
                        
        gc.collect()
        
    else:
                        
        print('database name in ' + sFN_data_mat + ' differs from ' + sDB + ' -> I will not write .hd5-file, please fix this before')
        dfData = pd.DataFrame()
        
    
    return dfData
 







#
# function to create .csv-files for labelling the data
# 
# input:
#       - dfData:   dataframe containing the data to be labelled, must contain columns 'create_time', 'ID' and 'channel'
#       - sFN:      full name of the label file to be stored with
#       - sFormatDataTime:   datetime-format-string which should be used for creating the string-create_time-column
#       - sSep:             csv-separator in the header files
#       - bSort:    if true the data will be sorted by 1) create_time, 2) ID, 3) channel
#
# output:
#       csv-files containing create_time (one column as numeric value, one as string), 
#
#
# Christian Kuehnert, 2018-8-23
#
def createLabelFile(dfData, sFN, sFormatDateTime = '%Y-%m-%d %H:%M:%S', sSep = ';', bSort = True):
                
    dTimePy = [matlab2datetime(t) for t in dfData.create_time]            
    sTimeString = [dpy.strftime(sFormatDateTime) for dpy in dTimePy]
    
    dfLab = pd.DataFrame(np.column_stack((dfData.db, dfData.create_time, sTimeString, dfData.ID, dfData.channel)), columns=['db', 'create_time', 'str_create_time', 'ID', 'channel'])            
    
    if bSort:
        dfLab.sort_values(by=['create_time', 'ID', 'channel']) 
    
    dfLab.to_csv(sFN, sep=sSep, index=False)




#		
# function to create .csv-file for labelling manually
# Note: existing label file will be overwritten
#       --> therefore one possibility to use this function:
#           1) check if label file already exists
#           2) synchronize data with that file
#           3) create now label file from these synchronized data
#
# 2018-8-13
#
def createLabelFile_old(sFN_hd5):	

    sFN_csv = sFN_hd5.replace('.hd5', '_tabLabels_unfilled.csv')			# Ending von sFN_hd5 entfernen, _label.csv anhaengen
    dfData = readHD5(sFN_hd5, 'data')                      # - hd5-daten einlesen
	
    dTimePy = [matlab2datetime(t) for t in dfData.create_time]
    str_create_time = [dpy.strftime('%Y-%m-%d %H:%M:%S') for dpy in dTimePy]

    
    # - dfLab = aus entsprechenden Spalten zusammenbauen (auch schon vorhandene labels verwenden! wenn keine vorhanden sind, dann neue anlegen und ueberall -1 einsetzen, diese dann auch im .hd5 hinzufuegen)	
    dfLab = np.column_stack((dfData.db, dfData.ID, dfData.create_time, str_create_time, dfData.channel, dfData.label, dfData.fail_type))    
            
    dfLab.to_csv(sFN_csv, sep=';')                          #dfLab als .csv speichern  




  
    
#
# function that reads in the data from a .mat-time-series-file and from the related header-.csv-file
# optional result is stored in a to a hd5-files
# if the output file already exists a warning is thrown but the data are taken from the mat-file anyway, 
# but no saving to the already existing file (when option bSaveResult==true) will be done
#
# input:
#       - sDB:                  database name
#       - sFN_data_mat:         full name of file containing the data    (.mat)
#       - sFN_headersData_cv:   full name of file containing the headers (.csv)
#       - sSep:                 csv-separator in the header files
#       - bSaveResult:          if true the resulting dataFrame will be saved in the file with name like sFN_data_mat
#                               but with different type ending (.hd5 instead of .mat)                        
#       
#       the headers in the header files must be consistent with the columns of the data in the .mat-files,
#
# output:
#       dfData:                 read-in data as pandas.DataFrame with columns
#       if bSaveResult==True and this file not exists before then also a file containing the data (.hd5)
#
#
#
# Christian Kuehnert, 2018-10-11
def loadMatData(sDB, sPathData, sSep = ';', bSaveResult = False):
        
#    if (sDB in sFN_data_mat) and (sDB in sFN_header_csv):     
    
    try:
                    
        tmp = scipy.io.loadmat(sFN_data_mat)                
        structData = tmp['structTS']
        del tmp              
        dfData = pd.DataFrame(structData[0,0][1])            
        del structData
                                    
        #TODO 2018-8-23: hier noch pruefen, ob auch vorhanden!
        tmp = pd.read_csv(sFN_header_csv, sep=sSep)
        sHeadersData = list(tmp.sHeadersData)
        dfData.columns = sHeadersData
            
        #iColChannel = len(sHeadersCDEF)                                                      
        #iMeasTime = dfData.shape[1] - 1- iColChannel        
        #sHeadersTS = [str(i) for i in range(iMeasTime)]
            
        #dfData.columns = sHeadersCDEF + ['channel'] + sHeadersTS 
                            
        if bSaveResult:                    
            sFN_hd5 = sFN_data_mat[:-4] + '.hd5'
            if os.path.isfile(sFN_hd5):
                print('file ' + sFN_hd5 + ' already exists - I will not overwrite it. Data are taken from .mat-file nevertheless')
            else:                
                writeHD5(dfData, 'data', sFN_hd5)                                       # store data in file
                writeHD5(pd.DataFrame([sDB], columns = ['db']), 'db', sFN_hd5)           # store database name in DataFrame in file
                                   
    except Exception as ex:
        # do nothing
        print('error occurred')
        dfData = pd.DataFrame()
                        
    gc.collect()
        
#    else:                        
#        print('database name in ' + sFN_data_mat + ' differs from ' + sDB + ' -> I will not write .hd5-file, please fix this before')
#        dfData = pd.DataFrame()        
    
    return dfData
 




#
# function that combines the .mat-time-series-files to hd5-files
# needs also the files containing the headers (as long as it is not possible to
# read them in from the .mat-files directly)
#
# if the output file already exists, a warning is thrown but nothing else is done
#
# input:
#       - sPathData:  path containing the data files
#       - sDB:        database name
#       - sSep:       csv-separator in the header files
#       
#       the headers in the header files must be consistent with the first columns of the data in the .mat-files,
#       the last column of this consistent part must be the column BEFORE the channel-column, after this the 
#       channel and then the time series data must follow (for them both the headers will be set automatically
#       within this function)
#
# output:
#       file containing the combination of the data in the .mat files
#       file for labels (.csv format)
#
#
# Christian Kuehnert, 2018-8-23
def combineMatMultipleFilesToHD5(sPathData, sDB, sSep):

    sFN_out = sPathData + '\\' + sDB + '_ts.hd5'
    
    sFiles = listdir(sPathData)
        
    sTmp = fnmatch.filter(sFiles, sFN_out)    
    
    try:

        if sTmp:    
            print('file ' + sFN_out + ' already exists, create label file only')
            dfData = readHD5(sFN_out, 'data')
                    
        else:
            sPattern = sDB + '*_ts*.mat'
            sFiles = fnmatch.filter(sFiles, sPattern)
        
            lData = []
            
            for sFN0 in sFiles:
        
                sFN = sPathData + '\\' + sFN0
                sFN_csv = sFN[:-4] + '_headers.csv'

                print(sFN)
                             
                dfData = loadMatData_old(sFN, sFN_csv, sSep, False)
                                
                #tmp = scipy.io.loadmat(sFN)                
                #structData = tmp['structTS']
                #del tmp              
                #dfData = pd.DataFrame(structData[0,0][1])            
                #del structData
                #                
                ##TODO 2018-8-23: hier noch pruefen, ob auch vorhanden!
                #tmp = pd.read_csv(sFN_csv, sep=sSep)
                #sHeadersCDEF = list(tmp.sHeadersCDEF)
                #
                #iColChannel = len(sHeadersCDEF)                                                      
                #iMeasTime = dfData.shape[1] - 1- iColChannel        
                #sHeadersTS = [str(i) for i in range(iMeasTime)]
        
                #dfData.columns = sHeadersCDEF + ['channel'] + sHeadersTS 
                 
                # filter for standing mode (not yet by pitch, this can be done later)
                #bIdx = (dfData.iloc[:,iColPowerMean] < 0) & (dfData.iloc[:, iColOmegaMean] < 0.05) & (dfData.iloc[:, iColPitchMean] > 35)
                #bIdx = (dfData.iloc[:,iColPowerMean] < 0) & (dfData.iloc[:, iColOmegaMean] < 0.05)
                #bIdx = (dfData.power_mean < 0) & (dfData.omega_mean < 0.05)                
                #lData.append(dfData[bIdx])
                
                lData.append(dfData)
                
                del dfData                
                gc.collect()
                                        
                    
            if (len(lData)>1):
                dfData = pd.concat(lData, axis=0)
            else:
                dfData = lData[0]                
            

            dfData.sort_values(by=['create_time', 'ID', 'channel'])         # sort by 1) create_time, 2) ID, 3) channel   
            dfDB = pd.DataFrame([sDB], columns = ['db'])
            
            writeHD5(dfData, 'data', sFN_out)            
            writeHD5(dfDB, 'db', sFN_out)
            
        # create file for labelling
        if dfData:
            sFN = sPathData + '\\' + sDB + '_tabLabels_unfilled.csv'                
            createLabelFile(pd.concat([dfDB, dfData], axis=1), sFN, sSep = sSep)
                            
            del(dfData)
                            
    except Exception as ex:
        # do nothing
        print('error occurred')
                            
    gc.collect()
 



    
##
## function to calculate the estimators for the quality of the model (precision, 
## recall etc.)
## iPred and iLabel must have the same size
##
## Christian Kuehnert, 2018-9-11
##
##  obsolete, there are better built-in-functions in scikit etc.
##    
#def predictionQuality(iPred, iLabel):
#	
#    iN = len(iPred)
#		
#    b00, b01, b10, b11, iN = comparePrediction(iPred, iLabel)
#                    
#    i00 = sum(b00);
#    i01 = sum(b01);
#    i10 = sum(b10);
#    i11 = sum(b11);
#                                                           
#    dPrecision = i11/(i10+i11);
#    dRecall = i11/(i01+i11);
#    dTotalOK = (i00+i11)/(i00+i01+i10+i11);
#    dF1score = 2*(dPrecision*dRecall)/(dPrecision+dRecall);
#
#    return({'i00': i00, 'i01': i01, 'i10': i10, 'i11': i11, 
#            'dPrecision': dPrecision, 'dRecall': dRecall, 'dTotalOK': dTotalOK, 'dF1score': dF1score})

    
    
    
# 
# function to update the label .csv-file
#
# input:
#		- sFN_lab:       name of existing label-.csv-file
#		- sFN_new:       name of .csv-file containing new label entries
#      - sSep:          .csv-separator
#      - iRepl:         if the labels in sFN_lab have that value, they are allowed to be replaced (e.g. nan or -1)
#   
# output:
#      new labels will be added to sFN_lab, but labels already there will not be overwritten
#
# 2018-8-24
#
#
def updateLabelFile(sFN_lab, sFN_new, sSep=';', iRepl = np.nan):
        
    dfLab = pd.read_csv(sFN_lab, sSep)                         # read in .csv
    dfNew = pd.read_csv(sFN_new, sSep)

    # find all positions in dfLab that are contained in dfLabNew
    dfRepl = dfNew[dfNew['label'] == iRepl].set_index('No.')
    dfLab = dfRepl.combine_first(dfLab.set_index('No.')).reset_index().reindex(columns=dfLab.columns)    
    #df22 = df2[df2['Type'] == 'MN'].set_index('No.')
    #df1 = df22.combine_first(df1.set_index('No.')).reset_index().reindex(columns=df1.columns)
    
    print('noch nicht fertig implementiert!!!')
    #dfLab.to_csv(sFN_lab, sep=sSep)                 # save new DataFrame
	



# 
# function to import manually labelled data, stored in .csv-files, and store them
# into the dfTS-hd5-file
#
# input:
#		- sFN_hd5: name of hd5-file containing the dfTS
#		- bOverwriteExisting: if true, all labels contained in .csv-file will be stored
#							     in the dfTS-dataFrame, already existing ones will be overwritten, 
#							     if false then only new ones will be used
#
# 2018-8-13
#
#
def updateLabels(sFN_hd5, bOverwriteExisting):

    sFN_csv = sFN_hd5.replace('_standing_ts.hd5', '_tabLabels.csv')     # name of (potencial) label file
	        
    #dfLab = readHD5(sFN_hd5, 'label')                   # read in hd5

    if os.path.isfile(sFN_csv):
        
        dfLab_csv = pd.read_csv(sFN_csv, sep=';')                         # read in .csv
 		
        # TODO 2018-8-13: spaeter machen, erstmal nur .csv-files mit labels verwenden
        #dfLab = synchronizeLabels(dfLab, dfLab_csv, bOverwriteExisting)
        dfLab = dfLab_csv
        #saveHD5(dfData, sFN_hd5)
        #save dfTS to hd5-file
    
    return(dfLab)
	
	
    

    


# 
# function that splits the data (in that special dataFrame, where the first columns contain the CDEF-Data, followed by a column with
# the channel numbers and after that the time series) into single dataFrames with cdef data, channel numbers and ts data
#
# Christian Kuehnert, 2018-8-31
#
def splitData(dfData, sHeaderChannel):

    iColChannel = findIdx(dfData.columns == sHeaderChannel)[0]
            
    dfCDEF = dfData.iloc[:,0:iColChannel]
    dfChannel = pd.DataFrame(dfData.iloc[:,iColChannel], columns = [sHeaderChannel])
    dfTS = dfData.iloc[:,iColChannel+1:]
    
    return {'dfCDEF': dfCDEF, 'dfChannel': dfChannel, 'dfTS': dfTS}




#
# function to synchronize labels in given data with labels from .csv-file
#
# input:
#		- dfData: data frame with data
#      - dfData: 
#		- bOverwriteExisting: if true, all labels contained in .csv-file will be stored
#							  in the dfTS-dataFrame, already existing ones will be overwritten, 
#							  if false then only new ones will be used
#
# 2018-8-13
#
def updateLabels_2(dfLab, dfLab_new, bOverwriteExisting):
   
    if bOverwriteExisting:
            
        # find indices of existing (dfLab) rows that are not in dfLab_new    
        # first for time
        setTmp = set(dfLab.create_time)
        iNotInNew_time = [i for i, e in enumerate(dfLab_new) if e not in setTmp]
                
        # second for cid
        setTmp = set(dfLab.ID)
        iNotInNew_ID = [i for i, e in enumerate(dfLab_new) if e not in setTmp]                        
    
        iNotInNew = union(iNotInNew_time, iNotInNew_ID)
            
        # take new and append not in new
        dfLab_synch = np.vstack(dfLab_new, dfLab[iNotInNew,:])        
                                        
    else:
            
        # take only those 
        s='...'

    # sort result by time, cid, channel
        
        
    return(dfLab_synch)
        
        



# 
# function to load labels for the labelled data, stored in .csv-files
#
# input:
#       - sPath: path containing the label-csv-files
#       - sDB: name of database
#
# 2018-8-15
#
#
#def loadLabels(sPath, sDB):
def loadLabels(sFN_csv):

    #sFN_csv = sDB + '_tabLabels.csv'     # name of (potencial) label file
	        
    #dfLab = readHD5(sFN_hd5, 'label')                   # read in hd5

    if os.path.isfile(sFN_csv):
        
        dfLab = pd.read_csv(sFN_csv, sep=';')                         # read in .csv
 		
    else:
        
        dfLab = []
        # TODO 2018-8-13: spaeter machen, erstmal nur .csv-files mit labels verwenden
        #dfLab = synchronizeLabels(dfLab, dfLab_csv, bOverwriteExisting)
        #dfLab = dfLab_csv
        #saveHD5(dfData, sFN_hd5)
        #save dfTS to hd5-file
    
    return(dfLab)
	

    



# aus class_sensor_classificator.py:
    """
    function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
    statistics over it and produces various figures etc.
    
    @author: Christian Kuehnert, 2019-1-4
    
    input:
        - sss:          stratified shuffle split containing the splits for the several runs
        #- dfFeat:       pd.DataFrame containing the features, THESE FEATURES MUST BE CONSISTENT WITH dQs, i.e. column i in dfFeat must correspond with element i of dQs
        - dfFeat:       pd.DataFrame containing the features, THIS DataFrame MUST HAVE THE dQs-values AS COLUMN NAMES (numeric, not as strings!)

    output:
        
        
    """
    def train_classifier_old(self, sss = None, dfFeat = None, dfLabel = None, dThresMin = None, dThresMax = None, iNStepsThres = 10, sFN = None):
                
        warnings.filterwarnings("ignore")     
        
        #dEps = 1e-6       # accuracy for comparing numerical values
        #dEps = np.max([np.finfo(type(dQs_cols[0])).eps, np.finfo(type(dSetQs[0])).eps])
    
        ## lists of results
        lB = []
        lF1 = []
    

        if not(dThresMin):                                  
            dThresMin = 0
            
        if not(dThresMax):
            dThresMax = max(dfFeat.values.max(), abs(dfFeat.values.min()))
            
        #dThres = [dThresMin + iIdx * (dThresMax-dThresMin) / iNStepsThres for iIdx in range(iNStepsThres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold            

        # TODO 2018-12-14: noch Konsistenz zwischen dfFeat und dQs pruefen!
        ## get quantiles from headers  
        #sQs = dfDQ_d1.columns
        #dQs_cols = [float(s.replace('diff_q', '')) for s in sQs]        
        #dQs = intersect(dQs_cols, dSetQs)        
        #dQs = [x for x in dQs_cols for y in dSetQs if np.isclose(x, y, atol=3*dEps)]
    
        # TODO 2018-9-28: folgende Mengenoperationen auch noch auf Toleranz umstellen
        #if len(dQs_cols)>len(dQs):
        #    dSetDiffQs = [x for x in dQs_cols if x not in dQs]
        #    print('q-values ' + ",".join([str(d) for d in dSetDiffQs]) + ' not requested')
        
        #if len(dSetQs)>len(dQs):
        #    dSetDiffQs = [x for x in dSetQs if x not in dQs]
        #    print('q-values ' + ",".join([str(d) for d in dSetDiffQs]) + ' not found in data columns')                
        dQs = dfFeat.columns
        
        # TODO 2019-1-4: EVTL.(!) hier noch Fall abfangen, dass die columns nicht die dQs enthalten
            
        #dQs.sort()
        iNumberOfRuns = sss.get_n_splits()    
                       
        # TODO 2018-12-14: die Optimierung ggf. noch verbessern - z.B. erst fuer {dQs} x {dBs} jeweils fuer alle Runs die Accuracy berechnen,
        # dann die Q-b-Kombination waehlen, fuer welche die meisten Runs optimal sind bzw. wo der Median aus den F1 ueber alle runs maximal ist
        # bzw. wo vielleicht auch (um eine gewisse Stetigkeit 'reinzubekommen) der Median von F1 ueber alle runs + Vorfaktor (z.B. 1/9) * Summe
        # der Mediane von F1 ueber alle Runs aus allen angrenzenden Q-b-Zellen maximal wird.
        # Jetzt erstmal so implementiert, um zu beginnen            
        
        ## loop through q's                                            
        #for iQ in range(len(dfFeat.shape[1])):
        for iQ in range(len(dQs)):
                                            
            dQ = dQs[iQ]
            print('q=' + str(dQ))
                                                                                              
            ## lists of results for each value of q
            lB_q = []                            
            lF1_q = []  
            
            ## loop trough the different runs
            iRun = 0
            for train_idx, test_idx in sss.split(dfFeat.values, dfLabel.label.values):
                                
                print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                                                                                                                              
                dX_train, dX_test = dfFeat.values[train_idx, iQ], dfFeat.values[test_idx, iQ]                                
                dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                                
                # define optimization fct.
                # find optimal b
                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(self.predict(dX_train.reshape(-1,1))-dLabel_train), ranges = ((dThresMin, dThresMax),), Ns=iNStepsThres, full_output=True, finish=None)
                                                        
                dB = resMin[0]
                                            
                lB_q.append(dB)
                                                
                ## calc. accuracy of the model                                                                
                iPred = self.predict_ext(dX_test, dB)                                                        
                
                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
                                                                            
                lF1_q.append(dAccu[2])
                                                                
                iRun = iRun + 1
                
            lB.append(np.hstack(lB_q))                                
            lF1.append(np.median(lF1_q))
                                
        idx = np.argmax(lF1)
        self.dB = np.median(lB[idx])
        self.dQ = np.median(dQs[idx])
                    
        print('opt. parameters: quantile = ' + str(self.dQ) + ', threshold = ' + str(self.dB) + ', F1score = ' + str(lF1[idx]))
        
        # save dateils to file if file name is given
#            if sFN:
#                dfRes = ...
#                dfRes.to_csv(...)
            
        return(self)




    
    
#
#  probably obsolete - keept only to be on safe side
#
# function that reads in the data from a .mat-time-series-file and from the related header-.csv-file
# optional result is stored in a to a hd5-files
# if the output file already exists a warning is thrown but the data are taken from the mat-file anyway, 
# but no saving to the already existing file (when option bSaveResult==true) will be done
#
# input:
#       - sDB:                  database name
#       - sFN_data_mat:         full name of file containing the data    (.mat)
#       - sFN_headersData_cv:   full name of file containing the headers (.csv)
#       - sSep:                 csv-separator in the header files
#       - bSaveResult:          if true the resulting dataFrame will be saved in the file with name like sFN_data_mat
#                               but with different type ending (.hd5 instead of .mat)                        
#       
#       the headers in the header files must be consistent with the columns of the data in the .mat-files,
#
# output:
#       dfData:                 read-in data as pandas.DataFrame with columns
#       if bSaveResult==True and this file not exists before then also a file containing the data (.hd5)
#
#
#
# Christian Kuehnert, 2018-10-11
def loadMatData(sDB, sPathData, sSep = ';', bSaveResult = False):
        
#    if (sDB in sFN_data_mat) and (sDB in sFN_header_csv):     
    
    try:
                    
        tmp = scipy.io.loadmat(sFN_data_mat)                
        structData = tmp['structTS']
        del tmp              
        dfData = pd.DataFrame(structData[0,0][1])            
        del structData
                                    
        #TODO 2018-8-23: hier noch pruefen, ob auch vorhanden!
        tmp = pd.read_csv(sFN_header_csv, sep=sSep)
        sHeadersData = list(tmp.sHeadersData)
        dfData.columns = sHeadersData
            
        #iColChannel = len(sHeadersCDEF)                                                      
        #iMeasTime = dfData.shape[1] - 1- iColChannel        
        #sHeadersTS = [str(i) for i in range(iMeasTime)]
            
        #dfData.columns = sHeadersCDEF + ['channel'] + sHeadersTS 
                            
        if bSaveResult:                    
            sFN_hd5 = sFN_data_mat[:-4] + '.hd5'
            if os.path.isfile(sFN_hd5):
                print('file ' + sFN_hd5 + ' already exists - I will not overwrite it. Data are taken from .mat-file nevertheless')
            else:                
                writeHD5(dfData, 'data', sFN_hd5)                                       # store data in file
                writeHD5(pd.DataFrame([sDB], columns = ['db']), 'db', sFN_hd5)           # store database name in DataFrame in file
                                   
    except Exception as ex:
        # do nothing
        print('error occurred' + sys.exc_info()[0])
        dfData = pd.DataFrame()
                        
    gc.collect()
        
#    else:                        
#        print('database name in ' + sFN_data_mat + ' differs from ' + sDB + ' -> I will not write .hd5-file, please fix this before')
#        dfData = pd.DataFrame()        
    
    return(dfData)
 





	  
# function to extract the acf-feature from the hd5-file and to reshape the resulting
# dataframe to a dataframe containing the acf-values to all desired lags in horizontal-direction
# contrary to my usual notation the empty filter values (time_interval, setIDs, setChannels, setLags)
# mean that NO FILTER for these parameters is applied, i.e. ALL data are taken (normally I would consider 
# this as empty desired sets and take NO data)
#
# input:
#
# output:
# 
# Christian Kuehnert, 2018-11-7
# 
def extract_feature_acf_ideasForLaterVersion(sDB, sPathData, sNodeFeat, sHeadersKey, time_interval = [], setIDs = [], setChannels = [], iOrderDiff=1, setLags = []):
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if sNodeFeat in f:
            lWhere = []
            lWhere.append('order_diff=' + str(iOrderDiff))
            
            if len(time_interval)>0:
                lWhere.append([])
            
            dfTmp = f.select(sNodeFeat, where=('order_diff=' + str(iOrderDiff)))
            
            
        else:
            dfRes = []







"""
function to check if measuring line are ok by classical method
@author: Christian Kuehnert
@last_modified: 2019-2-26

"""
def check_meas_line_classical_old(db, channels, start_time, end_time, start_freq=150, end_freq=350, meas_len=16.384):
	
    issues = []
    sTool = 'SE'
    
    ## first map channel numbers (0..5) to channel names ('e_101_edge' etc.)
    # TODO 2019-1-18: generisch machen!, now only first approach
    #dictMap_class = mapChannels(self.sDB, self.sPathData)
    dictMap_class = {'e_101_edge': 3, 'e_102_edge': 4, 'e_103_edge': 5, 'e_101_flap': 0, 'e_102_flap': 1, 'e_103_flap': 2}
    #dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
		
    #get thresholds from preferences
    # TODO 2019-1-25: sind Sensitivities schon beruecksichtigt?
							
    try:            
        lFlap = ['e_101_flap', 'e_102_flap', 'e_103_flap']
        lEdge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
        lDirs = lFlap + lEdge

        ## thresholds for alarm levels for all channels
        dictTmp = get_preferences(db)
        dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel'): s for s in lDirs}
        dfSE_thres = pd.DataFrame.from_records([dictTmp])
        dfSE_thres = dfSE_thres.loc[:, dictPrefCols.keys()]
        dfSE_thres.rename(columns = dictPrefCols)
																
        ## get data
        listColumns = ['create_time', 'cycle_id', 'measure_number', 'start_f'] + lDirs 

        #sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
        dfSE = mfdata.get_data_fromDB_old(db, 'ba_cycle_sig_energies',
                                          dictTypes={'cycle_id': int},
                                          listCols=listColumns,
                                          time_start=start_time, time_end=end_time)
		
        #now distinguish between systems that collect full (2Hz-wise) spectra and those that contain only sum from 150-350 Hz                                
        iFreq = np.unique(dfSE.start_f)
        if len(iFreq)==1:                
		
            #if iFreq[0]==dStartFreq:
            #    print('alles ok, offenbar Eisdetektor, SE kann so bleiben')
			 #					
            #else:															
            if not(iFreq[0]==start_freq):
                issues.append(create_issue(db,
                                           sErrorMsg = 'SE-Daten zum relevanten Frequenzbereich fehlen', 
                                           sAction = 'manuell pruefen',
                                           sLink = create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time), end_time = end_time),
                                           sTool = sTool))
   
        else:                                    
            dfSE1 = dfSE[(dfSE.start_f>=start_freq) & (dfSE.start_f < end_freq)]
            dfSE = dfSE1.groupby(['create_time', 'cycle_id'], sort=False).pipe(lambda x: np.sum(x, axis=0))                    # sum over the relevant frequency range for each cycle
            dfSE.reset_index(inplace=True)
		
        dfSE.dropna(axis=0, how='any', subset=lDirs, inplace=True)
						
        ## now compare with the thresholds    
        lErr = []
        for lList in [lFlap, lEdge]:
							
            dTmp = dfSE.loc[:, lList].values
            dSE_mean = np.mean(dTmp, axis=1)
            relSE = dTmp /  np.tile(dSE_mean.reshape((len(dSE_mean),1)), (1,3))                    
            # TODO 2019-1-17: hier individuelle Werte fuer jeweilige WEA auslesen
            dSE_thres = dfSE_thres.loc[:, lList].values
            dThres = np.tile(dSE_thres, (dTmp.shape[0],1))
            dfTmp = pd.DataFrame((relSE > dThres), columns=lList)		
            lErr.append(dfTmp)
				
        #bErrors = np.concatenate(lErr, axis=1)                    
        dfErr = pd.concat(lErr, axis=1)
        bTmp = dfErr.any(axis=1)
        dfCyc_cl = pd.concat((dfSE[bTmp].loc[:,['create_time', 'cycle_id']], dfErr[bTmp].set_index(dfSE[bTmp].index)), axis=1)
									   
        dfCyc_cl.rename(columns = dictMap_class, inplace=True)
        #dfCyc_cl = pd.wide_to_long(dfCyc_cl, stubnames = ['ch'], i = 'channel')
        dfCyc_cl = pd.melt(dfCyc_cl, id_vars=['create_time', 'cycle_id'], value_vars = dictMap_class.values(), var_name = 'channel', value_name = 'fail')
        dfCyc_cl = dfCyc_cl[dfCyc_cl.fail]
        # reformat 
						
        #iCrit_class = find_args(any(bErrors, axis=0))             # get index of columns that contain error-values
					
        # find cycles (create_time, cycle_id) of the times of the errors
        dfCyc_cl = dfCyc_cl.assign(origin = pd.Series(np.tile('classic', (dfCyc_cl.shape[0],))).values)           # add column with origin (classical method or ts method)				

    except:
        dfCyc_cl = None
        issues.append(create_issue(db,
                                   sErrorMsg='unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode',
                                   sAction='manuell ansehen',
                                   sLink=create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time), end_time = end_time)))


    return([dfCyc_cl, issues])




"""
function to check if measuring lines are ok
first check "classical way", i.e. from relative signal energy, second check by time series analysis

@author: Christian Kuehnert
@last_modified: 2019-2-25

input:
------
        - db: database name (including 'cmrblba_')
		- tickets: dataframe with tickets for this turbine
		- checks:  booleans of checks
		- issues:  list of issues
		- start_time: start time of interesting period
		- end_time:   end time of interesting period
		- dict_method: dictionary, methods by which the broken measuring lines will be detected and the respective **kwargs
"""
def check_meas_line_old(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350, 'meas_len': 16.384}}):
    #def check_measLines(self, time_start=None, time_end=None, sMethod = 'classical', sensor_classificator=None):
#    def check_measLines(self, sMethod = 'classical', sensor_classificator=None):
    sDTFormatMsg = '%d.%m.%Y, %H:%M'
    tShift = 3/24
    #dStartFreq = 150
    #dEndFreq = 350
    #dMeas_len = 16.384
    sTool = 'SE'
    dict_res = {}
    
    for sMethod, kwargs in dict_methods.items():
	
        ## 1) classical method
        if (sMethod=='classical'):
				
            
            
            ## first map channel numbers (0..5) to channel names ('e_101_edge' etc.)
            # TODO 2019-1-18: generisch machen!, now only first approach
            #dictMap_class = mapChannels(self.sDB, self.sPathData)
            #dictMap_class = {3: 'e_101_edge', 4: 'e_102_edge', 5: 'e_103_edge', 0: 'e_101_flap', 1: 'e_102_flap', 2: 'e_103_flap'}
            dictMap_class = {'e_101_edge': 3, 'e_102_edge': 4, 'e_103_edge': 5, 'e_101_flap': 0, 'e_102_flap': 1, 'e_103_flap': 2}
            dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
		
            #get thresholds from preferences
            # TODO 2019-1-25: sind Sensitivities schon beruecksichtigt?
							
            try:            
                ## 1. classical way                                        
                lFlap = ['e_101_flap', 'e_102_flap', 'e_103_flap']
                lEdge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
                lDirs = lFlap + lEdge

                ## thresholds for alarm levels for all channels
                dictTmp = get_preferences(db)
                dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel'): s for s in lDirs}
                dfSE_thres = pd.DataFrame.from_records([dictTmp])
                dfSE_thres = dfSE_thres.loc[:, dictPrefCols.keys()]
                dfSE_thres.rename(columns = dictPrefCols)
																
                ## get data
                listColumns = ['create_time', 'cycle_id', 'measure_number', 'start_f'] + lDirs 

                bUpdate = False
                if bUpdate:                                                              # update hd5-file and get data from it
                    print('       update se')
                    update_se(db, start_time, end_time)                                   # update SE-table
                    listNodes = [[sNodes.sig_energy, []]]
                    dfSE = mfdata.get_data(db, sPathData, listNodes, listColumns)            # get data
						
                else:
                    #sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
                    dfSE = mfdata.get_data_fromDB_old(db, 'ba_cycle_sig_energies',
                                                      dictTypes={'cycle_id': int},
                                                      listCols=listColumns,
                                                      time_start=start_time, time_end=end_time)
		
                #now distinguish between systems that collect full (2Hz-wise) spectra and those that contain only sum from 150-350 Hz                                
                iFreq = np.unique(dfSE.start_f)
                if len(iFreq)==1:                
		
                    if iFreq[0]==dStartFreq:
                        print('alles ok, offenbar Eisdetektor, SE kann so bleiben')
								
                    else:															
                        issues.append(create_issue(db,
                                                   sErrorMsg = 'SE-Daten zum relevanten Frequenzbereich fehlen', 
                                                   sAction = 'manuell pruefen',
                                                   sLink = create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time), end_time = end_time),
                                                   sTool = sTool))
   
                else:                                    
                    dfSE1 = dfSE[((dfSE.start_f>=dStartFreq) & (dfSE.start_f < dEndFreq))]
                    dfSE = dfSE1.groupby(['create_time', 'cycle_id'], sort=False).pipe(lambda x: np.sum(x, axis=0))                    # sum over the relevant frequency range for each cycle
                    dfSE.reset_index(inplace=True)
		
                dfSE.dropna(axis=0, how='any', subset=lDirs, inplace=True)
						
                ## now compare with the thresholds    
                lErr = []
                for lList in [lFlap, lEdge]:
							
                    dTmp = dfSE.loc[:, lList].values
                    dSE_mean = np.mean(dTmp, axis=1)
                    relSE = dTmp /  np.tile(dSE_mean.reshape((len(dSE_mean),1)), (1,3))                    
                    # TODO 2019-1-17: hier individuelle Werte fuer jeweilige WEA auslesen
                    dSE_thres = dfSE_thres.loc[:, lList].values
                    dThres = np.tile(dSE_thres, (dTmp.shape[0],1))
                    dfTmp = pd.DataFrame((relSE > dThres), columns=lList)		
                    lErr.append(dfTmp)
				
                #bErrors = np.concatenate(lErr, axis=1)                    
                dfErr = pd.concat(lErr, axis=1)
                bTmp = dfErr.any(axis=1)
                dfCyc_cl = pd.concat((dfSE[bTmp].loc[:,['create_time', 'cycle_id']], dfErr[bTmp].set_index(dfSE[bTmp].index)), axis=1)
									   
                dfCyc_cl.rename(columns = dictMap_class, inplace=True)
                #dfCyc_cl = pd.wide_to_long(dfCyc_cl, stubnames = ['ch'], i = 'channel')
                dfCyc_cl = pd.melt(dfCyc_cl, id_vars=['create_time', 'cycle_id'], value_vars = dictMap_class.values(), var_name = 'channel', value_name = 'fail')
                dfCyc_cl = dfCyc_cl[dfCyc_cl.fail]
                # reformat 
						
                #iCrit_class = find_args(any(bErrors, axis=0))             # get index of columns that contain error-values
					
                # find cycles (create_time, cycle_id) of the times of the errors
                dfCyc_cl = dfCyc_cl.assign(origin = pd.Series(np.tile('classic', (dfCyc_cl.shape[0],))).values)           # add column with origin (classical method or ts method)				
																	  
                # load cdef-data
                # get SE in frequency range
                #dfSE = dfSE.loc[:,['create_time', 'e_101_edge', 'e_102_edge', 'e_103_edge']]
                #dfSE.rename(columns={'e_101_edge': 'RBL1 Edge', 'e_102_edge': 'RBL2 Edge', 'e_103_edge': 'RBL3 Edge', 'e_101_flap': 'RBL1 Flap', 'e_102_flap': 'RBL2 Flap', 'e_103_flap': 'RBL3 Flap'}, inplace=True)
													
            except:
                issues.append(create_issue(db,
                                           sErrorMsg = 'unbekannter Fehler bei check_measLines, klassische Variante', 
                                           sAction = 'manuell pruefen',
                                           sLink = create_link(db, sTool=sTool, start_time=start_time, end_time=end_time),
                                           sTool = sTool))						
                dfCyc_cl = None                    
						
						
            dfCycCrit = dfCyc_cl                
            dict_res.append({sMethod: dfCycCrit})


        elif (sMethod=='ts'):
            ## 2) time series method                                            
            # TODO 2019-1-18: debuggen und aktivieren
            if False:
                update_ts(time_start=dtStart, time_end=dtEnd)
                dfCyc_ts = get_data(db, [[sNodes.ts_startstop, sWC + ' and channel<6']], ['create_time', 'ID', 'channel','start','stop'])    
						
                if dfCyc_ts.shape[0]==0:
                    issues.append(create_issue(db,
                                               sErrorMsg='keine Zeitdaten gefunden',
                                               sAction='manuell ansehen',
                                               sLink=''))
                else:
								
                    try:
                        iPred, dfFeat = super(turbine_mon, self).predict_sensor_state(dfCyc_ts, sensor_classificator)
								
                        # TODO 2019-1-17: stimmt das so???
                        bCrit = [i==1 for i in iPred]
								
                        # if any errornous channels were detected ..
                        if any(bCrit):									
                            dfCyc_ts = dfCyc_ts[bCrit]
                            dfCyc_ts = dfCyc_ts.assign(origin=pd.Series(np.tile('ts', (dfCyc_ts.shape[0],))).values)          # add column with origin (classical method or ts method)
														
                    except:
                        issues.append(create_issue(db,
                                                   sErrorMsg='unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode',
                                                   sAction='manuell ansehen',
                                                   sLink=''))
                        
                        print('unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode')
                        dfCyc_ts = None
								
                dfCycCrit = dfCyc_ts
		
        else:
            print('unbekannte Methode zur Sensordefekterkennung')
            dfCycCrit = None
					

        ## 3) now get info about found critical times                
        bOk = isinstance(dfCycCrit, pd.DataFrame)
        if bOk:
            bOk = (dfCycCrit.shape[0]>0)

            if bOk:     
                try:                                
				
                    # TODO 2019-1-18: combine results from both methods oder gegenseitig ueberpruefen oder sowas, akt. noch ts-methode deaktiviert									
                    iCh_crit = np.unique(dfCycCrit.channel)              # critical channels
		
                    # TODO 2019-1-18: ggf. andere Tabelle(?), wenn nicht alle SE-Eintraege gemerged werden
                    # TODO 2019-1-18: function noch so umstellen, dass dieser Teil nur dann ausgefuehrt wird, wenn neue Tickets erstellt werden muessen (dann wird das hier evtl. benoetigt)
                    listNodes = [[sNodes.cycle_status, []]]
                    listColumns = ['create_time', 'ID', 'cyc_status_alarm', 'cyc_status_warning', 
                                   'cyc_status_eval', 'cyc_status_system', 'status_alarm',
                                   'status_warning', 'status_eval', 'status_system', 'turbine_status',
                                   'omega_mean', 'omega_sigma', 'power_mean', 'power_sigma', 'pitch_mean',
                                   'pitch_sigma', 'wind_mean', 'wind_sigma', 'azimuth_mean',
                                   'azimuth_sigma', 'temperature_mean', 'ambient_temperature_mean']
                    dfExt = mfdata.get_data(db, sPathData, listNodes, listColumns)
                    dfCycCrit = dfCycCrit.merge(dfExt, how='inner', on=['create_time'])                              # merge both DataFrames
								
                    dfTicketsCrit = get_tickets(dfTickets, sType = 'check_measLines')                     # tickets for measure lines with problems
                    dictChTickets, bChTickets = mfdata.get_channels_from_tickets(dfTicketsCrit)     # find affected channels by the modified titles of the relevant tickets                                
								
                    ## loop through critical channels
                    # TODO 2018-12-20: noch eleganter, vektorisierter etc. machen!
                    for iCh in iCh_crit:
							
                        ## critical times for that channel
                        # TODO 2018-12-21: hier koennte man noch testen, ob iPred=1 ueber (fast) den ganzen betrachteten Zeitraum gilt oder nur einen kleinen Teil,
                        # und dann anhand dessen das 'ztw.' hinzufuegen oder weglassen
                        # TODO 2019-1-25: ausserdem testen, ob Beginn des Defekts vielleicht noch weiter zurueckliegt und entsprechende Zeit herausfinden
                        dtCrit = dfCycCrit[dfCycCrit.channel==iCh].create_time                                                        
                        sTmp = 'Channel ' + str(iCh) + ' (' + dictMap_output[iCh] + ') (ztw.) defekt seit mindestens ' + min(dtCrit).strftime(sDTFormatMsg)
			
                        ## look for related tickets
                        #dfTC = dictChTickets[str(iCh)]                      # tickets for that channel
                        dfTC = dictChTickets[iCh]                      # tickets for that channel
							
                        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets for that channel
                        if dfOpen.shape[0]>0:
                            sTmp += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                            issues.append(create_issue(db,
                                                       sErrorMsg=sTmp,
                                                       sAction='', 
                                                       sLink = ''))
							
                        else:
                            dfClosed = dfTC[dfTC.sStatus=='erledigt']
                            if dfClosed.shape[0]==0:
																	
                                #sStartLink = str(np.floor((min(dtCrit) - tShift).timestamp())*1000)
                                #sEndLink = str(np.floor(dt.now().timestamp())*1000)
													   
                                #HIER WEITER 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN                              
                                issues.append(create_issue(db, 
                                                           sErrorMsg=sTmp,
                                                           sAction='Ticket anlegen, ggf. Kanal deaktivieren',
                                                           sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=time_end),
                                                           sTool = sTool))
																		
                            else:
                                dfT = mfdata.get_ticket_times(dfClosed)                 # start and end times for the closed tickets
									
                                ## herausfinden, ob es iPred=1-Zeiten nach Ende der Tickets gibt, falls nein:
                                bAllIn = False
                                for idx, row in dfT.iterrows():
                                    bAllIn = bAllIn & all(dtCrit <= row['stop'])                                
									
                                    if bAllIn:
                                        sTmp = sTmp + ' - alles noch durch Ticket ' + ','.join(dfT.sTicketID) + ' (jetzt geschlossen) abgedeckt'
                                        issues.append(create_issue(db,
                                                                   sErrorMsg=sTmp,
                                                                   sAction='beobachten',
                                                                   sLink=''))
                                    else:             ## ansonsten 
                                        sTmp = sTmp + ', anscheinend schonmal aufgetreten (Ticket ' + ','.join(dfT.sTicketID) + ')'
                                        issues.append(create_issue(db,
                                                                   sErrorMsg=sTmp,
                                                                   sAction='altes Ticket wieder oeffnen oder neues Ticket anlegen',
                                                                   sLink=''))
		
                except:
                    issues.append(create_issue(db, 
                                               sErrorMsg='unbek. Fehler bei Check auf Sensordefekte (bei Ticketzuordnung)',
                                               sAction='manuell ansehen',
                                               sLink=''))
					
    return(dict_res)


  
