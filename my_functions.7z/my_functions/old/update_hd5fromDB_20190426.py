# -*- coding: utf-8 -*-
"""

function to update data in hd5-file directly from database
@author: Christian Kuehnert

2019-6-2

"""

import os
import pandas as pd

from data import fullfile, initialize_hd5file, get_data_fromDB, setdifference_df, append_to_hd5Table
#import fullfile
#import initialize_hd5file
#import get_data_fromDB
#import setdifference_df
#import append_to_hd5Table


def update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=None, time_start=None, time_end=None, iLimit=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
       
    if not os.path.isfile(sFN_hd5):               # if no such hd5-file exists      
        initialize_hd5file(sDB, sPathData)        # create it hd5-file

    bHD5Data = False
    with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:
        
            dfData = f[sNode]
        
            if not isinstance(dfData, pd.DataFrame):
                f.remove(sNode)
            else:
                bHD5Data = True
                                

        if iLimit:
            
            iOffset=0
            bContinue=True
            while bContinue:  
                print('offset=' + str(iOffset))                     
                dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start, iOffset=iOffset, iLimit=iLimit)
                bContinue = dfData_sql.shape[0]>0
                if bContinue:
                    if bHD5Data:
                        dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
                    else:
                        dfAppend = dfData_sql.reset_index(drop=True)
                    
                    append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)
                iOffset += iLimit                    
                                                
        else:
            
            dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start)
            if dfData_sql.shape[0]>0:
                if bHD5Data:
                    dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
                else:
                    dfAppend = dfData_sql.reset_index(drop=True)
                
                append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)

        f.close()                                                
    
   
