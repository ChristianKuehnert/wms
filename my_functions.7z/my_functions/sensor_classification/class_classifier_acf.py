# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 17:32:16 2019

@author: w012028
@modified: 2019-11-22
"""
import sys
import warnings
import numpy as np

#import pandas as pd

#from sklearn.pipeline import Pipeline
from sklearn.utils.validation import check_X_y, check_array
from sklearn.utils.multiclass import unique_labels

#from sklearn.preprocessing import FunctionTransformer
from sklearn.svm import SVC
from sklearn.metrics import precision_recall_fscore_support
from statsmodels.tsa.stattools import acf

sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\sensClass'
sys.path.append(sModulePath)
#import myFunctions_data as mfdata
#import data as mfdata
from sensor_classification.class_classifier_ts import classifier_ts



HIER WEITER 2019-11-22: TRAIN, SAVE AND LOAD OF ACF MODEL IMPLEMENTIEREN/BEENDEN, DANN AUF DIE LETZTEN TESTDATEN VON DB ANWENDEN UND MIT
ASYM-MODELL VERGLEICHEN





class classifier_acf(classifier_ts):
    
    """
    initialization
    
    """
                
    def __init__(self, iOrderDiff=1, lags=list(range(1,20)), pickle_path=None):
        
        #self.feat_kwargs = feat_kwargs
        #self.predict_kwargs = predict_kwargs
        
        #tmp = Pipeline([('feat_fct', classifier_asym.feat_fct(**feat_kwargs)), ('predict_fct', classifier_asym.predict_fct(**predict_kwargs))], memory=None)
        #tmp = Pipeline([('feat_fct', FunctionTransformer(self.calculate_features, validate=False)), ('predict_fct', FunctionTransformer(self.predict, validate=False))], memory=None)
        self.iOrderDiff = iOrderDiff
        self.lags = lags
        
        super().__init__(name = 'acf', 
                         feat_fct = self.calculate_features,
                         predict_fct = self.predict,
                         pickle_path=pickle_path)
        
        
    
    
    """
    calculate features
    
    Christian Kuehnert, 2019-4-8
    
    """
    def calculate_features(self, dTS = None):
        
        if dTS is None:
            dRes = None
        else:
            iMaxLag = max(self.lags)            
            btmp = [lag in self.lags for lag in range(iMaxLag)]
            dRes = acf(np.diff(dTS, n=self.iOrderDiff, axis=0), nlags=iMaxLag)[btmp]

        return(dRes)
#    def my_acf(dTS, iOrderDiff, lags, bWide=False):
#    
#        iLags = lags
#        dACF = acf(np.diff(dTS, n=iOrderDiff), nlags=max(iLags))
#        
#        if bWide:         
#            sCols = ['acf_lag' + str(i) for i in iLags]
#            df1 = pd.DataFrame(data=[iOrderDiff], columns = ['order_diff'], dtype=int)
#            df2 = pd.DataFrame(data=dACF[None], columns = sCols, dtype=float)
#            dfRes  = pd.concat((df1, df2), axis=1)      
#    
#        else:
#            iN = dACF.shape[0]
#            df1 = pd.DataFrame(data=np.tile(iOrderDiff, [iN, ]), columns = ['order_diff'], dtype=int)
#            df2 = pd.DataFrame(data=iLags, columns=['lag'], dtype=int)
#            df3 = pd.DataFrame(data=dACF, columns=['acf'], dtype=float)
#            dfRes = pd.concat((df1, df2, df3), axis=1)
#    
#        return(dfRes)
 


      
        
    
    """
    train model

    """                
    def fit(self, X, y):
        X, y = check_X_y(X, y)              # test if X and y have consistent shape
        
        self.classes_ = unique_labels(y)    # store the classes seen during fit
        
        self.X_ = X
        self.y_ = y
        
        return(self)




    """
    predict
    
    overwrites super.predict, check if fitted already is excluded, in this case use default values
    function to calculate the differences between quantile for positive values and quantiles for negative values
    TODO 2018-12-14: evtl. spaeter anders machen
    """
    def predict(self, X):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        X = check_array(X)                      # check if X is correct input
        
        iPred = (X > self.dB).astype(int)
        
        return(iPred)
    



    """
    predict with external threshold
    
    overwrites super.predict, check if fitted already is excluded, in this case use default values
    function to calculate the differences between quantile for positive values and quantiles for negative values
    TODO 2018-12-14: evtl. spaeter anders machen
    """
    def predict_ext(self, X, dB):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        #X = check_array(X)                      # check if X is correct input
        
        iPred = (X > dB).astype(int)
        
        return(iPred)
    








   
"""
 function that does several runs with different split of data into trainings and test data and learns parameters for acf method and calculates several 
 statistics over it and produces various figures etc.

 input:
       - sss:               stratified shuffle split containing the splits for the several runs
       - dfFeat:            data frame containing the acf's of d1-time series
                            the headers must be of format 'acf_'+ lag-Value, e.g. 'acf_1'
       - dfLabel:           labels for the data
       - dict_class_train:  dictionary with the parameters, must contain: [TODO 2019-4-8: spaeter default-Werte einfuehren]:
           - sKernel:       kernel to be used
           - dC:            value of dC for optimization
           - dGamma:        value of gamma for optimization

 output:


@author: Christian Kuehnert
@modified: 2019-4-8

"""
def train_classifier(self, sss=None, dfFeat=None, dfLabel=None, dict_class_train=None):

    warnings.filterwarnings("ignore")
            
    dEps = 1e-6       # accuracy for comparing numerical values
           
    iNumberOfRuns = sss.get_n_splits()
               
               
    kernel = dict_class_train['kernel']    
    if not(kernel):
        # dThresMin = dfFeat.values.min()
        kernel = 'linear'
        
    C = dict_class_train['C']
    if not(C):
        C = 1e3
    
    gamma = dict_class_train['gamma']
    if not(gamma):
        gamma = 1e-7
    
    model = SVC(kernel=dict_class_train['kernel'], C=dict_class_train['C'], gamma=dict_class_train['Gamma'])
    #model = SVC(**dict_class_train)
    
    lModel = []
    
    ## lists of results for the several runs
    lPrec = []
    lRec = []
    lF1 = []    
    lIdxFail = []                          
    lModel = []
                         
    ## loop trough the different runs
    iRun = 0     
    for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
         
        if ((iRun+1) % 10 == 0):                   
            print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                
        dACF_d1_train, dACF_d1_test = dfFeat.values[train_idx,:], dfFeat.values[test_idx, :]                                                                                                                                          
        dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                            
        #sSVMPars = sKernel + ', C=' + str(dC) + ', gamma=' + str(dGamma)            
        model.fit(dACF_d1_train, np.ravel(dLabel_train))
        iPred = model.predict(dACF_d1_test)
        iPred = np.reshape(iPred, (len(iPred), 1))

        bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data                
        idx_fail = test_idx[bFailClass]

        dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)            
                                                       
        lPrec.append(dAccu[0])
        lRec.append(dAccu[1])
        lF1.append(dAccu[2])
        lModel.append(model) 
        lIdxFail.append([len(bFailClass), sum(bFailClass), idx_fail])   
                                   
        iRun = iRun + 1
                  
    
    # TODO 2019-11-22: here (or already in the loop above) should be used an
    # ensemble method, or better the loop should be replaced by the call of an
    # ensemble method. The following selection of the model with the highest
    # F1 score makes no sense (since the models differ only by the randomly
    # chosen subset of data) and is only a placeholder!!!
    idx = [i for i in range(iRun) if (lF1[i]==max(lF1))]
    
    self.model = lModel[idx]
    self.feat_kwargs = 

                       
    print('opt. parameters: quantile = ' + str(dQ_opt) + ', threshold = ' + str(dB_opt) + ', F1score = ' + str(lF1[idx]))    
            
    return(self)



#    """
#    function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
#    statistics over it and produces various figures etc.
#    
#    @author: Christian Kuehnert, 2019-1-7
#    
#    input:
#        - sss:          stratified shuffle split containing the splits for the several runs
#        #- dfFeat:       pd.DataFrame containing the features, THESE FEATURES MUST BE CONSISTENT WITH dQs, i.e. column i in dfFeat must correspond with element i of dQs
#        - dfFeat:       pd.DataFrame containing the features, THIS DataFrame MUST HAVE THE dQs-values AS COLUMN NAMES (numeric, not as strings!)
#
#    output:
#        
#        
#    """
#    def train_classifier(self, sss = None, dfFeat = None, dfLabel = None, dictClassTrain = None):
#                
#             
#            
#        #dThres = [dThresMin + iIdx * (dThresMax-dThresMin) / n_thres for iIdx in range(n_thres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold            
#
#        dQs = dfFeat.columns
#        n_q = len(dQs)
#        # TODO 2019-1-4: EVTL.(!) hier noch Fall abfangen, dass die columns nicht die dQs enthalten
#            
#        #dQs.sort()
#        n_runs = sss.get_n_splits()    
#                       
#        # ggf. anders versuchen, z.B. erst fuer alle Kombinationen {dQs} x {dBs} jeweils fuer alle Runs die Accuracy berechnen,
#        # dann die Q-b-Kombination waehlen, fuer welche die meisten Runs optimal sind bzw. wo der Median aus den F1 ueber alle runs maximal ist
#        # dann die Parameter waehlen, wo vielleicht auch (um eine gewisse Stetigkeit 'reinzubekommen) der Median von 
#        # F1 ueber alle runs + Vorfaktor (z.B. 1/9) * Summe
#        # der Mediane von F1 ueber alle Runs aus allen angrenzenden Q-b-Zellen maximal wird.
#        # Jetzt erstmal so implementiert, um zu beginnen            
#        
#        dQ_r = np.zeros((n_runs))*np.nan
#        dB_r = np.zeros((n_runs))*np.nan
#        dF1_r = np.zeros((n_runs))*np.nan
#
#        ## loop trough the different runs
#        iRun = 0
#        for train_idx, test_idx in sss.split(dfFeat.values, dfLabel.label.values):
#                                
#            print('    run ' + str(iRun+1) + '/' + str(n_runs))
#
#            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
#        
#            dF1_q = np.zeros((n_q))*np.nan
#            dB_q = np.zeros((n_q))*np.nan
#        
#            ## loop through q's                                            
#            for iQ in range(n_q):
#                                                
#                dQ = dQs[iQ]
#                #print('    q=' + str(dQ))
#
#                dX_train, dX_test = dfFeat.values[train_idx, iQ], dfFeat.values[test_idx, iQ]                                
#                                                                                                                                                                                                                                                                                                                                                                                                       
#                # define optimization fct.
#                # find optimal b
#                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(self.predict_ext(dX_train.reshape(-1,1), x)-dLabel_train), ranges = ((dThresMin, dThresMax),), Ns=n_thres, full_output=True, finish=None)
#                                                            
#                dB = resMin[0]
#
#                ## calc. accuracy of the model                                                                
#                iPred = self.predict_ext(dX_test, dB)                                                        
#                    
#                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
#                
#                dB_q[iQ] = dB                                                                                                                
#                dF1_q[iQ] = dAccu[2]
#                
#            idx = np.argmax(dF1_q)
#            dQ_r[iRun] = dQs[idx]
#            dB_r[iRun] = dB_q[idx]
#            dF1_r[iRun]= dF1_q[idx]                                                     
#                                                                                                                        
#            iRun = iRun + 1
#                                            
#            
#        # TODO 2019-1-4: erstmal wie folgt gemacht, evtl. noch bessere Variante ueberlegen, welche Parameter am besten sind
#        #bTmp = dF1_r[dF1_r>0.8]
#        #if any(bTmp):
#        #    dTmp = np.unique(dB_r)        
#        #idx = np.argmax(lF1)
#        dQ_opt = np.median(dQ_r)
#        dB_opt = np.median(dB_r)
#        
#        self.predict_kwargs['dB'] = dB_opt
#        self.feat_kwargs['dQ'] = dQ_opt
#                        
#        print('opt. parameters: quantile = ' + str(dQ_opt) + ', threshold = ' + str(dB_opt) + ', F1score = ' + str(lF1[idx]))    
#            
#        return(self)


