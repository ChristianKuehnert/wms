# -*- coding: utf-8 -*-
"""
function to calculate the acf of diff-ed time series up to lag iMaxLag

 input:
       - dfTS:         ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
       - iOrderDiff:   order of differencing, i.e. how often differences are calculated
       - iMaxLag:      max. lag up to which the acf is calculated
       - bWide:        if true, a wide-table representation is returned (i.e. one column for each lag), otherwise
                       the returned dataframe has an extra column with the lag as value

 output:
       - dfRes:        dataframe with columns ['order_diff', 'acf'] and (if bWide) 'lag' containing the lag and the
                       acf of the iOrderDiff-times differenced time series


 Christian Kuehnert, 2018-12-6

"""

import numpy as np
import pandas as pd
from statsmodels.tsa.stattools import acf



def my_acf(dTS, iOrderDiff, iMaxLag, bWide=False):

    iLags = [i for i in range(iMaxLag+1)]
    dACF = acf(np.diff(dTS, n=iOrderDiff), nlags=iMaxLag)
    
    if bWide:         
        sCols = ['acf_lag' + str(i) for i in iLags]
        df1 = pd.DataFrame(data=[iOrderDiff], columns = ['order_diff'], dtype=int)
        df2 = pd.DataFrame(data=dACF[None], columns = sCols, dtype=float)
        dfRes  = pd.concat((df1, df2), axis=1)      

    else:
        iN = dACF.shape[0]
        df1 = pd.DataFrame(data=np.tile(iOrderDiff, [iN, ]), columns = ['order_diff'], dtype=int)
        df2 = pd.DataFrame(data=iLags, columns=['lag'], dtype=int)
        df3 = pd.DataFrame(data=dACF, columns=['acf'], dtype=float)
        dfRes = pd.concat((df1, df2, df3), axis=1)

    return(dfRes)
    


