# -*- coding: utf-8 -*-
"""
function to update all data in the given list with all features in the given list

@author: Christian Kuehnert, 2019-1-21
  
"""

def update_all_labels(sDBs, sPathData, sPathLabels):

    for sDB in sDBs:                         
        print('update labels for turbine: ' + sDB)            
#        update_labels(sDB, sPathData, sPathLabels)
    
    