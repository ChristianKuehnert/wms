# -*- coding: utf-8 -*-
"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-13
"""
def asym_predict(dDiffQ = None, dThreshold = None):
    
    iPred = (abs(dDiffQ) > dThreshold).astype(int)   
    return(iPred)
    #bPred = (abs(dDiffQ) > dThreshold)  
    #return(bPred)

