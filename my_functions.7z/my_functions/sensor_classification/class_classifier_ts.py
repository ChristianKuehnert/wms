# -*- coding: utf-8 -*-
"""
class to build my own models


Created on Thu Dec  6 01:40:52 2018
last modified: 2019-3-13

@author: Christian Kuehnert, based on/parts taken from 
https://scikit-learn.org/dev/developers/contributing.html#rolling-your-own-estimator
on 2019-5-16


"""




#from myFunctions_data import combine_filters
import pandas as pd
import numpy as np
#import datetime as dt
#import ast
import sys
#import warnings
#import itertools
#import scipy
#import stats

import os
#import os.path
#import fnmatch
#import random
#import scikitlearn as skl
#from sklearn.preprocessing import LabelEncoder
#from sklearn.model_selection import StratifiedShuffleSplit
#from sklearn.metrics import precision_recall_fscore_support
#from sklearn.preprocessing import MinMaxScaler
#from sklearn.externals import joblib
from sklearn.base import BaseEstimator, ClassifierMixin
#from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils.validation import check_X_y, check_array
from sklearn.utils.multiclass import unique_labels
#from sklearn.pipeline import Pipeline
     
try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle


#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\functions'
sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
sys.path.append(sModulePath)    
import data as mfdata





class classifier_ts(BaseEstimator, ClassifierMixin):
    
    
    """
    initialization
    @author: Christian Kuehnert
    @last_modified: 2019-3-12
    
    TODO 2019-3-12: evtl. aendern, automat. Einlesen, wenn Datei vorhanden, Fehler melden, wenn data_fct oder model_pipeline angegeben sind, aber Datei schon vorhanden ist und 
                    beide Varianten nicht uebereinstimmen oder so
    
    """
    #def __init__(self, name = '', data_fct=None, model_pipeline=None, pickle_path=None):
    def __init__(self, name = '', feat_fct=None, predict_fct=None, pickle_path=None):
        self.name = name
        #self.data_fct = data_fct                            # function to retrieve the data
        #self.model_pipeline = model_pipeline                # pipeline consisting of feature function (must be applicable to result of data_fct) and model to predict the classes
        self.feat_fct = feat_fct
        self.predict_fct = predict_fct
        self.pickle_path = pickle_path                      # path where to pickle and load the dump of the pipeline and data_fct
 
    
        
        
    """
    function to create file name for saving and loading
    
    2019-3-12
    """
    def create_fn(self):
        return(self.pickle_path + '\\' + self.name + '.pkl')
    
    
    
    
    """
    fit model

    """                
    def fit(self, X, y):
        X, y = check_X_y(X, y)              # test if X and y have consistent shape
        
        self.classes_ = unique_labels(y)    # store the classes seen during fit
        
        self.X_ = X
        self.y_ = y
        
        return(self)




    """
    predict
    
    Christian Kuehnert, 2018-12-13
    """
    def predict(self, X):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called                
        X = check_array(X)                      # check if X is correct input        
        iPred = self.model_pipeline(X)
        
        return(iPred)
    



    """
    predict the class from a given time period
    2019-3-13
    
    """
    def predict_for_period(self, db, channels, start_time=None, end_time=None, path_hd5=None):
        
        #dict_res = {}
        lres = []
        if self.feat_fct:
            dict_res = self.data_fct(self.feat_fct, db, start_time=start_time, end_time=end_time, channels = channels)
            #iPred = self.model_pipeline(X)
            # TODO 2019-3-13: eleganter machen!            
            for k, v in dict_res.items():                
                if not v is None:
                    #dict_res[k] = self.predict(v)
                    #tmp = self.predict(v)[0][0]
                    tmp = self.predict(v)
                else:
                    #dict_res[k] = np.nan()
                    tmp = np.nan
                
                lres.append((k[0], k[1], k[2], k[3], v, tmp))

        #if len(dict_res)>0:
        df = pd.DataFrame(lres, columns = ['db', 'create_time', 'id', 'channel', 'value', 'prediction'])
        #else:
        #    df = pd.DataFrame(columns = ['db', 'create_time', 'id', 'channel'])
        return(df)
            
    
    
    
    
    

    """
    predict the class from a given time series
    
    arr_ts:  time series as np.array
    
    2019-9-17
    
    """
    def predict_for_ts(self, arr_ts):
        
        res = None
        if self.feat_fct:
            feat = self.feat_fct(arr_ts)
            res = self.predict(feat)[0][0]
            #res = self.predict(feat)
        
        return(res)
            
    
    
    
    
    
    
    """
    function to retrieve the time series for the given time interval
    2019-3-13
    
    Note: when setting apply_fct = true_feat_fct \circ predict_fct one gets 
            the prediction directly
    
    TODO 2019-3-13: erweitern, so dass sowohl von hd5-file als auch aus 
                    file-system gelesen werden kann (ggf. in Kombination)
    
    """
    def data_fct_old(self, apply_fct, db, start_time=None, end_time=None, 
                 channels=range(6), power_min=None):
        
        dfCyc = mfdata.get_cycles(db, start_time=start_time, end_time=end_time, 
                                  columns=['create_time', 'ID', 'power_mean'], 
                                  where='available_data>2', 
                                  power_min=power_min)
        
        dict_res = {}
        #i=0
        #stmp = str(dfCyc.shape[0])
        for idx, cycle in dfCyc.iterrows():
            
            ct = cycle['create_time']
            iID = cycle['ID']
            #i += 1
            #print(f"{i}/{stmp}")
            for channel in channels:
                
                dTS = mfdata.get_ts_one_channel(db, ct, iID, channel, 
                                                count_meas_base=8192)
                        
                ## apply function to not-None results            
                dict_res.update({(db, ct, iID, channel): apply_fct(dTS)})
                
        #dRes = np.concat(lRes, axis=1)        
        return(dict_res)
            
            
        
    
        
    """
    new version of function to retrieve the time series for the given time 
    interval

    2019-11-19
    
    Note: when setting apply_fct = true_feat_fct \circ predict_fct one gets 
            the prediction directly
    
    TODO 2019-3-13: erweitern, so dass sowohl von hd5-file als auch aus 
                    file-system gelesen werden kann (ggf. in Kombination)
    
    """
    def data_fct(self, apply_fct, db, start_time=None, end_time=None, 
                 channels=range(6), power_min=None):
        
        dfCyc = mfdata.get_cycles(db, start_time=start_time, end_time=end_time, 
                                  columns=['create_time', 'ID', 'power_mean'], 
                                  where='available_data>2', 
                                  power_min=power_min)
        
        dict_res = {}
        #i=0
        #stmp = str(dfCyc.shape[0])
        for idx, cycle in dfCyc.iterrows():
            
            ct = cycle['create_time']
            iID = cycle['ID']
            #i += 1
            #print(f"{i}/{stmp}")
            
            path = mfdata.get_folder(db, ct, iID)  # get folder for this create_time and ID

            dict_ts, _critical_channels = mfdata.update_hd5.combine_at(path)
            chs = dict_ts.keys()
            
            for ch in channels:
                sch = str(ch)
                if not (sch in chs):
                    print(f'.gz-at-data for channel {sch} not found or not combined')

                else:
                    dTS = dict_ts[sch].a_t.values
                    
                    ## apply function to not-None results            
                    dict_res.update({(db, ct, iID, ch): apply_fct(dTS)})
                
        #dRes = np.concat(lRes, axis=1)        
        return(dict_res)
            
            
        
    
    


    """
    optimizes the model within a given range of parameters
    
    """
    def train_classifier(self, **kwargs):
        pass
    
    
    

    """
    pickle classificator to file
    
    Christian Kuehnert, 2019-3-12
    """
    def save(self):
        
        with open(self.create_fn(), 'wb') as hdl:
            pickle.dumps({'data_fct': self.data_fct, 'model_pipeline': self.model_pipeline}, hdl, protocol=pickle.HIGHEST_PROTOCOL)




    
    """
    load model from file
    
    Christian Kuehnert, 2019-3-12
    """
    def load(self):
        
        file_name = self.create_fn()
        
        if not(self.data_fct) and not(self.model_pipeline):
            
            try:
                if os.path.isfile(file_name):
                    
                    with open(file_name, 'rb') as hdl:
                        tmp = pickle.load(hdl)
                        
                        self.data_fct = tmp['data_fct']
                        self.model_pipeline = tmp['model_pipeline']
                else:
                    print(f'file{file_name} not found')
    
            except Exception as e:
                print('problem with loading classifier from file ' + file_name)
                self.data_fct=None
                self.model_pipeline=None

        else:
            print('data_fct or model_pipeline already exists, cannot overwrite - please create new classificator instance')
            
            
            

