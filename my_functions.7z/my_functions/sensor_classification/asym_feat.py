# -*- coding: utf-8 -*-
"""
function to calculate the differences between quantile for positive values and quantiles for negative values

@author Christian Kuehnert (w012028)

2018-12-14
"""

import numpy as np


# TODO 2018-12-13: so aendern, dass kein df sondern ein np.array zurueckgegeben wird, welches man direkt fuer die Klassifikation einlesen kann
def asym_feat(dTS, iOrderDiff, dQ):
    
    #sCols = ['diff' + str(iOrderDiff) + '_q' + str(dQ)]
    d_dTS = np.diff(dTS, n=iOrderDiff, axis=0)
    
    d_dTS = d_dTS[~np.isnan(d_dTS)]
    d_dTS = d_dTS / np.linalg.norm(d_dTS, ord=2, axis=0)
    
    d1 = np.percentile(d_dTS[d_dTS>0], dQ*100, axis=0)
    
    d2 = -d_dTS[d_dTS<0]
    d3 = np.percentile(d2, dQ*100, axis=0)
                            
    dDiff = d1 - d3
    
    #dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
    #dfRes = pd.DataFrame(columns = sCols)
    #dfRes.loc[0] = np.append(iOrderDiff, dDiff.values.transpose())
    #dfRes.loc[0] = dDiff
    
    #dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    #for s in sCols:
    #    dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    #return(dfRes)
    return(dDiff)
    
    