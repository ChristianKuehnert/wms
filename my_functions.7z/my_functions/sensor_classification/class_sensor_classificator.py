# -*- coding: utf-8 -*-
"""
class to build my own models


Created on Thu Dec  6 01:40:52 2018
last modified: 2018-12-13

@author: Christian Kuehnert, based on/parts taken from 
https://scikit-learn.org/dev/developers/contributing.html#rolling-your-own-estimator
on 2019-9-25


"""




#from myFunctions_data import combine_filters
import pandas as pd
import numpy as np
#import datetime as dt
import ast
import sys
import warnings
#import itertools
import scipy
#import stats

import os
#import os.path
#import fnmatch
#import random
#import scikitlearn as skl
#from sklearn.preprocessing import LabelEncoder
#from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import precision_recall_fscore_support
#from sklearn.preprocessing import MinMaxScaler
from sklearn.externals import joblib
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils.multiclass import unique_labels
     

#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\functions'
sModulePath = r'C:\Repositories\python\functions'
sys.path.append(sModulePath)    
import myFunctions_data as mfdata





class classifierTemplate(BaseEstimator, ClassifierMixin):
    
    
    """
    initialization
    
    """
    def __init__(self, name = '', param = None, feat_fct = None, 
                 feat_kwargs = None, predict_fct = None, predict_kwargs = None,
                 keys = None):
        self.name = name                         # str, name of the classifier
        self.param = param
        self.feat_fct = feat_fct                   # function to calculate the features from the time series
        self.feat_kwargs = feat_kwargs
        self.predict_fct = predict_fct                   # function to predict the classes
        self.predict_kwargs = predict_kwargs
        self.keys = keys                         # keys and subkeys of the hd5-
                                                 # files that lead to the data
 
    
        
    
    """
    fit model

    """                
    def fit(self, X, y):
        X, y = check_X_y(X, y)              # test if X and y have consistent shape
        
        self.classes_ = unique_labels(y)    # store the classes seen during fit
        
        self.X_ = X
        self.y_ = y
        
        return(self)




    """
    predict
    
    Christian Kuehnert, 2018-12-13
    """
    def predict(self, X):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        X = check_array(X)                      # check if X is correct input
        
        iPred = self.predict_fct(X, **self.predict_kwargs)
        
        return(iPred)
    




    """
    calculate the features from a given time series
    
    """
    def calculate_features(self, dTS = None):
        return(self.feat_fct(dTS, **self._feat_kwargs))




    """
    function to load the data
    2019-9-25
    """
    def load_data(self, path_hd5, kwargs):
        




    """
    function to preprocess the data, i.e. to calculate the features for the
    classificator
    
    properties:
    -----------
        - path_hd5: str, path to the hd5-data

    2019-9-25
    """
    def preprocess_data(self, path_hd5):
        # apply calculate_features to the date
        
  


    """
    predict the class from a given time series
    
    """
    def predict_from_ts(self, dTS = None):
        dFeat = self.calculate_features(dTS)
        iPred = self.predict(dFeat)
        return(iPred)
    
    


    """
    optimizes the model within a given range of parameters
    
    """
    def train_classifier(self, **kwargs):
        pass
    
    
    

    """
    save classificator to file
    
    Christian Kuehnert, 2018-12-13
    """
    # TODO 2018-12-13: hier weiter 2018-12-13
    def save_classificator(self, sFileName=None):
        
        sFN_model = sFileName + '_model'
        joblib.dump(self.model, sFN_model)
        
        dfTmp = pd.DataFrame(columns=['parameter','value'])
        dfTmp.loc[0] = ['name', self.name]
        dfTmp.loc[1] = ['sFN_model',sFN_model]
        dfTmp.loc[2] = ['feat_fct', self.feat_fct.__str__()]
        i=3
        for n,v in self.feat_kwargs:
            dfTmp.loc[i] = [n,v]
            i += 1 
        
        dfTmp.to_csv(path_or_buf=sFileName, sep=';', header=True, index=False)
        
    
    
    
    """
    load model from file
    
    Christian Kuehnert, 2018-12-13
    """
    def load_classificator(self, sFileName = None):
        
        try:
            if os.path.isfile(sFileName):
                dfPar = pd.read_csv(filepath_or_buffer=sFileName, sep=';', header=True, index_col=None)
            
                self.name = ast.literal_eval(dfPar.loc['name'].value)
                self.feat_fct = ast.literal_eval(dfPar.loc['feat_fct'].value)
                sFN_model = dfPar.loc['sFN_model'].value
                self.model = joblib.load(sFN_model)
                
                self.feat_kwargs = {}
                for idx, row in dfPar.iterrows():
        
                    sN = row['parameter']
                    
                    if not(sN in ['name','feat_fct','sFN_model']):
                        self.feat_kwargs.append({sN: row['value']})

        except Exception as e:
            print('problem with loading classifier from file ' + sFileName)














class classifier_asym(classifierTemplate):
    
    """
    initialization
    
    """
    def __init__(self, feat_kwargs = {'iOrderDiff': 1, 'dQ': 0.99}, predict_kwargs = {'dB': 0.0025}):
        classifierTemplate.__init__(self, name = 'asym', feat_kwargs = feat_kwargs, predict_fct = mfdata.asym_predict, predict_kwargs = predict_kwargs)
        self.iOrderDiff = feat_kwargs['iOrderDiff']
        #self.dQ = feat_kwargs['dQ']
        #self.dB = predict_kwargs['dB']
        self.feat_fct = classifier_asym.feat_fct
        self.feat_kwargs = feat_kwargs
        self.predict_kwargs = predict_kwargs
#    def __init__(self, iOrderDiff = 1, dQ = 0.99, dB = 0.0025):
#        super(name='asym', feat_kwargs = , predict_fct = mfdata.asym_predict, predict_kwargs = predict_kwargs)
#        self.iOrderDiff = feat_kwargs['iOrderDiff']
#        self.dQ = feat_kwargs['dQ']
#        self.dB = predict_kwargs['dB']
        
        
        
            
            
    """
    function to calculate the differences between quantile for positive values and quantiles for negative values as features
    
    @author: Christian Kuehnert, 2019-1-4
    
    Parameters:
    -----------
    
    dTS:            time series
    iOrderDiff:     order of difference that should be applied to time series
    dQs:            list of quantiles for which the values should be calculated
    
    """
    # TODO 2018-12-13: so aendern, dass kein df sondern ein np.array zurueckgegeben wird, welches man direkt fuer die Klassifikation einlesen kann
    def feat_fct(dTS = None, iOrderDiff = None, dQs = None):
    
#        if not iOrderDiff:
#            iOrderDiff = self.iOrderDiff
#            
#        if not dQs:
#            dQs = [self.dQ]
                       
        
        lDiff = []
        for q in dQs:
            #sCols = ['diff' + str(iOrderDiff) + '_q' + str(dQ)]
            d_dTS = np.diff(dTS, n=iOrderDiff, axis=0)
            
            d_dTS = d_dTS[~np.isnan(d_dTS)]
            d_dTS = d_dTS / np.linalg.norm(d_dTS, ord=2, axis=0)
            
            d1 = np.percentile(d_dTS[d_dTS>0], q*100, axis=0)
            
            d2 = -d_dTS[d_dTS<0]
            d3 = np.percentile(d2, q*100, axis=0)
                                    
            #lDiff.append(d1 - d3)
            lDiff.append(abs(d1 - d3))
            
            #dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)
            #dfRes.loc[0] = np.append(iOrderDiff, dfDiff.values.transpose())
            #dfRes = pd.DataFrame(columns = sCols)
            #dfRes.loc[0] = np.append(iOrderDiff, dDiff.values.transpose())
            #dfRes.loc[0] = dDiff
            
            #dfRes['order_diff'] = dfRes['order_diff'].astype(int)
            #for s in sCols:
            #    dfRes[s] = dfRes[s].astype(float)
        
            #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
            #return(dfRes)
        

        return(lDiff)
        
        



    """
    calculate features
    
    Christian Kuehnert, 2019-1-2
    
    """
    def calculate_features(self, dTS = None):        
        #return(self.feat_fct(dTS = dTS, iOrderDiff = self.iOrderDiff, dQs = [self.dQ]))
        return(self.feat_fct(dTS = dTS, iOrderDiff = self.feat_kwargs['iOrderDiff'], dQs = [self.feat_kwargs['dQ']]))


  
        
        
    
    """
    train model

    """                
    def fit(self, X, y):
        X, y = check_X_y(X, y)              # test if X and y have consistent shape
        
        self.classes_ = unique_labels(y)    # store the classes seen during fit
        
        self.X_ = X
        self.y_ = y
        
        return(self)




    """
    predict
    
    overwrites super.predict, check if fitted already is excluded, in this case use default values
    function to calculate the differences between quantile for positive values and quantiles for negative values
    TODO 2018-12-14: evtl. spaeter anders machen
    """
    def predict(self, X):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        X = check_array(X)                      # check if X is correct input
        
        bPred = (X > self.predict_kwargs['dB']).astype(int)
        
        return(bPred)
    



    """
    predict with external threshold
    
    overwrites super.predict, check if fitted already is excluded, in this case use default values
    function to calculate the differences between quantile for positive values and quantiles for negative values
    TODO 2018-12-14: evtl. spaeter anders machen
    """
    def predict_ext(self, X, dB):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        #X = check_array(X)                      # check if X is correct input
        
        bPred = (X > dB).astype(int)
        
        return(bPred)
    


   


    """
    function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
    statistics over it and produces various figures etc.
    
    @author: Christian Kuehnert, 2019-1-7
    
    input:
        - sss:          stratified shuffle split containing the splits for the several runs
        #- dfFeat:       pd.DataFrame containing the features, THESE FEATURES MUST BE CONSISTENT WITH dQs, i.e. column i in dfFeat must correspond with element i of dQs
        - dfFeat:       pd.DataFrame containing the features, THIS DataFrame MUST HAVE THE dQs-values AS COLUMN NAMES (numeric, not as strings!)

    output:
        
        
    """
    def train_classifier(self, sss = None, dfFeat = None, dfLabel = None, dictClassTrain = None):
                
        warnings.filterwarnings("ignore")     
        
        #dEps = 1e-6       # accuracy for comparing numerical values
        #dEps = np.max([np.finfo(type(dQs_cols[0])).eps, np.finfo(type(dSetQs[0])).eps])
    
        ## lists of results
        lB = []
        lF1 = []
    
        #if not(dThresMin) or not(dThresMax):
        #    dfTmp0 = dfFeat[dfLabel.label==0]
        #    dfTmp1 = dfFeat[dfLabel.label==1]                                                
                
        dThresMin = dictClassTrain['dThresMin']
        dThresMax = dictClassTrain['dThresMax']
        n_thres = dictClassTrain['n_thres']
        
        if not(dThresMin):
            # dThresMin = dfFeat.values.min()
            dThresMin = dfFeat[dfLabel.label==1].values.min()
            
        if not(dThresMax):
            #dThresMax = dfFeat.values.max()
            dThresMax = dfFeat[dfLabel.label==0].values.max()
        
        if not(n_thres):
            n_thres = 10
        
            
            
        #dThres = [dThresMin + iIdx * (dThresMax-dThresMin) / n_thres for iIdx in range(n_thres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold            

        dQs = dfFeat.columns
        n_q = len(dQs)
        # TODO 2019-1-4: EVTL.(!) hier noch Fall abfangen, dass die columns nicht die dQs enthalten
            
        #dQs.sort()
        n_runs = sss.get_n_splits()    
                       
        # ggf. anders versuchen, z.B. erst fuer alle Kombinationen {dQs} x {dBs} jeweils fuer alle Runs die Accuracy berechnen,
        # dann die Q-b-Kombination waehlen, fuer welche die meisten Runs optimal sind bzw. wo der Median aus den F1 ueber alle runs maximal ist
        # dann die Parameter waehlen, wo vielleicht auch (um eine gewisse Stetigkeit 'reinzubekommen) der Median von 
        # F1 ueber alle runs + Vorfaktor (z.B. 1/9) * Summe
        # der Mediane von F1 ueber alle Runs aus allen angrenzenden Q-b-Zellen maximal wird.
        # Jetzt erstmal so implementiert, um zu beginnen            
        
        dQ_r = np.zeros((n_runs))*np.nan
        dB_r = np.zeros((n_runs))*np.nan
        dF1_r = np.zeros((n_runs))*np.nan

        ## loop trough the different runs
        iRun = 0
        for train_idx, test_idx in sss.split(dfFeat.values, dfLabel.label.values):
                                
            print('    run ' + str(iRun+1) + '/' + str(n_runs))

            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
        
            dF1_q = np.zeros((n_q))*np.nan
            dB_q = np.zeros((n_q))*np.nan
        
            ## loop through q's                                            
            for iQ in range(n_q):
                                                
                dQ = dQs[iQ]
                #print('    q=' + str(dQ))

                dX_train, dX_test = dfFeat.values[train_idx, iQ], dfFeat.values[test_idx, iQ]                                
                                                                                                                                                                                                                                                                                                                                                                                                       
                # define optimization fct.
                # find optimal b
                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(self.predict_ext(dX_train.reshape(-1,1), x)-dLabel_train), ranges = ((dThresMin, dThresMax),), Ns=n_thres, full_output=True, finish=None)
                                                            
                dB = resMin[0]

                ## calc. accuracy of the model                                                                
                iPred = self.predict_ext(dX_test, dB)                                                        
                    
                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
                
                dB_q[iQ] = dB                                                                                                                
                dF1_q[iQ] = dAccu[2]
                
            idx = np.argmax(dF1_q)
            dQ_r[iRun] = dQs[idx]
            dB_r[iRun] = dB_q[idx]
            dF1_r[iRun]= dF1_q[idx]                                                     
                                                                                                                        
            iRun = iRun + 1
                                            
            
        # TODO 2019-1-4: erstmal wie folgt gemacht, evtl. noch bessere Variante ueberlegen, welche Parameter am besten sind
        #bTmp = dF1_r[dF1_r>0.8]
        #if any(bTmp):
        #    dTmp = np.unique(dB_r)        
        #idx = np.argmax(lF1)
        dQ_opt = np.median(dQ_r)
        dB_opt = np.median(dB_r)
        
        self.predict_kwargs['dB'] = dB_opt
        self.feat_kwargs['dQ'] = dQ_opt
                        
        print('opt. parameters: quantile = ' + str(dQ_opt) + ', threshold = ' + str(dB_opt) + ', F1score = ' + str(lF1[idx]))    
            
        return(self)


#
#    """
#    function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
#    statistics over it and produces various figures etc.
#    
#    @author: Christian Kuehnert, 2019-1-4
#    
#    input:
#        - sss:          stratified shuffle split containing the splits for the several runs
#        #- dfFeat:       pd.DataFrame containing the features, THESE FEATURES MUST BE CONSISTENT WITH dQs, i.e. column i in dfFeat must correspond with element i of dQs
#        - dfFeat:       pd.DataFrame containing the features, THIS DataFrame MUST HAVE THE dQs-values AS COLUMN NAMES (numeric, not as strings!)
#
#    output:
#        
#        
#    """
#    def train_classifier(self, sss = None, dfFeat = None, dfLabel = None, dThresMin = None, dThresMax = None, n_thres = 10, sFN = None):
#                
#        warnings.filterwarnings("ignore")     
#        
#        #dEps = 1e-6       # accuracy for comparing numerical values
#        #dEps = np.max([np.finfo(type(dQs_cols[0])).eps, np.finfo(type(dSetQs[0])).eps])
#    
#        ## lists of results
#        lB = []
#        lF1 = []
#    
#        #if not(dThresMin) or not(dThresMax):
#        #    dfTmp0 = dfFeat[dfLabel.label==0]
#        #    dfTmp1 = dfFeat[dfLabel.label==1]                                                
#                
#        if not(dThresMin):
#            # dThresMin = dfFeat.values.min()
#            dThresMin = dfFeat[dfLabel.label==1].values.min()
#            
#        if not(dThresMax):
#            #dThresMax = dfFeat.values.max()
#            dThresMax = dfFeat[dfLabel.label==0].values.max()
#        
#            
#            
#        #dThres = [dThresMin + iIdx * (dThresMax-dThresMin) / n_thres for iIdx in range(n_thres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold            
#
#        dQs = dfFeat.columns
#        n_q = len(dQs)
#        # TODO 2019-1-4: EVTL.(!) hier noch Fall abfangen, dass die columns nicht die dQs enthalten
#            
#        #dQs.sort()
#        n_runs = sss.get_n_splits()    
#                       
#        # ggf. anders versuchen, z.B. erst fuer alle Kombinationen {dQs} x {dBs} jeweils fuer alle Runs die Accuracy berechnen,
#        # dann die Q-b-Kombination waehlen, fuer welche die meisten Runs optimal sind bzw. wo der Median aus den F1 ueber alle runs maximal ist
#        # dann die Parameter waehlen, wo vielleicht auch (um eine gewisse Stetigkeit 'reinzubekommen) der Median von 
#        # F1 ueber alle runs + Vorfaktor (z.B. 1/9) * Summe
#        # der Mediane von F1 ueber alle Runs aus allen angrenzenden Q-b-Zellen maximal wird.
#        # Jetzt erstmal so implementiert, um zu beginnen            
#        
#        dQ_r = np.zeros((n_runs))*np.nan
#        dB_r = np.zeros((n_runs))*np.nan
#        dF1_r = np.zeros((n_runs))*np.nan
#
#        ## loop trough the different runs
#        iRun = 0
#        for train_idx, test_idx in sss.split(dfFeat.values, dfLabel.label.values):
#                                
#            print('    run ' + str(iRun+1) + '/' + str(n_runs))
#
#            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
#        
#            dF1_q = np.zeros((n_q))*np.nan
#            dB_q = np.zeros((n_q))*np.nan
#        
#            ## loop through q's                                            
#            for iQ in range(n_q):
#                                                
#                dQ = dQs[iQ]
#                #print('    q=' + str(dQ))
#
#                dX_train, dX_test = dfFeat.values[train_idx, iQ], dfFeat.values[test_idx, iQ]                                
#                                                                                                                                                                                                                                                                                                                                                                                                       
#                # define optimization fct.
#                # find optimal b
#                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(self.predict_ext(dX_train.reshape(-1,1), x)-dLabel_train), ranges = ((dThresMin, dThresMax),), Ns=n_thres, full_output=True, finish=None)
#                                                            
#                dB = resMin[0]
#
#                ## calc. accuracy of the model                                                                
#                iPred = self.predict_ext(dX_test, dB)                                                        
#                    
#                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
#                
#                dB_q[iQ] = dB                                                                                                                
#                dF1_q[iQ] = dAccu[2]
#                
#            idx = np.argmax(dF1_q)
#            dQ_r[iRun] = dQs[idx]
#            dB_r[iRun] = dB_q[idx]
#            dF1_r[iRun]= dF1_q[idx]                                                     
#                                                                                                                        
#            iRun = iRun + 1
#                                            
#            
#        # TODO 2019-1-4: erstmal wie folgt gemacht, evtl. noch bessere Variante ueberlegen, welche Parameter am besten sind
#        #bTmp = dF1_r[dF1_r>0.8]
#        #if any(bTmp):
#        #    dTmp = np.unique(dB_r)        
#        #idx = np.argmax(lF1)
#        dQ_opt = np.median(dQ_r)
#        dB_opt = np.median(dB_r)
#        
#        self.predict_kwargs['dB'] = dB_opt
#        self.feat_kwargs['dQ'] = dQ_opt
#                        
#        print('opt. parameters: quantile = ' + str(dQ_opt) + ', threshold = ' + str(dB_opt) + ', F1score = ' + str(lF1[idx]))
#        
#        # save dateils to file if file name is given
##            if sFN:
##                dfRes = ...
##                dfRes.to_csv(...)
#            
#        return(self)
#




    """
    save classificator to file
    
    Christian Kuehnert, 2019-1-4
    """
    # TODO 2019-1-4: testen
    def save_classificator(self, sFileName=None):
        
        #sFN_model = sFileName + '_model'
        #joblib.dump(self.model, sFN_model)
        
        dfTmp = pd.DataFrame(columns=['parameter','value'])
        dfTmp.loc[0] = ['name', self.name]
        dfTmp.loc[1] = ['sFN_model',sFN_model]
        dfTmp.loc[2] = ['feat_fct', self.feat_fct.__str__()]
        dfTmp.loc[3] = ['dQ', self.dQ]
        dfTmp.loc[4] = ['dB', self.dB]
                
        dfTmp.to_csv(path_or_buf=sFileName, sep=';', header=True, index=False)
        
    
    
    
    """
    load model from file
    
    Christian Kuehnert, 2019-1-4
    """
    # TODOO 2019-1-4: Testen
    def load_classificator(self, sFileName = None):
        
        try:
            if os.path.isfile(sFileName):
                dfPar = pd.read_csv(filepath_or_buffer=sFileName, sep=';', header=True, index_col=None)
            
                self.name = ast.literal_eval(dfPar.loc['name'].value)
                self.feat_fct = ast.literal_eval(dfPar.loc['feat_fct'].value)
                sFN_model = dfPar.loc['sFN_model'].value
                self.model = joblib.load(sFN_model)
                
                self.dQ = dfPar.loc['dQ'].value
                self.dB = dfPar.loc['dB'].value

        
        except Exception as e:
            print('problem with loading classifier from file ' + sFileName)




















