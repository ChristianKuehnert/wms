# -*- coding: utf-8 -*-
"""

function to calculate the skewness of the differentiated time series data

@author: Christian Kuehnert, 2018-12-12
"""

import numpy as np
import pandas as pd
from scipy.stats import skew



def skewness(dTS, iOrderDiff):

#    df = dfTS.diff(periods=iOrderDiff, axis=0)
    dTmp = np.diff(dTS, n=iOrderDiff)
    dSk = skew(dTmp, axis=0, nan_policy = 'omit')

    dfRes = pd.DataFrame(columns=['order_diff', 'skewness'])
    dfRes.loc[0] = np.append(iOrderDiff, dSk)
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    dfRes['skewness'] = dfRes['skewness'].astype(float)

    return(dfRes)
    



def my_process(dfTS):
    return(None)


