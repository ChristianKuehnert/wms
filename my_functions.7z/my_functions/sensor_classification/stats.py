# -*- coding: utf-8 -*-
"""


 function to calculate the mean and variance of the (differentiated) time series 
 as well as the mean of the absolute values

 input:
       - dfTS:             ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
       - iMaxOrderDiff:    max. order of differencing, i.e. how often differences are calculated
       - iMaxMoment:       max. moment to calculate

 output:
       - dfRes:        dataframe with columns ['mean_d...', 'mean_abs_d...', 'var_d...'] containing the 
                       respective values for the respective values


@author: Christian Kuehnert, 2018-12-12

"""

import numpy as np
import pandas as pd

from scipy.stats import moment


def stats(dTS, iMaxOrderDiff, iMaxMoment):

    rD = range(iMaxOrderDiff+1)
    rM = range(1,iMaxMoment+1)
    
    sCols = list(['d'+str(d) + '_m' + str(k) for d in rD for k in rM])
    dMoments = [moment(np.diff(dTS, n=d), moment=k, axis=0, nan_policy='omit') for d in rD for k in rM]
    
    dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)    
    dfRes.loc[0] = dMoments
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    return(dfRes)

