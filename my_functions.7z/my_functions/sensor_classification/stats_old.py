# -*- coding: utf-8 -*-
"""
 function to calculate the mean and variance of the (differentiated) time series 
 as well as the mean of the absolute values

 input:
       - dfTS:         ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
       - iOrderDiff:   order of differencing, i.e. how often differences are calculated

 output:
       - dfRes:        dataframe with columns ['mean_d...', 'mean_abs_d...', 'var_d...'] containing the 
                       respective values for the respective values


@author: Christian Kuehnert, 2018-12-12

"""

import pandas as pd
import numpy as np
from scipy.stats import skew, kurtosis


def stats_old(dfTS, iOrderDiff):
    
    # TODO 2018-12-12: vielleicht allgemein bis zum n-ten Moment berechnen und damit weiterklassifizieren!?
    sCols = list(['mean', 'mean_abs', 'std_dev', 'skewness', 'kurtosis'])

    d_dTS = np.diff(dfTS, n=iOrderDiff)
    
    dMean = np.asarray(np.mean(d_dTS))
    dMeanAbs = np.asarray(np.mean(abs(d_dTS)))
    dVar = np.asarray(np.var(d_dTS, ddof=1))
    dSk = skew(d_dTS, axis=0, nan_policy = 'omit')
    dKurt = kurtosis(d_dTS, axis=0, nan_policy = 'omit')

    dfRes = pd.DataFrame(columns = ['order_diff'] + sCols)    
    dfRes.loc[0] = [iOrderDiff, dMean, dMeanAbs, dVar, dSk, dKurt]
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)

