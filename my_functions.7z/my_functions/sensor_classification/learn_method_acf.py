# -*- coding: utf-8 -*-
"""

function that does several runs with different split of data into trainings and test data and learns parameters for acf method and calculates several 
 statistics over it and produces various figures etc.

 input:
       - sss:          stratified shuffle split containing the splits for the several runs
       - dfACF_d1:     data frame containing the acf's of d1-time series
                       the headers must be of format 'acf_'+ lag-Value, e.g. 'acf_1'
       - dfLabel:      labels for the data
       - iSetMaxLags:  set with max lags to be used, all lags <= max lag will be included, TODO 20180927: spaeter umstellen auf iLags:        lags to be included
       - sKernel:      kernel to be used
       - dC:           value of dC for optimization
       - dGamma:       value of gamma for optimization

 output:


@author: Christian Kuehnert, 2018-11-23
 
"""

import warnings
import numpy as np

from sklearn.svm import SVC
from sklearn.metrics import precision_recall_fscore_support


def learn_method_acf(sss, dfACF_d1, dfLabel, dfProperties, sKernel, dC, dGamma):

    warnings.filterwarnings("ignore")
            
    dEps = 1e-6       # accuracy for comparing numerical values
           
    #dACFs = np.array(iSetMaxLags)
                                                                                      
    iNumberOfRuns = sss.get_n_splits()    
               
    ## lists of results
    lPrec = []
    lRec = []
    lF1 = []
    #lModel = []
    lPropFail = []              # list containing the properties of the wrongly classified data


    model = SVC(kernel=sKernel, C=dC, gamma=dGamma)
   
    lModel = []
    
    ## lists of results for the several runs
    lPrec = []
    lRec = []
    lF1 = []    
    lPropFail = []                          
    lModel = []
                         
    ## loop trough the different runs
    iRun = 0     
    for train_idx, test_idx in sss.split(np.zeros(dfLabel.shape), dfLabel.label.values):
         
        if ((iRun+1) % 10 == 0):                   
            print('    run ' + str(iRun+1) + '/' + str(iNumberOfRuns))
                                
        dACF_d1_train, dACF_d1_test = dfACF_d1.values[train_idx,:], dfACF_d1.values[test_idx, :]                                                                                                                                          
        dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
                                                                                                                                            
        #sSVMPars = sKernel + ', C=' + str(dC) + ', gamma=' + str(dGamma)            
        model.fit(dACF_d1_train, np.ravel(dLabel_train))
        iPred = model.predict(dACF_d1_test)
        iPred = np.reshape(iPred, (len(iPred), 1))

        bFailClass = [b[0] for b in ~np.isclose(iPred, dLabel_test, 3*dEps)]                # logical index of fail-classified data                
        dfProperties_fail = dfProperties.iloc[test_idx[bFailClass],:]                                        

        dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)            
                                                       
        lPrec.append(dAccu[0])
        lRec.append(dAccu[1])
        lF1.append(dAccu[2])
        lModel.append(model) 
        lPropFail.append([len(bFailClass), sum(bFailClass), dfProperties_fail])           
                                   
        iRun = iRun + 1
                               
    dPrec = np.hstack(lPrec)
    dRec = np.hstack(lRec)
    dF1 = np.hstack(lF1)

    return(dPrec, dRec, dF1, lPropFail, lModel)

