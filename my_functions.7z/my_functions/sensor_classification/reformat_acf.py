# -*- coding: utf-8 -*-
"""

function to reformat the acf-data from long to short table 

 input:

 output:
 
@author: Christian Kuehnert, 2018-11-22
"""


 
def reformat_acf(dfACF):             
    
    sCols = set(dfACF.columns) - set(['lag', 'acf'])
    dfRes = dfACF.pivot_table(index=list(sCols), columns=['lag'], values=['acf']).reset_index()
    dfRes.rename(columns = {'lag': 'index', 'acf': 'lag_'}, inplace=True)
    dfRes.columns = dfRes.columns.map('{0[0]}{0[1]}'.format)

    return(dfRes)
    
    
    