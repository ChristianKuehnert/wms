# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 17:32:16 2019

@author: w012028
@modified: 2019-11-22
"""
import sys
import numpy as np
#import pandas as pd

#from sklearn.pipeline import Pipeline
from sklearn.utils.validation import check_X_y #, check_array
from sklearn.utils.multiclass import unique_labels
#from sklearn.preprocessing import FunctionTransformer

#sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\functions'
#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\sensClass'
#sys.path.append(sModulePath)
#import data as mfdata

sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions\sensor_classification'
#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\sensClass'
sys.path.append(sModulePath)
from class_classifier_ts import classifier_ts





class classifier_asym(classifier_ts):
    
    """
    initialization
    
    """
#    def __init__(self, data_fct=None, feat_kwargs = {'iOrderDiff': 1, 'dQ': 0.99}, predict_kwargs = {'dB': 0.0025}, pickle_path=None):
#        
#        self.feat_kwargs = feat_kwargs
#        self.predict_kwargs = predict_kwargs
#        
#        #tmp = Pipeline([('feat_fct', classifier_asym.feat_fct(**feat_kwargs)), ('predict_fct', classifier_asym.predict_fct(**predict_kwargs))], memory=None)
#        #tmp = Pipeline([('feat_fct', FunctionTransformer(self.calculate_features, validate=False)), ('predict_fct', FunctionTransformer(self.predict, validate=False))], memory=None)
#        
#        super().__init__(name = 'asym', 
#                         #data_fct=data_fct,
#                         #model_pipeline=tmp,
#                         feat_fct = self.calculate_features,
#                         predict_fct = self.predict,
#                         pickle_path=pickle_path)
                
    def __init__(self, iOrderDiff=1, dQ=0.99, dB=0.0025, pickle_path=None):
        
        #self.feat_kwargs = feat_kwargs
        #self.predict_kwargs = predict_kwargs
        
        #tmp = Pipeline([('feat_fct', classifier_asym.feat_fct(**feat_kwargs)), ('predict_fct', classifier_asym.predict_fct(**predict_kwargs))], memory=None)
        #tmp = Pipeline([('feat_fct', FunctionTransformer(self.calculate_features, validate=False)), ('predict_fct', FunctionTransformer(self.predict, validate=False))], memory=None)
        self.iOrderDiff = iOrderDiff
        self.dQ = dQ
        self.dB = dB
        
        super().__init__(name = 'asym', 
                         #data_fct=data_fct,
                         #model_pipeline=tmp,
                         feat_fct = self.calculate_features,
                         predict_fct = self.predict,
                         pickle_path=pickle_path)
        
        

            
#    """
#    function to calculate the differences between quantile for positive values and quantiles for negative values as features
#    
#    @author: Christian Kuehnert, 2019-3-13
#    
#    Parameters:
#    -----------
#    
#    dTS:            time series
#    iOrderDiff:     order of difference that should be applied to time series
#    dQ:             quantile for which the values should be calculated
#    
#    """
#    # TODO 2018-12-13: so aendern, dass kein df sondern ein np.array zurueckgegeben wird, welches man direkt fuer die Klassifikation einlesen kann
#    def feat_fct(dTS, iOrderDiff = None, dQs = None):
#    
##        if not iOrderDiff:
##            iOrderDiff = self.iOrderDiff
##            
##        if not dQs:
##            dQs = [self.dQ]                                           
#        d_dTS = np.diff(dTS, n=iOrderDiff, axis=0)            
#        d_dTS = d_dTS[~np.isnan(d_dTS)]
#        d_dTS = d_dTS / np.linalg.norm(d_dTS, ord=2, axis=0)
#        
#        d_dTS_pos = d_dTS[d_dTS>0]
#        d_dTS_neg = -d_dTS[d_dTS<0]
#
#        lDiff = []
#        for q in dQs:
#            
#            #d1 = np.percentile(d_dTS_pos, q*100, axis=0)            
#            #d3 = np.percentile(d_dTS_neg, q*100, axis=0)                                    
#            lDiff.append(abs(np.percentile(d_dTS_pos, q*100, axis=0) - np.percentile(d_dTS_neg, q*100, axis=0)))            
#
#        return(lDiff)
        
        



#    """
#    calculate features
#    
#    Christian Kuehnert, 2019-1-2
#    
#    """
#    def calculate_features(self, dTS = None):        
#        #return(self.feat_fct(dTS = dTS, iOrderDiff = self.iOrderDiff, dQs = [self.dQ]))
#        return(self.feat_fct(dTS = dTS, iOrderDiff = self.feat_kwargs['iOrderDiff'], dQs = [self.feat_kwargs['dQ']]))


  
  



    """
    calculate features
    
    """
    def calculate_features(self, dTS = None):
            
        dRes = None

        if dTS is not None:    
            d_dTS = np.diff(dTS, n=self.iOrderDiff, axis=0)            
            d_dTS = d_dTS[~np.isnan(d_dTS)]
            
            nl = np.linalg.norm(d_dTS, ord=2, axis=0)
            if nl>0:
                d_dTS = d_dTS / nl
            
                d_dTS_pos = d_dTS[d_dTS>0]
                d_dTS_neg = -d_dTS[d_dTS<0]
    
                dRes = abs(np.percentile(d_dTS_pos, self.dQ*100, axis=0) - \
                           np.percentile(d_dTS_neg, self.dQ*100, axis=0))
                
        return(dRes)



      
        
    
    """
    train model

    """                
    def fit(self, X, y):
        X, y = check_X_y(X, y)              # test if X and y have consistent shape
        
        self.classes_ = unique_labels(y)    # store the classes seen during fit
        
        self.X_ = X
        self.y_ = y
        
        return(self)




    """
    predict
    
    overwrites super.predict, check if fitted already is excluded, in this case use default values
    function to calculate the differences between quantile for positive values and quantiles for negative values
    TODO 2018-12-14: evtl. spaeter anders machen
    """
    def predict(self, X):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        #X = check_array(X)                      # check if X is correct input
        
        iPred = (X > self.dB).astype(int)
        
        return(iPred)
    



    """
    predict with external threshold
    
    overwrites super.predict, check if fitted already is excluded, in this case use default values
    function to calculate the differences between quantile for positive values and quantiles for negative values
    TODO 2018-12-14: evtl. spaeter anders machen
    """
    def predict_ext(self, X, dB):
#        pass
        
        # TODO 2018-12-13: wenn nicht, dann default-Werte benutzen im Fall von asym-Classificator
        #check_is_fitted(self, ['X_', 'y_'])     # check if fit has been called
                
        #X = check_array(X)                      # check if X is correct input
        
        iPred = (X > dB).astype(int)
        
        return(iPred)
    


   


    """
    function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
    statistics over it and produces various figures etc.
    
    @author: Christian Kuehnert, 2019-1-7
    
    input:
        - sss:          stratified shuffle split containing the splits for the several runs
        #- dfFeat:       pd.DataFrame containing the features, THESE FEATURES MUST BE CONSISTENT WITH dQs, i.e. column i in dfFeat must correspond with element i of dQs
        - dfFeat:       pd.DataFrame containing the features, THIS DataFrame MUST HAVE THE dQs-values AS COLUMN NAMES (numeric, not as strings!)

    output:
        
        
    """
    def train_classifier(self, sss = None, dfFeat = None, dfLabel = None, dictClassTrain = None):
                
        warnings.filterwarnings("ignore")     
        
        #dEps = 1e-6       # accuracy for comparing numerical values
        #dEps = np.max([np.finfo(type(dQs_cols[0])).eps, np.finfo(type(dSetQs[0])).eps])
    
        ## lists of results
        lB = []
        lF1 = []
    
        #if not(dThresMin) or not(dThresMax):
        #    dfTmp0 = dfFeat[dfLabel.label==0]
        #    dfTmp1 = dfFeat[dfLabel.label==1]                                                
                
        dThresMin = dictClassTrain['dThresMin']
        dThresMax = dictClassTrain['dThresMax']
        n_thres = dictClassTrain['n_thres']
        
        if not(dThresMin):
            # dThresMin = dfFeat.values.min()
            dThresMin = dfFeat[dfLabel.label==1].values.min()
            
        if not(dThresMax):
            #dThresMax = dfFeat.values.max()
            dThresMax = dfFeat[dfLabel.label==0].values.max()
        
        if not(n_thres):
            n_thres = 10
        
            
            
        #dThres = [dThresMin + iIdx * (dThresMax-dThresMin) / n_thres for iIdx in range(n_thres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold            

        dQs = dfFeat.columns
        n_q = len(dQs)
        # TODO 2019-1-4: EVTL.(!) hier noch Fall abfangen, dass die columns nicht die dQs enthalten
            
        #dQs.sort()
        n_runs = sss.get_n_splits()    
                       
        # ggf. anders versuchen, z.B. erst fuer alle Kombinationen {dQs} x {dBs} jeweils fuer alle Runs die Accuracy berechnen,
        # dann die Q-b-Kombination waehlen, fuer welche die meisten Runs optimal sind bzw. wo der Median aus den F1 ueber alle runs maximal ist
        # dann die Parameter waehlen, wo vielleicht auch (um eine gewisse Stetigkeit 'reinzubekommen) der Median von 
        # F1 ueber alle runs + Vorfaktor (z.B. 1/9) * Summe
        # der Mediane von F1 ueber alle Runs aus allen angrenzenden Q-b-Zellen maximal wird.
        # Jetzt erstmal so implementiert, um zu beginnen            
        
        dQ_r = np.zeros((n_runs))*np.nan
        dB_r = np.zeros((n_runs))*np.nan
        dF1_r = np.zeros((n_runs))*np.nan

        ## loop trough the different runs
        iRun = 0
        for train_idx, test_idx in sss.split(dfFeat.values, dfLabel.label.values):
                                
            print('    run ' + str(iRun+1) + '/' + str(n_runs))

            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
        
            dF1_q = np.zeros((n_q))*np.nan
            dB_q = np.zeros((n_q))*np.nan
        
            ## loop through q's                                            
            for iQ in range(n_q):
                                                
                dQ = dQs[iQ]
                #print('    q=' + str(dQ))

                dX_train, dX_test = dfFeat.values[train_idx, iQ], dfFeat.values[test_idx, iQ]                                
                                                                                                                                                                                                                                                                                                                                                                                                       
                # define optimization fct.
                # find optimal b
                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(self.predict_ext(dX_train.reshape(-1,1), x)-dLabel_train), ranges = ((dThresMin, dThresMax),), Ns=n_thres, full_output=True, finish=None)
                                                            
                dB = resMin[0]

                ## calc. accuracy of the model                                                                
                iPred = self.predict_ext(dX_test, dB)                                                        
                    
                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
                
                dB_q[iQ] = dB                                                                                                                
                dF1_q[iQ] = dAccu[2]
                
            idx = np.argmax(dF1_q)
            dQ_r[iRun] = dQs[idx]
            dB_r[iRun] = dB_q[idx]
            dF1_r[iRun]= dF1_q[idx]                                                     
                                                                                                                        
            iRun = iRun + 1
                                            
            
        # TODO 2019-1-4: erstmal wie folgt gemacht, evtl. noch bessere Variante ueberlegen, welche Parameter am besten sind
        #bTmp = dF1_r[dF1_r>0.8]
        #if any(bTmp):
        #    dTmp = np.unique(dB_r)        
        #idx = np.argmax(lF1)
        dQ_opt = np.median(dQ_r)
        dB_opt = np.median(dB_r)
        
        self.predict_kwargs['dB'] = dB_opt
        self.feat_kwargs['dQ'] = dQ_opt
                        
        print('opt. parameters: quantile = ' + str(dQ_opt) + ', threshold = ' + str(dB_opt) + ', F1score = ' + str(lF1[idx]))    
            
        return(self)


#
#    """
#    function that does several runs with different split of data into trainings and test data and learns parameters for skewness method and calculates several 
#    statistics over it and produces various figures etc.
#    
#    @author: Christian Kuehnert, 2019-1-4
#    
#    input:
#        - sss:          stratified shuffle split containing the splits for the several runs
#        #- dfFeat:       pd.DataFrame containing the features, THESE FEATURES MUST BE CONSISTENT WITH dQs, i.e. column i in dfFeat must correspond with element i of dQs
#        - dfFeat:       pd.DataFrame containing the features, THIS DataFrame MUST HAVE THE dQs-values AS COLUMN NAMES (numeric, not as strings!)
#
#    output:
#        
#        
#    """
#    def train_classifier(self, sss = None, dfFeat = None, dfLabel = None, dThresMin = None, dThresMax = None, n_thres = 10, sFN = None):
#                
#        warnings.filterwarnings("ignore")     
#        
#        #dEps = 1e-6       # accuracy for comparing numerical values
#        #dEps = np.max([np.finfo(type(dQs_cols[0])).eps, np.finfo(type(dSetQs[0])).eps])
#    
#        ## lists of results
#        lB = []
#        lF1 = []
#    
#        #if not(dThresMin) or not(dThresMax):
#        #    dfTmp0 = dfFeat[dfLabel.label==0]
#        #    dfTmp1 = dfFeat[dfLabel.label==1]                                                
#                
#        if not(dThresMin):
#            # dThresMin = dfFeat.values.min()
#            dThresMin = dfFeat[dfLabel.label==1].values.min()
#            
#        if not(dThresMax):
#            #dThresMax = dfFeat.values.max()
#            dThresMax = dfFeat[dfLabel.label==0].values.max()
#        
#            
#            
#        #dThres = [dThresMin + iIdx * (dThresMax-dThresMin) / n_thres for iIdx in range(n_thres)]    # array of threshold steps for later images prec., rec., F1 vs. threshold            
#
#        dQs = dfFeat.columns
#        n_q = len(dQs)
#        # TODO 2019-1-4: EVTL.(!) hier noch Fall abfangen, dass die columns nicht die dQs enthalten
#            
#        #dQs.sort()
#        n_runs = sss.get_n_splits()    
#                       
#        # ggf. anders versuchen, z.B. erst fuer alle Kombinationen {dQs} x {dBs} jeweils fuer alle Runs die Accuracy berechnen,
#        # dann die Q-b-Kombination waehlen, fuer welche die meisten Runs optimal sind bzw. wo der Median aus den F1 ueber alle runs maximal ist
#        # dann die Parameter waehlen, wo vielleicht auch (um eine gewisse Stetigkeit 'reinzubekommen) der Median von 
#        # F1 ueber alle runs + Vorfaktor (z.B. 1/9) * Summe
#        # der Mediane von F1 ueber alle Runs aus allen angrenzenden Q-b-Zellen maximal wird.
#        # Jetzt erstmal so implementiert, um zu beginnen            
#        
#        dQ_r = np.zeros((n_runs))*np.nan
#        dB_r = np.zeros((n_runs))*np.nan
#        dF1_r = np.zeros((n_runs))*np.nan
#
#        ## loop trough the different runs
#        iRun = 0
#        for train_idx, test_idx in sss.split(dfFeat.values, dfLabel.label.values):
#                                
#            print('    run ' + str(iRun+1) + '/' + str(n_runs))
#
#            dLabel_train, dLabel_test = dfLabel.values[train_idx], dfLabel.values[test_idx]
#        
#            dF1_q = np.zeros((n_q))*np.nan
#            dB_q = np.zeros((n_q))*np.nan
#        
#            ## loop through q's                                            
#            for iQ in range(n_q):
#                                                
#                dQ = dQs[iQ]
#                #print('    q=' + str(dQ))
#
#                dX_train, dX_test = dfFeat.values[train_idx, iQ], dfFeat.values[test_idx, iQ]                                
#                                                                                                                                                                                                                                                                                                                                                                                                       
#                # define optimization fct.
#                # find optimal b
#                resMin = scipy.optimize.brute(lambda x: np.linalg.norm(self.predict_ext(dX_train.reshape(-1,1), x)-dLabel_train), ranges = ((dThresMin, dThresMax),), Ns=n_thres, full_output=True, finish=None)
#                                                            
#                dB = resMin[0]
#
#                ## calc. accuracy of the model                                                                
#                iPred = self.predict_ext(dX_test, dB)                                                        
#                    
#                dAccu = precision_recall_fscore_support(dLabel_test, iPred, average = 'binary', pos_label=1)
#                
#                dB_q[iQ] = dB                                                                                                                
#                dF1_q[iQ] = dAccu[2]
#                
#            idx = np.argmax(dF1_q)
#            dQ_r[iRun] = dQs[idx]
#            dB_r[iRun] = dB_q[idx]
#            dF1_r[iRun]= dF1_q[idx]                                                     
#                                                                                                                        
#            iRun = iRun + 1
#                                            
#            
#        # TODO 2019-1-4: erstmal wie folgt gemacht, evtl. noch bessere Variante ueberlegen, welche Parameter am besten sind
#        #bTmp = dF1_r[dF1_r>0.8]
#        #if any(bTmp):
#        #    dTmp = np.unique(dB_r)        
#        #idx = np.argmax(lF1)
#        dQ_opt = np.median(dQ_r)
#        dB_opt = np.median(dB_r)
#        
#        self.predict_kwargs['dB'] = dB_opt
#        self.feat_kwargs['dQ'] = dQ_opt
#                        
#        print('opt. parameters: quantile = ' + str(dQ_opt) + ', threshold = ' + str(dB_opt) + ', F1score = ' + str(lF1[idx]))
#        
#        # save dateils to file if file name is given
##            if sFN:
##                dfRes = ...
##                dfRes.to_csv(...)
#            
#        return(self)
#

