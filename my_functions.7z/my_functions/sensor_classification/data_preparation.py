# -*- coding: utf-8 -*-
"""
Created on Wed Aug 26 14:25:34 2020

@author: w012028
"""

# collect raw data and intermediate data
import sys
import pandas as pd
from itertools import chain
from os.path import isfile
sModulePath = (r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer'
               r'_CK\Repositories\python\my_functions')
sys.path.append(sModulePath)
from data.query_tableData_PIT import query_tableData_PIT
from data.myprint import myprint
from data.filter_data import filter_data
from data.update_hd5 import update_ts, update_cdef
from data.class_hd5Nodes import hd5Nodes as sNodes
from sensor_classification.check_ts import calc_ts_properties

#from monitor import get_turbines_and_tickets_for_monitoring, get_relevant_tickets, get_turbine_info, get_ticket_times

# TODO 2020-8-25: ueberall noch zu perzentilen uebergehen, im header diese in int verwandeln (float wie bisher bei quantilen ist eher unguenstig), an allen relevanten stellen anpassen

def prepare_data2(fn_full, list_requests, dict_fcts, filter_cdef = None,
                  path_data = (r'C:\Users\w012028\Documents\CK\data\data__ts'),
                  b_update_ts=True, try_2_if_wrong_availability_values = False):

    #fn_all = 'all_turbines.csv'
    #fn_full = f'{path_dest}\\{fn_all}'
    #if fn_all in os.listdir(path_dest):
    if isfile(fn_full):
        if fn_full[-4:]=='.csv':
            df_all = pd.read_csv(fn_full, sep=';', header=0)
            df_all['create_time']=pd.to_datetime(df_all['create_time'], format="%Y-%m-%d %H:%M:%S")
        
        elif fn_full[-4:]=='.pkl':            
            df_all = pd.read_pickle(fn_full)
            
        else:
            print(f"can't find {fn_full}")

        # rename columns from string names (necessary for .csv) to (order, quantile) for dataframe
        #repl = {c: (c.split('_')[1], c.split('_')[2]) for c in df_all.columns if c.find('asym')>-1}
        #df_all.rename(columns = repl, inplace=True)
        
    else:
        # collect data
        if b_update_ts:
            for db, start_date, end_date, req in list_requests:
                print(f'start update ts {db}')
                try:
                    if start_date is None:
                        sstart = "start"
                    else:
                        sstart = f"{start_date.strftime('%Y-%m-%d %H:%M:%S')}"

                    if end_date is None:
                        send = "now"
                    else:
                        send = f"{end_date.strftime('%Y-%m-%d %H:%M:%S')}"

                    print(f"{req}: {db},  {sstart}... {send}")

                    update_cdef(db, path_data, time_start=start_date, time_end=end_date)
                    update_ts(db, path_data, time_start=start_date, 
                              time_end=end_date, filter_cdef = filter_cdef,
                              try_2_if_wrong_availability_values = try_2_if_wrong_availability_values)
                except:
                    print(f'problems collecting data for {db}')


        # calculate intermediate values (if not already existent)
        res_all = list()
        
        fields_pit = ['Windpark_WEA#Windparkname', 'WEA_Name', 'WEA_Typ#Name', 
              'Datenbankname', 'WEA_Typ#Rotorblatt_Typ#Name']
        where_clause = "Datenbankname in ('" + "','".join([x[0] for x in list_requests]) + "')"
        df_turbines = query_tableData_PIT('VIEW_Windkraftanlagen', fields_pit, where_clause)        
        
        for db, start_date, end_date, req in list_requests:

            print(f'start analysis {db}')

            try:            
                tb = df_turbines[df_turbines.Datenbankname == db]

                farm = tb['Windpark_WEA#Windparkname'].values[0]
                name = tb['WEA_Name'].values[0]
                type_turbine = tb['WEA_Typ#Name'].values[0]
                type_blades = tb['WEA_Typ#Rotorblatt_Typ#Name'].values[0]

                if start_date is None:
                    sstart = "start"
                else:
                    sstart = f"{start_date.strftime('%Y-%m-%d %H:%M:%S')}"

                if end_date is None:
                    send = "now"
                else:
                    send = f"{end_date.strftime('%Y-%m-%d %H:%M:%S')}"

                

                fn_hd5 = f'{path_data}\\{db}.hd5'

                # check the stored at-data
                #res = list()
                count = 1
                col_headers = dict_fcts.keys()
                with pd.HDFStore(fn_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

                    node_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
                    node_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts

                    if (node_ts_data in f):    
                        #bCycEx = True
                        df_cyc = f.select(key=node_ts_startstop)
                        
                        # filter data                             
                        df_cyc = df_cyc[df_cyc.channel.between(0,5)]
                        if not(start_date is None):
                            df_cyc = df_cyc[df_cyc.create_time>=start_date]
                        if not(end_date is None):
                            df_cyc = df_cyc[df_cyc.create_time<=end_date]
                            
                        # TODO 2020-9-2: evtl. hier noch einbauen, zuerst muesste ja nach cdef gefiltert werden und dann danach die df_cyc
                        #if not(filter_cdef is None):
                        #    df_cyc, _s = filter_data(df_cyc, filter_cdef)

                        print(f"{req}: {db},  {sstart}... {send} ({df_cyc.shape[0]} data)")
                        #print(f'letzter Zeitpunkt: {df_cyc.create_time.max()}')
                        for idx, cyc in df_cyc.iterrows():                            

                            if count % 20 == 0:
                                myprint(f'{count}/{df_cyc.shape[0]}')

                            try:
                                tsCT = cyc['create_time']
                                iID = cyc['ID']
                                iCh = cyc['channel']

                                df_ts = f.select(node_ts_data, start = cyc['start'], stop=cyc['stop'])
                                #df_ts.sort_values(by=['time'], inplace=True)

                                ## now calculate the features
                                #dres = check_ts(df_ts.a_t, min_no_elements=500, max_slope=1000, 
                                #                min_se=10, dQ=0.99, asym_thres=0.0025)
                                #no_false = 4-sum(dres['checks'])
                                #for header in headers_fcts:
                                # tuple of function results
                                
                                #dres = [dict_fcts[h](df_ts) for h in col_headers]
                                dres = [dict_fcts[h](df_ts.a_t.values) for h in col_headers]
                                
                                #dres = calc_ts_properties(df_ts.a_t, list_asym_pars)
                                
                                #res.append((farm, name, db, type_turbine, type_blades, tsCT, iID, iCh, no_false)+dres['values'] + dres['checks'])
                                res_all.append(tuple(chain([farm, name, db, type_turbine, type_blades, tsCT, iID, iCh], dres)))
                            except:
                                myprint(f'problem with ts {count}')

                            count += 1

                #df_res = pd.DataFrame.from_records(res, columns = ['farm', 'turbine', 'db', 'type_turbine', 'type_blades', 'create_time', 'ID', 'channel', 'Anz_checks_failed', 'no_el', 'max_slope', 'sum_se', 'asym', 'no_el_pass', 'max_slope_pass', 'min_se_pass', 'asym_pass'])

                #fn_res = f'{path_dest}\\{db}_results.csv'
                #df_res.to_csv(fn_res, sep=';', index=False)

            except:
                print(f'problems evaluating {db} at {count}')

    # TODO 2020-8-27: hier noch richtig machen: return df mit (o,q)-headers,
    # csv mit o_q-headers
        #col_headers = [f'asym_{o}_{q}' for (o,q) in list_asym_pars]
        df_all = pd.DataFrame.from_records(res_all, columns = ['farm', 'turbine', 'db', 'type_turbine', 'type_blades', 'create_time', 'ID', 'channel'] + list(col_headers))
        
        if fn_full[-4:]=='.pkl':              
            df_all.to_pickle(fn_full)               # pickle result
        elif fn_full[-4:]=='.csv':
            df_all.to_csv(fn_full, sep=';', index=False)
        else:
            print(f"handling of ending {fn_full[-4:]} not implemented, save as pickled file")
            df_all.to_pickle(f'{fn_full}.pkl')               # pickle result

    return(df_all)    
    
    
    
    

def prepare_data2_old(fn_full, list_requests, filter_cdef=None, list_asym_pars = [(1, .99)],
                 path_data = (r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500'
                              r'_Arbeitsunterlagen\Transfer_CK\defekteMessstrecke\Dehn'
                              r'messstreifen\data'),
                 b_update_ts=True):

    #fn_all = 'all_turbines.csv'
    #fn_full = f'{path_dest}\\{fn_all}'
    #if fn_all in os.listdir(path_dest):
    if isfile(fn_full):
        df_all = pd.read_csv(fn_full, sep=';', header=0)
        df_all['create_time']=pd.to_datetime(df_all['create_time'], format="%Y-%m-%d %H:%M:%S")
        
        # rename columns from string names (necessary for .csv) to (order, quantile) for dataframe
        repl = {c: (c.split('_')[1], c.split('_')[2]) for c in df_all.columns if c.find('asym')>-1}
        df_all.rename(columns = repl, inplace=True)
        
    else:
        # collect data
        if b_update_ts:
            for db, start_date, end_date, req in list_requests:
                print(f'start update ts {db}')
                try:
                    if start_date is None:
                        sstart = "start"
                    else:
                        sstart = f"{start_date.strftime('%Y-%m-%d %H:%M:%S')}"

                    if end_date is None:
                        send = "now"
                    else:
                        send = f"{end_date.strftime('%Y-%m-%d %H:%M:%S')}"

                    print(f"{req}: {db},  {sstart}... {send}")

                    update_cdef(db, path_data, time_start=start_date, time_end=end_date)
                    update_ts(db, path_data, time_start=start_date, 
                              time_end=end_date, filter_cdef = filter_cdef)
                except:
                    print(f'problems collecting data for {db}')


        # calculate intermediate values (if not already existent)
        res_all = list()
        
        fields_pit = ['Windpark_WEA#Windparkname', 'WEA_Name', 'WEA_Typ#Name', 
              'Datenbankname', 'WEA_Typ#Rotorblatt_Typ#Name']
        where_clause = "Datenbankname in ('" + "','".join([x[0] for x in list_requests]) + "')"
        df_turbines = query_tableData_PIT('VIEW_Windkraftanlagen', fields_pit, where_clause)        
        
        for db, start_date, end_date, req in list_requests:

            print(f'start analysis {db}')

            try:            
                tb = df_turbines[df_turbines.Datenbankname == db]

                farm = tb['Windpark_WEA#Windparkname'].values[0]
                name = tb['WEA_Name'].values[0]
                type_turbine = tb['WEA_Typ#Name'].values[0]
                type_blades = tb['WEA_Typ#Rotorblatt_Typ#Name'].values[0]

                if start_date is None:
                    sstart = "start"
                else:
                    sstart = f"{start_date.strftime('%Y-%m-%d %H:%M:%S')}"

                if end_date is None:
                    send = "now"
                else:
                    send = f"{end_date.strftime('%Y-%m-%d %H:%M:%S')}"

                print(f"{req}: {db},  {sstart}... {send}")

                fn_hd5 = f'{path_data}\\{db}.hd5'

                # check the stored at-data
                #res = list()
                count = 1
                with pd.HDFStore(fn_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

                    node_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
                    node_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts

                    if (node_ts_data in f):    
                        #bCycEx = True
                        df_cyc = f.select(key=node_ts_startstop)
                        
                        # TODO 2020-8-19: filter noch richtig einbauen, ausserdem hier und bei update hd5 noch
                        # Kompression einbauen
                        #if not(filter_cdef is None):
                        #    df_cyc, _s = filter_data(df_cyc, filter_cdef)
                             
                        #df_cyc = dfCycTSEx.copy()
                        df_cyc = df_cyc[df_cyc.channel.between(0,5)]
                        if not(start_date is None):
                            df_cyc = df_cyc[df_cyc.create_time>=start_date]
                        if not(end_date is None):
                            df_cyc = df_cyc[df_cyc.create_time<=end_date]

                        print(f'letzter Zeitpunkt: {df_cyc.create_time.max()}')
                        for idx, cyc in df_cyc.iterrows():                            

                            if count % 20 == 0:
                                myprint(f'{count}/{df_cyc.shape[0]}')

                            try:
                                tsCT = cyc['create_time']
                                iID = cyc['ID']
                                iCh = cyc['channel']

                                df_ts = f.select(node_ts_data, start = cyc['start'], stop=cyc['stop'])
                                #df_ts.sort_values(by=['time'], inplace=True)

                                ## now calculate the features
                                #dres = check_ts(df_ts.a_t, min_no_elements=500, max_slope=1000, 
                                #                min_se=10, dQ=0.99, asym_thres=0.0025)
                                #no_false = 4-sum(dres['checks'])
                                dres = calc_ts_properties(df_ts.a_t, list_asym_pars)
                                
                                #res.append((farm, name, db, type_turbine, type_blades, tsCT, iID, iCh, no_false)+dres['values'] + dres['checks'])
                                res_all.append(tuple(chain([farm, name, db, type_turbine, type_blades, tsCT, iID, iCh], dres)))
                            except:
                                myprint(f'problem with ts {count}')

                            count += 1

                #df_res = pd.DataFrame.from_records(res, columns = ['farm', 'turbine', 'db', 'type_turbine', 'type_blades', 'create_time', 'ID', 'channel', 'Anz_checks_failed', 'no_el', 'max_slope', 'sum_se', 'asym', 'no_el_pass', 'max_slope_pass', 'min_se_pass', 'asym_pass'])

                #fn_res = f'{path_dest}\\{db}_results.csv'
                #df_res.to_csv(fn_res, sep=';', index=False)

            except:
                print(f'problems evaluating {db} at {count}')

    # TODO 2020-8-27: hier noch richtig machen: return df mit (o,q)-headers,
    # csv mit o_q-headers
        col_headers = [f'asym_{o}_{q}' for (o,q) in list_asym_pars]
        df_all = pd.DataFrame.from_records(res_all, columns = ['farm', 'turbine', 'db', 'type_turbine', 'type_blades', 'create_time', 'ID', 'channel', 'no_el', 'max_slope', 'sum_se'] + col_headers)
        df_all.to_csv(fn_full, sep=';', index=False)
    
    return(df_all)    
    
    
    
    
    
"""
function to load a single at from the hd5 files, no update of hd5 (data must
have been collected previously)
@modified: 2020-8-28
"""
def load_at(db, create_time, channels = range(6), 
            path_data = (r'C:\Users\w012028\Documents\CK\data\data__ts')):

    res = dict()
    try:
        fn_hd5 = f'{path_data}\\{db}.hd5'
        with pd.HDFStore(fn_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

            node_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
            node_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts

            if (node_ts_data in f):    
                #bCycEx = True
                df_cyc = f.select(key=node_ts_startstop)
                        
                df_cyc = df_cyc[df_cyc.channel.isin(channels)]
                df_cyc = df_cyc[df_cyc.create_time==create_time]

                for idx, cyc in df_cyc.iterrows():                            
                    try:
                        ch = cyc['channel']
                        df_ts = f.select(node_ts_data, start = cyc['start'], stop=cyc['stop'])                    
                        res.update({ch: df_ts})
                    except:
                        print(f'problem with index {idx}')
                    #    df_ts = None                    
    except:
        print(f'problems evaluating {db} at {create_time}, channels {channels}')
            
    return(res)
    
    
    
    
    
    
    
"""
function to load the cdef data with columns for all turbines in dbs, filtered by filter and for the given period

@modified: 2020-8-26
"""
def load_cdef_data(dbs, columns=None, filters=None, period=None, 
                   path_data = (r'C:\Users\w012028\Documents\CK\data\data__ts')):
    node_cdef = sNodes.cdef
    res = list()
    for db in dbs:
        try:
            fn_hd5 = f'{path_data}\\{db}.hd5'
            with pd.HDFStore(fn_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:
                df = f.select(node_cdef)

            if not(period is None):
                if not(period[0] is None):
                    df = df[df.create_time>=period[0]]
                if not(period[1] is None):
                    df = df[df.create_time<=period[1]]

            df, _f = filter_data(df, filters)
            if not(columns is None):
                cols = set(columns).intersection(df.columns).union(['create_time', 'ID'])
                df = df.loc[:, cols]
            df = df.assign(db = db)
            res.append(df)
    
        except:
            print(f'probem with extracting cdef data for {db}')

    try:
        df_res = pd.concat(res, axis=0)
        df_res.index = range(df_res.shape[0])
    except:
        df_res = pd.DataFrame(columns = columns)

    return(df_res)
    
    
    