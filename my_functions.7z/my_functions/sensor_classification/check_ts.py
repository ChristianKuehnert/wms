# -*- coding: utf-8 -*-


## import necessary libraries
import pandas as pd
import numpy as np
from numpy import unique
from numpy.linalg import norm
from datetime import datetime as dt

from .asym_feat import asym_feat



"""
function to check if series show anomalies:
    - if it contains a minimum number of unique elements
        (returns True) or not (returns False)

@modified: 2020-5-6
"""
def check_ts(ts, min_no_elements=20, max_slope=1000, min_se=10, dQ=0.99,
             asym_thres=0.0025):
    
    # check for minimal number of unique elements
    no_el = len(unique(ts))
    b_no_el = (no_el>=min_no_elements)


    # check for max. abs value of slope
    dts = np.diff(ts)
    ms = max(abs(dts))
    b_ms = (ms<=max_slope)

    # check if series has reasonable amount of signal energy (i.e. larger or 
    # equal than a lower threshold
    se = norm(ts)
    b_se = (se>=min_se)
    
    # check for asymmetry
    dts = dts[~np.isnan(dts)]   # drop na's            
    nl = norm(dts, ord=None, axis=0)
    if nl>0:
        dts = dts / nl
            
        dts_pos = dts[dts>0]
        dts_neg = -dts[dts<0]
    
        asym = abs(np.percentile(dts_pos, dQ*100, axis=0) - \
                   np.percentile(dts_neg, dQ*100, axis=0))

        b_asym = (asym <= asym_thres)

    else:
        asym = pd.nan
        b_asym = None
        
    return({'values': (no_el, ms, se, asym), 'checks': (b_no_el, b_ms, b_se, b_asym)})
#






"""
function to calculate several quantities related to the time series

returned is a vector res with:
    res[0]:     no. of unique elements
    res[1]:     max. abs slope
    res[2]:     signal energy
    res[3..n]:  aymmetry for the given parameter combinations

@modified: 2020-8-24
"""
def calc_ts_properties(ts, params = [(0, .9), (1, .9), (2, .9), 
                                     (0, .95), (1, .95), (2, .95), 
                                     (0, .99), (1, .99), (2, .99)]):
    
    res = np.empty((3+len(params)))
    res.fill(np.nan)
    
    # number of unique elements
    res[0] = len(unique(ts))

    # max. abs value of slope
    dts = np.diff(ts)
    res[1] = max(abs(dts))

    # amount of signal energy
    res[2] = norm(ts)
    
    # asymmetry values
    i = 3
    for (order, quantile) in params:
        dts = np.diff(ts, n=order)
        dts = dts[~np.isnan(dts)]   # drop na's            
        nl = norm(dts, ord=None, axis=0)
        if nl>0:
            dts = dts / nl                
            dts_pos = dts[dts>0]
            # TODO 2020-8-25: nochmal ueberlegen, ob das so richtig/sinnvoll ist
            if len(dts_pos)==0:
                qp = 0
            else:
                qp = np.percentile(dts_pos, quantile*100, axis=0)
            
            dts_neg = -dts[dts<0]
            # TODO 2020-8-25: nochmal ueberlegen, ob das so richtig/sinnvoll ist
            if len(dts_neg)==0:
                qn = 0
            else:
                qn = np.percentile(-dts[dts<0], quantile*100, axis=0)
            
            res[i] = abs(qp-qn)

        i += 1
        
    return(res)




"""
function to check the time series in a csv file that was downloaded from webAna
@modified: 2020-7-1
"""
def check_downloaded_csv(db, fn_csv):
    
    # load data
    df = pd.read_csv(fn_csv, sep=',', header=0)

    # get create time from epoch time
    time_e = df.epoch.min()
    tsCT = dt.fromtimestamp(time_e/1000)    
    iID = ''
    res = list()
    for iCh in range(6):
        col = f'Channel-{iCh}'
        
        ts = df.loc[:, col].values
            
        ## now calculate the features
        dres = check_ts(ts, min_no_elements=500, max_slope=1000, 
                        min_se=10, dQ=0.99, asym_thres=0.0025)
        no_false = 4-sum(dres['checks'])
        res.append((db, tsCT, iID, iCh, no_false)+dres['values'] + dres['checks'])
                
    df_res = pd.DataFrame.from_records(res, 
                                       columns = ['db', 'create_time', 'ID', 
                                                  'channel', 
                                                  'Anz_checks_failed', 'no_el', 
                                                  'max_slope', 'sum_se', 
                                                  'asym', 'no_el_pass', 
                                                  'max_slope_pass', 
                                                  'min_se_pass', 'asym_pass'])

    return(df_res)








"""
function to calculate the number of elements
@modified: 2020-8-28
"""
def num_el(ts):
    # number of unique elements
    #return(ts.nunique())
    return(np.unique(ts).size)

"""
function to calc the max. slope
@modified: 2020-8-28
"""
def max_slope(ts):
    return(max(abs(np.diff(ts))))

"""
function to calculate the mean(abs(at))
@modified: 2020-8-28
"""
def mean_abs(ts):
    return(np.mean(abs(ts)))


"""
function to calculate the skewness

"""
def skew(ts):
    try:
        return((np.mean(ts)-np.median(ts))/np.std(ts))
    except:
        return(np.nan)
        

"""
bandwidth
"""
def bandwidth(ts):
    return(max(ts)-min(ts))


"""
max plateau length
"""
def plateau_max(ts):    
    d2ts = np.diff(list(map(int, np.diff(ts,prepend=ts[0]-1, append=ts[-1]+1)==0)))
    starts, = np.where(d2ts > 0)
    ends, = np.where(d2ts < 0)
    return(max(ends-starts)+1)


"""
mean of plateau length
"""
def plateau_mean(ts):    
    d2ts = np.diff(list(map(int, np.diff(ts,prepend=ts[0]-1, append=ts[-1]+1)==0)))
    starts, = np.where(d2ts > 0)
    ends, = np.where(d2ts < 0)
    return(np.mean(ends-starts))





"""
function to calculate asym like suggested by DS in mail from 2020-8-27
@modified: 2020-8-28
"""
def skew_split(ts, difforder = 0):

    # diff ts
    ts = np.diff(ts, n=difforder, axis=0, prepend=ts[0])

    # TODO 2020-8-28: alles nochmal sicherer machen
    # split in ~1 s intervals
    n = int(len(ts)/1024)
    
    split = np.split(ts, n)    
    
    sk = np.empty(n)
    sk.fill(np.nan)
    
    # TODO 2020-8-28: auf split-apply-combine umstellen
    i=0
    for ts_part in split:
        sk[i] = skew(ts_part)    
        i+=1
    
    absk = np.abs(sk)
    return({'mean': np.mean(sk), 'median': np.median(sk), 
            'mean_abs': np.mean(absk),
            'median_abs': np.median(absk),
            'max_abs': np.max(absk)})    
    

def skew_split_0_mean(ts):
    return(skew_split(ts)['mean'])

def skew_split_0_median(ts):
    return(skew_split(ts)['median'])

def skew_split_0_mean_abs(ts):
    return(skew_split(ts)['mean_abs'])

def skew_split_0_median_abs(ts):
    return(skew_split(ts)['median_abs'])

def skew_split_0_max_abs(ts):
    return(skew_split(ts)['max_abs'])

def skew_split_1_mean(ts):
    return(skew_split(ts, difforder=1)['mean'])

def skew_split_1_median(ts):
    return(skew_split(ts, difforder=1)['median'])

def skew_split_1_mean_abs(ts):
    return(skew_split(ts, difforder=1)['mean_abs'])

def skew_split_1_median_abs(ts):
    return(skew_split(ts, difforder=1)['median_abs'])

def skew_split_1_max_abs(ts):
    return(skew_split(ts, difforder=1)['max_abs'])



       


"""
several functions to calculate several percentiles for different orders of
differentiation
@modified: 2020-8-28
"""
def asym_0_75(ts):
    return(asym_feat(ts, 0, .75))

def asym_0_80(ts):
    return(asym_feat(ts, 0, .8))

def asym_0_85(ts):
    return(asym_feat(ts, 0, .85))

def asym_0_90(ts):
    return(asym_feat(ts, 0, .90))
    
def asym_0_95(ts):
    return(asym_feat(ts, 0, .95))

def asym_0_99(ts):
    return(asym_feat(ts, 0, .99))

def asym_1_75(ts):
    return(asym_feat(ts, 1, .75))

def asym_1_80(ts):
    return(asym_feat(ts, 1, .80))

def asym_1_85(ts):
    return(asym_feat(ts, 1, .85))

def asym_1_90(ts):
    return(asym_feat(ts, 1, .90))
    
def asym_1_95(ts):
    return(asym_feat(ts, 1, .95))

def asym_1_99(ts):
    return(asym_feat(ts, 1, .99))


"""
function to calculate asym like suggested by DS in mail from 2020-8-27
@modified: 2020-8-28
"""
def asym_split(ts, difforder = 0, perc=95):

    # diff ts
    ts = np.diff(ts, n=difforder, axis=0, prepend=ts[0])

    # TODO 2020-8-28: alles nochmal sicherer machen
    # split in ~1 s intervals
    n = int(len(ts)/1024)
    
    split = np.split(ts, n)    
    
    asym = np.empty(n)
    asym.fill(np.nan)
    
    # TODO 2020-8-28: auf split-apply-combine umstellen
    i=0
    for ts_part in split:
        ts_scaled = (ts_part-ts_part.mean())/max(abs(ts_part))
        
        # here asym_feat can't be used because the data are now scaled already    
        ts_scaled = ts_scaled[~np.isnan(ts_scaled)]
    
        d1 = np.percentile(ts_scaled[ts_scaled>0], perc, axis=0)
        d2 = -ts_scaled[ts_scaled<0]
        d3 = np.percentile(d2, perc, axis=0)
                            
        asym[i] = d1-d3
    
        i+=1
    
    absasym = np.abs(asym)        
    return({'mean': np.mean(asym), 'median': np.median(asym), 
            'mean_abs': np.mean(absasym),
            'median_abs': np.median(absasym),
            'max_abs': np.max(absasym)})
        

"""
functions to return the values for several parameters
@modified: 2020-8-28
"""    
def asym_split_0_75_mean(ts):
    return(asym_split(ts, perc=75)['mean'])

def asym_split_0_80_mean(ts):
    return(asym_split(ts, perc=80)['mean'])

def asym_split_0_85_mean(ts):
    return(asym_split(ts, perc=85)['mean'])

def asym_split_0_90_mean(ts):
    return(asym_split(ts, perc=90)['mean'])

def asym_split_0_95_mean(ts):
    return(asym_split(ts, perc=95)['mean'])

def asym_split_0_99_mean(ts):
    return(asym_split(ts, perc=99)['mean'])

def asym_split_0_75_median(ts):
    return(asym_split(ts, perc=75)['median'])

def asym_split_0_80_median(ts):
    return(asym_split(ts, perc=80)['median'])

def asym_split_0_85_median(ts):
    return(asym_split(ts, perc=85)['median'])

def asym_split_0_90_median(ts):
    return(asym_split(ts, perc=90)['median'])

def asym_split_0_95_median(ts):
    return(asym_split(ts, perc=95)['median'])

def asym_split_0_99_median(ts):
    return(asym_split(ts, perc=99)['median'])





"""
functions to return the values for several parameters
@modified: 2020-8-28
"""    
def asym_split_0_75_mean_abs(ts):
    return(asym_split(ts, perc=75)['mean_abs'])

def asym_split_0_80_mean_abs(ts):
    return(asym_split(ts, perc=80)['mean_abs'])

def asym_split_0_85_mean_abs(ts):
    return(asym_split(ts, perc=85)['mean_abs'])

def asym_split_0_90_mean_abs(ts):
    return(asym_split(ts, perc=90)['mean_abs'])

def asym_split_0_95_mean_abs(ts):
    return(asym_split(ts, perc=95)['mean_abs'])

def asym_split_0_99_mean_abs(ts):
    return(asym_split(ts, perc=99)['mean_abs'])

def asym_split_0_75_median_abs(ts):
    return(asym_split(ts, perc=75)['median_abs'])

def asym_split_0_80_median_abs(ts):
    return(asym_split(ts, perc=80)['median_abs'])

def asym_split_0_85_median_abs(ts):
    return(asym_split(ts, perc=85)['median_abs'])

def asym_split_0_90_median_abs(ts):
    return(asym_split(ts, perc=90)['median_abs'])

def asym_split_0_95_median_abs(ts):
    return(asym_split(ts, perc=95)['median_abs'])

def asym_split_0_99_median_abs(ts):
    return(asym_split(ts, perc=99)['median_abs'])

def asym_split_0_75_max_abs(ts):
    return(asym_split(ts, perc=75)['max_abs'])

def asym_split_0_80_max_abs(ts):
    return(asym_split(ts, perc=80)['max_abs'])

def asym_split_0_85_max_abs(ts):
    return(asym_split(ts, perc=85)['max_abs'])

def asym_split_0_90_max_abs(ts):
    return(asym_split(ts, perc=90)['max_abs'])

def asym_split_0_95_max_abs(ts):
    return(asym_split(ts, perc=95)['max_abs'])

def asym_split_0_99_max_abs(ts):
    return(asym_split(ts, perc=99)['max_abs'])





