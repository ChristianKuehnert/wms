# -*- coding: utf-8 -*-
"""
function to calculate the ratio of the variances of trend and residuals of the time series

 input:
       - dTS:          ordered time series, must contain columns 'idx' (with time in ms) and 'at' (values of ts)
       - iOrderDiff:   order of differencing, i.e. how often differences are calculated
       - iWdwSize:     size of moving-average-window

 output:
       - dfRes:        dataframe with columns ['varTrend', 'varRes', 'ratioVar'] containing the 
                       respective values for the respective values


@author: Christian Kuehnert, 2018-11-8

"""

import numpy as np
import pandas as pd


def ratio_variances(dTS, iOrderDiff, iWdwSize):

    sCols = list(['std_dev_trend', 'std_dev_res', 'ratio'])

    d_dTS = np.diff(dTS, n=iOrderDiff)
    d_maTS = d_dTS.rolling(iWdwSize, center = True, axis = 0).mean()                            # moving average                       
    d_diffTS = d_dTS - d_maTS                                                                  # difference to moving average                

    dVarTrend = np.asarray(np.var(d_maTS, axis=0, ddof=1))
    dVarRes = np.asarray(np.var(d_diffTS, axis=0, ddof=1))
    dRatioVar = np.asarray(dVarTrend/dVarRes)

    dfRes = pd.DataFrame(columns = ['order_diff', 'window_size'] + sCols)
    dfRes.loc[0] = [iOrderDiff, iWdwSize, dVarTrend, dVarRes, dRatioVar]
    
    dfRes['order_diff'] = dfRes['order_diff'].astype(int)
    dfRes['window_size'] = dfRes['window_size'].astype(int)
    for s in sCols:
        dfRes[s] = dfRes[s].astype(float)

    #return(pd.DataFrame(data=[dVarTrend, dVarRes, dRatioVar], columns=list(['varTrend', 'varRes', 'ratioVar'])))
    return(dfRes)

