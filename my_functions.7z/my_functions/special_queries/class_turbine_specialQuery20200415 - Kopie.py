# -*- coding: utf-8 -*-
"""
class for turbine to be monitored

Created on Thu Dec  6 2018


@author: Christian Kuehnert (w012028)
@modified: 2020-2-11


Properties:
-----------
    
TODO 2020-2-11: eigenstaendige Klasse, da mehr Felder von turbine erforderlich als bei 'normaler' turbine class,
das generischer machen (dict_turbine statt der einzelnen Felder), d.h. turbine-class so anpassen, dass sie wie hier
aufgebaut ist, dann die class_turbin_offset entsprechend anpassen und die Klasse hier dann von der neuen turbine-
Klasse ableiten

"""

    
#from myFunctions_data import combine_filters
import re
import pandas as pd
import numpy as np
import datetime as dt
import sys
import pathlib
import win32com.client as win32
from dateutil import parser

#from numbers import Number
 
       
#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\functions'
sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
sys.path.append(sModulePath)
import data as mfdata
import monitor as mfmon
#from class_turbine import turbine
from data import query_MySQL2, get_preferences, get_bit

from data.class_hd5Nodes import hd5Nodes as sNodes
from monitor.class_issue import issue

#sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian')
from wms.dbs import weadbs








"""
auxiliary function to check measuring program version, for 
newer programs the entries in status table and ice peak table 
should be synchronous, for older not                

@modified: 2020-1-29

TODOO 2020-1-29: eleganter machen
"""
def use_synchronized_data(revision):
    
    try:
        # first remove everything from 'release' onwards
        tmp = revision[:revision.find('release')].strip(' ')
        #ix = tmp.index('release')
        
        # find version number
        ver = re.findall("((?:cmrbl)\d+(?:.\d+)*)", tmp)[0]
        
        # find remaining revision
        rev = (tmp.replace(ver, '').replace('rev', '')
                                    .replace('(', '').replace(')', '').strip())
        
        ver_parts = [int(v) for v in 
                     ver.replace('cmrbl', '').split('.')]
              
        v1 = ver_parts[0]
        if (v1 > 2):
            bSync = True
        elif (v1<2):
            bSync = False
        else:  # case v1==2
            bSync = False
            if len(ver_parts)>1:            
                if (int(ver_parts[1])>= 4):                
                    try:
                        bSync = (int(rev)>=1111)
                    except:
                        bSync = True
                        # revsion number not integer
                        
    except:
        print('problem with evaluating revision')
        bSync = True
                
    return(bSync)








"""

function that returns TRUE if the state vector is valid (plausible), otherwise
FALSE

@modified: 2020-1-17

"""
def state_vector_valid(omega, power, pitch, prefs):
    
    max_pitch_rot = prefs['max_pitch_rot']
    min_omega = prefs['omega_min']
        
    valid = ((omega < min_omega) & (power < 0) & (pitch > max_pitch_rot) |# standing or idling
             (omega >= min_omega) & (pitch <= max_pitch_rot) & (power >= 0))  # rotating
    
    return(valid)
   















#IDEE 2020-2-4: lockerer Blattdeckel als erstes Schadensbild zum autom. Detektieren von Schaeden anhand af/se
class turbine_mon():

    # TODO 2019-1-28: noch generischen Wert eintragen
    eps = 1e-16                
    
    #dMeas_len = 16.384
    sDTFormatMsg = '%d.%m.%Y, %H:%M'


   
    """
    initialization
    
    Christian Kuehnert, 2020-2-11
    
    TODO 2020-2-11: checks mit enumerates o.ae. machen!
    """
    def __init__(self, turbine, path_hd5 = None, tickets = None, 
                 start_mon = None,
                 end_mon = None,
                 checks = {'db': True,
                           'prefs': True,
                           'data_fix': True,
                           'imp_ext': True,
                           'no_ice_eval': True,
                           'meas_lines': True,
                           'low_pass': True,
                           'stick_slip': False,
                           'overdrive': False},
                 map_channels = {0: 'e_101_flap',
                                 1: 'e_102_flap',
                                 2: 'e_103_flap',
                                 3: 'e_101_edge',
                                 4: 'e_102_edge',
                                 5: 'e_103_edge'}):

        self.turbine = turbine  # dictionary with the properties of the turbine
        self.tickets = tickets
        
                
        # end of monitoring period
        if (end_mon is None):
            end_mon = dt.datetime.now()        
        else:
            if isinstance(end_mon, str):
                end_mon = parser.parse(end_mon)
        self.end_mon = end_mon
        
        
        # start of monitoring period
        if (start_mon is None):
            try:
                sTmp = self.turbine['dt_last_monitoring']
                if sTmp:
                    sLastMon =re.sub(r'(:[a-zA-ZäöüßÄÖÜ0-9: ]+)]*','', sTmp)
                    start_mon = parser.parse(sLastMon)
                else:            
                    start_mon = self.turbine['begin_data']
            except:
                print('cannot assign start time, will use endtime - 30 d')
                start_mon = self.end_mon - dt.timedelta(days=30)

        else:
            if isinstance(start_mon, str):
                start_mon = parser.parse(start_mon)
                    
        self.start_mon = start_mon

        
        try:
            db = self.turbine['db']
        except:
            db = None
            
        if (path_hd5 is None):
            if (db is None):
                self.path_hd5 = None
            else:
                self.path_hd5 = pathlib.Path('W:') / db.replace(
                                            'cmrblba_', '') / '_current'
        else:
            self.path_hd5 = path_hd5

#        self.checks = {'db': True,
#                       'prefs': True,
#                       'data_fix': True,
#                       'imp_ext': True,
#                       'no_ice_eval': True,
#                       'meas_lines': True,
#                       'tpv': True}
#        
#        if not(checks is None):
#            self.checks.update(checks)
        self.checks = checks        
        self.map_channels = map_channels

        self.prefs = {}

        self.issues = []                
               
        #self.monitoringDays = None
    
    
    
    
   
        
    """
    get the turbine info from database name via PIT
        
    Christian Kuehnert, 2020-2-11
    """
    @classmethod
    def init_from_PIT(self, where_clause, btickets=False):
       
        dict_map = {'farm': 'Windpark_WEA#Windparkname', 
                    'name': 'WEA_Name',
                    'db': 'Datenbankname',
                    'wtg_type': 'WEA_Typ#Name',
                    'manufacturer': 'WEA_Typ#Hersteller#Firmenname',
                    'begin_data': 'Beginn_Datenspeicherung',                            
                    'begin_operational': 'Inbetriebnahme_abgeschlossen',
                    'id': 'o_ContainerID',
                    'id_farm': 'Windpark_WEA#',                   
                    'dt_last_monitoring': 'Monitoring_zuletzt_durchgeführt',
                    'ssh_port': 'ssh_port',
                    'email_customer': 'Ansprechpartner_Kunde#E_Mail_Adresse',
                    'monitoring_type': 'Systemart#Bezeichnung',
                    'monitoring_short': 'Systemart#Kürzel_Monitor',
                    'turbine_in_monitoring': 'Anlage_im_Monitoring',
                    'contract_status': 'Gesamtstatus_Überwachungsaufträge',
                    'sens_e1': 'Sensor_Rotorblatt_1#z_Sensitivität',
                    'sens_f1': 'Sensor_Rotorblatt_1#x_Sensitivität',
                    'sens_e2': 'Sensor_Rotorblatt_2#z_Sensitivität',
                    'sens_f2': 'Sensor_Rotorblatt_2#x_Sensitivität',
                    'sens_e3': 'Sensor_Rotorblatt_3#z_Sensitivität',
                    'sens_f3': 'Sensor_Rotorblatt_3#x_Sensitivität',
                    'id': 'o_ContainerID',
                    'id_farm': 'Windpark_WEA#',
                    'revision': 'revision'}

#        dict_res = {'farm': None,
#                    'name': None,
#                    'db': None,
#                    'wtg_type': None,
#                    'manufacturer': None,
#                    'begin_data': None,
#                    'begin_operational': None,
#                    'tickets': None
#                    }

        fields = dict_map.keys()        
        turbine = {f: None for f in fields}
        tickets = None
        
        listCols = [dict_map[i] + ' as ' + i for i in dict_map]
                
        try:
            df = mfdata.query_tableData_PIT('VIEW_Windkraftanlagen', listCols, where_clause)
    
            n = df.shape[0]
            if n==0:
                print(f'no result for PIT-query with {where_clause}')
            
            elif n==1:                
#                dict_res = {k: df.iloc[0].loc[k] for k in ['farm', 'name', 'db', 
#                            'wtg_type', 'manufacturer', 'begin_data', 
#                            'begin_operational']}
                turbine = {k: df.iloc[0].loc[k] for k in fields}
                                                  
                if ('farm' in fields):
                    turbine['farm'] = turbine['farm'].replace('\x96', '-')

                
                if btickets:
                    ## find all tickets
                    dictMap_tickets =  {'sTitle': 'Titel',
                                        'sDescription': 'Beschreibung',
                                        'sStatus': 'Status',
                                        'sFarm': 'Windpark#Windparkname',
                                        'weasImWP': 'WEAs_im_Windpark',                            
                                        'sTicketID': 'TicketID',
                                        'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                                        'dtCreated': 'Beginn_am',
                                        'dtClosed': 'Geschlossen_am',
                                        'dtErrorFixed': 'Behebung_des_Fehlers'}
        
                    listCols_tickets = [dictMap_tickets[i] + ' as ' + i for i in dictMap_tickets]
                       
                    sWC_tickets = f"Windpark#='{df.id_farm[0]}'"
                    dfTickets = mfdata.query_tableData_PIT('VIEW_Tickets', 
                                                           listCols_tickets, 
                                                           sWC_tickets)
                    
                    dfTickets.column_names = dictMap_tickets.keys
                
                    ## prepare list of ticket IDs combined with indices of weas im Windpark
                    ## in order to split tickets to single turbines
                    sContainerID = str(df.id[0])

                    btmp = [sContainerID in c.split(',') for c in 
                            dfTickets.loc[:, 'weasImWP']]
                                
                    tickets = dfTickets[btmp]
                        
            else:
                print(f'more than one entries found in PIT for {where_clause}')
            
        except:
            print(f'error querying PIT for {where_clause}')
            
            
        return(turbine, tickets)




    

    @classmethod
    def from_db(cls, db, checks = None, btickets = True, path_hd5 = None, 
                start_mon = None, end_mon = None,
                map_channels = {0: 'e_101_flap',
                                1: 'e_102_flap',
                                2: 'e_103_flap',
                                3: 'e_101_edge',
                                4: 'e_102_edge',
                                5: 'e_103_edge'}):
        ("Initialize turbine from database name - existing values for farm, "
         "name, wtg_type, manufacturer, begin_data, begin_operational, tickets" 
         " will be overwritten without warning")        
        sWC_wt = 'Datenbankname=\'' + db + '\''        
        turbine, tickets = cls.init_from_PIT(sWC_wt, btickets = btickets)
        kwargs = {'checks': checks,
                  'tickets': tickets, 
                  'path_hd5': path_hd5, 
                  'map_channels': map_channels,
                  'start_mon': start_mon,
                  'end_mon': end_mon}
        return cls(turbine, **kwargs)

 
    
    """
    get preferences
    
    @modified: 2020-2-12
    """    
    def get_prefs(self):
        self.prefs = get_preferences(self.turbine['db'])

    
    
    
    
    
    """
    sets the checks, i.e. determines which monitoring checks have to be done
    (if possible from data side)
    
    Christian Kuehnert, 2020-2-11
    """ 
    def update_checks(self, dict_checks):
        self.checks.update(dict_checks)

#    def set_checks(self, 
#                   bCheckDB = True,
#                   bcheckPrefs = True,
#                   bCheckDataFix = True,
#                   bCheckImpExt = True,
#                   bCheckNoIceEval = True,
#                   bCheckMeasLines = True,
#                   bCheckTPV = True):
#
#        self.checkDB = bCheckDB,
#        self.checkPrefs = bcheckPrefs,
#        self.checkDataFix = bCheckDataFix,
#        self.checkImpExt = bCheckImpExt,
#        self.checkNoIceEval = bCheckNoIceEval,
#        self.checkMeasLines = bCheckMeasLines,
#        self.checkTPV = bCheckTPV
        

       



        
#    """
#    creates link to turbine data in webVis
#    
#    Christian Kuehnert, 2019-1-27
#     2019-9-19: verschoben nach class_turbine.py
#    """          
#    def create_link(self, sTool = 'IV', time_start = dt.datetime.now()-dt.timedelta(days=30), time_end = dt.datetime.now()):
#                
#        sStartLink = str(np.floor((max(time_end - dt.timedelta(days=30), time_start)).timestamp())*1000)
#        sEndLink = str(np.ceil(time_end.timestamp())*1000)
#
#        # TODO 2019-1-27: links noch fuer alle 3 (oder mehr) tools richtig machen
#        if (sTool == 'GH'):
#            sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.db + r'&s=' + sStartLink + '&e=' + sEndLink + r'&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'            
#
#        elif (sTool == 'SE'):
#            sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.db + r'&s=' + sStartLink + '&e=' + sEndLink + r'&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'
#            
#        else:
#            print('konnte Tool-Kuerzel nicht einordnen, verwende IceVis fuer Link')
#            sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.db + r'&s=' + sStartLink + '&e=' + sEndLink + r'&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'
#                
#        sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.db + f'&s={sStartLink}&e={sEndLink}&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'
#
#        return(sLink)


    """
    get turbine info
    
    @modified: 2020-2-11
    """
    def get_info(self):
        
        try:
            sFarm = self.turbine['farm'].__str__()
        except:
            sFarm = 'None'
            
        try:
            sName = self.turbine['name'].__str__()
        except:
            sName = 'None'
            
        try:
            sDB = self.turbine['db'].__str__()
        except:
            sDB = 'None'
        
        info_text = sFarm + ', ' + sName + ' (' + sDB + ')'
        info_fn = sFarm + '__' + sName + '__' + sDB
        info_fn.replace(' ', '_').replace('(','_').replace('(','_').replace(',','_')
            
        return info_text, info_fn
            
    

        
    """
    creates instance of the issue class
    
    Christian Kuehnert, 2020-2-12
    """          
    def append_issue(self, sErrorMsg = '', sAction = '', sLink = '', 
                     sTool = '', bShort = True):
        
        self.issues.append(issue(sFarm = self.turbine['farm'], 
                                 sWT = self.turbine['name'], 
                                 sDB = self.turbine['db'], 
                                 sErrorMsg = sErrorMsg, 
                                 sAction = sAction, 
                                 sLink = sLink, 
                                 sTool = sTool, 
                                 bShort = bShort))




    
    """
    creates mail for customers
    TODO 2019-9-25: generischer/systematischer machen
    
    Christian Kuehnert, 2019-9-25
    """        
    def create_mail(self, sType, sRecipient, sPathTemplates):
        
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = sRecipient
        #mail.CC = "moreaddresses here"
        #mail.BCC = "address"

        sTmp = self.get_info()
        sFN_template = sPathTemplates + '\\template__' + sType + '.htm'
        #sFN_template = sPathTemplates + '\\template__no_stop_ice_alarm.htm'

        if (sType=='no_stop_ice_alarm'):            
            mail.Subject = sTmp + \
                            ': no response to BLADEcontrol® ice alert signal'

            sText = ''
            with open(sFN_template, 'r') as f_template:
                sText = f_template.read()            
             
            #sFN_msg = sPathSave + '\\' + sInfoFN + '_email__no_stop_ice_alarm.htm'
            mail.HtmlBody=sText.replace('REPLACEMENT_FOR_WINDFARM_AND_TURBINE', 
                                        sTmp)
            
        else:
            mail.Subject = sTmp + ': test'
            mail.HtmlBody = f'unknown Type {sType}, don''t know what to write'

        #mail.Attachments.Add(sPathAttachment)
        #mail.SaveAs(Path = sFN_msg)
        #mail.Display(False)
        return(mail)
        
    
            
        
    """
    TODO 2020-2-11: eleganter machen, viell. map key->function
    @modified: 2020-2-11
    """
    def monitor(self):
        
        self.check__db()
        self.check__prefs()
        self.check__data_fix()
        self.check__imp_ext()
        self.check__no_ice_eval()
        self.check__meas_lines()
        self.check__low_pass()
        self.check__stick_slip()
        self.check__overdrive()
        
        
                                                                                     
                                                                      
       
        
    """
    checks if there are missing tables or no tables starting with 'ba_' in the turbine's database
    
    @modified: 2020-2-12
    """   
    def check__db(self):
        
        # TODO 2018-12-6: noch Tickets auswerten, ob schon entsprechendes vorhanden!
        if self.checks['db']:
                
            ## check if wt has db name - first check if it is a string (and not None) and second check if it is 
            ## TODO 2018-12-10: noch konsistenter machen, auch bei init von turbine und turbine_mon (alles auf None umstellen oder alles auf '' etc.)
            db = self.turbine['db']
            bTmp = isinstance(db, str)
            if bTmp:
                bTmp = (len(db.strip())>0)
            
            if not(bTmp):
                self.append_issue(sErrorMsg= 'kein DB-Name im PIT eingetragen')
                    
                self.update_checks({'db': False, 
                                    'prefs': False, 
                                    'data_fix': False,
                                    'imp_ext': False,
                                    'no_ice_eval': False,
                                    'meas_lines': False,
                                    'low_pass': False,
                                    'stick_slip': False,
                                    'override': False})
    
            else:
                try:              
                    sTablesDB = pd.DataFrame(data=np.array(
                            query_MySQL2(db, 'SHOW TABLES;'))
                    ).infer_objects().iloc[:,0].tolist()
                                        
                    list_msg = list()
            
                    ## check for special required tables
                    ## TODO 2020-2-13: nur auf die Tabellen testen, die für die
                    ## ausgewählten checks relevant sind
                    if not (('ba_cycle_measurement_cycle' in sTablesDB) or 
                            ('ba_cycle_measurement_cycle_state' in sTablesDB)):                        
                        self.update_checks({'db': False,
                                            'meas_lines': False,
                                            'low_pass': False})                
                        list_msg.append('ba_cycle_measurement_cycle oder '
                                        'ba_cycle_measurement_cycle_state '
                                        '(kein Check auf Sensor TPV/defekt)')
                                        
                            						                    
                    if not ('ba_cycle_measurement_cycle' in  sTablesDB):
                        self.update_checks({'no_ice_eval': False})
                        list_msg.append('ba_cycle_measurement_cycle '
                                        '(kein Check auf Eisauswertung)')
    						                                               
                    if not('ba_cycle_status' in sTablesDB):
                        self.update_checks({'db': False,
                                            'imp_ext': False,
                                            'data_fix': False})
                        list_msg.append('ba_cycle_status (kein Check auf '
                                        'improper Externals und fehlende '
                                        'Produktionsdaten)')
                            
                    if not('ba_cycle_externals' in sTablesDB):
                        self.update_checks({'db': False,
                                            'data_fix': False})
                        list_msg.append('ba_cycle_externals fehlt in DB '
                                        '(kein Check auf fehlende Externals)')
                                                                                          
                    if not('ba_cycle_icing_peak', sTablesDB):
                        self.update_checks({'db': False,
                                            'no_ice_eval': False})
                        list_msg.append('ba_cycle_icing_peak '
                                        '(kein Check auf Eisauswertung)')
                                                                                                                                          
                    if not('preferences', sTablesDB):
                        self.update_checks({'prefs': False,
                                            'no_ice_eval': False})
                        list_msg.append('preferences (kein Check auf '
                                        'Eisauswertung)')
                                

                                              
                    #    lIssues.append(issue(sFarm = self.farm, sWT = self.name, sDB = self.db, sErrorMsg = 'DB enthaelt keine Tab. mit \'ba_\'', iErrorClass = 12, sAction = '', sLink = '', bShort = True))
                    if len(list_msg)>0:                                                        
                        self.append_issue(sErrorMsg = ('folgende Tabellen '
                                                       'fehlen: ' + \
                                                       ', '.join(list_msg)))
                                                                            
                except:
    
                    self.update_checks({k: False for k in self.checks.keys()})
                                        
                    self.append_issue(sErrorMsg = 'DB n.e., SSHport: ' + \
                            self.turbine['ssh_port'].__str__())
                                             
                    self.update_checks({'db': False, 
                                        'prefs': False, 
                                        'data_fix': False,
                                        'imp_ext': False,
                                        'no_ice_eval': False,
                                        'meas_lines': False,
                                        'low_pass': False,
                                        'stick_slip': False,
                                        'override': False})




    """
    check if necessary bits are masked
    
    Christian Kuehnert, 2020-2-11
    """
    def check__prefs(self):
                                         
        if self.checks['prefs']:  # && bcheckPrefs_do            
                       
            db = self.turbine['db']              
            lMsg = []
            
            if len(self.prefs)==0:
                prefs = get_preferences(db)
                
            bMaskEval = (get_bit(prefs['Turbine@UseDefaultSVEval']
                        .replace(' ',''), 10) == 1)    # Bit fuer Maskierung eval-bit                                
            if bMaskEval:
                lMsg.append('ice-eval-Bit maskiert')
                                           
            bMaskAlarm = (get_bit(prefs['Turbine@UseDefaultSVAlarm']
                            .replace(' ',''), 10) == 1)   # Bit fuer Maskierung Alarm-Bit
            if bMaskAlarm:
                lMsg.append('ice-alarm-Bit maskiert')
                
            bMaskWarning = (get_bit(prefs['Turbine@UseDefaultSVWarning']
                            .replace(' ', ''), 10) == 1)
            
            if bMaskWarning:
                lMsg.append('ice-warning-Bit maskiert')
                
                
            if bMaskEval or bMaskAlarm or bMaskWarning:        
                #issues.append(create_issue(db, sErrorMsg = ', '.join(lMsg), 
                #                           sAction = 'demaskieren'))
                self.append_issue(sErrorMsg = ', '.join(lMsg), 
                                  sAction = 'demaskieren')
            
        
               
        
        
        
    """
    checks if ice evaluation takes place
    
    Christian Kuehnert, 2020-2-12
    """   
    def check__no_ice_eval(self, delta=dt.timedelta(hours=48)):            
        
        if self.checks['no_ice_eval']:  # && bcheckPrefs_do            
                
            sDTFormatDB='%Y%m%d%H%M%S'
                        
            # TODO 2018-12-6: noch Tickets auswerten, ob schon entsprechendes vorhanden!            
            try:
                
                if len(self.prefs)<=0:
                    self.get_prefs()
                
                prefs = self.prefs
                db = self.turbine['db']
                
                if 'MinWindLevel' in prefs.keys():                                       
                    sMinWindLevel = prefs['MinWindLevel']
                    if len(sMinWindLevel.strip())==0:
                        sMinWindLevel = '3'
                else:
                    sMinWindLevel = '3'    
                                
                if 'Turbine@StopMinPitchAngle' in prefs.keys():                                       
                    sPitchMax = prefs['Turbine@StopMinPitchAngle']
                    if len(sPitchMax.strip())==0:
                        sPitchMax = '75'
                else:
                    sPitchMax = '75'    
                                            
                if 'Turbine@OmegaMinFreq' in prefs.keys():                                       
                    sOmegaMin = prefs['Turbine@OmegaMinFreq']
                    if len(sOmegaMin.strip())==0:
                        sOmegaMin = '0.05'
                else:
                    sOmegaMin = '0.05'    
                            
                stype_mpr = ''
                
                # 2019-9-25: NOTE: for checking the ice evaluation only the interval
                # [end_time - delta, end_time] is considered (in order to react swiftly
                # enough)
                #sStartTimeCheck = (self.end_mon-delta).strftime(sDTFormatDB)
                sStartTimeCheck = (max(self.end_mon-delta, 
                                       self.start_mon)).strftime(sDTFormatDB)
                sEndTime = self.end_mon.strftime(sDTFormatDB)
                        
                sHeadersKeys = ['create_time','ID']
                # TODO 2018-12-14: evtl. alles mit einer Abfrage erledigen und gleich die beiden Counts ausgeben
                sQuery = 'select distinct create_time,ID ' \
                        + 'from ba_cycle_status ' \
                        + 'where (create_time>=\'' + sStartTimeCheck + \
                            '\') and (create_time<=\'' + sEndTime + '\') ' \
                        + 'and (wind_mean>' + sMinWindLevel + \
                            ') and (omega_mean>=' + sOmegaMin + \
                            ') and (pitch_mean<=' + sPitchMax + ');'                      
                        
                tupTmp = mfdata.query_MySQL2(db, sQuery)
                if len(tupTmp)>0:                                                    
                    dfStatus = pd.DataFrame(data=np.array(tupTmp), columns=sHeadersKeys).infer_objects()                        
                else:
                    dfStatus = pd.DataFrame(columns=sHeadersKeys)                        
                    
                iCtStatus = dfStatus.shape[0]
                            
        #            sQuery = 'select distinct create_time,cycle_id  ' \
        #                    + 'from ba_cycle_icing_peak ' \
        #                    + 'where (create_time>=\'' + sStartTimeCheck + '\') and (create_time <= \''  + sEndTime + '\') ' \
        #                    + 'and (actual_freq > 0);'
                sQuery = 'select distinct create_time,cycle_id  ' \
                        + 'from ba_cycle_icing_peak ' \
                        + 'where (status>0) and (create_time>=\'' + \
                            sStartTimeCheck + '\') and (create_time <= \''  + \
                            sEndTime + '\') and (actual_freq > 0);'
                    
                tupTmp = mfdata.query_MySQL2(db, sQuery)
                if len(tupTmp)>0:
                    dfIcingPeak= pd.DataFrame(data=np.array(tupTmp), 
                                              columns=sHeadersKeys).infer_objects()
                    
                    if use_synchronized_data(self.turbine['revision']):
                        iCtIcingPeak = mfdata.intersect_df(dfStatus, dfIcingPeak, 
                                                           sHeadersKeys).shape[0]
                    else:
                        iCtIcingPeak = dfIcingPeak.shape[0]
                        stype_mpr = ' (unsynchronized)'
                else:
                    iCtIcingPeak = 0
        
                if (iCtStatus > 0) and (iCtIcingPeak == 0):
                    #sStartLink = str(int(np.floor((dt_time_start - dt.timedelta(hours = 6)).timestamp())*1000))
                    #sEndLink = str(int(np.floor((dt_time_end + dt.timedelta(hours = 3)).timestamp())*1000))
                    #sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + self.sDB + r'&s=' + sStartLink + r'&e=' + sEndLink + \
                    #         r'&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'
                    #sLink = mfmon.create_link(db, start_time = start_time - dt.timedelta(hours=6), end_time = end_time + dt.timedelta(hours=3))
                    # TODO 2019-9-25: vorherige Zeile debuggen und wieder aktivieren
                    #sLink = ''
                    #issues.append(mfmon.create_issue(db, sErrorMsg = 'Problem mit Eisauswertung! status=' + str(iCtStatus) + ', icing peak=' + str(iCtIcingPeak), sAction = '', sLink = sLink, sTool = 'IV'))
                    self.append_issue(
                            sErrorMsg = 'Problem mit Eisauswertung! status=' +\
                                            str(iCtStatus) + ', icing peak=' + \
                                            str(iCtIcingPeak) + stype_mpr)
                                                 
            except:
                #sStartLink = str(int(np.floor((dt_time_start - dt.timedelta(hours = 6)).timestamp())*1000))
                #sEndLink = str(int(np.floor((dt_time_end + dt.timedelta(hours = 3)).timestamp())*1000))
                #sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + self.sDB + r'&s=' + sStartLink + r'&e=' + sEndLink + \
                #         r'&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'
        #        sLink = mfmon.create_link(db, start_time = start_time - dt.timedelta(hours=6), end_time = end_time + dt.timedelta(hours=3))                    
                # TODO 2019-9-25: vorherige Zeile debuggen und wieder aktivieren
                #sLink = ''
                #issues.append(mfmon.create_issue(db, sErrorMsg = 'unbek. Fehler bei Check auf Eisauswertung', sAction = '', sLink = sLink, sTool = 'IV'))
                self.append_issue(
                    sErrorMsg = 'unbek. Fehler bei Check auf Eisauswertung')
                                

                                           
        
            
    """
    function to determine the last times the data in given columns are not missing and not fix
    @author: Christian Kuehnert
    
    2019-9-25
    """               
    def getTimesLastData(dfData, sTable, sCols, 
                         dtAllowed=dt.timedelta(hours=1)):
        
        
        sColTime = ['create_time']
        ## reduce table to the columns in sCols and sColTime
        dfData.drop(columns = list(set(dfData.columns)-set(sColTime+sCols)), 
                    inplace=True)
        
        # remove na in time
        dfData.dropna(subset=sColTime, inplace=True)
        
        ## now find last time for available data
        sCols2 = list(set(dfData.columns)-set(sColTime))
        
        ## now find last time for not-fix data
        dictRes = {}
        sCols_data = []
        sCols_fix = []
        dfNotNa = dfData.notna()
        dTime = dfData.loc[:, sColTime].values
        
        for col in sCols2:
            
            bTmp = dfNotNa.loc[:, col]
            if any(bTmp):
                dtLastData = max(dTime[bTmp])
            else:                                         
                dtLastData = np.NaT
                sCols_data.append(col)
                
            dfTmp = dfData.loc[:, col].diff(periods=1)
            dfTmp.iloc[0,] = 0
            bTmp = (abs(dfTmp.values)>self.eps)
            if any(bTmp):
                dtLastNotFix = max(dTime[bTmp])
            else:
                dtLastNotFix = np.NaT
                sCols_fix.append(col)
                        
            dictRes.update({col: [dtLastData, dtLastNotFix]})
        
        
        ## for those columns those data are fix or not available longer ago than allowed find out by database the last time of fixed/available data        
        if len(sCols_data)>0:
            dict_data = getTimesLastData_fromDB(sTable, sCols_data, 
                                                time_start = min(dTime))
            for col in sCols_data:
                dictRes[col][0] = dict_data[col]
        
        
        if len(sCols_fix)>0:
            dict_fix = getTimesLastDataFix_fromDB(sTable, sCols_data, 
                                                  time_start = min(dTime))
            for col in sCols_fix:
                dictRes[col][1] = dict_fix[col]
        
        return(dictRes)
        
        
        
        
        
        
        
            
            
    """
    function to get the last entry after for the given columns in the given table
    of the given database after the given time
    
    Created on Wed Jul 24 10:40:59 2019
    
    @modified: 2020-2-13
    
    """
    def get_last_entries(self, table, cols, last_time_ok):
    
        tmp = [(f"select '{c}',{c} from {table} where create_time>'{last_time_ok}' "
                "limit 1") for c in cols]
    
        sQuery = " union ".join(tmp) + ";"
    
        last_entries = dict(mfdata.query_MySQL2(self.turbine['db'], sQuery))
    
        return(last_entries)
        


            
    """
    function to find the last datetime with non-fix data in the given table in the
    given database, after this date either no new data were stored or they are fix
    
    @modified: 2019-3-26
    
    Parameters:
    -----------
    
        db:              database name
        table:           table name
        str_end_time:    end time as string
        col_time:        name of the column containing the time, must not be None
        cols_to_test:    names of the columns that should be analysed for fixed or
                         missing data
        
    Results:
    --------
    
        last_times_not_ok:  
    
    """    
    def get_times_last_data(self, table, str_end_time=None, 
                            col_time='create_time', cols_to_test=None):         
    
        last_times_not_ok = {}   #None
        
        if len(cols_to_test)>0:
    
            if (str_end_time is None):
                cTmp = [(f"(select '{col}', max({col_time}) from {table} group"
                        f" by {col} order by max({col_time}) desc limit 1,1)") 
                        for col in cols_to_test]
                                
            else:
                cTmp = ["select '" + col + "',max(t2." + col_time + ") " + \
                        "from " + table + " t2 " + \
                        "where not(t2." + col_time + " is NULL) and not(t2."+ \
                                col + " is NULL) and (t2." + col_time + \
                                "<='" + str_end_time + "') and (t2." + col + \
                                "<>" + "(select t." + col + " " + \
                            "from " + table + " t " + \
                            "where t." + col_time + "=(" + \
                                "select max(tm." + col_time + ") " + \
                                "from " + table + " tm " + \
                                "where not(tm." + col_time + \
                                " is NULL) and not(tm." + col + \
                                " is NULL) and (tm." + col_time + "<='" + \
                                str_end_time + "')) limit 1))" for col in 
                                                                cols_to_test]
                    
            sQuery = ' union '.join(cTmp) + ';'
            last_times_not_ok = dict(mfdata.query_MySQL2(self.turbine['db'], 
                                                         sQuery))
                
        return(last_times_not_ok)
              
            
        
        
            
    """
    function to get information about the missing data
    
    @modified: 2020-2-13
    """
    def get_missing_data(self, table, time_delta_allowed=dt.timedelta(days=1), 
                         col_time='create_time', cols_to_test=None):
        
        sMsg = ''
        sFormatDT = '%Y%m%d%H%M%S'
        last_times_not_ok = {}   #None
        bOk = True
        
        n_cols = len(cols_to_test)            # number of columns to test
    	                
        if (n_cols == 0):        
            sMsg = 'keine Spalten zum Testen ausgewaehlt'
            
        else:
            
            ## first: query if there are at least two distinct values during the allowed period for all columns to test
            try:
                db = self.turbine['db']
                end_time = self.end_mon
    
                tmp = end_time - time_delta_allowed
                sStartTime = tmp.strftime(sFormatDT)                                                        # starting time for first test
                sEndTime = end_time.strftime(sFormatDT)
                
                tmp = [f"count(distinct {col})" for col in cols_to_test]                        
                sQuery = "select " + ','.join(tmp) + \
                        f" from {table} where ({col_time}>='{sStartTime}')" + \
                        f" and ({col_time}<='{sEndTime}')"
                
                res1 = mfdata.query_MySQL2(db, sQuery)[0]
    
                btmp = [x < 2 for x in res1]                               
    
                if any(btmp):
                    cols_not_ok = list(pd.Series(cols_to_test)[btmp])        
                    last_times_not_ok = self.get_times_last_data(table, 
                                str_end_time=sEndTime, col_time='create_time', 
                                cols_to_test=cols_not_ok)
                                                      
            except Exception as e:            
                #sMsg = 'Zugriffsproblem ' + db + '.' + table + ', ' + logger.error(repr(e))
                sMsg = 'Zugriffsproblem ' + db + '.' + table + ', ' + str(e)
                bOk = False        
        
        return(last_times_not_ok, sMsg, bOk)
              
           
            
   
    
    
    # TODO 2019-7-24: am besten alles nochmal neu entwerfen (aus speed achten, 
    # moeglichst viel gleich bei den SQL-Abfragen erledigen)
    """
    check if data are fix
    
    Christian Kuehnert, 2020-2-13
    """
    def check__data_fix(self):
        
        if self.checks['data_fix']:
            
            tAllowedDelay = dt.timedelta(days=1)
            
            sFormatDT_out = '%d.%m.%Y %H:%M'
                        
            #sAction = ''
            #bShort = True
            sTool = 'GH'
            dict_cols_gh = None
            
            #sColTime = 'create_time'
            #sColsProd = ['omega_mean','wind_mean','power_mean','pitch_mean',
            #'azimuth_mean','temperature_mean','cyc_status_system',        
            #'cyc_status_eval']
            sColsProd = ['omega_mean','wind_mean','power_mean','pitch_mean',
                         'temperature_mean']
            #sColsExt = ['create_time', 'omega', 'wind', 'power', 'pitch', 
            #'azimuth', 'temperature']
            sColsExt = ['wind', 'power', 'pitch']
            
            ## columns to check in order to decide if fixed data are due to standing
            ## turbine or due to issue
            #cols_stand_prod = ['omega_mean', 'pitch_mean']
            #cols_stand_ext = ['pitch']
            
            
            # TODO 2019-5-16: evtl. mit uebergeben, wird ja ggf. vorher schonmal 
            # ausgelesen (oder vielleicht nur dann hier nochmal bestimmen, wenn 
            # None uebergeben wird)
            prefs = self.prefs
            db = self.turbine['db']
            
            # TODO 2019-3-1: folgendes noch generischer machen - dynamisch die 
            # relevanten keys herausfinden (viell. anhand von Suche nach 'azimuth' 
            # und 'ambienttemperature' in den keys) und diese verwenden
            tmp = prefs.keys()
            if 'UseAmbientTemperature' in tmp:
                if bool(int(prefs['UseAmbientTemperature'])):
                    sColsExt.append('temperature')
            
            if 'AzimuthAvailable' in tmp:
                if bool(int(prefs['AzimuthAvailable'])):
                    sColsExt.append('azimuth')
                                  
            try:
                times_prod = self.get_missing_data('ba_cycle_status', 
                                                   tAllowedDelay, 
                                                   'create_time', sColsProd)
                
                times_ext = self.get_missing_data('ba_cycle_externals', 
                                                  tAllowedDelay, 
                                                  'create_time', sColsExt)
                               
                ## check if data are fix due to standing wtg, not due to issue
                # TODO 2019-7-24: in einem naechsten Iterationsschritt evtl. nochmal
                # die get_missing_data so aendern, dass zwischen letztem Zeitpunkt mit
                # Nicht-NULL-Werten und mit fixen Werten unterschieden wird, dann
                # bei NULL-Werten doch als issue ansehen, nur bei fixen Werten nicht
        #        set_pd = {s[0] for s in dict_tmp['Betriebsdaten']}
        #        set_ext = {s[0] for s in dict_tmp['Externals']}
        #        
        #        b_stand = (len(set_pd + set_ext - \
        #                       set(cols_stand_prod + cols_stand_ext))==0)
        #        
        #        # if this is true, do detailed check if all values are consistent
        #        if b_stand:
        #            # check if omega_mean == 0 and power_mean, power <= 0 and pitch,
        #            # pitch_mean >= rot
        #            # TODO 2019-7-24: get_missing_data so anpassen, dass auch gleich
        #            # die letzten Werte ausgegeben werden                                      
        #                        
        #            s_last_time =
        #            last_prod = get_last_entries(db, 'ba_cycle_status',cols_stand_prod)
        #            last_ext = get_last_entries(db,'ba_cycle_externals',cols_stand_ext)
        #        
        #            if 
        #        
                b_stand = False
                if b_stand:
                    times_prod = {}
                
                                             
                lMsg = []
                dict_tmp = {'Betriebsdaten': [sColsProd, times_prod, 
                                              'ba_cycle_status'],
                           'Externals': [sColsExt, times_ext, 
                                         'ba_cycle_externals']}
                            
                bFix = []
                tMin = []
                dict_cols_gh = {}
                for key, val in dict_tmp.items():
                        
                    cols = val[0]
                    ctimes, sTmp, bOk = val[1]
        
                    # if there is a message, append it to the list of messages
                    if sTmp:
                        lMsg.append(sTmp)
                    
                    # Ausgabe fuer missing prod/ext
                    if bOk:
                    
                        if len(ctimes)>0:
                            bFix.append(True)
                            dict_cols_gh.update({val[2]: list(ctimes.keys())})
                            
                            times_notNone = [t for t in list(ctimes.values()) if t 
                                             is not None]
                            if len(times_notNone)==0:
                                sTimeMin = 'Beginn'
            
                            else:
                                tmp = min(times_notNone)
                                tMin.append(tmp)
                                sTimeMin = tmp.strftime(sFormatDT_out)
                        
                        
                            if len(val)==len(cols):
                                lMsg.append(key + ' fehlen/sind fix seit ' + \
                                            sTimeMin)
                                    
                            else:
                                lMsg.append('folgende ' + key + \
                                            ' fehlen/sind fix seit ' + sTimeMin + \
                                            ': ' + ', '.join(ctimes.keys()))
                                
                        else:
                            bFix.append(False)
        
                    else:
                        bFix.append(True)
                                    
                
                if len(dict_cols_gh)==0:
                    dict_cols_gh = None


# TODO 2020-2-13: noch Pruefung auf state_vector_valid durchfuehren!
                   
                #bNoPort = (ssh_port == '0.0')                # entspricht 'Tunnel: Port ist 0!'
                bNoPort = (self.turbine['ssh_port']==0)
                bNoProd = bFix[0]
                bNoExt = bFix[1]
                
                
                tEndLink = self.end_mon + dt.timedelta(hours = 6)
                if len(tMin)>0:
                    tStartLink = max([min(tMin), self.end_mon - \
                                      dt.timedelta(days=30)]) - \
                                dt.timedelta(hours=6)
                else:
                    tStartLink = self.end_mon - dt.timedelta(days=30) - \
                                                            dt.timedelta(hours=6)
                        
                bFixed = bNoProd | bNoExt    # true if at least one of externals or production data are fix or missing
                bECUne = bNoProd & bNoExt & bNoPort
                bHMUne = bNoProd & ~bNoExt & ~bNoPort
        
        
                if bECUne:
                    lMsg.append('vmtl. ECU n.e.')
                    self.update_checks({'no_ice_eval': False})
        
                if bHMUne:
                    lMsg.append('vmtl. HMU n.e.')
                    self.update_checks({'no_ice_eval': False})
        
        
                # TODO 2017-12-8: Hier nochmal mit DB sprechen, wann welche Probleme auftreten
                ## if problems are found, create link
                if bFixed:
                    ## TODO 2017-12-8: noch Fall abfangen, dass der Zeitraum zu lang wird, dann nur Ende mit den letzten Daten darstellen 
                    sLink = mfmon.create_link(db, sTool = sTool, 
                                              cols_gh = dict_cols_gh, 
                                              start_time = tStartLink, 
                                              end_time = tEndLink)
        
        
                ## find and analyse suitable tickets
                tmp = mfmon.get_relevant_tickets(self.tickets, sType = 'data_fix')    # tickets for measure lines with problems                                                            
                dfTC = tmp[0]
                dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets
                    
                ## consider open tickets
                if dfOpen.shape[0]>0:
                    
                    if bFixed:
                        lMsg[-1] += ' - vermutlich durch Ticket ' + \
                                    ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                        #lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = '', sLink = ''))
                        self.append_issue(sErrorMsg = ', '.join(lMsg),
                                          sAction = 'beobachten', sLink = sLink,
                                          sTool = sTool, bShort=False)
        
                    else:
                        #tS = max(tLastProd, tLastExtNotFix)
                        # TODO 2019-2-22: noch herausfinden, seit wann die Daten wieder vorhanden sind, und hier entsprechend eintragen, Beginn vom Link entsprechend anpassen                 
                        #if (tMin is pd.NaT):
                        #    tS = tLastMon
                        #else:
                        #    tS = tMin
                        #sMsg = 'Daten wieder vorhanden seit ' + tS.strfrmtime(sFormatDTOutput)                
                        sMsg = 'Daten wieder vorhanden'
                        sAction = 'Ticket ' + ', '.join(dfOpen.sTicketID) + \
                                    ' schliessen'                    
                        #sLink = create_link(sTool = sTool, time_start = tS - dt.timedelta(hours = 4), time_end = dt0 + dt.timedelta(hours = 2))
                        sLink = mfmon.create_link(db, sTool = sTool, 
                                                  cols_gh = None, 
                                                  start_time = tStartLink, 
                                                  end_time = tEndLink)
                                                   
                        self.append_issue(sErrorMsg = sMsg, sAction = sAction,
                                          sLink = sLink, sTool = sTool)
                          
                else:
                    if bFixed:
                        dfClosed = dfTC[dfTC.sStatus=='erledigt']
                        # TODO 2019-3-1: nur Tickets betrachten, die noch nicht allzulange zurueckliegen (sonst ist es nicht mehr
                        # wirklich ein NACHFOLGEticket)
                        #dfClosed = dfTC[dfTC.sStatus=='erledigt' & dfTC.dtClosed-tMin<dt.timedelta(days=30)]
                        sMsg = ', '.join(lMsg)                        
        
                        if dfClosed.shape[0]==0:                        
                            sAction = 'Ticket anlegen'
                        
                        else:
                            dfClosed.sort_values(['sTicketID'], axis=0, 
                                                 ascending=False, inplace=True)
                            sTmp = ', '.join(dfClosed.head(3).sTicketID)
                            sMsg += ', schon früher aufgetreten (Tickets ' + \
                                                                        sTmp + ')'
                            sAction = 'Nachfolgeticket für ' + \
                                            dfClosed.sTicketID.max() + ' anlegen'
        
                        # TODO 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN   
                        if bECUne:
                            mail_type = 'ECUne'
                        else:
                            mail_type = 'missing_data'                    
                                   
                        self.append_issue(sErrorMsg = ', '.join(lMsg), 
                                          sAction = sAction,
                                          sLink = sLink,
                                          sTool = sTool)
                                    
            except:
                
                self.append_issue(sErrorMsg = 'unbek. Fehler bei Check auf fix data', 
                                  sAction = 'manuell ansehen', sLink = '')
    

                               

        
    """
    checks for broken/damaged measure lines
    
    properties:
    -----------
        - sc: sensor classificator (class)
    
    
    Christian Kuehnert, 2020-3-23
    """   
    #def check_measLines(self, time_start=None, time_end=None, sMethod = 'classical', sensor_classificator=None):
    def check__meas_lines(self, sMethod='elementary'):

        lIssues = []

        if self.checks['meas_lines']:
            
            tShift = 3/24
            dStartFreq, dEndFreq = 150, 350
            sTool = 'SE'
                    
            #time_start, time_end = self.start_monitoring, self.end_monitoring
            data = sc.preprocess_data(self.path_hd5)
            
            prediction = sc.predict(data)
            
            
            ## 1) classical method
            if (sMethod=='classical'):
            
                # first map channel numbers (0..5) to channel names ('e_101_edge' etc.)
                # TODO 2019-1-18: generisch machen!, now only first approach
                #dictMap_class = mapChannels(self.db, self.sPathData)
                #dictMap_class = {3: 'e_101_edge', 4: 'e_102_edge', 5: 'e_103_edge', 0: 'e_101_flap', 1: 'e_102_flap', 2: 'e_103_flap'}
                dictMap_class = {'e_101_edge': 3, 'e_102_edge': 4, 'e_103_edge': 5, 'e_101_flap': 0, 'e_102_flap': 1, 'e_103_flap': 2}
                dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
    
                # get thresholds from preferences
                # TODO 2019-1-25: sind Sensitivities schon beruecksichtigt?
    
                
                try:            
                    ## 1. classical way                                        
                    lFlap = ['e_101_flap', 'e_102_flap', 'e_103_flap']
                    lEdge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
                    lDirs = lFlap + lEdge

                    ## thresholds for alarm levels for all channels
                    self.get_preferences()
                    dictTmp = self.prefs
                    #sKeys = [s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel') for s in lDirs]
                    dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel'): s for s in lDirs}
                    #dfSE_thres = pd.DataFrame.from_records([{k: v for k, v in dictTmp.items() for k in sKeys}], columns = lDirs)
                    dfSE_thres = pd.DataFrame.from_records([dictTmp])
                    dfSE_thres = dfSE_thres.loc[:, dictPrefCols.keys()]
                    dfSE_thres.rename(columns = dictPrefCols)
                                    
                    
                    ## get data
                    listColumns = ['create_time', 'cycle_id', 'measure_number', 'start_f'] + lDirs 

                    # update will be obsolete if only working with hd5-files
#                    if self.bUpdate:                # update hd5-file and get data from it
#                        print('       update se')
#                        self.update_se(time_start, time_end)                                   # update SE-table
#                        listNodes = [[sNodes.sig_energy, []]]
#                        dfSE = mfdata.get_data(self.db, self.sPathData, listNodes, listColumns)            # get data
#                    
#                    else:
#                        #sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
#                        dfSE = mfdata.get_data_fromDB(self.db, 'ba_cycle_sig_energies', 
#                                               dictTypes={'cycle_id': int}, 
#                                               listCols=listColumns, 
#                                               time_start=time_start, time_end=time_end)            

                    dfSE = mfdata.get_data_fromDB(self.db, 
                                                  'ba_cycle_sig_energies', 
                                                  dictTypes={'cycle_id': int}, 
                                                  listCols=listColumns, 
                                                  time_start=time_start, 
                                                  time_end=time_end)            

    
                    # now distinguish between systems that collect full (2Hz-wise) spectra and those that contain only sum from 150-350 Hz                                
                    iFreq = np.unique(dfSE.start_f)
                    if len(iFreq)==1:                
    
                        if iFreq[0]==dStartFreq:
                            print('alles ok, offenbar Eisdetektor, SE kann so bleiben')
                            
                        else:									
                            #sStartLink = str(np.floor((max(time_end - dt.timedelta(days=30), time_start)).timestamp())*1000)
                            #sEndLink = str(np.ceil(time_end.timestamp())*1000)
                            lIssues.append(self.create_issue(sErrorMsg = 'SE-Daten zum relevanten Frequenzbereich fehlen', 
                                                             sAction = 'manuell pruefen',
                                                             sLink = self.create_link(sTool = sTool, time_start = time_start, time_end = time_end),
                                                             sTool = sTool))
    
                    else:                                    
                        dfSE1 = dfSE[((dfSE.start_f>=dStartFreq) & (dfSE.start_f < dEndFreq))]
                        dfSE = dfSE1.groupby(['create_time', 'cycle_id'], sort=False).pipe(lambda x: np.sum(x, axis=0))                    # sum over the relevant frequency range for each cycle
                        dfSE.reset_index(inplace=True)
    
                    dfSE.dropna(axis=0, how='any', subset=lDirs, inplace=True)
                    
                    ## now compare with the thresholds    
                    #dSE = dfSE.loc[:, lDirs].values                                       
                                    
                    #dfTmp = dfData.loc[:, ['edge1', 'edge2', 'edge3']]
                    lErr = []
                    for lList in [lFlap, lEdge]:
                        
                        dTmp = dfSE.loc[:, lList].values
                        dSE_mean = np.mean(dTmp, axis=1)
                        relSE = dTmp /  np.tile(dSE_mean.reshape((len(dSE_mean),1)), (1,3))                    
                        # TODO 2019-1-17: hier individuelle Werte fuer jeweilige WEA auslesen
                        dSE_thres = dfSE_thres.loc[:, lList].values
                        dThres = np.tile(dSE_thres, (dTmp.shape[0],1))
                        dfTmp = pd.DataFrame((relSE > dThres), columns=lList)
    
                        lErr.append(dfTmp)
    
    
                    #bErrors = np.concatenate(lErr, axis=1)                    
                    dfErr = pd.concat(lErr, axis=1)
                    bTmp = dfErr.any(axis=1)
                    dfCyc_cl = pd.concat((dfSE[bTmp].loc[:,['create_time', 'cycle_id']], dfErr[bTmp].set_index(dfSE[bTmp].index)), axis=1)
                                   
                    dfCyc_cl.rename(columns = dictMap_class, inplace=True)
                    #dfCyc_cl = pd.wide_to_long(dfCyc_cl, stubnames = ['ch'], i = 'channel')
                    dfCyc_cl = pd.melt(dfCyc_cl, id_vars=['create_time', 'cycle_id'], value_vars = dictMap_class.values(), var_name = 'channel', value_name = 'fail')
                    dfCyc_cl = dfCyc_cl[dfCyc_cl.fail]
                    # reformat 
                    
                    #iCrit_class = find_args(any(bErrors, axis=0))             # get index of columns that contain error-values
                    
                    # find cycles (create_time, cycle_id) of the times of the errors
                    dfCyc_cl = dfCyc_cl.assign(origin = pd.Series(np.tile('classic', (dfCyc_cl.shape[0],))).values)           # add column with origin (classical method or ts method)
    
    
          									                      
                    # load cdef-data
                    # get SE in frequency range
                    #dfSE = dfSE.loc[:,['create_time', 'e_101_edge', 'e_102_edge', 'e_103_edge']]
                    #dfSE.rename(columns={'e_101_edge': 'RBL1 Edge', 'e_102_edge': 'RBL2 Edge', 'e_103_edge': 'RBL3 Edge', 'e_101_flap': 'RBL1 Flap', 'e_102_flap': 'RBL2 Flap', 'e_103_flap': 'RBL3 Flap'}, inplace=True)
                    
                    
    
                except :
                    lIssues.append(self.create_issue(sErrorMsg = 'unbekannter Fehler bei check_measLines, klassische Variante', 
                                                     sAction = 'manuell pruefen',
                                                     sLink = self.create_link(sTool = sTool, time_start = self.start_mon, time_end = self.end_mon),
                                                     sTool = sTool))
                    
                    dfCyc_cl = None                    
                    
                    
                dfCycCrit = dfCyc_cl                



            elif (sMethod=='ts'):
                ## 2) time series method                                            
                # TODO 2019-1-18: debuggen und aktivieren
                if False:
                    self.update_ts(self, time_start = self.dtStart, time_end = self.dtEnd)
                    dfCyc_ts = self.get_data(self, [[sNodes.ts_startstop, sWC + ' and channel<6']], ['create_time', 'ID', 'channel','start','stop'])    
                    
                    if dfCyc_ts.empty:
                        lIssues.append(self.create_issue(sErrorMsg = 'keine Zeitdaten gefunden', sAction = 'manuell ansehen', sLink = ''))
                    else:
                            
                        try:                                    
                                            
                            iPred, dfFeat = super(turbine_mon, self).predict_sensor_state(dfCyc_ts, sensor_classificator)
                            
                            # TODO 2019-1-17: stimmt das so???
                            bCrit = [i==1 for i in iPred]
                            
                            # if any errornous channels were detected ..
                            if any(bCrit):
                                
                                dfCyc_ts = dfCyc_ts[bCrit]
                                dfCyc_ts = dfCyc_ts.assign(origin=pd.Series(np.tile('ts', (dfCyc_ts.shape[0],))).values)          # add column with origin (classical method or ts method)
                                                    
                        except:
                            lIssues.append(self.create_issue(sErrorMsg = 'unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode', sAction = 'manuell ansehen', sLink = ''))
                            print('unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode')
                            dfCyc_ts = None
                            
                dfCycCrit = dfCyc_ts
    
    
            elif (sMethod=='elementary'):
                pass
                #HIER WEITER 2020-3-22
                
                
                
                

    
    
            else:
                print('unbekannte Methode zur Sensordefekterkennung')
                


            ## 3) now get info about found critical times                
            bOk = isinstance(dfCycCrit, pd.DataFrame)
            if bOk:
                bOk = not(dfCycCrit.empty)

            if bOk:     
                try:                                
            
                    # TODO 2019-1-18: combine results from both methods oder gegenseitig ueberpruefen oder sowas, akt. noch ts-methode deaktiviert
                                
                    iCh_crit = np.unique(dfCycCrit.channel)              # critical channels
    
                    # TODO 2019-1-18: ggf. andere Tabelle(?), wenn nicht alle SE-Eintraege gemerged werden
                    # TODO 2019-1-18: function noch so umstellen, dass dieser Teil nur dann ausgefuehrt wird, wenn neue Tickets erstellt werden muessen (dann wird das hier evtl. benoetigt)
                    listNodes = [[sNodes.cycle_status, []]]
                    listColumns = ['create_time', 'ID', 'cyc_status_alarm', 'cyc_status_warning', 
                                   'cyc_status_eval', 'cyc_status_system', 'status_alarm',
                                   'status_warning', 'status_eval', 'status_system', 'turbine_status',
                                   'omega_mean', 'omega_sigma', 'power_mean', 'power_sigma', 'pitch_mean',
                                   'pitch_sigma', 'wind_mean', 'wind_sigma', 'azimuth_mean',
                                   'azimuth_sigma', 'temperature_mean', 'ambient_temperature_mean']
                    dfExt = mfdata.get_data(self.db, self.sPathData, listNodes, listColumns)
                    dfCycCrit = dfCycCrit.merge(dfExt, how='inner', on=['create_time'])                              # merge both DataFrames
    
                        
                    dfTicketsCrit = self.get_tickets(sType = 'check_measLines')                     # tickets for measure lines with problems
                    dictChTickets, bChTickets = mfdata.get_channels_from_tickets(dfTicketsCrit)     # find affected channels by the modified titles of the relevant tickets                                
                            
                    ## loop through critical channels
                    # TODO 2018-12-20: noch eleganter, vektorisierter etc. machen!
                    for iCh in iCh_crit:
                        
                        ## critical times for that channel
                        # TODO 2018-12-21: hier koennte man noch testen, ob iPred=1 ueber (fast) den ganzen betrachteten Zeitraum gilt oder nur einen kleinen Teil,
                        # und dann anhand dessen das 'ztw.' hinzufuegen oder weglassen
                        # TODO 2019-1-25: ausserdem testen, ob Beginn des Defekts vielleicht noch weiter zurueckliegt und entsprechende Zeit herausfinden
                        dtCrit = dfCycCrit[dfCycCrit.channel==iCh].create_time                                                        
                        sTmp = 'Channel ' + str(iCh) + ' (' + dictMap_output[iCh] + ') (ztw.) defekt seit mindestens ' + min(dtCrit).strftime(self.sDTFormatMsg)
    
    
                        ## look for related tickets
                        #dfTC = dictChTickets[str(iCh)]                      # tickets for that channel
                        dfTC = dictChTickets[iCh]                      # tickets for that channel
                        
                        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets for that channel
                        if dfOpen.shape[0]>0:
                            sTmp += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                            lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = '', sLink = ''))
                        
                        else:
                            dfClosed = dfTC[dfTC.sStatus=='erledigt']
                            if dfClosed.shape[0]==0:
                                                                
                                #sStartLink = str(np.floor((min(dtCrit) - tShift).timestamp())*1000)
                                #sEndLink = str(np.floor(dt.now().timestamp())*1000)
                                                   
#HIER WEITER 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN                              
                                lIssues.append(self.create_issue(sErrorMsg = sTmp, 
                                                                 sAction = 'Ticket anlegen, ggf. Kanal deaktivieren', 
                                                                 sLink = self.create_link(sTool = sTool, time_start = min(dtCrit) - tShift, time_end = time_end),
                                                                 sTool = sTool))
                                
                                
                            else:
                                dfT = mfdata.get_ticket_times(dfClosed)                 # start and end times for the closed tickets
                                
                                ## herausfinden, ob es iPred=1-Zeiten nach Ende der Tickets gibt, falls nein:
                                bAllIn = False
                                for idx, row in dfT.iterrows():
                                   bAllIn = bAllIn & all(dtCrit <= row['stop'])                                
                                
                                if bAllIn:
                                    sTmp = sTmp + ' - alles noch durch Ticket ' + ','.join(dfT.sTicketID) + ' (jetzt geschlossen) abgedeckt'
                                    lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = 'beobachten', sLink = ''))
                                else:
                                    ## ansonsten 
                                    sTmp = sTmp + ', anscheinend schonmal aufgetreten (Ticket ' + ','.join(dfT.sTicketID) + ')'
                                    lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = 'altes Ticket wieder oeffnen oder neues Ticket anlegen', sLink = ''))
    
                except:
                    lIssues.append(self.create_issue(sErrorMsg = 'unbek. Fehler bei Check auf Sensordefekte (bei Ticketzuordnung)', sAction = 'manuell ansehen', sLink = ''))
                
        return(lIssues)















    """
    check for relative signal energy in a given interval
    
    parameters:
    -----------
        - filters:    dictionary, variable names : limits for production data
        - fband:      tuple, frequency band for the calculation os the signal
                      energy
        - dict_channels: dictionary, channel name ('e_10{blade}_{direction}'): 
                                           (warning threshold, alarm threshold)
    
    
    2020-3-20
    """
    def check__signal_energy(self, filters: None, fband = (150, 350),
                             warn = {'edge': [1.4, 1.4, 1.4],
                                     'flap': [1.4, 1.4, 1.4]},
                             alarm = {'edge': [2, 2, 2], 'flap': [2, 2, 2]},
                             channels = {'e_101_edge',
                                         'e_102_edge',
                                         'e_103_edge',
                                         'e_101_flap',
                                         'e_102_flap',
                                         'e_103_flap'}):
        
        
        # retrieve data from database
        # store it in class to apply several checks
        if self.sed is None:
            filter_per = {'create_time': (self.start_mon, self.end_mon)}
            self.sed = weadbs.SEData.from_db(self.db, where = filter_per)
        
        # check if se data contain necessary frequencies
        
        
        # filters for production data
        self.sed.select_st(filters)        
        
        # calculate relative se
        df_se = sed.agg_freq(band).se / (fband[1]-fband[0])
        
        # now calc. the rel. se
        res = {}
        for direction in ['edge', 'flap']:
            cols = [c for c in channels if not(c.lower().find(direction)==-1)]
            se_rel = mfdata.get_relative_se2(df_se)
            df_se.loc[:, chs] = se_rel
    
            # compare with thresholds
            b_warn = (df_se.values >= warn[direction])
            b_alarm = (df_se.values >= alarm[direction])
            
            chs_warn = cols[any(b_warn, axis=0)]
            chs_alarm = cols[any(b_alarm, axis=0)]
            
            # only check for warnings because assuming that alarm_threshold
            # always is >= warning threshold
            for ch in chs_warn:
                start_warn = df_se[b_warn[ch]].index.min()
                
            for ch in chs_alarm:
                start_alarm = df_se[b_alarm[ch]].index.min()
                
            
                
                
                
                        
            
            
            
#HIER WEITER 2020-3-20
        
        # compare with tickets
        
        # create issues and messages







        
    """
    checks for broken/damaged measure lines
    first check "classical way", i.e. from relative signal energy, second check by time series analysis
    
    Christian Kuehnert, 2019-1-28
    
    old version, to be removed later
    """   
    #def check_measLines(self, time_start=None, time_end=None, sMethod = 'classical', sensor_classificator=None):
    def check_measLines_old(self, sMethod = 'classical', sensor_classificator=None):

        lIssues = []

        if self.checkMeasLines:
            sDTFormatMsg = '%d.%m.%Y, %H:%M'
            tShift = 3/24
            dStartFreq = 150
            dEndFreq = 350
            #dMeas_len = 16.384
            sTool = 'SE'
                    
            time_start = self.dtStart
            time_end = self.dtEnd
            

            ## 1) classical method
            if (sMethod=='classical'):
            
                # first map channel numbers (0..5) to channel names ('e_101_edge' etc.)
                # TODO 2019-1-18: generisch machen!, now only first approach
                #dictMap_class = mapChannels(self.db, self.sPathData)
                #dictMap_class = {3: 'e_101_edge', 4: 'e_102_edge', 5: 'e_103_edge', 0: 'e_101_flap', 1: 'e_102_flap', 2: 'e_103_flap'}
                dictMap_class = {'e_101_edge': 3, 'e_102_edge': 4, 'e_103_edge': 5, 'e_101_flap': 0, 'e_102_flap': 1, 'e_103_flap': 2}
                dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
    
                # get thresholds from preferences
                # TODO 2019-1-25: sind Sensitivities schon beruecksichtigt?
    
                
                try:            
                    ## 1. classical way                                        
                    lFlap = ['e_101_flap', 'e_102_flap', 'e_103_flap']
                    lEdge = ['e_101_edge', 'e_102_edge', 'e_103_edge']
                    lDirs = lFlap + lEdge

                    ## thresholds for alarm levels for all channels
                    self.get_preferences()
                    dictTmp = self.prefs
                    #sKeys = [s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel') for s in lDirs]
                    dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel'): s for s in lDirs}
                    #dfSE_thres = pd.DataFrame.from_records([{k: v for k, v in dictTmp.items() for k in sKeys}], columns = lDirs)
                    dfSE_thres = pd.DataFrame.from_records([dictTmp])
                    dfSE_thres = dfSE_thres.loc[:, dictPrefCols.keys()]
                    dfSE_thres.rename(columns = dictPrefCols)
                                    
                    
                    ## get data
                    listColumns = ['create_time', 'cycle_id', 'measure_number', 'start_f'] + lDirs 

                    if self.bUpdate:                # update hd5-file and get data from it
                        print('       update se')
                        self.update_se(time_start, time_end)                                   # update SE-table
                        listNodes = [[sNodes.sig_energy, []]]
                        dfSE = mfdata.get_data(self.db, self.sPathData, listNodes, listColumns)            # get data
                    
                    else:
                        #sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
                        dfSE = mfdata.get_data_fromDB(self.db, 'ba_cycle_sig_energies', 
                                               dictTypes={'cycle_id': int}, 
                                               listCols=listColumns, 
                                               time_start=time_start, time_end=time_end)            


    
                    # now distinguish between systems that collect full (2Hz-wise) spectra and those that contain only sum from 150-350 Hz                                
                    iFreq = np.unique(dfSE.start_f)
                    if len(iFreq)==1:                
    
                        if iFreq[0]==dStartFreq:
                            print('alles ok, offenbar Eisdetektor, SE kann so bleiben')
                            
                        else:									
                            #sStartLink = str(np.floor((max(time_end - dt.timedelta(days=30), time_start)).timestamp())*1000)
                            #sEndLink = str(np.ceil(time_end.timestamp())*1000)
                            lIssues.append(self.create_issue(sErrorMsg = 'SE-Daten zum relevanten Frequenzbereich fehlen', 
                                                             sAction = 'manuell pruefen',
                                                             sLink = self.create_link(sTool = sTool, time_start = time_start, time_end = time_end),
                                                             sTool = sTool))
    
                    else:                                    
                        dfSE1 = dfSE[((dfSE.start_f>=dStartFreq) & (dfSE.start_f < dEndFreq))]
                        dfSE = dfSE1.groupby(['create_time', 'cycle_id'], sort=False).pipe(lambda x: np.sum(x, axis=0))                    # sum over the relevant frequency range for each cycle
                        dfSE.reset_index(inplace=True)
    
                    dfSE.dropna(axis=0, how='any', subset=lDirs, inplace=True)
                    
                    ## now compare with the thresholds    
                    #dSE = dfSE.loc[:, lDirs].values                                       
                                    
                    #dfTmp = dfData.loc[:, ['edge1', 'edge2', 'edge3']]
                    lErr = []
                    for lList in [lFlap, lEdge]:
                        
                        dTmp = dfSE.loc[:, lList].values
                        dSE_mean = np.mean(dTmp, axis=1)
                        relSE = dTmp /  np.tile(dSE_mean.reshape((len(dSE_mean),1)), (1,3))                    
                        # TODO 2019-1-17: hier individuelle Werte fuer jeweilige WEA auslesen
                        dSE_thres = dfSE_thres.loc[:, lList].values
                        dThres = np.tile(dSE_thres, (dTmp.shape[0],1))
                        dfTmp = pd.DataFrame((relSE > dThres), columns=lList)
    
                        lErr.append(dfTmp)
    
    
                    #bErrors = np.concatenate(lErr, axis=1)                    
                    dfErr = pd.concat(lErr, axis=1)
                    bTmp = dfErr.any(axis=1)
                    dfCyc_cl = pd.concat((dfSE[bTmp].loc[:,['create_time', 'cycle_id']], dfErr[bTmp].set_index(dfSE[bTmp].index)), axis=1)
                                   
                    dfCyc_cl.rename(columns = dictMap_class, inplace=True)
                    #dfCyc_cl = pd.wide_to_long(dfCyc_cl, stubnames = ['ch'], i = 'channel')
                    dfCyc_cl = pd.melt(dfCyc_cl, id_vars=['create_time', 'cycle_id'], value_vars = dictMap_class.values(), var_name = 'channel', value_name = 'fail')
                    dfCyc_cl = dfCyc_cl[dfCyc_cl.fail]
                    # reformat 
                    
                    #iCrit_class = find_args(any(bErrors, axis=0))             # get index of columns that contain error-values
                    
                    # find cycles (create_time, cycle_id) of the times of the errors
                    dfCyc_cl = dfCyc_cl.assign(origin = pd.Series(np.tile('classic', (dfCyc_cl.shape[0],))).values)           # add column with origin (classical method or ts method)
    
    
          									                      
                    # load cdef-data
                    # get SE in frequency range
                    #dfSE = dfSE.loc[:,['create_time', 'e_101_edge', 'e_102_edge', 'e_103_edge']]
                    #dfSE.rename(columns={'e_101_edge': 'RBL1 Edge', 'e_102_edge': 'RBL2 Edge', 'e_103_edge': 'RBL3 Edge', 'e_101_flap': 'RBL1 Flap', 'e_102_flap': 'RBL2 Flap', 'e_103_flap': 'RBL3 Flap'}, inplace=True)
                    
                    
    
                except :
                    lIssues.append(self.create_issue(sErrorMsg = 'unbekannter Fehler bei check_measLines, klassische Variante', 
                                                     sAction = 'manuell pruefen',
                                                     sLink = self.create_link(sTool = sTool, time_start = time_start, time_end = time_end),
                                                     sTool = sTool))
                    
                    dfCyc_cl = None                    
                    
                    
                dfCycCrit = dfCyc_cl                



            elif (sMethod=='ts'):
                ## 2) time series method                                            
                # TODO 2019-1-18: debuggen und aktivieren
                if False:
                    self.update_ts(self, time_start = self.dtStart, time_end = self.dtEnd)
                    dfCyc_ts = self.get_data(self, [[sNodes.ts_startstop, sWC + ' and channel<6']], ['create_time', 'ID', 'channel','start','stop'])    
                    
                    if dfCyc_ts.shape[0]==0:
                        lIssues.append(self.create_issue(sErrorMsg = 'keine Zeitdaten gefunden', sAction = 'manuell ansehen', sLink = ''))
                    else:
                            
                        try:                                    
                                            
                            iPred, dfFeat = super(turbine_mon, self).predict_sensor_state(dfCyc_ts, sensor_classificator)
                            
                            # TODO 2019-1-17: stimmt das so???
                            bCrit = [i==1 for i in iPred]
                            
                            # if any errornous channels were detected ..
                            if any(bCrit):
                                
                                dfCyc_ts = dfCyc_ts[bCrit]
                                dfCyc_ts = dfCyc_ts.assign(origin=pd.Series(np.tile('ts', (dfCyc_ts.shape[0],))).values)          # add column with origin (classical method or ts method)
                                                    
                        except:
                            lIssues.append(self.create_issue(sErrorMsg = 'unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode', sAction = 'manuell ansehen', sLink = ''))
                            print('unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode')
                            dfCyc_ts = None
                            
                dfCycCrit = dfCyc_ts
    
            else:
                print('unbekannte Methode zur Sensordefekterkennung')
                


            ## 3) now get info about found critical times                
            bOk = isinstance(dfCycCrit, pd.DataFrame)
            if bOk:
                bOk = (dfCycCrit.shape[0]>0)

            if bOk:     
                try:                                
            
                    # TODO 2019-1-18: combine results from both methods oder gegenseitig ueberpruefen oder sowas, akt. noch ts-methode deaktiviert
                                
                    iCh_crit = np.unique(dfCycCrit.channel)              # critical channels
    
                    # TODO 2019-1-18: ggf. andere Tabelle(?), wenn nicht alle SE-Eintraege gemerged werden
                    # TODO 2019-1-18: function noch so umstellen, dass dieser Teil nur dann ausgefuehrt wird, wenn neue Tickets erstellt werden muessen (dann wird das hier evtl. benoetigt)
                    listNodes = [[sNodes.cycle_status, []]]
                    listColumns = ['create_time', 'ID', 'cyc_status_alarm', 'cyc_status_warning', 
                                   'cyc_status_eval', 'cyc_status_system', 'status_alarm',
                                   'status_warning', 'status_eval', 'status_system', 'turbine_status',
                                   'omega_mean', 'omega_sigma', 'power_mean', 'power_sigma', 'pitch_mean',
                                   'pitch_sigma', 'wind_mean', 'wind_sigma', 'azimuth_mean',
                                   'azimuth_sigma', 'temperature_mean', 'ambient_temperature_mean']
                    dfExt = mfdata.get_data(self.db, self.sPathData, listNodes, listColumns)
                    dfCycCrit = dfCycCrit.merge(dfExt, how='inner', on=['create_time'])                              # merge both DataFrames
    
                        
                    dfTicketsCrit = self.get_tickets(sType = 'check_measLines')                     # tickets for measure lines with problems
                    dictChTickets, bChTickets = mfdata.get_channels_from_tickets(dfTicketsCrit)     # find affected channels by the modified titles of the relevant tickets                                
                            
                    ## loop through critical channels
                    # TODO 2018-12-20: noch eleganter, vektorisierter etc. machen!
                    for iCh in iCh_crit:
                        
                        ## critical times for that channel
                        # TODO 2018-12-21: hier koennte man noch testen, ob iPred=1 ueber (fast) den ganzen betrachteten Zeitraum gilt oder nur einen kleinen Teil,
                        # und dann anhand dessen das 'ztw.' hinzufuegen oder weglassen
                        # TODO 2019-1-25: ausserdem testen, ob Beginn des Defekts vielleicht noch weiter zurueckliegt und entsprechende Zeit herausfinden
                        dtCrit = dfCycCrit[dfCycCrit.channel==iCh].create_time                                                        
                        sTmp = 'Channel ' + str(iCh) + ' (' + dictMap_output[iCh] + ') (ztw.) defekt seit mindestens ' + min(dtCrit).strftime(self.sDTFormatMsg)
    
    
                        ## look for related tickets
                        #dfTC = dictChTickets[str(iCh)]                      # tickets for that channel
                        dfTC = dictChTickets[iCh]                      # tickets for that channel
                        
                        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets for that channel
                        if dfOpen.shape[0]>0:
                            sTmp += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                            lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = '', sLink = ''))
                        
                        else:
                            dfClosed = dfTC[dfTC.sStatus=='erledigt']
                            if dfClosed.shape[0]==0:
                                                                
                                #sStartLink = str(np.floor((min(dtCrit) - tShift).timestamp())*1000)
                                #sEndLink = str(np.floor(dt.now().timestamp())*1000)
                                                   
#HIER WEITER 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN                              
                                lIssues.append(self.create_issue(sErrorMsg = sTmp, 
                                                                 sAction = 'Ticket anlegen, ggf. Kanal deaktivieren', 
                                                                 sLink = self.create_link(sTool = sTool, time_start = min(dtCrit) - tShift, time_end = time_end),
                                                                 sTool = sTool))
                                
                                
                            else:
                                dfT = mfdata.get_ticket_times(dfClosed)                 # start and end times for the closed tickets
                                
                                ## herausfinden, ob es iPred=1-Zeiten nach Ende der Tickets gibt, falls nein:
                                bAllIn = False
                                for idx, row in dfT.iterrows():
                                   bAllIn = bAllIn & all(dtCrit <= row['stop'])                                
                                
                                if bAllIn:
                                    sTmp = sTmp + ' - alles noch durch Ticket ' + ','.join(dfT.sTicketID) + ' (jetzt geschlossen) abgedeckt'
                                    lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = 'beobachten', sLink = ''))
                                else:
                                    ## ansonsten 
                                    sTmp = sTmp + ', anscheinend schonmal aufgetreten (Ticket ' + ','.join(dfT.sTicketID) + ')'
                                    lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = 'altes Ticket wieder oeffnen oder neues Ticket anlegen', sLink = ''))
    
                except:
                    lIssues.append(self.create_issue(sErrorMsg = 'unbek. Fehler bei Check auf Sensordefekte (bei Ticketzuordnung)', sAction = 'manuell ansehen', sLink = ''))
                
        return(lIssues)


       
 



    """
    find times of last data entries and times of last not-fixed data for the given variables
    
    Christian Kuehnert, 2018-12-12
    """
    def getTimesLastData(self, sTable, sCols, sTimeStart, sTimeEnd):
        pass
#        bExclNaN = True
#        
#        dfData, dfTimes, lMsg = mfdata.getTimesLastData(sDB = self.db, sTable = sTable, sColTime='create_time', sCols = sCols, sTimeStart = sTimeStart, sTimeEnd = sTimeEnd, bExclNaN = bExclNaN)
#        #dfTimes_prod = mfdata.getTimesLastData_tab(dfData = self.dfCycleStatus, sColTime = 'create_time', sCols = sColsProd, sTimeStart = sTimeStart, sTimeEnd = sTimeEnd, bExclNaN = bExclNaN)
#        #dfTimes_prod = mfdata.getTimesLastData_db(dfTimes = dfTimes_prod, sDB = self.db, sTable = 'ba_cycle_status', sTimeStart = sTimeStart, bExclNaN = bExclNaN)
#        
#        return(dfData, dfTimes, lMsg)
#        
        
        
 
    
    """
    function to check for low-pass effects
    
    2019-9-25
    """
    def check__low_pass(self):
        pass
    
    
    
    
    """
    function to check for stick-slip effect
    
    2020-2-12
    """
    def check__stick_slip(self):
        pass
    
    
    """
    check for channel overdrive
    
    wg. spezieller Anfrage von DB, s. Mail vom 2018-12-21
    
    Christian Kuehnert, 2018-12-21  
    """
    # TODO 2018-12-21: noch in haupt-Monitoring integrieren sowie alles eleganter machen
    #def check__overdrive(self, sTimeStart=None, sTimeEnd=None):    
    def check__overdrive(self):
        if self.checks['overdrive']:
            iCritical = [41,42,43,211]
            
            sFarm = self.farm
            sName = self.name
            sDB = self.db
            
            dfRes = pd.DataFrame({'farm': [sFarm, sFarm, sFarm],
                                  'name': [sName, sName, sName],
                                  'db': [sDB, sDB, sDB],
                                  'blade': [0,0,0],
                                  41: [0,0,0],
                                  42: [0,0,0],
                                  43: [0,0,0],
                                  211: [0,0,0],
                                  'total': [0,0,0]}, index=[0,1,2])
        
            #dictRes = {'farm': self.farm, 'name': self.name, 'db': self.db, 'blade': 0, 41: 0, 42: 0, 43: 0, 211: 0, 'total': 0}       # last is for total
            
    #        sQueryOverview = 'select tmp.object_id-100, sum(if(((tmp.amp_max>=' + num2str(dThres(1)) + ') and (ext.wind_mean>8) and (tmp.object_id=101)) '  \
    #                       + 'or ((tmp.amp_max>=' + num2str(dThres(2)) + ') and (ext.wind_mean>8) and (tmp.object_id=102)) ' \
    #                       + 'or ((tmp.amp_max>=', num2str(dThres(3)), ') and (ext.wind_mean>8) and (tmp.object_id=103)),1,0)) as events, count(*) ' \
    #                       + 'from ba_cycle_measurement_cycle_state state ' \
    #                       + 'where (state.object_id in (101,102,103)) ' \
    #                       + 'left join ba_cycle_measurement_cycle cyc ' \
    #                       + 'on (state.backup_time=tmp.backup_time) and (state.cycle_id=tmp.id)' \
    #                       + 'where (cyc.create_time>sTimeStart)
    #                       + 'group by tmp.object_id;'
      
            sQuerySimple =   'select cyc.create_time, cyc.id, state.object_id-100, state.igus_id, cyc.wind_mean, cyc.power_mean, cyc.temperature_mean, cyc.pitch_mean, cyc.omega_mean ' \
                           + 'from ba_cycle_measurement_cycle_state state ' \
                           + 'left join ba_cycle_measurement_cycle cyc ' \
                           + 'on (state.backup_time=cyc.backup_time) and (state.cycle_id=cyc.id) ' \
                           + 'where (state.object_id in (101,102,103)) and (cyc.create_time>\'' + sTimeStart + '\');'
                           
                    
            # retrieve all cdef-data in the given time interval
            #sWC = mfdata.whereClause_from_timeInterval(time_start=sTimeStart, time_end=sTimeEnd, sFormat = '%Y%m%d%H%M%S')
            #if sWC:
            #    if (len(sWC.strip())>0):
            #        sSQL = sSQL + ' where ' + sWC.strip()
         
            dfData = pd.DataFrame(data=np.array(query_MySQL2(self.db, sQuerySimple, params=None))).infer_objects()
            dfData.columns = ['create_time', 'ID', 'blade', 'igus_id', 'wind_mean', 'power_mean', 'temperature_mean', 'pitch_mean', 'omega_mean']
    
            print('      ' + ', '.join([str(i) for i in np.unique(dfData.igus_id)]))
    
            groups_data = dfData.groupby(['blade'])
            i=0        
            for iBlade, dfG in groups_data:
                
                #print(self.farm + ', ' + self.name + '(' + self.db + '), RBL' + str(iBlade) + ': ')
                
                #dictRes['blade'] = iBlade
                iN = dfG.loc[:, ['create_time', 'ID']].drop_duplicates(subset=['create_time','ID']).shape[0]
                #dictRes['total'] = iN
                dfRes.at[i,'blade'] = iBlade
                dfRes.at[i,'total'] = iN
                
                groups2 = dfG.groupby(['igus_id'])
                
                for iMsg, dfG2 in groups2:
                    
                    if iMsg in iCritical:
                        iC = dfG2.loc[:, ['create_time', 'ID']].drop_duplicates(subset=['create_time','ID']).shape[0]
                        #print(str(iMsg) + ': ' + str(iC))
                        #dictRes[iMsg] = iC
                        dfRes.at[i,iMsg] = iC
    
                #print('total:' + str(iN))
                i += 1
                
                
            #for i in iRel:
                
            #dfData['appendix'] = dfData['appendix'].astype('str')
        
        
            ## set all timestamp-datatypes to pd.datetime
    #        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
    #        sCols = listFields[iPos]
            #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
    #        for s in sCols:    
    #            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    
    
            #dfRes = pd.DataFrame(dictRes, index=[0])
            
            return(dfRes)



          
    
    
    """
    check if there are improper externals
    
    Christian Kuehnert, 2018-12-9
    """
    #def check__imp_ext(self, dfCDEF, dfExt):
    def check__imp_ext(self):
        pass
    

        