# -*- coding: utf-8 -*-
"""
function to create html-report

@author: w012028
@modified: 2020-7-3   
"""
import pandas as pd
from shutil import copyfile
from jinja2 import Environment, FileSystemLoader


def create_html(content, path_temp, fn_temp, path_save, fn_html):
        
    # copy main.css - style sheet to save-folder
    copyfile(f'{path_temp}\\main.css', f'{path_save}\\main.css')
    
    pd.set_option("display.max_colwidth", 200)

    file_loader = FileSystemLoader(path_temp)
    env = Environment(loader=file_loader)
    
    template = env.get_template(fn_temp)
        
    #output = template.render(content)    
    #with open(f'{path_save}\\{fn_html}', 'wb') as fh:
    #    fh.write(output.encode('utf-8'))
  
    output = template.render(content).encode('utf-8')
    with open(f'{path_save}\\{fn_html}', 'wb') as fh:
        fh.write(output)
        
    return(output)

