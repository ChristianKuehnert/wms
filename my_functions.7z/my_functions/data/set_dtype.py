# -*- coding: utf-8 -*-
"""
function to set the types of the dataframe
TODO 2018-11-6: wenn moeglich die "asymmetrie"
bzgl. timestamp beseitigen und alles generisch machen


Created on Wed Apr 24 18:28:42 2019

@author: Christian Kuehnert, 2018-11-6
"""
import numpy as np
import pandas as pd

def set_dtype(dfDF, listCols, listTypes):
    
    for i in range(len(listCols)):
        s = listCols[i]
        t = listTypes[i]
        #if (t == 'timestamp'):
        if (t is np.datetime64):
            dfDF[s] = pd.to_datetime(dfDF[s], errors='coerce')
        else:
            dfDF[s] = dfDF[s].astype(t)
    
    return(dfDF)
            