# -*- coding: utf-8 -*-
"""
function to extract features from the hd5-file 

input:

output:
 
Christian Kuehnert, 2018-11-13

"""

from data import fullfile
import pandas as pd

 
def extract_feature_fromHD5(sDB, sPathData, sNodeFeat, sHeadersKey, listFilters):
    
    dfRes = []
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if sNodeFeat in f:
            #lWhere = [] 
            #for sName, vals in dictFilters.items():
            #    lWhere.append(sName + ' in [' + ','.join([str(i) for i in vals]) + ']')            
            #sWhere = '(' + ') and ('.join(lWhere) + ')'            
            sWhere = '(' + ') and ('.join(listFilters) + ')'            
                            
            dfRes = f.select(sNodeFeat, where=sWhere)       
            	  
    return(dfRes)
        
      
    