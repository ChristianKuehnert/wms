# -*- coding: utf-8 -*-
"""
function to create a .csv-label-file
 
label==0: normal state (usually 'ok')
label==1: failure (or sth. similar)
label==9: unknown/not yet labelled

 
@author: Christian Kuehnert, 2018-10-28
"""

from data import update_label_intern


def label_to_csv(sDB, sPathData, sPathLabelFile):
        
    dfLabel = update_label_intern(sDB, sPathData)
        
    sFN_label = sPathLabelFile + '\\' + sDB + '_label.csv'            

    dfLabel.to_csv(sFN_label, sep=',', columns=['database', 'ID', 'create_time', 'channel', 'label', 'last_changed'], index=False)
 
    return(dfLabel)
        

