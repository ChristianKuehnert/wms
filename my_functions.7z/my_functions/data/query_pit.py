# -*- coding: utf-8 -*-
"""
 function to query the PIT-Database


 received from Sebastian Bitzer at 2018-10-12

"""
import pymssql
import pandas as pd

def query_pit(sql, params=None):
    with pymssql.connect(host=r'DR4DBS01', user='monitoring', 
                         password=r'+KLJzQDMuk3C*DGPPzrL', 
                         database='el_igus-its', as_dict=True) as conn:
        with conn.cursor() as cursor:
            if params is None:
                cursor.execute(sql)
            else:
                cursor.execute(sql, params)
                            
            #return pd.DataFrame(cursor.fetchall())
            return pd.DataFrame(data=cursor.fetchall()).infer_objects()


