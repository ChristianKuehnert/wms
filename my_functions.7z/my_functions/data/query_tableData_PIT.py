# -*- coding: utf-8 -*-
"""
 function to retrieve data from a given table from the PIT

 Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden


 Input:
   sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
   sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
   sWhereClause:       where clause

 Output:
   dfData:             pandas.DataFrame mit den geholten Daten

 Verwendung:
 sDB = 'cmrblba_bc_t_00835'
 sTable = 'ba_cycle_externals'
 sWhereClause = ''  # TODO 2018-11-2: noch richtiges Bsp. machen
 query_tableData(sDB, sTable, listTimeIntervals)
   
 ----------------------------------------------------------------------------

@author: Christian Kuehnert
@modified: 2018-11-2

"""

from data.query_pit import query_pit
#import query_pit

def query_tableData_PIT(sTable, listCols = [], sWhereClause = None):   
        
    if len(listCols)>0:
        sSQL = 'select ' + ','.join(listCols) + ' from ' + sTable
    else:
        sSQL = 'select * from ' + sTable
        
    if isinstance(sWhereClause, str):
        if len(sWhereClause.strip())>0:
            sSQL = sSQL + ' where ' + sWhereClause
        
    return(query_pit(sSQL))
    


