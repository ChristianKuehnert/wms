# -*- coding: utf-8 -*-
"""
function to merge the features with other nodes from the hd5-file 

@input:
           - listNodes: list with nodes and columns that should be merged to dfFeat
    
@output:
 
@author: Christian Kuehnert, 2018-11-16
"""

import pandas as pd
import numpy as np

def merge_data(dfFeat, sDB, sPathData, listNodes):

    bNew = False
    
    ## combine with production data                                                               
    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
    
    bOk = True
    # neue Variante, funktioniert aber noch nicht richtig, ausserdem unklar, ob sie
    # prinzipiell mit vielen Feature-Daten (d.h. vielen Indices) funktioniert
    # --> deshalb erstmal die "alte" Variante unten verwendet    
    if bNew:                
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
            for sNode, sCols, sKeyCols, sHow in listNodes:            
                sListMultiIdx = np.unique(dfFeat.set_index(sKeyCols).index)
                sWhere =  ','.join(sKeyCols) + ' in [' + ','.join(sListMultiIdx) + ']'                                    
                dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sKeyCols)                                                                        
                dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)

    else:
            
        ## combine with production data                                           
        lTmp = []
#        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#            for sNode, sCols, sKeyCols, sHow in listNodes:            
#                        
#                if sNode in f:
#                    dfTmp = f.select(sNode, columns=sKeyCols + sCols)
#                    dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)            

        ## combine with production data                                           
        lTmp = []
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
            for sNode, sCols, sKeyCols, sHow in listNodes:            
                        
                if sNode in f:
                    lTmp.append([f.select(sNode, columns=sKeyCols + sCols), sCols, sKeyCols])
                else:
                    bOk = False
                
        if bOk:
            i=0
            dfRes = dfFeat.copy()
            while (dfRes.shape[0]>0) & (i < len(lTmp)):
                dfTmp, sCols, sKeyCols = lTmp[i]
                i += 1
                if dfTmp.shape[0]>0:                        
                    dfRes = pd.merge(dfRes, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)
                else:
                    dfRes = pd.DataFrame()                                          
                    
        else:
            dfRes = pd.DataFrame()                     

    return dfRes
    
    