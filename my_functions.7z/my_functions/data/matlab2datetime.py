# -*- coding: utf-8 -*-
"""
function to transform matlab datetime to python datetime

@author: https://stackoverflow.com/questions/13965740/converting-matlabs-datenum-format-to-python
"""
import datetime as dt

def matlab2datetime(matlab_datenum):

    day = dt.datetime.fromordinal(int(matlab_datenum))
    dayfrac = dt.timedelta(days=matlab_datenum%1) - dt.timedelta(days = 366)
    return day + dayfrac

