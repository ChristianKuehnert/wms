# -*- coding: utf-8 -*-
"""
Function to read the data from mysql tables and store them in hd5 file node
@author: Christian Kuehnert
2019-2-7

"""

import pandas as pd

from data import read_from_table
from data import setdifference_df


def read_mysql_toHD5(f, sNode, sDB, sTable, sWC=None, iChunkSize=10**5):

    tmp = read_from_table(sDB, sTable, sWC=None, iChunkSize=iChunkSize)

    
    dfData_hd5 = None
    if sNode in f:        
        dfData_hd5 = f[sNode]        
        if not isinstance(dfData_hd5, pd.DataFrame):
            f.remove(sNode)
            dfData_hd5 = None

            f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
            
    i=0
    for chunk in tmp['sql_reader']:
        i += 1
        print('chunk ' + str(i))
        dfData = pd.DataFrame(data=np.array(chunk)).infer_objects()            
        dfData.columns = tmp['listFields']
        
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in tmp['sColsTimeStamp']:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

        dfAdd = setdifference_df(dfData, dfData_hd5, sHeadersKey).reset_index(drop=True)
 
        if dfAdd.shape[0]>0:
            if sNode in f:
                f.append(sNode, dfAdd, index=False)
            else:
                f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)                        

