# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 12:55:01 2019

@author: w012028
"""

def get_channel_states(str_where_clause = None, start_time = None, end_time = None):
    
    
    #query_sql = '...'    
    #if str_where_clause 
    #    query_sql = '...'
        
    # get all weas that fullfill the condition, with tickets
    
    # for all tickets check if it indicates sensor deviations (failure, increased sig energy etc) during the given period
    
    # return dictionary {'issues': {dict with (db, channel) as keys and the df_tickets as channels that have problems during that period},
    #                    'no_issues': {dict with (db, channel) as keys and the df_tickets as channels that have no problems during that period}}
    
    # TODO 2019-6-26: obiges noch implementieren, jetzt fuer die Auswertung der Wikinger-WEAs erstmal fixe Loesung:
    {'no_issues': ('bc_t_01646', )}
    
    
    
    
    
    