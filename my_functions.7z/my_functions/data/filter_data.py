# -*- coding: utf-8 -*-
"""
function to filter the data by the given conditions

 input:
       - dfData:                 pandas.DataFrame to be filtered
       - listFilterConditions:   list with filter conditions as strings, the columns
                                 and types must correspond with the columns
                                 and types in dfData
                                 the condition must start with the column name, followed by
                                 the criterion
                                 if there are more than 1 conditions they will be 
                                 combined using 'and'
                                 only elementary conditions (like 'a<5' or 'v isin [1,2,3]') 
                                 are allowed, combinations will terminate the function
                                 or return incorrect results

 output:
       - dfRes:                  pandas.DataFrame with data that meet the conditions

@modified: 2020-9-21

TODO 2020-2-28: besser machen im Fall dict, mit Intervallobjekten (um Halboffenheit richtig abzubilden)

example: listFilterConditons = ['wind_mean<10', 'wind_mean>=2', 'channel isin [0,1,2]']
        list or, if dict: filters = {'omega_mean': (None, 5), 
        'power_mean': (100,2000)}

"""

#import numpy as np
#import pandas as pd
def filter_data(df, filters):

    if (filters is None):
        sfilters = ''
        
    else:   
        if isinstance(filters, list):
            sfilters = ' and '.join(filters)
            for f in filters:
                try:
                    df = eval('df[df.' + f.strip() + ']')
                except:
                    pass
            
        elif isinstance(filters, dict):
            columns = df.columns            
            ltmp = list()
            for k, v in filters.items():
                if k in columns:
                    if not(v[0] is None):
                        df = df[df.loc[:, k]>=v[0]]
                        ltmp.append(f'({k}>={v[0]})')
                    if not(v[1] is None):
                        df = df[df.loc[:, k]<=v[1]]
                        ltmp.append(f'({k}<={v[1]})')
            sfilters = ' and '.join(ltmp)

        else:
            print('unknown type of filters, return unfiltered data')
            sfilters = 'unknown type of filters'
                          
    return(df, sfilters)



   
"""
create where-clause from given filters (can be list or dict)

@modified: 2020-3-26
"""
def where_clause_from_filters(filters = None):
                    
    if (filters is None):
        swhere = ''
        
    else:
        if isinstance(filters, str):
            swhere = filters
            
        elif isinstance(filters, list):
            swhere = '(' + ') and ('.join(filters) + ')'
            
        elif isinstance(filters, dict):        
            lwhere = list()
            for k, v in filters.items():
                if not(v[0] is None):
                    lwhere.append(f'{k}>={v[0]}')
                 
                if not(v[1] is None):
                    lwhere.append(f'{k}<={v[1]}')
    
            swhere = '(' + ') and ('.join(filters) + ')'
                    
        else:
            print('unknown type of filters, return empty string')
            swhere = ''

    return(swhere)
         