# -*- coding: utf-8 -*-
"""
Created on Mon May  6 17:26:41 2019

function to read attributes of the given hd5-file (if possible)

parameters:
-----------

    - fn_hd5:        name of the hd5-file


output:
-------
    if plain:     dictionary with attributes of the hd5-file or empty dict if something went wrong or no attributes are contained
    if not plain: dictionary with attributes of the hd5-file or empty dict if something went wrong or no attributes are contained
    

@author: w012028
@modified: 2019-5-10

"""

import pandas as pd
import numpy as np

def read_hd5_attributes(fn_hd5, plain=True):
    res = {}
    try:
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as g:
            tmp = g.root
            for k in tmp._v_children:
                
                tmp2 = dict(vars(tmp[k].attrs))
    
                # return plain dict with all attributes
                if plain:
                    res.update({k: tmp2})
                    
                # return dict with attributes that are in _v_attrnames, decoded, with key:values for key and file names
                else:
                    rel_names = tmp2['_v_attrnames']
                    #dict_tmp={'key': k,
                    #          'file': fn_hd5}
                    dict_tmp = {}
                    for k2 in rel_names:
                        if isinstance(tmp2[k2], np.bytes_):
                            dict_tmp.update({k2: tmp2[k2].decode()})
                        else:
                            dict_tmp.update({k2: tmp2[k2]})
                    res.update({(k, fn_hd5): dict_tmp})
                    
    except:
        pass
    
    return(res)