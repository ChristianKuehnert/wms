# -*- coding: utf-8 -*-
"""
Created on Fri May 29 01:09:12 2020

@author: w012028
"""

def get_bin_code(all_elements, list_elements):
    
    # TODO 2020-5-29: eleganter machen
    i = 0
    bin_code = 0
    for x in list_elements:
        if x in all_elements:
            bin_code += 2**i
            i += 1
            
    return(bin_code)
    
    
    
    
    
    