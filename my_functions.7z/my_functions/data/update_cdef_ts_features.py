# -*- coding: utf-8 -*-
"""
function to collect time series as well as cdef data, and collect
and store the features calculated from the time series
in a first version save them separately as well as combined,
later the combined data can be dropped if suitable functions
to combine are implemented

 
@author: Christian Kuehnert, 2018-11-9
@modified: 2019-7-29

TODO 2018-10-18: eleganter machen, nur die Daten auslesen, die wirklich benoetigt werden etc.
"""

import os
import fnmatch
import numpy as np
import pandas as pd


from .update_hd5 import update_cdef
from data import extract_cycleKeys_from_node
from data import get_folder
from data import intersect_df
from .update_hd5 import combine_ts
from .update_hd5 import read_gz




def update_cdef_ts_features(sDB, sPathData, listFeatures, listTimeIntervals=[-np.Infinity, np.Infinity], iCntMeasBase = 8192, bSloppy = True):

    lMsg = []
    
    sNode = 'raw_data/ts'                                           # node where the time series data are stored
    
    sHeadersKey = ['create_time', 'ID', 'channel']                             # headers of the columns that relate the ts data to the cdef data
    
    sFN_hd5 = f'{sPathData}\\{sDB}.hd5'                             # full hd5-file name
    
    dfCDEF = update_cdef(sDB, sPathData, listTimeIntervals)         # update cdef-data and return list of all entries
        
    iCycles = dfCDEF.shape[0]                                              # number of cycles
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe
            bCycEx = False
            iStop = -1
            #if '/'+sNode in f.keys():
            if sNode in f:
                #if (type(f[sNode]) is pd.DataFrame):
                bCycEx = True
                iStop = f.get_storer(sNode).nrows
                               

# TODO 2018-11-9: complete implementation of this part                                                                                     
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
                if bSloppy:
                    dfCycEx = extract_cycleKeys_from_node(f, sNode, sHeadersKey)
                                    


            # find lists cycles for which the features already exist
            listCycFeatEx = []
            for i in range(len(listFeatures)):
                sNodeFeat = listFeatures[i][2]
            
                if sNodeFeat in f:
                    listCycFeatEx.append(extract_cycleKeys_from_node(f, sNodeFeat, sHeadersKey))
			
                else:		# perhaps here otherwise create this node with empty set but correct columns
                    #listCycEx.append([])
                    listCycFeatEx.append(pd.DataFrame(columns=sHeadersKey))                



            iCycles = dfCDEF.shape[0]
            #iCycles = 10
            for i in range(iCycles):
            #for i in range(2382, 2500):

                tsCT = dfCDEF.create_time[i]                          # current create_time
                iID = dfCDEF.ID[i]                                     # current ID
                
                if not ((iID==0) or pd.isnull(tsCT)):
                
                    sInfo = str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                    print(sInfo)                   
                        
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(os.listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            print('    files exist')
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                dfCycEx = f.select(sNode, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                    #iTmp = dfCycEx[(dfCycEx.create_time == tsCT) & (dfCycEx.ID==iID)].channels       # get channels for that they are existing                              
                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
# TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    #iTS, lOL, sMsg = combine_ts(listTS, iCntMeasBase)                        
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                        
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(np.datetime64)                                
                                        dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')
                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['overlap'] = dfTmp['overlap'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #dfTmp.set_index(sHeadersKey)
                                        
                                        #f.append(sNode, dfTmp.set_index(sHeadersKey), format='table', data_columns = True)
                                        f.append(sNode, dfTmp, format='table', data_columns = True, index=False)                                
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        
                                        
                                        ## now calculate and add features
                                        for j in range(len(listFeatures)):
                                            feat_fct, kwargs, sNodeFeat = listFeatures[j]

                                            # TODO 2018-11-9: eleganter machen								
                                            dfCyc = pd.DataFrame(data=([[tsCT, iID, iCh]]), columns = sHeadersKey)

                                            dfCyc['create_time'] = pd.to_datetime(dfCyc['create_time'], errors='coerce')                                        
                                            dfCyc['ID'] = dfCyc['ID'].astype(int)
                                            dfCyc['channel'] = dfCyc['channel'].astype(int)
                                            
                                            if (intersect_df(dfCyc, listCycFeatEx[j], sHeadersKey).shape[0] == 0):								# if the current cycle is NOT in the cycles for which the current feature is already calculated                                            

                                                dfFeat = feat_fct(iTS, **kwargs)
                                            
                                                iN = dfFeat.shape[0]
                                                dfTmpF = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [iN, 1]))
                                                dfTmpF.set_index(dfFeat.index, inplace=True)                                            
                                                dfTmpF.columns = sHeadersKey                                                                
                                            
                                                dfTmpF['create_time'] = pd.to_datetime(dfTmpF['create_time'], errors='coerce')                                        
                                                dfTmpF['ID'] = dfTmpF['ID'].astype(int)
                                                dfTmpF['channel'] = dfTmpF['channel'].astype(int)                                                                                            
                                                
                                                dfTmpF = pd.concat([dfTmpF, dfFeat], axis=1)
                        
                                                f.append(sNodeFeat, dfTmpF, format='table', ignore_index=True, index=False, data_columns=True)
                    
                                                
                                                #print(sInfo + ', ch ' + str(iCh) + ': feature ' + sNodeFeat + ' added')

                    
                                    else:
                                        lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception as ex:
                                    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                                
    return(lMsg)


