# -*- coding: utf-8 -*-
"""
function to extract data from a node in the hd5-file 

input:

output:
 
@author: Christian Kuehnert, 2018-11-22

""" 

import pandas as pd

from data import fullfile
from sensor_classification import reformat_acf


def extract_data_fromNode(sDB, sPathData, sNode, sCols=None, listFilters=[]):
    
    sNode_acf = 'features/dfACF_d1TS'              

    
    dfRes = pd.DataFrame(columns = sCols)
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:

            if (sNode==sNode_acf):
# TODO 2018-11-22: hier gleich aus den uebergebenen columns (lag_1, lag_2, ...) die benoetigten lags 
# herausziehen und beim Auslesen aus dem hd5-file mit where danach filtern (ggf. zum where-clause in listFilters hinzufuegen)
                #iLags = [int(s.replace('lag_','')) for s in sCols  if (s.find('lag_')>-1)]
                #sW2= '(lag==' + ') or (lag=='.join([str(i) for i in iLags]) + ')'
                sLags = [s.replace('lag_','') for s in sCols  if (s.find('lag_')>-1)]
                sWhere = '(lag=[' + ','.join(sLags) + '])'
                
                if len(listFilters)>0:
                    sWhere = '(' + sWhere + ' and (' + ') and ('.join(listFilters) + '))'
                    
                dfRes = f.select(sNode, where=sWhere)
                
                ## reformat acf-data            
                if (dfRes.shape[0]>0):        
                    dfRes = reformat_acf(dfRes)
                    dfRes = dfRes.loc[:, sCols]
            
            else:                
                if len(listFilters)>0:
                    sWhere = '(' + ') and ('.join(listFilters) + ')'
                    dfRes = f.select(sNode, where=sWhere, columns=sCols)
                else:
                    dfRes = f.select(sNode, columns=sCols)
                                
                
    return(dfRes)
       
	 
    