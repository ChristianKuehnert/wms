# -*- coding: utf-8 -*-
"""
Function to retrieve the data from the database
@author: Christian Kuehnert


2020-4-18

"""

# TODO 2019-7-29: zusammenfuehren mit get_data_from_db.py!!!
#from data import whereClause_from_timeInterval
#from data import query_tableData
#from data import whereClause_from_timeInterval as whereClause_from_timeInterval
#from data import query_tableData as query_tableData
#import data.whereClause_from_timeInterval as whereClause_from_timeInterval
from .query_tableData import query_tableData
#from .whereClause_from_timeInterval import whereClause_from_timeInterval
#import data.query_tableData as query_tableData
from .filter_data import where_clause_from_filters
from .time_to_string import time_to_string

def get_data_fromDB(sDB, sTable, dictTypes=None, listCols=None, 
                    time_start=None, time_end=None, filters = None):
    
    sFormat = '%Y%m%d%H%M%S'
    
#    sWC = whereClause_from_timeInterval(time_start=time_start, 
#                                        time_end = time_end, 
#                                        sFormat = sFormat)    # retrieve all data in the given time interval        
    
    period = [None, None]
    if not(time_start is None):
        period[0] = time_to_string(time_start, sFormat)
    
    if not(time_end is None):
        period[1] = time_to_string(time_end, sFormat)
    
    if any(period):
        if (filters is None):
            filters = dict()
        filters.update({'create_time': tuple(period)})
    
    sWC = where_clause_from_filters(filters)
    
    dfData, sMsg = query_tableData(sDB, sTable, sWC=sWC)    

    ## set types, if some type dictionary is given                                        
    if dictTypes:    
        for sField, tType in dictTypes.items():
            dfData[sField] = dfData[sField].astype(tType)
        
    ## return wanted columns only        
    if listCols:
        return(dfData.loc[:, listCols])
        
    else:
        return(dfData)

    
            
    