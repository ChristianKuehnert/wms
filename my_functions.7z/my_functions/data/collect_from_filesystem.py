# -*- coding: utf-8 -*-
"""

function to collect the data from the file system, especially in the case that
no information about data_available are avaiblable (e.g. when the database
can't be accessed)

Created on Mon Mar  2 11:40:12 2020

parameters:
-----------

    - db:          name of turbine database
    - data_type:   type of data to be collected, can be 'af', 'at' or 'both'
    - path_save:   path to store the results
    - start_time:  start time for collection
    - end_time:    end time for collection
    
    
@author: w012028
"""
from calendar import monthrange

def collect_from_filesystem(db, data_type = 'af', path_save,
                            start_time = None, end_time = None):
    
    ## get list all drives and directories for the given period    
    ## TODO 2020-3-2: evtl. s
    ## dates when the storage directories were changed
    
    #start_bcdata2 = pd._libs.tslibs.timestamps.Timestamp('2017-03-06 10:36:00')    
    #start_bcdata3 = pd._libs.tslibs.timestamps.Timestamp('2019-03-12 17:17:00')       # todo 2019-3-15: ggf. nochmal genau von jmd. geben lassen, ist erstmal empirisch aus webAna bestimmt
    res = list()

    if (start_time is none):
        start_time = dt.datetime(1970,1,1)
        
    if (end_time is None):
        end_time = dt.datetime.now()+dt.timedelta(hours=2)

    for drive in ['X:', 'Y:', 'Z:\\bcdata\data']:
        
        path_main = f'{drive}\\{db.replace("cmrblba_", "")}'
        
        years = next(os.walk(path_main))[1]
                
        for y in years:
            
            if (y>=start_time.year) and (y<=end_time.year):

                p = f'{path_main}\{y}'
                months = next(os.walk(p))[1]
                
                for m in months:
                    
                    if (dt.datetime(y, m, 1)<=start_time) and \
                            (dt.datetime(y, m, monthrange(y,m)[1])>=end_time):
                        
                        days = next(os.walk(f'{path_main}\{y}\{m}'))[1]
                        
                        for d in days:
                            
                            if (dt.datetime(y, m, d)>=start_time) and \
                                            (dt.datetime(y, m, d)<=end_time):
                            
                                path_tmp = f'{path_main}\y\m\d'
                                ids = next(os.walk(path_tmp))[1]
                                
                                for i in ids:
                                    path_tmp2 = f'{path_tmp}\{i}'
                                    files = [x for x in next(os.walk(path_tmp2))[1]
                                            if x.substring(f'{data_type}%.csv.gz')]
                                    
                                    if data_type=='af':
                                        combine_af(files)
                                        
                                    elif datatype=='at':
                                        combine_at(files)
                                        
                                    else:
                                        print("can't combine this type of data")
                                        
                                        
    df_res = pd.DataFrame.from_records(res, columns = ['year', 'month', 'day',
                                                       'id', data_type])