# -*- coding: utf-8 -*-
"""

function to create a new folder (if it not already exists)


Created on Tue Mar  5 07:28:37 2019
@author: Christian Kuehnert
"""

import os

def create_folder(sFolderName):
    if not os.path.exists(sFolderName):
        os.makedirs(sFolderName)
        
    return
    #directory = os.path.dirname(sFolderName)
    #try:
    #    os.stat(directory)
    #except:
    #    os.mkdir(directory)   

