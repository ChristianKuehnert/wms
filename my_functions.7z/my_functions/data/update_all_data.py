# -*- coding: utf-8 -*-
"""
function to update all data in the given list with all features in the given list

@author: Christian Kuehnert, 2018-11-13
"""
import numpy as np

from data import update_cdef_ts_features

def update_all_data(sDBs, sPathData, listFeatures):
                       
    for sDB in sDBs:                         
        print('update data for turbine: ' + sDB)            
        update_cdef_ts_features(sDB, sPathData, listFeatures, listTimeIntervals=[-np.Infinity, np.Infinity], bSloppy = False)
        
            