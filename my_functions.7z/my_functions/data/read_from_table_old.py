# -*- coding: utf-8 -*-
"""
Function to read from mysql tables
@author: Christian Kuehnert
2019-2-14

"""

import pymysql
import pandas as pd

from data import get_fields_MySQL


def read_from_table_old(sDB, sTable, sWC=None, iChunkSize=10**5):

    sHost = r'10.41.52.30'
    con = pymysql.connect(host=sHost, user='webvis-intern', port=3306,
                           password=r'ne0Nae2Aloo0Gi1E', database=sDB)
        
    listTmp = get_fields_MySQL(sDB, sTable)
    listFields = listTmp.Field
    listTypes = listTmp.Type
    
    ## set all timestamp-datatypes to pd.datetime
    iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
    sColsTimeStamp = listFields[iPos]
    
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL += ' where ' + sWC.strip()
            
    sql_reader = pd.read_sql(sSQL, con, chunksize=iChunkSize)
    
    return({'listFields': listFields,
            'sColsTimeStamp': sColsTimeStamp,
            'sql_reader': sql_reader})
