# -*- coding: utf-8 -*-
"""

function that calculates the spectrum like the messprogram does


parameters:
-----------

- data:                    time series to be transformed
- sampling_rate:           sampling rate
- n_measurement:           length of one measurement, i.e. length of each ts for which the fft is conducted
- measurements_per_cycle:  cycles per measurement like in preferences
- overlap_factor:          overlap factor like in preferences



Created on Thu Mar 28 15:25:50 2019

@author: Christian Kuehnert, aufbauend auf timedata.to_spec von Sebastian Bitzer
@modified: 2019-6-21

"""
import scipy
#import numpy as np
#import pandas as pd


def fft_messprogram(data, sampling_rate=1000, n_meas = 16384, measurements_per_cycle = 5, f_overlap = 2):

#    #iL = int(len(data)/ n_parts)
#    
#    # TODO 2019-6-21: noch Konsistenz testen, d.h. ob length(data), n_measurement, measurements_per_cycle und overlap_factor zusammenpassen
#    
#    #if only one sub-ts then spare the splitting    
#    if measurements_per_cycle==1:
#        iL = len(data)
#        spec = pd.Series(np.abs(np.fft.rfft(data)*2/iL))
#        freq = np.fft.rfftfreq(iL*sampling_rate)                                       # frequencies
#    
#    # if >1 sub-ts:
#    else:        
#            
#        # TODO 2019-6-21: noch testen, ob n_measurent auch wirklich ein Vielfaches von overlap_factor ist!
#        iShift = int(n_measurement / overlap_factor)                      # t^start_n+1 = t^start_n + shift
#        lspec = []
#        #iShift = int(iL/2)
#        for n in range(measurements_per_cycle):
#            start = n*iShift
#            idx = range(start, start + n_measurement)
#            data_part = data[idx]
#            #lspec.append(pd.Series(np.abs(np.fft.rfft(data_part))*2/iL))
#            #lspec.append(pd.Series(np.abs(np.fft.rfft(data_part))*2/n_measurement))
#            lspec.append(pd.Series(np.abs(np.fft.rfft(data_part))))
#            #lspec.append(pd.Series(np.fft.rfft(data_part)))
#
#                            
#        #spec = pd.concat(lspec, axis=1).mean(axis=1)
#        spec = pd.concat(lspec, axis=1).mean(axis=1)*2/n_measurement
#        freq = np.fft.rfftfreq(n_measurement)*sampling_rate                                       # frequencies
    
    spec_kws = {'scaling': 'spectrum',
                'detrend': False,
                'mode': 'magnitude',
                'window': 'hann'}
                        
    # TODO 2019-6-21: noch testen, ob n_measurent auch wirklich ein Vielfaches von overlap_factor ist!
    n_overlap = int(n_meas - n_meas/f_overlap)
    
    freq, t, Sxx = scipy.signal.spectrogram(data,                                          
                                            fs=sampling_rate,
                                            nperseg = n_meas,
                                            noverlap = n_overlap,
                                            **spec_kws)
    
    spec = Sxx.mean(axis=1)*2
    
    return(freq, spec)

