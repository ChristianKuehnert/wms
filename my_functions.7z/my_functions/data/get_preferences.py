# -*- coding: utf-8 -*-
"""

@author: christian
"""


      
"""
get preferences

Created on Tue Mar 26 01:52:35 2019

@author: Christian Kuehnert
@modified: 2019-5-16

"""
#from data import query_MySQL2
import data as mfdata

def get_preferences(db):    
    tmp = mfdata.query_MySQL2(db, 'SELECT name, value FROM preferences;')
    return(dict(tmp))
    
