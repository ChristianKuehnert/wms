# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 07:36:22 2019


@author: from 
           https://stackoverflow.com/questions/15864082/python-equivalent-of-matlabs-ismember-function

"""

def ismember(a, b):
    bind = {}
    for i, elt in enumerate(b):
        if elt not in bind:
            bind[elt] = i
    return [bind.get(itm, None) for itm in a]  # None can be replaced by any other "not in b" valu
 