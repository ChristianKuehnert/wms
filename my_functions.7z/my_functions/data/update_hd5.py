# -*- coding: utf-8 -*-
"""
 module with functions to update hd5 files with several data from database and file system
 
 NOTE: the ts-data (data and startstop) contain create_day (not create_time) which only contains the day!

 


Created on Wed Mar 27 10:21:02 2019

@author: christian kuehnert
"""

import os
import fnmatch
import pandas as pd
import numpy as np
import math
import datetime as dt
from datetime import date, timedelta
from os import listdir

#from data import class_hd5Nodes as sNodes
#from data import fullfile, get_folder, read_gz, combine_ts, setdifference_df, whereClause_from_timeInterval
#from data.class_hd5Nodes import hd5Nodes as sNodes
#import data.setdifference_df as setdifference_df
#import data.query_pit as query_pit
from .class_hd5Nodes import hd5Nodes as sNodes
from .setdifference_df import setdifference_df
from .query_pit import query_pit
from .get_data_fromDB import get_data_fromDB
from .append_to_hd5Table import append_to_hd5Table
from .whereClause_from_timeInterval import whereClause_from_timeInterval
from .myprint import myprint
from .filter_data import filter_data

#from data.get_data_fromDB import get_data_fromDB
#from data.append_to_hd5Table import append_to_hd5Table
#from data.whereClause_from_timeInterval import whereClause_from_timeInterval








"""
Created on Wed Mar 27 10:30:02 2019

function to get folder names for retrieving ts data or sda data
the main directory is selected by the given date


@author: christian kuehnert
@modified: 2020-8-26

"""
def get_day_folder(db, tsCT):
    
    ## matlab date number for time change: 736760.4416666666511446237564, 
    ## equals datenum( 2017,3,6,10,36,0)
    if isinstance(tsCT, pd._libs.tslibs.timestamps.Timestamp):
        start_bcdata2 = pd._libs.tslibs.timestamps.Timestamp('2017-03-06 10:36:00')    
        start_bcdata3 = pd._libs.tslibs.timestamps.Timestamp('2019-03-12 17:17:00')       # todo 2019-3-15: ggf. nochmal genau von jmd. geben lassen, ist erstmal empirisch aus webAna bestimmt
        start_bcdata4 = pd._libs.tslibs.timestamps.Timestamp('2020-06-3 14:05:00')
    else:
        start_bcdata2 = dt.datetime(2017,3,6,10,36,0)
        start_bcdata3 = dt.datetime(2019,3,12,17,17,0)
        start_bcdata4 = dt.datetime(2020,6,3,14,5)
        
    if (tsCT > start_bcdata2):
        if (tsCT > start_bcdata3):
            if (tsCT > start_bcdata4):
                sDir = 'T:\\bcdata\data'
            else:
                sDir = 'Z:\\bcdata\data'
        else:
            sDir = 'X:'
    else:
        sDir = 'Y:'
                    
    tmp1 = db.replace('cmrblba_', '')
    tmp2 = tsCT.strftime('%Y\\%m\\%d')

    return f'{sDir}\\{tmp1}\\{tmp2}'





"""
Created on Wed Mar 27 10:30:02 2019

function to get folder names for retrieving ts data or sda data
the main directory is selected by the given date


@author: christian kuehnert
@modified: 2020-4-22

"""

def get_folder(db, tsCT, dID):              
    
    folder = get_day_folder(db, tsCT)
    
    return f'{folder}\\{str(dID)}'






"""
function to read in the ts-data from the gz-files
 
Created on Wed Mar 27 10:10:52 2019

@author: Christian Kuehnert
@modified: 2018-10-23

"""

def read_gz(fn, tType = np.int32):
    dRes = pd.read_csv(fn, compression='gzip', header=None, sep=';', 
                       quotechar='"', index_col=False, usecols=[0], 
                       squeeze = True, dtype=tType)
    return dRes








"""
 function to combine the ts-data from the single gz-files for one channel into 
 one time series
 search for overlapping parts of the time series and combine there, if no such parts are found than 
 just append the time series from the single files
 if the series have different lengths then return error message

 input:
       - listTS:           list of series of integers (i.e. time series of the sensors)
       - iCntMeasBase:     integer, base lenght of measurement

 output:


Created on Wed Mar 27 10:15:25 2019

@author:  Christian Kuehnert
@modified: 2018-11-1
"""
def combine_ts(listTS, iCntMeasBase):                     
    
    # TODO 2018-11-1: Fall abfangen, dass eine Sensorstrecke (streckenweise) 
    # konstant ist, dann vielleicht an den iOLs der 
    # anderen Sensoren orientieren
    # am besten aber vielleicht doch alle Teilabschnitte EINZELN abspeichern 
    # und dann nur mit gemeinsamen gruppenindizes versehen, 
    # die im fail-Fall = None oder so sind
    # TODO 2019-7-18: noch besser: Anhand der gespeicherten!!! Startzeitpunkte
    # die DAten synchronisieren (so wie SB, AK machen)
    
    iTS = []
    lOL = []                      # list of numbers of overlapping values
    
    ## test if all parts have the same length that must be integer multiple of 
    # measurement length
    # TODO 2018-10-30: die ZRn liessen sich wohl auch dann zuammenfuegen, wenn 
    # diese Tests entfallen wuerden, ggf. muesste
    # man dafuer noch testen, ob die verwendeten Indizes nicht die Anzahl der 
    # Werte uebersteigen
    iN = [len(iV) for iV in listTS]
    if (len(np.unique(iN))==1) & all([iNn % iCntMeasBase == 0 for iNn in iN]):

        ## first try simple approach: assume 50% overlap of subsequent sub-ts, 
        ## if this is not correct than do full search        
        iL = iN[0]
        iOL = int(iL/2)            
        bOk = True
        i = 0
        while bOk & (i<len(listTS)-1):
            iDiff=listTS[i][iOL:iL].values-listTS[i+1][0:iOL].values
            bOk = bOk & all(iDiff==0)
            i=i+1
        
        
        if bOk:                                                         # if overlap is 50% ...
            if (len(listTS) % 2 ==0):                                   # if number of ts in list is not odd ...
                listTS.append(listTS[-1][iOL:iL])                       #    ... add last part of the last ts in the list
              
            iTS = pd.concat(listTS[0::2], ignore_index=True) # take only every 
                                                             # second element 
                                                             # from the list
          
              
        else:                            # otherwise - here comes the cavalry:
            
            iTS = listTS[0]
            i=1
            lOL = []                    # list of overlap-lengths
            while (i<len(listTS)):
                                                    
                iNext = listTS[i]
                iNext.index = range(len(iNext))

                ## find all positions of last element of iTS in iNext
                listPos = iNext[iNext == iTS.iloc[-1]].index                
                
                ## keep only those positions where overlap is at least 100ms
                listPos = [i for i in listPos if math.gcd(i+1, 8192) > 100]       
                
                if len(listPos)>0:

                    ## now test for all positions if remaining elements in iTS 
                    ## agree with elements in iNext
                    bOk2 = False
                    iIdx = len(listPos)-1
                    while (not bOk2) & (iIdx >=0):
                                   
                        iOL = listPos[iIdx] + 1    # position where overlap 
                                                   # starts (= overlap length)
                                                   
                        # calculate differences of overlap region                                                   
                        iDiff = iTS[len(iTS)-iOL:].values - iNext[0:iOL].values
                        bOk2 = all(iDiff == 0)    # check if all are 0
                        iIdx -= 1                 # set index of next position
                
                    ## if such a position is found, cut the value in 
                    ## listTS[i+1] until this point and append it to the iTS
                    if (not bOk2):              # if no overlap was found ...
                        iOL = 0                 #   ... set it to 0 (appending 
                                                # the ts parts without overlap)
                                            
                else:
                    iOL = 0
                
                ## now combine parts up to here and append to lists                
                iTS = pd.concat((iTS, iNext[iOL:]), ignore_index = True)
                #iTS = np.concatenate((iTS, iNext[iOL:]))
                iTS.index = range(len(iTS))
                
                lOL.append(iOL)
                    
                i += 1                       # next part of the ts
            
            ## assume sth.is incorrect if not all overlap lengths are equal
            ## one could also return the combination, but only give a warning!
            # TODO 2018-10-30: nochmal ueberlegen, ob diese Variante die beste 
            # Loesung ist            
            if (len(np.unique(lOL))>1):
                # lMsg.append('overlap lengths not unique')                
                iTS = []
                iOL = []
                
            else:
                iOL = lOL[0]
                                                            
    #return iTS, lOL, ', '.join(lMsg)
    return iTS, iOL









"""
function to calculate the interval starting points from the start times of the
measurements
it is a step before combining ts-data.
The ts-data are stored in the files t_<startdatetime>_measurement.csv.gz in the
a table like, e.g.

cycle_create_time	ID	cycle_id	create_time	create_millisec
2.01908E+13	84763	9419	2.01908E+13	74
2.01908E+13	84764	9419	2.01908E+13	170
2.01908E+13	84765	9419	2.01908E+13	266
2.01908E+13	84766	9419	2.01908E+13	362
2.01908E+13	84767	9419	2.01908E+13	458
2.01908E+13	84768	9419	2.01908E+13	554
2.01908E+13	84769	9419	2.01908E+13	650
2.01908E+13	84770	9419	2.01908E+13	746
2.01908E+13	84771	9419	2.01908E+13	842

The ID relates to the ID in the names of the single ts-files, e.g.
at_84771_4.csv.gz


parameters:
-----------

    - fn_meas: .csv.gz-file containing the dataframe with ID and create_time and 
               create_millisec as above.
               NOTE: the df must be chronologically ordered (create_time +
                     create_millisec)


results:
--------

    - dict_lengths: dictionary {ID: length} giving the lenghts of the time
                    series in the ts-file(s) for the ID, i.e. the combined ts
                    contains a length-long sequence from the beginning of the 
                    data in that file
                    The last single ts-file will be included in the combined
                    ts files completely
                    
    - id_last:      ID of the last measurement-part

@author: Christian Kuehnert
@modified: 2020-8-28


"""
def get_single_ts_lengths(fn_meas):


    dict_lengths = {}
    
    try:
        df = pd.read_csv(fn_meas, compression='gzip', sep=',', 
                           quotechar='"', index_col=False, 
                           dtype={'create_time': str, 'create_millisec': int})
    
        times = [dt.datetime.strptime(s, "%Y%m%d%H%M%S") for s in 
                 df.create_time.values] 
        
        ## TODO 2019-8-12: evtl. hier schon sicherstellen, dass int herauskommt
        difft = [d.total_seconds()*1000 for d in np.diff(times)] + np.diff(
                df.create_millisec)
        
        if len(np.unique(difft))!=1:
            print(f'{fn_meas}: error: multiple time differences between single ts-data files!')
    
            
        ## TODO 2019-8-12: noch so verbessern, dass die minimale Anzahl an single-
        ## ts-files zur Kombination verwendet wird! Dafuer aber wahrscheinlich noch
        ## laenge der single-ts notwendig
        for i in range(len(difft)):
            dict_lengths.update({df.iloc[i, :].loc['ID']: int(round(difft[i]))})
    
        id_last = df.iloc[-1,:].loc['ID']
        
        time = times[0] + dt.timedelta(milliseconds=int(
            df.iloc[0,:].loc['create_millisec']))

    except:
        id_last = None
        time = None
        #print(f'problem with reading/evaluating {fn_meas}')
    
    return(dict_lengths, id_last, time)
    
    
    





"""
 function to combine the ts-data from the single gz-files for one channel into 
 one time series
 search for overlapping parts of the time series and combine there, if no such parts are found than 
 just append the time series from the single files
 if the series have different lengths then return error message

 input:
       - path:         str, folder containing the data files
       - channels:     list of int, containing the channels that should be 
                       considered

 output:


Created on Wed Mar 27 10:15:25 2019

@author:  Christian Kuehnert
@modified: 2021-2-3
"""
def combine_at(path, channels = None):
    
    # check if file t_*_measurement.csv.gz exists
    # TODO 2019-8-9: andernfalls in spaeterem Iterationsschritt die Daten wie
    # bisher anhand ueberlappender Bereiche kombinieren
    critical_channels = []
    dict_res = {}
    
    if os.path.exists(path):
        list_info = [fn for fn in os.listdir(path) if 
                     ('_measurement.csv.gz' in fn)]
    else:
        #print(f'path {path} not found')
        list_info = []
        
    
    if len(list_info)==1:

         # calculate lengths of the contributions from the single parts                                                            
        dict_sl, id_last, t0 = get_single_ts_lengths(f'{path}\\{list_info[0]}')

        if (id_last is None):
            critical_channels = [np.nan]
            #print(f'{list_info[0]}: problems in determining combination times')
            
        else:
            # get 'at_'-files
            list_files = [fn for fn in os.listdir(path) if ('at_' in fn)]
    
            ## extract channels that are in these data
            ltmp = list()               
            if (channels is None):
                for fn in list_files:
                    sid, sch = fn.replace('at_', '').replace('.csv.gz', '').split('_')
                    #ltmp.append({'channel': sch, 'csv_id': int(sid), 
                    #             'file': fn})
                    ltmp.append({'channel': int(sch), 'csv_id': int(sid), 
                                 'file': fn})

            else:
                
                # to be sure that channels are int
                channels = [int(c) for c in channels] 
                
                # only consider channels that are in the given list of channels                
                for fn in list_files:
                    sid, sch = fn.replace('at_', '').replace('.csv.gz', '').split('_')
                    sch = int(sch)
                    if sch in channels:
                        ltmp.append({'channel': sch, 'csv_id': int(sid), 
                                     'file': fn})


            try:            
                df = pd.DataFrame.from_records(ltmp)            
                groups = df.groupby(by=['channel'])
            
                for channel, df_g in groups:
        
                    list_ts = []
                    try:
                        for _idx, row  in df_g.sort_values(by=['csv_id']).iterrows():
                            fn = row['file']
                            meas_id = row['csv_id']
                            tmp = read_gz(f'{path}\\{fn}')
                            # add the last single-ts sequence completely, the others
                            # only until the given stop-index
                            if meas_id==id_last:
                                list_ts.append(tmp)
                                iTS = pd.concat(list_ts, ignore_index=True)
                                times = [t0 + dt.timedelta(milliseconds=i) for i in 
                                         range(len(iTS))]
                                dfTS = pd.DataFrame(data={'time': times,
                                                          'a_t': iTS})
                            else:
                                list_ts.append(tmp[:dict_sl[meas_id]])
                                                            
                        dict_res.update({channel: (dfTS)})
                
                    except:
                        critical_channels.append(channel)
                    #print('Problem bei Kombination von ts-Daten')

            except:
                critical_channels = [np.nan]
                #print('problems, somehow no channels when combination at')

            
    return(dict_res, critical_channels)








"""
auxiliary function to create the hd5-file and add turbine info node

Created on Wed Apr 24 18:24:07 2019

@author: Christian Kuehnert
@modified: 2019-7-18
"""
def initialize_hd5file(db, path_data):
    
    try:
        fn_hd5 = f'{path_data}\\{db}.hd5'
        
        if not os.path.isfile(fn_hd5):             # if no such hd5-file exists            
            with pd.HDFStore(fn_hd5, mode="w", complevel=9, complib='blosc:lz4') as f:        # create empty hd5-file
                f.close()
                
                
        #node = 'turbine_info'
        node = sNodes.turbine_info
        
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
    
            if not (node in f):
                # retrieve relevant data (farm, turbine etc.) from pit   
                sTmp = f"SELECT Windpark_WEA#Windparkname as farm, \
                            WEA_Name as turbine, \
                            WEA_Typ#Name as turbine_type, \
                            Datenbankname as turbine_database, \
                            Beginn_Datenspeicherung as begin_data, \
                            Inbetriebnahme_abgeschlossen as operational \
                        FROM VIEW_Windkraftanlagen \
                        WHERE Datenbankname='{db}'"
                        
                dfTmp = query_pit(sTmp)
    
                f.put(node, dfTmp, format='table', data_columns=True, index=False)                           

        bOk = True
    
    except:
        bOk = False

    return bOk
            



      

"""
auxiliary function to update data in hd5-file directly from database table

@modified: 2020-8-26
"""
def update_hd5fromDB(db, path_data, sTable, node, sHeadersKey, dictTypes=None, 
                     time_start=None, time_end=None, iLimit=None):

    
    sFN_hd5 = f'{path_data}\\{db}.hd5'

    ## if no such hd5-file exists create empty one  
    #if not os.path.isfile(sFN_hd5):                     
    #    with pd.HDFStore(sFN_hd5, mode="w", complevel=9, complib='blosc:lz4'
    #                     ) as f:       
    #        f.close()
    initialize_hd5file(db, path_data)
    
    bHD5Data = False
    with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

        if node in f:
        
            dfData = f[node]
        
            if not isinstance(dfData, pd.DataFrame):
                f.remove(node)
            else:
                bHD5Data = True
                                
            
        dfData_sql = get_data_fromDB(db, sTable, dictTypes=dictTypes, 
                                     listCols=None, time_start=time_start, 
                                     time_end=time_end)
        # TODO 2020-8-28: alles noch stringenter und eleganter machen!
        if not(dfData_sql.empty):
            if bHD5Data:
                dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey
                                            ).reset_index(drop=True)                
                if not(dfAppend.empty):
                    # try to append the newly queried data, if that is not 
                    # possible (this can be e.g. when one string column is in
                    # smaller for the values in f than for the values in 
                    # dfAppend), combine the data outside, remove the original 
                    # node and put it then newly
                    try:            
                        f.append(node, dfAppend, index=False)
                    except:                        
                        dfAppend = dfData_sql.reset_index(drop=True)
                        f.remove(node)                        
                        append_to_hd5Table(f, node, dfAppend, sHeadersKey)

            else:
                dfAppend = dfData_sql.reset_index(drop=True)            
                append_to_hd5Table(f, node, dfAppend, sHeadersKey)

        #f.close()                                                
    
   


"""
function to update the cdef-data

@modified: 2019-7-17


"""
def update_cdef(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cdef
    sTable = 'ba_cycle_measurement_cycle'
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int, 'appendix': str}
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
     









"""
function to collect sda series and store them to .hd5-file

Created on Thu Apr 25 11:38:54 2019

@author: Christian Kuehnert
@modified: 2019-6-25

"""

def update_sda(sDB, sPathData, time_start=None, time_end=None, bSloppy=True):

    lRes = []
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef  #'raw_data/cdef'
    sNode_sda_data = sNodes.sda_data     # sNode_sda + '/data'                                 # subnode with sda data
    sNode_sda_startstop = sNodes.sda_startstop     # sNode_sda + '/startstop'                        # subnode with row numbers of start and stop of each sda series
       
    #sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = f'{sPathData}\\{sDB}.hd5'               # full hd5-file name
        
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

            #TODO 2018-12-16: klaeren, ob die sda-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!
            lWhere = ['available_data>=2']                            # consider only cycles where sda-files were stored
            sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                
            if sWhere:
                lWhere.append(sWhere)
                
            sWhere = ' and '.join(lWhere)
                        
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                            
            iCycles = dfCDEF.shape[0]                                          # number of cycles
    
    
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2019-6-25: assume that always both sNode_sda and sNode_sda_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_sda_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                #bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_sda_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the sda-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the sda-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=False - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                #bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'filename', 'blade', 'direction', 'start','stop'])
            
                                    
            iCycles = dfCDEF.shape[0]

            count = 0
            #for i in range(iCycles):
            for idx, cdef in dfCDEF.iterrows():
                
                count += 1
                
                #tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                #iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                tsCT = cdef['create_time']
                iID = cdef['ID']                 
                   
                if (count % 100 == 0):
                    print(sDB + '  ' + str(count) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID), end = '\r', flush=True)


                if not ((iID==0) or pd.isnull(tsCT)):
                                                            
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        # TODO 2019-1-10: evtl. mit regex noch genauer spezifizieren
                        sFiles = fnmatch.filter(os.listdir(sFolder), 'af_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
        
                        for sFN in sFiles:
#TODO 2019-7-16: hier auch hub_axial usw. mitnehmen, moeglichst generisch!                            
                            sFN_short = sFN.replace('af_', '').replace('.csv.gz', '')       # remove 'af_' and ending from file name
                            
                            ## check if already stored in the .hd5-file
                            #if bCycEx:                                              # if there are already existing time series
                                
                            # if there is no entry for this cycle and channel:
                            if (dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID) & (dfCycTSEx.filename==sFN_short)].shape[0]==0):
                        
                                parts = sFN_short.split('_')      # split (short) file name by '_'
                        
                                iBlade = int(parts[-1])-100
                                sDirection = parts[0]
                                #if (parts[1]=='axial') and not((sDirection=='edge') or (sDirection == 'flap')):
                                #if (parts[1]=='axial'):
                                if parts[1].isalpha():
                                    sDirection = sDirection + '_' + parts[1]
                                                                                                                   
                                create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                                                                                          
                                try:    

                                    ## now aggregate the remaining files                                
                                    dSDA = read_gz(f'{sFolder}\\{sFN}', tType=np.float64)                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                                                     
                                    iCnt = len(dSDA)
                                    if iCnt>0:  
                                    
                                        #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df1 = pd.DataFrame(data=(np.tile([create_day, iID, sFN_short], [iCnt,1])), columns = ['create_day', 'ID', 'filename'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCnt)), dSDA), axis=1)))
                                        df2.columns = ['idx', 'a_f']
                                        dfTmp = pd.concat((df1,df2), axis=1)

                                        dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        #dfTmp['filename'] = dfTmp['filename'].astype(string)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        #dfTmp['a_f'] = dfTmp['a_f'].astype(float)
                                        
                                        #iStart = f.get_storer(sNode_ts_data).nrows
                                        f.append(sNode_sda_data, dfTmp, format='table', data_columns = True, index=False, min_itemsize={'filename': 40})
                                        
                                        # now add row numbers for start and stop for this time series
                                        iStop = f.get_storer(sNode_sda_data).nrows
                                        iStart = iStop - dfTmp.shape[0]
                                        
                                        dfMap = pd.DataFrame(data=[[tsCT, iID, sFN_short, iBlade, sDirection, iStart, iStop]], columns = ['create_time','ID','filename','blade', 'direction','start','stop'])
                                        dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                        dfMap['ID'] = dfMap['ID'].astype(int)
                                        dfMap['blade'] = dfMap['blade'].astype(int)
                                        #dfMap['filename'] = dfMap['filename'].astype(str)
                                        #dfMap['direction'] = dfMap['direction'].astype(str)
                                        dfMap['start'] = dfMap['start'].astype(np.int64)
                                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                        f.append(sNode_sda_startstop, dfMap, format='table', data_columns = True, index=False, min_itemsize={'filename': 40})    
                                        
                                        lRes.append(dfMap)

                                                                        
                                except Exception:
                                    print(sDB + '  ' + str(count) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', file ' + sFN + ': Probleme mit Entpacken oder Einlesen', end = '\r', flush=True)

                 
    if len(lRes)==0:
        return(pd.DataFrame(columns=['create_time', 'ID', 'filename', 'blade', 'direction', 'start','stop']))
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        return(dfRes)


    #return(lMsg)






"""
function to update the ts data


# TODO 2018-12-4: aufspalten in update_ts_fromCDEF(sDB, sPathData, dfCDEF) wo nur die in dfCDEF uebergebenen cycles upgedatet werden, und update_ts() wo die dfCDEF-cycles
# wie hier implementiert bestimmt werden, und dann darauf update_ts_fromCDEF anwenden. D.h. 
# TODO 2018-12-7: hier noch so implementieren, dass entweder 1) die sNode_ts_startstop eine Spalte enthaelt, ob ein folder ueberhaupt ts-daten enthaelt, der zugehoerige dataframe
# ist dann bzgl. der Keys eine Kopie von dfCDEF, bei sloppy=True werden dann wirklich nur noch neue cycles durchsucht, oder 2) einen weitere node sNode_cycles anlegen, welche
# eben alle cycles von dfCDEF enthaelt und jeweils eine spalte mit true/false oder 1/0 fuer ts-Daten und eine entsprechend fuer sda-Daten, dann mit dieser entsprechend arbeiten


@modified: 2019-7-18

"""
def update_ts_old(sDB, sPathData, time_start=None, time_end=None, iCntMeasBase = 8192, bSloppy=True):

    #lMsg = []
    lRes = []
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef               #  'raw_data/cdef'
    #sNode_ts = 'raw_data/ts'                                           # node where the time series data are stored
    sNode_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
       
    sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = f'{sPathData}\\{sDB}.hd5'                 # full hd5-file name
    
    
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

#TODO 2018-12-16: klaeren, ob die TS-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!            
            lWhere = ['available_data>2']                            # consider only cycles where sda-files were stored
            sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                
            if sWhere:
                lWhere.append(sWhere)
                
            sWhere = ' and '.join(lWhere)
                        
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                
            iCycles = dfCDEF.shape[0]                                          # number of cycles                

    
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2018-12-2: assume that always both sNode_ts and sNode_ts_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_ts_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_ts_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the ts-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=True - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'channel', 'overlap', 'start','stop'])
            
                                    
            iCycles = dfCDEF.shape[0]

            for i in range(iCycles):
                
                #tsCT = dfCDEF.create_time[i]                                       # current create_time
                #iID = dfCDEF.ID[i]                                                 # current ID
                tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                                    
                if (i % 20 == 0):
                    #                        print(sInfo)                   
                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID))


                if not ((iID==0) or pd.isnull(tsCT)):
                                    
#                    sInfo = sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                        
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            #if (i % 20 > 0):
                            #    print(sInfo)
                            
                            #print('    files exist')
                            create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                #dfCycEx = f.select(sNode_ts, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                #dfCycEx = dfCycTSEx[(dfCycTSEx.create_day==create_day) & (dfCycTSEx.ID==iID)]
                                dfCycEx = dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID)]

                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    #print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
                            # TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            lChAdded = []
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(f'{sFolder}\\{sFN0}'))     # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                   
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        
                                        #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df1 = pd.DataFrame(data=(np.tile([create_day, iID, iCh], [iCntTS,1])), columns = sHeadersKey)
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)

                                        dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #iStart = f.get_storer(sNode_ts_data).nrows
                                        f.append(sNode_ts_data, dfTmp, format='table', data_columns = True, index=False)    
                                        
                                        # now add row numbers for start and stop for this time series
                                        iStop = f.get_storer(sNode_ts_data).nrows
                                        iStart = iStop - dfTmp.shape[0]
                                        
                                        dfMap = pd.DataFrame(data=[[tsCT, iID, iCh, iOL, iStart, iStop]], columns = ['create_time','ID','channel','overlap','start','stop'])
                                        dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                        dfMap['ID'] = dfMap['ID'].astype(int)
                                        dfMap['channel'] = dfMap['channel'].astype(int)
                                        dfMap['overlap'] = dfMap['overlap'].astype(int)
                                        dfMap['start'] = dfMap['start'].astype(np.int64)
                                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                        f.append(sNode_ts_startstop, dfMap, format='table', data_columns = True, index=False)    
                                        
                                        lRes.append(dfMap)
                                        
                                        #lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        #print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        lChAdded.append(str(iCh))
                    
                                    #else:
                                    #    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception:
                                    #lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
                                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                            # information if time series were added
                            #if len(lChAdded)>0:
                            #    print(sInfo + ': ts for channels ' + ','.join(lChAdded) + ' added')
                 
    if len(lRes)==0:
        return(pd.DataFrame(columns=['create_time','ID','channel','overlap','start','stop']))
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        return(dfRes)


    #return(lMsg)




"""
function to find all channels for the given period (with max_lag tolerance)
returns series with index = (create_time, cycle id (as string)) and data=list
of datas for that data exist in this folder

@modified: 2020-4-24
"""
def get_existing_ts(db, time_start = None, time_end = None, channels = None,
                    max_lag = timedelta(days=2)):
    
    #1. get all days within period
    if (time_end is None):
        time_end = dt.datetime.now()
        
    # TODO 2020-4-25: anhand Beginn Datensammeln der WEA Startzeitpunkt waehlen
    if (time_start is None):
        time_start = dt.datetime(2000,1,1)   
    
    
    d_s, d_e = (time_start - max_lag).date(), min(dt.datetime.now(), (time_end + max_lag)).date()
    dates = [d_s + timedelta(days=x) for x in range((d_e-d_s).days + 1)]

#    keys = list()
#    list_channels = list()
    res = list()
    
    for path_date in dates:

        day_folder = get_day_folder(db, dt.datetime(path_date.year, 
                                                    path_date.month, 
                                                    path_date.day))
        if os.path.isdir(day_folder):
            try:
                cycle_folders = [dI for dI in os.listdir(day_folder) if 
                                     os.path.isdir(os.path.join(day_folder, dI))]
            except:
                cycle_folders = list()
        else:
            cycle_folders = list()       
            
        for id_folder in cycle_folders:
            
            try:
                folder = f'{day_folder}\\{id_folder}'
                files = os.listdir(folder)
                cand = [fn for fn in files if (fn[:3]=='at_') and 
                        (fn[-7:]=='.csv.gz')]
                
                if len(cand)>0:
                    chs = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in cand])
                    
                    # if required channels are given than take into account
                    # those only
                    if not(channels is None):
                        chs = sorted(set(chs).intersection(set(channels)))
                        
                    for ch in chs:
                        res.append((path_date, id_folder, folder, ch))
                    #[res.append((day, id_folder, folder, ch)) for ch in chs]
                    
                    
#                    if len(chs)>0:
#                        list_info = [fn for fn in files if 
#                                     fn[-19:]=='_measurement.csv.gz']
#                    
#                        fn_meas = f'{path}\\{list_info[0]}'
#                        
#                        df = pd.read_csv(fn_meas, 
#                                         compression='gzip', sep=',',
#                                         quotechar='"', index_col=False, 
#                                         usecols = ['create_time'],
#                                         dtype={'create_time': str})
#                        
#                        cts = df.create_time.unique()[0]
                        
                        # TODO 2020-4-23: eigentlich hier noch folgendes hin, da die 
                        # ts-folder-Namen nicht die genauen Zeitstempel wiedergeben,
                        # und dafuer oben die 
                        # if (cts >= start_time) and (cts<=end_time):
#                        ct = dt.datetime.strptime(cts, "%Y%m%d%H%M%S")
#                        keys.append((ct, cycle_id))
#                        keys.append(folder)
#                        list_channels.append(chs)

            except:
                pass
 
    df = pd.DataFrame.from_records(res, columns = ['path_date', 'ID', 
                                                   'folder', 'channel'])
#    return(pd.Series(index=keys, data=list_channels))
    return(df)
 
    







"""
function to update the ts data from the file system (if the database is not
available or doesn't have correct availability entries)

Note: one could probably speed up this function by applying the check if an
entry for a cycle already exists within the loops through the day folders, then
the listdir process has to be done only once per folder and some redundant
operations could be neglected. However, the approach given below was chosen in
order to keep the main extraction part the same way as it is in update_ts(...)


ATTENTION: PRELIMINARY VERSION, ONLY TO BE USED FOR SOME SPECIAL OCCASIONS, DO 
NOT (YET) COMBINE WITH NORMAL UPDATE_TS - FUNCTION, 



@modified: 2020-4-23

"""
def update_ts_without_db(db, sPathData, time_start=None, time_end=None,
                         max_lag = dt.timedelta(days=2), 
                         channels=range(6), bNewVersion = True):

    
    #lMsg = []
    lRes = list()
    
    #sDTFormat_hd5='%Y%m%d%H%M%S'
    
    #sNode_cdef = sNodes.cdef               #  'raw_data/cdef'
    sNode_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
       
    #sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    sHeadersKey = ['folder', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = f'{sPathData}\\{db}_ts_from_fs.hd5'                 # full hd5-file name
    
    # series of existing channels with folders, df_new contains the columns
    # 'path_date', 'ID', 'folder', 'channel'
    df_new = get_existing_ts(db, time_start=time_start, time_end=time_end, 
                               max_lag = max_lag, channels=channels)

#    3. get set difference between folder,channel - already existing 
#       folder, channel in startstop        
    if not(df_new.empty):
    #TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
    
            # TODO 2020-4-28: noch Fall abfangen, dass sNode_ts_data vorhanden
            # ist, aber nicht sNode_ts_startstop, aktuell wird beider 
            # Existenz und Konsistenz vorausgesetzt
            if (sNode_ts_data in f):    
                #bCycEx = True
                dfCycTSEx = f.select(key=sNode_ts_startstop)                    
                
                # find all existing folders that are contained in the new folder list
                #df_ex = dfCycTSEx[dfCycTSEx.folder.isin(cdef.index)]
                # TODO 2020-4-24: Noch VIEEEL eleganter machen! (groupby, 
                # setdiff o.ae., ohne Umweg ueber dataframe)
                df_new = setdifference_df(df_new, dfCycTSEx, ['folder', 
                                                                'channel'])
                
                # TODO 2020-10-5: eigentlich lieber schon in setdifference_df auf Index 0,1,... zuruecksetzen, alles konsistent machen
                df_new.reset_index(drop=True, inplace=True)
#    2. search in each day folder for top level directories (i.e. cycle ids)
#   and there for (cycle) folders that contain at_....csv.gz files  
    # TODO 2020-4-22: zeitlich optimieren
    cnt = 1
    n_cyc = df_new.shape[0]
    
    
    # assumes consistency of the three columns
    groups = df_new.groupby(['path_date', 'ID', 'folder'])
    #groups = df_new.groupby(['folder'])
    for group, df_g in groups:

        path_date = group[0]
        cyc_id = group[1]
        path = group[2]
        
        if (cnt % 20 == 0):
            myprint(f"{cnt}/{n_cyc}: {path}")
        cnt += 1
        try:                            
            list_info = [fn for fn in os.listdir(path) if 
                                             ('_measurement.csv.gz' in fn)]
        
            fn_meas = f'{path}\\{list_info[0]}'
            
            df = pd.read_csv(fn_meas, 
                             compression='gzip', sep=',',
                             quotechar='"', index_col=False, 
                             usecols = ['create_time'],
                             dtype={'create_time': str})
            
            #cts = df.create_time.unique()[0]
            cts = df.create_time.min()
            ct = dt.datetime.strptime(cts, "%Y%m%d%H%M%S")                                        
            iID = int(cyc_id)
            
            bOk = not ((iID==0) or pd.isnull(ct))
            if bOk:
                
                # da die ts-folder-Namen nicht die genauen Zeitstempel wiedergeben:
                # if (cts >= start_time) and (cts<=end_time):
                if not(time_start is None):
                    bOk = (ct >= time_start)
                    
                if not(time_end is None):
                    bOk = bOk and (ct <= time_end)
            
            
            if bOk:
    
                #create_day = pd.to_datetime(ct.date(), errors='coerce')            # day of create_time
                
                #if os.path.isdir(sFolder):
                # TODO 2020-4-24: combine_at so aendern, dass nur die 
                try:
                    
                    dict_res, critical_channels = combine_at(path, channels)
                            
                    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
                                                                                        
                        for ch, df_at in dict_res.items():
                                    
                            iCntTS = df_at.shape[0]
                            if iCntTS>0:  
                                
                                # old version, in new version without redundant
                                # information to save time and space
                                if bNewVersion:
                                    df_at['time'] = pd.to_datetime(df_at['time'], 
                                                                 errors='coerce')                                        
                                    df_at['a_t'] = df_at['a_t'].astype(float)
                                    
                                    #iStart = f.get_storer(sNode_ts_data).nrows
                                    f.append(sNode_ts_data, df_at, format='table', 
                                             data_columns = True, index=False)
                                    
                                    # now add row numbers for start and stop for this time series
                                    iStop = f.get_storer(sNode_ts_data).nrows
                                    iStart = iStop - df_at.shape[0]
    
                                else:
                                    df1 = pd.DataFrame(data=(np.tile([path, ch], 
                                                                     [iCntTS,1])), 
                                                columns = sHeadersKey, index=df_at.index)
                                    dfTmp = pd.concat((df1, df_at), axis=1)
            
                                    #dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                    #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                    #dfTmp['ID'] = dfTmp['ID'].astype(int)
                                    dfTmp['folder'] = dfTmp['folder'].astype(str)
                                    dfTmp['channel'] = dfTmp['channel'].astype(int)
                                    #dfTmp['idx'] = dfTmp['idx'].astype(int)
                                    dfTmp['time'] = pd.to_datetime(dfTmp['time'], 
                                                                         errors='coerce')                                        
                                    dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                    
                                    #iStart = f.get_storer(sNode_ts_data).nrows
                                    f.append(sNode_ts_data, dfTmp, format='table', 
                                             data_columns = True, index=False,
                                             min_itemsize = {'folder' : 150 })    
    
                                
                                    # now add row numbers for start and stop for this time series
                                    iStop = f.get_storer(sNode_ts_data).nrows
                                    iStart = iStop - dfTmp.shape[0]
                                
                                dfMap = pd.DataFrame(data=[[ct, iID, ch, path, 
                                                            iStart, iStop]], 
                                                    columns = ['create_time','ID',
                                                               'channel','folder',
                                                               'start','stop'])
                                dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                dfMap['ID'] = dfMap['ID'].astype(int)
                                dfMap['channel'] = dfMap['channel'].astype(int)
                                dfMap['folder'] = dfMap['folder'].astype(str)
                                dfMap['start'] = dfMap['start'].astype(np.int64)
                                dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                f.append(sNode_ts_startstop, dfMap, format='table', 
                                         data_columns = True, index=False,
                                         min_itemsize = {'folder' : 150 })    
                                
                                lRes.append(dfMap)
                                
                                #lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                #print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                #lChAdded.append(str(ch))
                
                except Exception:
                    print(f'{db}  {cnt} / {n_cyc}, {path_date}  {cyc_id}: Probleme mit einem oder mehreren der channels')

                    
        except Exception:
            #lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
            #tmp = cts.strftime("%Y\\%m\\%d")
            print(f'{db}  {cnt} / {n_cyc}, {path_date}  {cyc_id}: Probleme mit entpacken oder zusammenfuegen')

                 
    if len(lRes)==0:
        dfRes = pd.DataFrame(columns=['create_time','ID','channel','folder',
                                     'start','stop'])
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        
    return(dfRes)



"""
function to update the ts data


# TODO 2018-12-4: aufspalten in update_ts_fromCDEF(sDB, sPathData, dfCDEF) wo nur die in dfCDEF uebergebenen cycles upgedatet werden, und update_ts() wo die dfCDEF-cycles
# wie hier implementiert bestimmt werden, und dann darauf update_ts_fromCDEF anwenden. D.h. 
# TODO 2018-12-7: hier noch so implementieren, dass entweder 1) die sNode_ts_startstop eine Spalte enthaelt, ob ein folder ueberhaupt ts-daten enthaelt, der zugehoerige dataframe
# ist dann bzgl. der Keys eine Kopie von dfCDEF, bei sloppy=True werden dann wirklich nur noch neue cycles durchsucht, oder 2) einen weitere node sNode_cycles anlegen, welche
# eben alle cycles von dfCDEF enthaelt und jeweils eine spalte mit true/false oder 1/0 fuer ts-Daten und eine entsprechend fuer sda-Daten, dann mit dieser entsprechend arbeiten

try_2_if_wrong_availability_values: for some db the availability-flag was not set correctly to 3 for time series, if this
option is True then the method will in this case check for available ts data
within the folders even when available_data == 2 and not 3
    
    
@modified: 2020-9-24

"""
def update_ts(sDB, sPathData, time_start=None, time_end=None, 
              filter_cdef = None, bSloppy=True, bReturn = False,
              try_2_if_wrong_availability_values = False):

    #lMsg = []
    lRes = list()
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef               #  'raw_data/cdef'
    sNode_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
       
    #sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = f'{sPathData}\\{sDB}.hd5'                 # full hd5-file name    
    
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

#TODO 2018-12-16: klaeren, ob die TS-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!            
            sWhere = whereClause_from_timeInterval(time_start=time_start, 
                                                   time_end = time_end, 
                                                   sFormat = sDTFormat_hd5)                                

            if try_2_if_wrong_availability_values:
                lWhere = ['available_data>1']                          # consider only cycles where sda-files were stored

            else:
                lWhere = ['available_data>2']                          # consider only cycles where sda-files were stored
                
            if not(sWhere is None):
                lWhere.append(sWhere)                
                sWhere = ' and '.join(lWhere)                        
                
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()                

            b3 = (dfCDEF.available_data.values==3)
            # if there are rows with ==3 or otherwise nothing should be done
            # then select only those rows (and get empty df if there are none),
            # otherwise work with the ==2-values
            if (any(b3) or not(try_2_if_wrong_availability_values)):
                dfCDEF = dfCDEF[b3]
            else:
                print(f'{sDB}: no data_availability==3, try ==2-folders, but this might take a while')
                        
            # sWhere = whereClause_from_timeInterval(time_start=time_start, 
            #                                        time_end = time_end, 
            #                                        sFormat = sDTFormat_hd5)                                
            # if sWhere:
            #     lWhere.append(sWhere)                
            # sWhere = ' and '.join(lWhere)                        
            # dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()                

    
    if not(dfCDEF.empty):
        iCycles = dfCDEF.shape[0]         
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2018-12-2: assume that always both sNode_ts and sNode_ts_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_ts_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_ts_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the ts-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=True - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, 
                                              ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 
                                                    'channel', 'folder', 
                                                    'start','stop'])
            
                      
            if not(filter_cdef is None):
                dfCDEF, sfilter = filter_data(dfCDEF, filter_cdef)
                print(f'filter: {sfilter}')
                
            iCycles = dfCDEF.shape[0]

            for i in range(iCycles):
                
                #tsCT = dfCDEF.create_time[i]             # current create_time
                #iID = dfCDEF.ID[i]                                # current ID
                tsCT = dfCDEF.iloc[i,:].loc['create_time']# current create_time
                iID = dfCDEF.iloc[i,:].loc['ID']                   # current ID
                                    
                if (i % 20 == 0):
                    #                        print(sInfo)                   
                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + \
                          ', day ' + tsCT.strftime('%Y\\%m\\%d') + \
                          ', ID ' + str(iID))


                if not ((iID==0) or pd.isnull(tsCT)):
                                    
#                    sInfo = sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                        
                    folder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(folder):
        
                        sFiles = fnmatch.filter(listdir(folder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            #if (i % 20 > 0):
                            #    print(sInfo)
                            
                            #print('    files exist')
                            #create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                #dfCycEx = f.select(sNode_ts, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                #dfCycEx = dfCycTSEx[(dfCycTSEx.create_day==create_day) & (dfCycTSEx.ID==iID)]
                                dfCycEx = dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID)]

                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    #print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
                            # combine the channels
                            try:
                                dict_res, critical_channels=combine_at(folder, 
                                                                    iChannels)                            
                                with pd.HDFStore(sFN_hd5, 'a', complevel=9, 
                                                 complib='blosc:lz4') as f:
                                                                                                    
                                    for ch, df_at in dict_res.items():
                                                
                                        iCntTS = df_at.shape[0]
                                        if iCntTS>0:  
    
                                            df_at['time']=pd.to_datetime(
                                                    df_at['time'], 
                                                    errors='coerce')                                        
                                            df_at['a_t']=df_at['a_t'].astype(
                                                    float)
                                            
                                            #iStart = f.get_storer(sNode_ts_data).nrows
                                            f.append(sNode_ts_data, df_at, 
                                                     format='table', 
                                                     data_columns = True, 
                                                     index=False)
                                            
                                            # now add row numbers for start and 
                                            # stop for this time series
                                            iStop=f.get_storer(sNode_ts_data).nrows
                                            iStart=iStop - df_at.shape[0]
            
                                            dfMap = pd.DataFrame(data=[[tsCT, iID, ch, folder, 
                                                                        iStart, iStop]], 
                                                                columns = ['create_time','ID',
                                                                           'channel','folder',
                                                                           'start','stop'])
                                            dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                            dfMap['ID'] = dfMap['ID'].astype(int)
                                            dfMap['channel'] = dfMap['channel'].astype(int)
                                            dfMap['folder'] = dfMap['folder'].astype(str)
                                            dfMap['start'] = dfMap['start'].astype(np.int64)
                                            dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                            f.append(sNode_ts_startstop, dfMap, format='table', 
                                                     data_columns = True, index=False,
                                                     min_itemsize = {'folder' : 150 })    
                                            
                                            lRes.append(dfMap)
                                            
                                            #lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                            #print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                            #lChAdded.append(str(iCh))
                        
                                        #else:
                                        #    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                            except Exception:
                                #lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
                                print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ': Probleme mit Entpacken oder Zusammenfuegen')

                            # information if time series were added
                            #if len(lChAdded)>0:
                            #    print(sInfo + ': ts for channels ' + ','.join(lChAdded) + ' added')
      
    if bReturn:           
        if len(lRes)==0:
            dfRes=pd.DataFrame(columns=['create_time','ID','channel','folder',
                                          'start','stop'])
        else:
            dfRes=pd.concat(lRes, axis=0, ignore_index=True).reset_index()
    
        return(dfRes)
        
#    else:
#        return(None)















"""
function to update cdef data


Created on Thu Apr 25 02:03:56 2019

@author: Christian Kuehnert, 2019-2-6
TODO 2019-7-28: umgestalten, dass hier auch mit SChluesseltabelle gearbeitet
wird ODER auf Variante von SB umstellen
"""
def update_se(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.sig_energy
    #sTable = 'sig_energies'
    sTable = 'ba_cycle_sig_energies'
    sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
    dictTypes={'cycle_id': int}
    iLimit = 500000
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)

    #return(dfData)
        


#
#"""
#function to save turbine info in hd5-file if not already there
#
#
#Created on Wed Apr 24 18:25:14 2019
#
#@author: Christian Kuehnert, 2019-1-11
#"""
#def set_turbineInfo(db, path_data):
#    
#    #node = 'turbine_info'
#    node = sNodes.turbine_info
#
#    fn_hd5 = fullfile([path_data, db + '.hd5'])    
#    
#    with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#
#        if not (node in f):
#            # retrieve relevant data (farm, turbine etc.) from pit   
#            sTmp = f"SELECT Windpark_WEA#Windparkname as farm, \
#                        WEA_Name as turbine, \
#                        WEA_Typ#Name as turbine_type, \
#                        Datenbankname as turbine_database, \
#                        Beginn_Datenspeicherung as begin_data, \
#                        Inbetriebnahme_abgeschlossen as operational \
#                    FROM VIEW_Windkraftanlagen \
#                    WHERE Datenbankname='{db}'"
#                    
#            dfTmp = query_pit(sTmp)
#
#            f.put(node, dfTmp, format='table', data_columns=True, index=False)                           



"""
function to update data in table 'ba_cycle_status'

@author: Christian Kuehnert, 2019-2-6
"""
def update_status(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cycle_status
    sTable = 'ba_cycle_status'
    #dictTypes={'ID': int, 'appendix': str}
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int}
    iLimit = 500000

    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)

    #return(dfData)
 




"""
function to update cdef data


Created on Thu Apr 25 02:02:49 2019

@author: Christian Kuehnert, 2019-2-6
"""

#from data import class_hd5Nodes as sNodes
#from data import update_hd5fromDB

def update_ext(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.externals
    sTable = 'ba_cycle_externals'
    sHeadersKey = ['create_time']
    dictTypes=None
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
           
    




"""
function to update the hd5-file of the given turbine
@author: Christian Kuehnert

2019-2-6

Example:
--------
sDB = 'cmrblba_bc_t_mb_bw48'
sPathData = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\data\hd5_files'
update_all_hd5(sDB, sPathData)


"""

def update_all_hd5(sDB, sPathData, time_start=None, time_end=None):
    
    print('updating ' + sDB + ':')
    
    print('       update cdef')
    update_cdef(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update status')
    update_status(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update se')
    update_se(sDB, sPathData, time_start=time_start, time_end=time_end)        
    
    print('       update sda')
    update_sda(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update ts')
    update_ts(sDB, sPathData, time_start=time_start, time_end=time_end)
         


