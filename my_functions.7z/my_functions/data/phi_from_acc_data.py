# -*- coding: utf-8 -*-
"""
Created on Mon May 27 13:36:40 2019

function to determine rotation angle from acc. data, migration from MATLAB-function rblTheta.m from Simon Roeschner:

% ----------------------------------------------------------------------------
% Simon Röschner (SR2,w010217)
%  -- erstellt: 28.06.18
%  -- zuletzt geändert: 10.07.18
%
% Ablauf:
%   Berechnet einen Rotorwinkel aus gegebenen Zeitdaten, die zuvor auf
%   Rotordrehfrequenz gefiltert wurden. Dabei wird der Winkel für jedes
%   Blatt einzeln berechnet.
% 
% In:
%   zd_R: Matrix (11x49152 double); auf Rotordrehfrequenz gefilterte Zeitdaten
%   eORf: String; Richtung: Edge ('e') oder Flap ('f');
%   Te: double; berechnete Einschwingzeit
%
% Out:
%   theta_rad: Matrix; Rotorwinkel in rad für Blatt 1,2,3
%   theta_deg: Matrix; Rotorwinkel in Grad für Blatt 1,2,3
%
% ----------------------------------------------------------------------------
function [ theta_rad, theta_deg ] = rblTheta( zd_R, eORf, Fs )
t = 0:1/Fs:(size(zd_R,2)-1)/Fs; % Zeitachse
[ch,~] = direction(eORf); % Channels der Zeitdaten für angegebene Richtung bestimmen.
delta = zeros(size(zd_R(ch,:),1),size(zd_R,2));
anstieg = zeros(size(zd_R(ch,:)));
for m = 2:size(zd_R,2)
    delta(:,m) = (zd_R(ch,m)-zd_R(ch,m-1))/(t(m)-t(m-1)); % Anstieg zwischen den Messpunkten der Zeitdaten bestimmen
end
for m = 2:size(zd_R,2)-1
    anstieg(:,m) = mean([delta(:,m) delta(:,m+1)],2); % Anstieg an den jeweiligen Messpunkten (MW-Bildung). Anstieg des ersten und letzten Messwerts nicht korrekt.
end

%% Zuordnung der Zeitdaten zum Rotorwinkel
% 1. Quadrant (zwischen 12 und 3 Uhr): zd > 0 und anstieg < 0
% 2. Quadrant (zwischen 12 und 9 Uhr): zd < 0 und anstieg < 0
% 3. Quadrant (zwischen 9 und 6 Uhr): zd < 0 und anstieg > 0
% 4. Quadrant (zwischen 6 und 3 Uhr): zd > 0 und anstieg > 0
% dementsprechend muss gelten: anstieg = sin(theta), zd = -cos(theta)
% und so theta = atan(anstieg/-zd)
theta_rad = zeros(size(zd_R(ch,:)));
theta2_rad = zeros(size(zd_R(ch,:))); % Winkel aus delta berechnet: Winkel zwischen den Zeitpunkten.
for m = 2:size(zd_R,2)-1 % Da durch die Einschwingzeit Bereiche 0 gesetzt wurden, werden nur zu vorhandenen Datenwerden (ab Te) Anstiege berechnet.
    theta_rad(:,m) = atan2(anstieg(:,m),-zd_R(ch,m)); % atan2: 4-Quadranten Inverse!
end
for m = 2:size(zd_R,2) % Da durch die Einschwingzeit Bereiche 0 gesetzt wurden, werden nur zu vorhandenen Datenwerden (ab Te) Anstiege berechnet.
    theta2_rad(:,m) = atan2(delta(:,m),-zd_R(ch,m)); % atan2: 4-Quadranten Inverse, nutzt Anstieg zwischen den Werten.
end
theta_deg = theta_rad * 180/pi; % Winkel in [Grad]

end


@author: w012028
@modified: 2019-5-27
"""

import math
import numpy as np
import pandas as pd



def rblTheta(zd_r, eORf, Fs, dict_dir = {'edge': [3,4,5], 'flap': [0,1,2]}):

    #t = 0:1/Fs:(size(zd_R,2)-1)/Fs; # Zeitachse
    
   # [ch,~] = direction(eORf); % Channels der Zeitdaten für angegebene Richtung bestimmen.
    
    #delta = zeros(size(zd_R(ch,:),1),size(zd_R,2));
    
    #anstieg = zeros(size(zd_R(ch,:)));
        
    #for m = 2:size(zd_R,2)    
    #    delta(:,m) = (zd_R(ch,m)-zd_R(ch,m-1))/(t(m)-t(m-1)); % Anstieg zwischen den Messpunkten der Zeitdaten bestimmen
    #end
    #for m = 2:size(zd_R,2)-1
    #    anstieg(:,m) = mean([delta(:,m) delta(:,m+1)],2); % Anstieg an den jeweiligen Messpunkten (MW-Bildung). Anstieg des ersten und letzten Messwerts nicht korrekt.
    #end

    delta = np.diff(zd_r)
    tmp = pd.concat(delta[1:],delta[:-2])
    anstieg = np.mean(tmp, axis=1)
            
    
#    %% Zuordnung der Zeitdaten zum Rotorwinkel
#    % 1. Quadrant (zwischen 12 und 3 Uhr): zd > 0 und anstieg < 0
#    % 2. Quadrant (zwischen 12 und 9 Uhr): zd < 0 und anstieg < 0
#    % 3. Quadrant (zwischen 9 und 6 Uhr): zd < 0 und anstieg > 0
#    % 4. Quadrant (zwischen 6 und 3 Uhr): zd > 0 und anstieg > 0
#    % dementsprechend muss gelten: anstieg = sin(theta), zd = -cos(theta)
#    % und so theta = atan(anstieg/-zd)

    #theta_rad = zeros(size(zd_R(ch,:)));

    #theta2_rad = zeros(size(zd_R(ch,:))); % Winkel aus delta berechnet: Winkel zwischen den Zeitpunkten.

    #for m = 2:size(zd_R,2)-1 % Da durch die Einschwingzeit Bereiche 0 gesetzt wurden, werden nur zu vorhandenen Datenwerden (ab Te) Anstiege berechnet.
    #    theta_rad(:,m) = atan2(anstieg(:,m),-zd_R(ch,m)); % atan2: 4-Quadranten Inverse!
    #end
    
    theta_rad = np.arctan2(anstieg, -zd_r)
    
    

    #for m = 2:size(zd_R,2) % Da durch die Einschwingzeit Bereiche 0 gesetzt wurden, werden nur zu vorhandenen Datenwerden (ab Te) Anstiege berechnet.
    #    theta2_rad(:,m) = atan2(delta(:,m),-zd_R(ch,m)); % atan2: 4-Quadranten Inverse, nutzt Anstieg zwischen den Werten.
    #end
    theta2_rad = np.arctan2(delta, -zd_r)
    

    theta_deg = theta_rad * 180/math.pi; # Winkel in [Grad]
    

return([ theta_rad, theta_deg ])





