# -*- coding: utf-8 -*-
"""
Created on Mon Dec 17 15:56:11 2018

@author: w012028
@modified: 2019-8-8
"""

class hd5Nodes:
    
    turbine_info = 'turbine_info'
    
    cdef = 'raw_data/cdef'    
    externals = 'raw_data/externals'
    cycle_measurement = 'raw_data/measurement'
    cycle_status = 'raw_data/cycle_status'            # node with data from table 'ba_cycle_status'
    sig_energy = 'raw_data/sig_energy'
    dyn_loads = 'raw_data/dyn_loads'
    
    label = 'raw_data/label'
    sda = 'raw_data/sda'    
    #ts = 'raw_data/ts'    
    ts_data = 'raw_data/ts/data'                      # subnode with ts data
    ts_startstop = 'raw_data/ts/startstop'            # subnode with row numbers of start and stop of each ts

    sda_data = 'raw_data/sda/data'                    # subnode with sda data
    sda_startstop = 'raw_data/sda/startstop'          # subnode with row numbers of start and stop of each sda series


    # new nodes for auxiliary files for special query from SW, mail from
    # 2019-8-6
    startstop = 'startstop'
    af = 'sda'
    at = 'ts'


