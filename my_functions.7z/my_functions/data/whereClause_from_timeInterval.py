# -*- coding: utf-8 -*-
"""
function to create a where clause for the 'where=' in hdfstore.select-method or SQL-Query
from the given datetimes for start and stop

Created on Wed Mar 27 10:23:29 2019

@author: Christian Kuehnert
@modified: 2019-7-17

"""

#from data import time_to_string as time_to_string
#import data.time_to_string as time_to_string
#from data.time_to_string import time_to_string
#from . import time_to_string
from . import time_to_string


def whereClause_from_timeInterval(time_start=None, time_end=None, sFormat='%Y%m%d%H%M%S', sTimeCol='create_time'):
        
    # TODO 2018-12-21: den Zweig, dass time_start oder time_end strings sind, noch mit nach time_to_string auslagern, 
    # dort allerdings dann parsen und ggf. auf gewuenschtes Format umschreiben
    if isinstance(time_start, str):
        sTimeStart = time_start
    else:
        sTimeStart = time_to_string.time_to_string(time_start, sFormat)
        
    if isinstance(time_end, str):
        sTimeEnd = time_end
    else:
        sTimeEnd = time_to_string.time_to_string(time_end, sFormat)


    lWhere = []        
    if sTimeStart:
        lWhere.append(sTimeCol + '>=\'' + sTimeStart + '\'')            
        
    if sTimeEnd:
        lWhere.append(sTimeCol + '<=\'' + sTimeEnd + '\'')            

    if (len(lWhere)>0):
        return(' and '.join(lWhere))
    else:
        return(None)
    

