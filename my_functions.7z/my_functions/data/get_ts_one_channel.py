# -*- coding: utf-8 -*-
"""
function to get the time series for a the given cycle and (single) channel

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channel:          integer, channel number
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-3-14

"""
import fnmatch
import os

import numpy as np

from data import get_folder, get_ts_from_files


def get_ts_one_channel(db, create_time, iID, channel, count_meas_base=8192):
                   
    iTS = None
                     
    sFolder = get_folder(db, create_time, iID)                     # get folder for this create_time and ID

    pattern = f'at_*_{channel}.csv.gz'                         
               
    if os.path.isdir(sFolder):
        
        sFilesCh = fnmatch.filter(os.listdir(sFolder), pattern)    # find files in folder that match the time-series-files-format and the channel number
                                
        if len(sFilesCh)>0:

            ## sort files by the measure-number
            iMeas = [int(s.replace('at_', '').replace('_' + str(channel) + '.csv.gz', '')) for s in sFilesCh]
            sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
            
            iTS = get_ts_from_files(sFolder, sFilesCh, count_meas_base=count_meas_base)
  
    return(iTS)


