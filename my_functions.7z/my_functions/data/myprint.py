# -*- coding: utf-8 -*-
"""
Created on Thu Mar 19 11:36:54 2020

@author: w012028
"""
import sys
def myprint(text):
    sys.stdout.write("\r" + text)
    sys.stdout.flush()
    
    
    