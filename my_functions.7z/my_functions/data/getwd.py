# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 07:26:24 2019

@author: Christian Kuehnert
"""

import os.path

def getwd():
    return os.path.dirname(os.path.abspath(__file__))

