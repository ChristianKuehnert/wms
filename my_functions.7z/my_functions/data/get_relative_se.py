# -*- coding: utf-8 -*-
"""
function to calculate the relative signal energy from the given absolute SE for the column names in the given list of lists

Created on Tue Mar 26 02:34:36 2019

@author: Christian Kuehnert
@last_modified: 2020-3-20

"""
import pandas as pd
import numpy as np


## old version:
#def get_relative_se(dfSE, col_names):
#
#    dTmp = dfSE.loc[:, col_names].values
#    dSE_mean = np.mean(dTmp, axis=1)
#    dSE_rel = dTmp /  np.tile(dSE_mean.reshape((len(dSE_mean),1)), (1,len(col_names)))
#    
#    return(dSE_rel)
#
### returning dataframe with same index and column names
#def calc_relative_se(df_se, col_names):
#    dSE_rel = get_relative_se(df_se, col_names)
#    return(pd.DataFrame(dSE_rel, columns = col_names, index = df_se.index))


def get_relative_se(dse):
    return(dse/np.tile(dse.mean(axis=1), (dse.shape[1],1)).transpose())
        

## returning dataframe with same index and column names
def calc_relative_se(df_se, col_names):
    dse = df_se.loc[:, col_names].values
    dse_rel = get_relative_se(dse)
    return(pd.DataFrame(dse_rel, columns = col_names, index = df_se.index))


## returning dataframe with same index and column names, 'pure version'
def calc_relative_se2(df_se):
    dse = df_se.values
    dse_rel = get_relative_se(dse)
    return(pd.DataFrame(dse_rel, columns =df_se.columns, index =df_se.index))

