# -*- coding: utf-8 -*-
"""
function to get the turbines and related tickets from PIT
       
@author: Christian Kuehnert 
@created: 2018-12-7
@modified: 2020-9-12
"""
import pandas as pd

from data.query_tableData_PIT import query_tableData_PIT
def get_turbines_and_tickets(dictCols_wt={'sFarm': 'Windpark_WEA#Windparkname', 
                                          'sName': 'WEA_Name',
                                          'sDB': 'Datenbankname',
                                          'id': 'o_ContainerID',
                                          'id_farm': 'Windpark_WEA#'},        
                             sWC_wt=None, 
                             dictCols_tickets={'sTitle': 'Titel',
                                          'sDescription': 'Beschreibung',
                                          'sStatus': 'Status',
                                          'sFarm': 'Windpark#Windparkname',
                                          'weasImWP': 'WEAs_im_Windpark', 
                                          'sTicketID': 'TicketID',
                                          'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                                          'dtCreated': 'Beginn_am',
                                          'dtErrorFixed': 'Behebung_des_Fehlers',
                                          'dtClosed': 'Geschlossen_am',
                                          'id_farm': 'Windpark#'}, 
                             sWC_tickets=None):
    
    
    print('FUNKTIONIERT NICHT RICHTIG, DURCH WAS BESSERES ERSETZEN UND OBSOLET MACHEN')
    dictWTsTickets = {}
    dEps = 1e-6
    ## get all turbines
# TODO 2019-1-24: hier noch pruefen, ob in den uebergebenen column names auch die hier benoetigten enthalten sind, falls nein, dann diese temporaer hinzufuegen (und bei der Ergebnisrueckgabe wieder entfernen)
#    if not dictCols_wt:
#        # alter Version, noch mit CASE(...)
#        dictCols_wt = {'sFarm': 'Windpark_WEA#Windparkname', 
#                       'sName': 'WEA_Name',
#                       'sDB': 'Datenbank',
#                       'id': 'CAST(o_ContainerID as varchar(8000))',
#                       'id_farm': 'CAST(Windpark# as varchar(8000))'}
    
    #listCols = [dictCols_wt[i] + ' as ' + i for i in dictCols_wt]
    listCols = dictCols_wt.values()
    dfWTs = query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)

    ## get all tickets
# TODO 2019-1-24: hier noch pruefen, ob in den uebergebenen column names auch die hier benoetigten enthalten sind, falls nein, dann diese temporaer hinzufuegen (und bei der Ergebnisrueckgabe wieder entfernen)
#    if not dictCols_tickets:
#        # alte Version, noch mit CAST(...)
#        dictCols_tickets =  {'sTitle': 'Titel',
#                            'sDescription': 'Beschreibung',
#                            'sStatus': 'Status',
#                            'sFarm': 'CAST(Windpark#Windparkname as varchar(8000))',
#                            'weasImWP': 'CAST(WEAs_im_Windpark as varchar(8000))',                            
#                            'sTicketID': 'TicketID',
#                            'dtFirstOcc': 'Erstauftreten_des_Fehlers',
#                            'dtCreated': 'Beginn_am',
#                            'dtErrorFixed': 'Behebung_des_Fehlers',
#                            'dtClosed': 'Geschlossen_am',
#                            'id_farm': 'Windpark#'}
                     
    #listCols_tickets = [dictCols_tickets[i] + ' as ' + i for i in dictCols_tickets]    
    listCols_tickets = dictCols_tickets.values()
    dfTickets = query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets);
    #dfTickets.column_names = dictCols_tickets.keys
    dict_cols_tickets_rev = {v:k for k,v in dictCols_tickets.items()}

    ## loop through turbines to find and assign the tickets    
    for idx, row in dfWTs.iterrows():
        
        #sFarm = row['sFarm']
        #sName = row['sName']
        sDB = row['Datenbankname']
        id_farm = row['Windpark_WEA#']
        id_wt = row['o_ContainerID']            
        
        ## now find tickets for that wt
        dfTmp = dfTickets[abs(dfTickets.id_farm-id_farm)<3*dEps]        ## consider only tickets referring to the same wind farm
        lTicketsWT = []        
        for idx2, dfT in dfTmp.iterrows():
            sWiW = dfT.weasImWP
            if (len(sWiW)>0):
                lTmp = sWiW.split(',')
                if str(id_wt) in lTmp:
                    lTicketsWT.append(idx2)
            
        dfTicketsWT = dfTmp.loc[lTicketsWT,:]
        dfTicketsWT.drop(columns=['Windpark#'], inplace=True)
        dfTicketsWT['Beginn_am'] = pd.to_datetime(dfTicketsWT['Beginn_am'], errors='coerce')
        dfTicketsWT['Erstauftreten_des_Fehlers'] = pd.to_datetime(dfTicketsWT['Erstauftreten_des_Fehlers'], errors='coerce')
        dfTicketsWT['Behebung_des_Fehlers'] = pd.to_datetime(dfTicketsWT['Behebung_des_Fehlers'], errors='coerce')
        dfTicketsWT['Geschlossen_am'] = pd.to_datetime(dfTicketsWT['Geschlossen_am'], errors='coerce')

        dictWTsTickets.update({sDB: dfTicketsWT.rename(columns = dict_cols_tickets_rev)})
        
    dict_col_rev = {v:k for k,v in dictCols_wt.items()}
     
    return({'tickets': dictWTsTickets, 'turbines': dfWTs.rename(columns=dict_col_rev)})

