# -*- coding: utf-8 -*-
"""
function to get the rows of df1 that are not in df2, regarding to the values
in columns sHeaders


Created on Wed Apr 24 18:27:10 2019

@author: Christian Kuehnert, 2018-10-18
"""
import pandas as pd
def setdifference_df(df1, df2, sHeaders):
    
    if ((df1.shape[0]==0) or (df2.shape[0]==0)):
        return df1
    else:
        df1 = df1.set_index(sHeaders, drop=False)
        df2 = df2.set_index(sHeaders, drop=False)
        idx = df1.index.difference(df2.index)
        
        # TODO 2018-11-13: komisch, dass Unterschiedliches verhalten fuer leeren
        # und nichtleeren Index -> nochmal genau verstehen und moeglichst auf
        # identischen Code umstellen
        if len(idx)>0:
            dfDiff = df1.loc[idx,:]
        else:
             #dfDiff = df1.iloc[idx,:]
             dfDiff = pd.DataFrame(columns = df1.columns)
                
        #return dfDiff.reset_index(drop=True)
        return(dfDiff)

