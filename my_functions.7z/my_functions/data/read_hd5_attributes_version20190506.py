# -*- coding: utf-8 -*-
"""
Created on Mon May  6 17:26:41 2019

function to read attributes of the given hd5-file (if possible)

parameters:
-----------

    - fn_hd5:        name of the hd5-file


output:
-------
    - dictionary with attributes of the hd5-file or empty dict if something went wrong or no attributes are contained
    

@author: w012028

"""

import pandas as pd

def read_hd5_attributes(fn_hd5):
    res = {}
    try:
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as g:
            tmp = g.root
            for k in tmp._v_children:
                res.update({k: dict(vars(tmp[k].attrs))})
    except:
        pass
    
    return(res)