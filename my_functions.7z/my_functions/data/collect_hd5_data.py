  
  
  
  
"""
function to collect the data and store them in (split) hd5-files
periods must be non-overlapping
TODO 2020-8-6: noch overlapping erlauben



@author: Christian Kuehnert
@modified: 2020-8-6

"""
def collect_hd5_data(path_data_multiple, db, periods = [(None, None)]):
       
    ## check for which turbines hd5-files already exist and exclude them, it is
    ## assumed that if there exist at least one file the data for this wtg are
    ## already collected
    all_files = os.listdir(path_data_multiple)
               
    months = range(1, 12, 2)
                
    #(start_date_min, end_date_max) = period
    
    df_tmp = pd.DataFrame.from_records(periods, columns = ['start', 'end'])
        
    if df_tmp.end.isna().any():
        #end_date_max is None:
        end_date_max = dt.now()
    else:
        end_date_max = df_tmp.end.max()
        
        
    if df_tmp.start.isna().any():
    #if start_date_min is None:

        # first try simple version, if this fails then the more advanced which
        # takes much longer
        ## TODO 2019-10-16: eleganter machen
        try:
            
            sql = ("select min(tmp.dct) "
                   "from ("
                       "select distinct(bas.create_time) as dct "
                       "from ba_cycle_sig_energies bas "
                       "order by bas.create_time "
                       "limit 5) tmp "
                   "where substring_index(tmp.dct, 1, 2)>'19';")
            
            start_date_min = mfdata.query_MySQL2(db, sql)[0][0]
            bOk = isinstance(start_date_min, dt)
        except:
            bOk = True
            
        if not bOk:
            print("can't get start date generically, use enddate minus 1 year")                        
            start_date_min = end_date_max - relativedelta(months=12)

    else:
        start_date_min = df_tmp.start.min()
    
    years = range(start_date_min.year, end_date_max.year+1, 1)
    
    start_dates = ((m, y) for m in months for y in years)
    for (month, year) in start_dates:
            
        start_date = dt(year, month,1,0,0,0)
        end_date = start_date + relativedelta(months=+2)
        
        # only collect if this period has some overlap with the desired periods
        if overlap_multiple((start_date, end_date), periods):
        
        #if (start_date <=end_date_max) & (end_date >= start_date_min):
                    
            fn = f'{db}_se_{start_date.strftime("%Y%m")}_{end_date.strftime("%Y%m")}.hd5'                
            if not(fn in all_files):

                fn_hd5 = f'{path_data_multiple}\\{fn}'
                                    
                try:
                    # TODO 2019-10-16: ganze Funktion streamlinen!
                    if False:
                        if isinstance(start_date, dt):
                            start_date = np.float64(start_date.timestamp())
    
                        if isinstance(end_date, dt):
                            end_date = np.float64(end_date.timestamp())
                        
                    weadbs.SEData.from_db(db, where={'create_time': (start_date, end_date)}, hdfpath = fn_hd5)
                except:
                    print(f'   problem with se data between {start_date}, {end_date}')
                

				
				
    
"""
function to collect the data and store them in (split) hd5-files

@author: Christian Kuehnert
@modified: 2019-8-23

"""   
def collect_hd5_data_farm(path_data_multiple, farm, period = (None, None)):

    where_clause=(f"(Windpark_WEA#Windparkname='{farm}') and not "
                   "((Datenbankname is NULL) or (Datenbankname = ''))")
        
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']    

    count = 0
    iN = turbines.shape[0]
    
    for idx, tb in turbines.iterrows():
                              
        ## TODO 2019-3-13: special treatment for 'TIANHEKOU - HuBei Suizhou', because the '-' seems to be saved as non-utf-8-character,
        ## - noch eleganter machen und "richtig" die encodings etc. verwenden!
        #tb['sFarm'] = tb['sFarm'].replace('\x96', '-')        
        db = tb['sDB']
    
        count += 1          
        #turbine_info, turbine_info_fn = mfmon.get_turbine_info(tb)
        print(str(count) + '/' + str(iN) + ': ' + db)
            
        collect_hd5_data(path_data_multiple, db, period=period)



    
"""
function to collect the data and store them in one single hd5-files

@author: Christian Kuehnert
@modified: 2019-8-21

"""   
def collect_hd5_data_one_hd5file(path_data, farm):

    where_clause=(f"(Windpark_WEA#Windparkname='{farm}') and not "
                   "((Datenbankname is NULL) or (Datenbankname = ''))")
        
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']    

    count = 0
    iN = turbines.shape[0]
           
    all_files = os.listdir(path_data)

    for idx, tb in turbines.iterrows():
                              
        ## TODO 2019-3-13: special treatment for 'TIANHEKOU - HuBei Suizhou', because the '-' seems to be saved as non-utf-8-character,
        ## - noch eleganter machen und "richtig" die encodings etc. verwenden!
        tb['sFarm'] = tb['sFarm'].replace('\x96', '-')        
        db = tb['sDB']
    
        count += 1          
        print(str(count) + '/' + str(iN) + ': ' + db)
                                    
        fn = f'{db}_se.hd5'                
        if (fn in all_files):
            print(f'    {fn} schon vorhanden')
        
        else:
            fn_hd5 = f'{path_data}\\{fn}'
                                        
            try:
                #if not os.path.isfile(fn_hd5):
                weadbs.SEData.from_db(db, hdfpath = fn_hd5)
            except:
                print(f'   problem with {db}')
                    

					    
"""
function to collect the data and store them in (split) hd5-files

@author: Christian Kuehnert
@modified: 2019-8-16

"""   
def collect_hd5_data_old(path_data_multiple, farm, period = (None, None)):

    where_clause=(f"(Windpark_WEA#Windparkname='{farm}') and not "
                   "((Datenbankname is NULL) or (Datenbankname = ''))")
        
    tmp = mfmon.get_turbines_and_tickets_for_monitoring(sWC_wt=where_clause)
    turbines = tmp['turbines']    

        
    ## check for which turbines hd5-files already exist and exclude them, it is
    ## assumed that if there exist at least one file the data for this wtg are
    ## already collected
    ## TODO 2019-8-16: um update-Moeglichkeit erweitern    
    all_files = os.listdir(path_data_multiple)
    #spat = r'((_se\.hd5)$|(_se.+\.hd5)$)'
    #files_se = [s for s in all_files if re.search(spat, s)]
    #dbs_exist = np.unique([fn.split('_se')[0] for fn in files_se])
    #dbs_new = list(set(turbines.sDB.values) - set(dbs_exist))
    #turbines = [tb for _idx, tb in turbines.iterrows() if not(tb.sDB in dbs_exist)]
    #turbines = turbines[turbines.sDB.isin(dbs_new)]

    count = 0
    iN = turbines.shape[0]
           
    (start_date_min, end_date_max) = period
     
#    if (period is None):
#        dt_now = dt.datetime.now() + dt.timedelta(days=1)
#        s_now = dt_now.strftime('%Y-%m-%d')
#        period = ('1970-7-2', s_now)      # s. Ticket 201809-002
    #dt_now = dt.datetime.now()
    
    months = range(1, 12, 2)
    
    for idx, tb in turbines.iterrows():
                              
        ## TODO 2019-3-13: special treatment for 'TIANHEKOU - HuBei Suizhou', because the '-' seems to be saved as non-utf-8-character,
        ## - noch eleganter machen und "richtig" die encodings etc. verwenden!
        tb['sFarm'] = tb['sFarm'].replace('\x96', '-')        
        db = tb['sDB']
    
        count += 1          
        #turbine_info, turbine_info_fn = mfmon.get_turbine_info(tb)
        print(str(count) + '/' + str(iN) + ': ' + db)
            
        #ok_status, fn_status = store_cdef_data(db, path_data, table = 'status', columns = None)
            
        if start_date_min is None:
            sql = 'select min(create_time) from ba_cycle_sig_energies;'
            start_date_min = mfdata.query_MySQL2(db, sql)[0][0]
    
        if end_date_max is None:
            end_date_max = dt.now()

        
        years = range(start_date_min.year, end_date_max.year+1, 1)
    
        start_dates = ((m, y) for m in months for y in years)
        for (month, year) in start_dates:
            
            start_date = dt(year, month,1,0,0,0)
            #end_date = start_date + dt.timedelta(months=2)
            end_date = start_date + relativedelta(months=+2)
            period = (start_date, end_date)
            
            if (start_date >= start_date_min) & (end_date <= end_date_max):
            
                fn = f'{db}_se_{start_date.strftime("%Y%m")}_{end_date.strftime("%Y%m")}.hd5'                
                if not(fn in all_files):
                    fn_hd5 = f'{path_data_multiple}\\{fn}'
                                        
                    try:
                        #if not os.path.isfile(fn_hd5):
                        weadbs.SEData.from_db(db, where={'create_time': period}, hdfpath = fn_hd5)
                    except:
                        print(f'   problem with se data between {start_date}, {end_date}')
                    
