# -*- coding: utf-8 -*-
"""
function to get the day only from the timeseries tsCT

@author: Christian Kuehnert, 2018-12-2
"""
def get_day(tsCT):
    tsCD = tsCT.day()
    return(tsCD)

