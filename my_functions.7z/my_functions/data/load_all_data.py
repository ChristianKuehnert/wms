# -*- coding: utf-8 -*-
"""
function to load and combine the data for all given databases
data related to labels with values not in {0,1} will be removed


Created on Wed Apr 24 18:14:25 2019

@author: Christian Kuehnert, 2018-10-4
"""

import os
import numpy as np

from data import readHD5

def load_all_data(sDBs, sPathData):
    

    # define strings for title and file names
    if len(sDBs)>1:
        sDB_title = ",".join(sDBs)
        sDB_fn = str(len(sDBs)) + 'wts'
    else:
        sDB_title = sDBs[0]
        sDB_fn = sDBs[0]
        

    lData = []
        
    ## loop through all turbines to load data
    for sDB in sDBs:
              
        ## load data
        sFN_hd5 = sPathData + '\\' + sDB + '_features.hd5'

        if not os.path.isfile(sFN_hd5):

            print('file ' + sFN_hd5 + ' not found')            
            iN = 0
            
        else:                

            print('load data from ' + sFN_hd5)                                    
            dfLabel0 = readHD5(sFN_hd5, 'label')    
            iN = dfLabel0.shape[0]
        
            dfCDEF0 = readHD5(sFN_hd5, 'cdef')              # read database name DataFrame
            dfChannel0 = readHD5(sFN_hd5, 'channel')        # read database name DataFrame
            #dfACF0.append(readHD5(sFN_hd5, 'acf'))          # read database name DataFrame
            dfACF_d10 = readHD5(sFN_hd5, 'acf_d1')          # read database name DataFrame
#            dfACF_d10 = readHD5(sFN_hd5, 'acf')
            dfDQ_d10 = readHD5(sFN_hd5, 'diff_quant_d1')    # read database name DataFrame
                
            #dfDB0 = pd.DataFrame(np.tile(sDB, [iN, 1]), columns=['db'])        # create dataframe with database name
            
            print(sDB + ': ' + str(iN) + ' data sets')
            
                            
                         
            ## eliminate rows where label==nan
            bNaN = np.isnan(dfLabel0).values | (dfLabel0.values == -1)
            if any(bNaN):
            
                print(sDB_title + ': ' + str(sum(bNaN)[0]) + ' data sets with nan, will be removed')
                    
                bNotNaN = np.invert(bNaN)
                #dfDB0 = dfDB0[bNotNaN]
                dfLabel0 = dfLabel0[bNotNaN]
                dfCDEF0 = dfCDEF0[bNotNaN]
                dfChannel0 = dfChannel0[bNotNaN]
                #dfACF0 = dfACF0[bNotNaN]
                dfACF_d10 = dfACF_d10[bNotNaN]
                dfDQ_d10 = dfDQ_d10[bNotNaN]
                
                iN = dfLabel0.shape[0]
           
                    
        if iN > 0:                
            
            lData.append([sDB, dfLabel0, dfCDEF0, dfChannel0, dfDQ_d10, dfACF_d10])            
            #lData.append({'sDB': sDB, 'dfLabel0': dfLabel0, 'dfCDEF0': dfCDEF0, 'dfChannel0': dfChannel0, 'dfDQ_d10': dfDQ_d10, 'dfACF_d10': dfACF_d10})
                                         

    return sDB_title, sDB_fn, lData


