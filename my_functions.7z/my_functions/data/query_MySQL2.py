# -*- coding: utf-8 -*-
"""
function to query the MySQL-Databases

Created on Wed Apr 24 18:00:41 2019

@author: Christian Kuehnert, 2018-12-10

"""        
import pymysql

def query_MySQL2(db, sql, params=None):
    
    sHost = r'10.41.52.30'
    conn = pymysql.connect(host=sHost, user='webvis-intern', port=3306,
                           password=r'ne0Nae2Aloo0Gi1E', database=db)
    
    crs = conn.cursor()
    
    if params is None:
        crs.execute(sql)
    else:
        crs.execute(sql, params)
            
    # TODO 2018-10-15: zumindest by tuple-Typ so machen, bei anderen Typen vielleicht das list() weglassen!?)
    #return pd.DataFrame(crs.fetchall())           
    return(crs.fetchall())



