# -*- coding: utf-8 -*-
"""
function that appends the given data dfAppend to the node sNode in hdfstore HDFStore
@author Christian Kuehnert
2019-6-2

Input:
------
    f:   hdfstore, must be opened with mode 'a' and complevel '9' and complib 'blosc:lz4'
    sNode: node in f, must contain dataframe to which the data in dfAppend are appendable
    dfAppend: pandas.DataFrame containing the data, must be appendable to the data in node sNode in f
                The synchronisation with the data in the node must have been done BEFORE calling this function
    

Output:
-------
    None

"""
def append_to_hd5Table(f, sNode, dfAppend, sHeadersKey):

    if sNode in f:
                
        if dfAppend.shape[0]>0:
            f.append(sNode, dfAppend, index=False)
            
    else:
        f.put(sNode, dfAppend, format='table', append=True, data_columns=True, index=False)


