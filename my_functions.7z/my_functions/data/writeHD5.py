# -*- coding: utf-8 -*-
"""
function to write the complete data file to hd5-file

Created on Wed Apr 24 18:13:33 2019


@author: Christian Kuehnert, 2018-8-15
"""
import pandas as pd

def writeHD5(dfData, sKey, sFN_hd5, sFormat = 'f'):

    hf = pd.HDFStore(sFN_hd5)
    hf.put(sKey, dfData, append=True)
    hf.close()    



