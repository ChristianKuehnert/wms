# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 07:55:58 2019

@author: christian
"""
 

from numpy import cumsum, insert
from collections import Counter

def detect_plateaus(series, value):
    
    #if isinstance(value, np.ndarray):
    #    indicators = list(map(int, [not(at==value) for at in insert(series, 0, value-1)]))
    #else:
    #   indicators = list(map(int, [not(at==value) for at in [value-1] + series]))
    indicators = list(map(int, [not(at==value) for at in insert(series, 0, value-1)]))      # Annahme, dass series vom Typ np.ndarray ist
    groups = cumsum([i for i in indicators])
    lengths = [v-1 for v in dict(Counter(groups)).values() if v>1]
        
    return(lengths)
