# -*- coding: utf-8 -*-
"""
function to retrieve turbine information

input:

output:

@author: Christian Kuehnert, 2018-11-16

"""

import pandas as pd

           
def get_turbine_info(sDB, sPathData):                        
    
    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
    sNode_info = 'turbine_info'
    sCols = ['farm', 'turbine', 'turbine_database']
    
    dfInfo = pd.DataFrame(columns = sCols)    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
        if sNode_info in f:
            dfInfo = f.select(sNode_info, columns=sCols)
            
    return(dfInfo)    


