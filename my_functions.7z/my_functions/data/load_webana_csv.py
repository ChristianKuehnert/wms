# -*- coding: utf-8 -*-
"""
Created on Tue Aug 11 14:11:13 2020

@author: w012028
"""

"""
function to load .csv-files that are stored from webAna containing at data

@modified: 2020-7-17
"""
from pandas import read_csv
from datetime import datetime as dt
def load_webana_csv(fn, dict_cols = {'Channel-0': 'e_101_flap',
                                     'Channel-1': 'e_102_flap',
                                     'Channel-2': 'e_103_flap',
                                     'Channel-3': 'e_101_edge',
                                     'Channel-4': 'e_102_edge',
                                     'Channel-5': 'e_103_edge',
                                     'Channel-11': 'hub',
                                     'Channel-13': 'e_101_temp',
                                     'Channel-14': 'e_102_temp',
                                     'Channel-15': 'e_103_temp'}):

    df = read_csv(fn, delimiter = ',', header=[0], na_values = ['Infinity'], 
                  dtype={'epoch': 'str', 'omega_mean': 'float64', 
                            'temperature_mean': 'float64'})
    df.dropna(how='all', axis=1, inplace=True)
    df.index= [dt.fromtimestamp(x) for x in df.epoch.astype(float).values/1000]
    
    if not(dict_cols is None):
        df.rename(columns = dict_cols, inplace=True)
    
    return(df)
    