# -*- coding: utf-8 -*-
"""

function to set specifically the headers of keys

Created on Thu Apr 25 01:14:31 2019

@author: Christian Kuehnert, 2018-11-6
"""

import numpy as np

from data import set_dtype

def set_dtype_headersKey(dfDF):
    listCols = ['create_time', 'ID', 'channel']    
    listTypes = [np.datetime64, int, int]
    return(set_dtype(dfDF, listCols, listTypes))
    
    
    