# -*- coding: utf-8 -*-

"""
 function to retrieve data from a given table

 Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden


 Input:
       sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
       sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
       sWC:                where clause

 Output:
       dfData:             pandas.DataFrame mit den geholten Daten

 Verwendung:
 sDB = 'cmrblba_bc_t_00835'
 sTable = 'ba_cycle_externals'
 sWC = ''
 dfCycle = query_tableData(sDB, sTable, sWC)
   
 ----------------------------------------------------------------------------

@author: Christian Kuehnert
@modified: 2019-1-14

"""
import numpy as np
import pandas as pd

from data import get_fields_MySQL
from data import query_MySQL2


def query_tableData_old(sDB, sTable, sWC = None):
    
    listMsg = []
    listTmp = get_fields_MySQL(sDB, sTable)
    listFields = listTmp.Field
    listTypes = listTmp.Type
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL = sSQL + ' where ' + sWC.strip()
        
    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
    
    if dfData.shape[0]>0:
        dfData.columns = listFields
    
        # TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
        # diese jeweils category (oder was besseres?) setzen)    
        #dfData['appendix'] = dfData['appendix'].astype('str')
        
        ## set all timestamp-datatypes to pd.datetime
        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
        sCols = listFields[iPos]
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in sCols:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

    else:
        listMsg.append('keine Daten gefunden')
        dfData = pd.DataFrame(columns=listFields)
    
    return dfData, listMsg
    
