# -*- coding: utf-8 -*-
"""
Created on Mon May 27 15:29:47 2019


function to determine rotation angle from acc. data, migration from MATLAB-function calcOmegaPiDuration.m from Stefan Reimann:

Konzept uebernommen aus Funktion calcOmegaPiDuration.m von SR



@author: w012028
@modified: 2019-5-27

"""

import numpy as np
from scipy.signal import savgol_filter



def calc_omega_pi_duration(at, samples_per_second=1000, wdw_size=None, min_amp=4000, min_pi_duration=1000, apply_low_pass_filter=False):

    bOk = True
    
    freq = np.nan
    sigma = np.nan
    zero_transitions = []
    
    
    #% Prüfen / Vorbelegen    
    if wdw_size is None:
        wdw_size = int(np.floor(samples_per_second/2))    	# Größe des Glättungsfensters
        
    if wdw_size % 2 == 0:
        wdw_size += 1
        print('add 1 to windowsize to make it odd')
        
        
    ## Initialisierung
    SampleCount = len(at)
    
    ## Mitteln und Nullstellen finden
    if SampleCount==0:
        bOk = False
        print('time series is empty')

    else:
        
        vect = savgol_filter(at, wdw_size, 2)        # smoothing with savgol filter
                
        max_amp = np.floor(max(abs(vect)))
        if max_amp < min_amp:
            print(f'insufficient amplitude of smoothed time series for omega calculation {max_amp} < {min_amp}')
            bOk = False
            
        
        if bOk:
            # optional: Hochpass anwenden
            if apply_low_pass_filter:
                # TODO: Hochpassfilter anwenden
                print('TODO: Hochpassfilter anwenden')
                # at = at - vect
            
            
            btmp = np.insert(np.diff(np.sign(vect))>.5, 0, False)
            zero_transitions = np.where(btmp)[0]
        
            bOk = (len(zero_transitions)>0)
            if bOk:
                t2 = zero_transitions[0]
                if t2 >= (SampleCount - wdw_size/2 - 1):
                    print('zero points only in end region - not used for determination of rotation frequency')
                    bOk = False

            else:
                print('no zero points found')
                
        
        if bOk:
            period = np.diff(zero_transitions)
            tmp = samples_per_second/(2*period)
            freq = np.mean(tmp)            
            sigma = np.std(tmp)
            
    
    return(freq, sigma, zero_transitions, bOk)
    










