# -*- coding: utf-8 -*-
"""
function to return the fields of a table (in MySQL) in database db

Created on Wed Apr 24 18:01:46 2019


@author: Christian Kuehnert, 2019-6-21
"""
import pandas as pd
import numpy as np
#from data import query_MySQL2
#from data import query_MySQL2 as query_MySQL2
#from . import query_MySQL2 as query_MySQL2
from .query_MySQL2 import query_MySQL2


def get_fields_MySQL(sDB, sTable):
    
    tplRes = query_MySQL2(sDB, 'DESCRIBE ' + sTable)
    dfFields = pd.DataFrame(data=np.array(tplRes), columns = ['Field', 'Type', 'Null', 'Key', 'Default', 'Extra']).infer_objects()
    return(dfFields)
    

