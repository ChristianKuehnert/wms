# -*- coding: utf-8 -*-
"""
function to read cdef-, ts- and label-data from hd5-file and combine all
to 1 dataframe

 
@author: Christian Kuehnert, 2018-10-25

"""

import pandas as pd
import numpy as np


from data import fullfile



def read_ts_from_hd5(sDB, sPathData, tsCreateTime, iID, iChannel):
        
    sNodeCDEF = 'raw_data/cdef'
    sNodeLabel = 'raw_data/label'
    sNodeTS = 'raw_data/ts'                                           # node where the time series data are stored
    
    #sHeadersKey = ['create_time', 'ID']                             # headers of the columns that relate the ts data to the cdef data
            
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        sCT = 'Timestampe("' + tsCreateTime + '")'
        sID = str(iID)
        sCh = str(iChannel)
        
        # TODO 2018-10-25: spaeter Filter einbauen, s. auskommentierte uebernaechste Zeile!
        #dfTS = f[sNodeTS]        
        dfTS = f.select(sNodeTS, where=('(create_time==' + sCT + ') and (ID==' + sID + ') and (channel==' + sCh + ')'))

        #dfCDEF = f[sNodeCDEF]
        dfCDEF = f.select(sNodeCDEF, where=('(create_time==' + sCT + ') and (ID==' + sID + ') and (channel==' + sCh + ')'))
        dfLabel = f.select(sNodeLabel, where=('(create_time==' + sCT + ') and (ID==' + sID + ') and (channel==' + sCh + ')'))

# TODO 2018-10-25: hier noch richtig machen!
        dfTS_short = np.reshape(dfTS)
        
        return(pd.concat((dfLabel, dfCDEF, dfTS_short), axis=1))
        


    
    