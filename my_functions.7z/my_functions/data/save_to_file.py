# -*- coding: utf-8 -*-
"""
function to save the given dataframe to a file with the given file
The function first checks if the given file already exists. If not, it saves the 
dataframe to this filename. If yes, it tries to append the dataframe to the file, 
if this is not possible, it overrides it or doesn't change anything (depending
on the overwrite-parameter)


Created on Mon Apr 29 14:25:13 2019

@author: w012028
"""

import os

def save_to_file(file_name, df, s_sep=';', s_na_rep = 'NaN', overwrite = False):

    if os.path.isfile(file_name):
        
        try:
        
            df.to_csv(file_name,
                      sep=s_sep,
                      mode='a',
                      header=False,
                      index=False,
                      na_rep = s_na_rep,
                      encoding='cp1252')
            
        except:
            if overwrite:
                os.remove(file_name)
                df.to_csv(file_name,
                          sep=s_sep, 
                          index=False,
                          na_rep = s_na_rep,
                          encoding='cp1252')
                
                print(f'existing file {file_name} now overwritten with new data')

            else:
                print(f'cannot append data to already existing file {file_name}')
            
    else:
        df.to_csv(file_name,
                  sep=s_sep, 
                  index=False,
                  na_rep = s_na_rep,
                  encoding='cp1252')

    
    
    