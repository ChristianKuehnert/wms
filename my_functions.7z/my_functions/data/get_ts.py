# -*- coding: utf-8 -*-
"""
function to get the time series (and the overlap length) for a the given cycle

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channels:         list of integers, list of channel numbers, if None then all found channels will be returned
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-3-13

"""
import os
import fnmatch
import numpy as np

#from data import get_folder, combine_ts, read_gz, fullfile
from .update_hd5 import get_folder, combine_ts, read_gz


def get_ts(db, create_time, iID, channels=None, count_meas_base=8192):
                   
    dict_res = {}
                     
    sFolder = get_folder(db, create_time, iID)                     # get folder for this create_time and ID
                                        
    if os.path.isdir(sFolder):
        
        sFiles = fnmatch.filter(os.listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
        if len(sFiles)>0:
            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
            if channels:
                set_ic = set(iChannels)
                set_c = set(channels)
                
                iChannels = list(set.intersection(set_ic, set_c))
                
                ## add None for missing channels
                for cm in list(set_c-set_ic):
                    dict_res.update({cm: None})
                    

            for iCh in iChannels:
                        
                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel

                ## sort files by the measure-number
                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                         
                try:    

                    ## now aggregate the remaining files                                
                    listTS = []
                    for sFN0 in sFilesCh:                    
                        listTS.append(read_gz(f'{sFolder}\\{sFN0}'))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                     
                    ## combine the measurements if possible
                    iTS, iOL = combine_ts(listTS, count_meas_base)                        
                        
                    #dict_res.update({iCh:(iTS, iOL)})
                    
                    if len(iTS)>0:  
                        dict_res.update({iCh:(iTS, iOL)})
                        
                    else:
                    #if len(iTS)==0:
                        print(f'channel {iCh}: Einzelzeitreihen ungleich lang oder keine Vielfachen von {count_meas_base}')
                        dict_res.update({iCh: None})

                except Exception:
                    print(f'channel {iCh}: Probleme mit Entpacken oder Zusammenfuegen')
                    dict_res.update({iCh: None})
                                        
  
    return(dict_res)

