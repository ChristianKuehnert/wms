# -*- coding: utf-8 -*-
"""

function to prepare Properties for later evaluation


Created on Wed Apr 24 18:11:08 2019

@author: Christian Kuehnert, 2018-9-28
"""
import math
import numpy as np

def prepare_properties(dfCDEF, sPropCols, dPropBinWidth):
    
    dfProperties = dfCDEF.loc[:, sPropCols]
    lBinEdges = []
    
    for iProp in range(len(sPropCols)):
        
        sProp = sPropCols[iProp]
        dStep = dPropBinWidth[iProp]
        
        dTmp = dfCDEF.loc[:, sProp]
        
        dMin = math.floor(min(dTmp) / dStep) * dStep
        dMax = (1+math.ceil(max(dTmp) / dStep)) * dStep
        
        lBinEdges.append(np.arange(dMin, dMax, dStep))

    
    return(dfProperties, lBinEdges)



