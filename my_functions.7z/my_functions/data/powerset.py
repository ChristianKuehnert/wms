# -*- coding: utf-8 -*-
"""
Created on Thu May 28 22:18:24 2020

@author: taken from the itertools recipies, on 2020-5-28 it could be found
         here:
             
             https://docs.python.org/3/library/itertools.html#itertools-recipes
             
"""
from itertools import chain, combinations

def powerset(iterable):
    "powerset([1,2,3]) --> () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))
