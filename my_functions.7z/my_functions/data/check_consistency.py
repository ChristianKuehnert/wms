# -*- coding: utf-8 -*-
"""
function to check hd5-ts-data for consistency of data
# TODO 2019-1-7: noch auf gleichzeitige Konsistenz mit den CDEF-Daten pruefen

@author: Christian Kuehnert, 2019-1-7

"""

import pandas as pd
import numpy as np


def check_consistency(sFN_hd5):

    bConsistent = True
    
    #sNode_cdef = 'raw_data/cdef'
    sNode_ts = 'raw_data/ts'                                           # node where the time series data are stored
    sNode_ts_data = sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
                   
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
    
        dfSS = f[sNode_ts_startstop]

        bConsistent = (dfSS.loc[:,['start','stop']].values.min()>=0) \
                        and (dfSS.loc[:,['start','stop']].values.max() == f.get_storer(sNode_ts_data).nrows) \
                        and (len(np.unique(dfSS.loc[:,['start']].values))==dfSS.shape[0]) \
                        and (len(np.unique(dfSS.loc[:,['stop']].values))==dfSS.shape[0])

        if bConsistent:
            # dfSS durchgehen
            for idx, row in dfSS.iterrows():
            
                # zugehoerige dfTS laden
                dtDate = row['create_time']
                iID = row['ID']
                iCh = row['channel']
                iStart = row['start']
                iStop = row['stop']
                
                bConsistent = bConsistent and (iStart>=0) and (iStop>0)    
    
                if bConsistent:
                    dfTS = f.select(sNode_ts_data, start=iStart, stop=iStop)
                                     
                    dfTmp = dfTS.drop_duplicates(subset=['create_day','ID','channel'], inplace=False)
                    bConsistent = bConsistent and (dfTmp.shape[0]==1) and (dfTmp.iloc[0,:].loc['create_day'] == pd.to_datetime(dtDate.date())) and (dfTmp.iloc[0,:].loc['ID']==iID) and (dfTmp.iloc[0,:].loc['channel']==iCh) and (dfTS.shape[0] % 8192 == 0)
                
                
    return(bConsistent)        



