# -*- coding: utf-8 -*-
"""
function to check if the file exists and if it contains the given node

@author: Christian Kuehnert, 2018-11-13
"""

import os
import pandas as pd


def check_node(sFN, sNodeFeat):

    bRes = False                    
    if os.path.isfile(sFN):
        with pd.HDFStore(sFN, 'a', complevel=9, complib='blosc:lz4') as f:                    
            if sNodeFeat in f:                
                bRes = True

    return(bRes)
    
    