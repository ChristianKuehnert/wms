# -*- coding: utf-8 -*-
"""
function that takes ts-DataFrame containing ONE time series and calculates the features of it

@author: Christian Kuehnert, 2018-11-6

#def ts2features(dfTS, sHeadersKey, sColTime, feat_fct, *args, **kwargs):
#def ts2features(sDB, sPathData, sHeadersKey, sColTime, listFeatures):
"""
import pandas as pd
import numpy as np

from data import fullfile
from data import intersect_df
from data import setdifference_df
from data import extract_cycleKeys_from_node




def ts2features(sDB, sPathData, sHeadersKey, listFeatures):
		
    sMsg = []
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name
    sNodeTS = 'raw_data/ts'    
    
    listCycEx = []

    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
        print('    find new cycles')
        #dfCycles = extract_cycleKeys_from_node(f, sNodeTS, sHeadersKey, 500000)
        dfCycles = extract_cycleKeys_from_node(f, sNodeTS, sHeadersKey)

        ## remove all elements from dfCycles for which already all features are calculated
        ## Note: of course this could be done more sophisticated in order to avoid duplicate 
        ## calculations if the different features have different keys they are existing, but
        ## this code here is at least a cheap and easy starting point        

        #for feat_fct, kwargs, sNodeFeat in listFeatures:			
        for i in range(len(listFeatures)):
            sNodeFeat = listFeatures[i][2]
            
            if sNodeFeat in f:
                listCycEx.append(extract_cycleKeys_from_node(f, sNodeFeat, sHeadersKey))
			
            else:		# perhaps here otherwise create this node with empty set but correct columns
                #listCycEx.append([])
                listCycEx.append(pd.DataFrame(columns=sHeadersKey))
                

    ## combine the found existing cycles and substract them from dfCycles
    #listTmp = [s for s in listCycEx if isinstance(s, pd.DataFrame)]
    #if listTmp:
    #    dfCycEx = listTmp[0]
    #    i=1
    #    while i<len(listTmp):
    #        dfCycEx = intersect_df(dfCycEx, listTmp[i], sHeadersKey)
    #        i=i+1
    dfCycEx = listCycEx[0]
    i=1
    while i<len(listCycEx):
        dfCycEx = intersect_df(dfCycEx, listCycEx[i], sHeadersKey)
        i=i+1
                    
    dfCycles = setdifference_df(dfCycles, dfCycEx, sHeadersKey)
    dfCycles.reset_index(drop=True, inplace=True)

    print('    ' + str(dfCycles.shape[0]) + ' new cycles found')
		
    if dfCycles.shape[0]>0:												# if there are cycles left ...
		
        sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                   # full hd5-file name

        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
           			
            ## use first cycle to create new feature if it not already exists
            dfCyc = dfCycles.iloc[[0],:]
			
            tsCT = dfCyc.create_time[0]
            iID = dfCyc.ID[0]
            iCh = dfCyc.channel[0]
												
            dfTS = f.select(sNodeTS, columns=['idx','at'], where=('(create_time=Timestamp("' + str(tsCT) + '")) and (ID=' + str(iID) + ') and (channel=' + str(iCh) + ')'))
            dfTS.sort_values(by=['idx'], inplace=True)
            
            ## now calculate the features
            for i in range(len(listFeatures)):
                feat_fct, kwargs, sNodeFeat = listFeatures[i]
								
                #if not (dfCyc in listCycEx[i]):								# if the current cycle is NOT in the cycles for which the current feature is already calculated
                if (intersect_df(dfCyc, listCycEx[i], sHeadersKey).shape[0] == 0):
                    dfFeat = feat_fct(dfTS.loc[:,'at'], **kwargs)

                    #dfTmp = pd.concat([dfCyc, dfFeat], axis=1)                        
                    iN = dfFeat.shape[0]
                    dfTmp = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [iN, 1]))
                    dfTmp.set_index(dfFeat.index, inplace=True)                                        
                    dfTmp.columns = sHeadersKey                                                                
                        
                    for s in sHeadersKey:
                        dfTmp[s] = dfTmp[s].astype(dfCycles[s].dtype)

                    dfTmp = pd.concat([dfTmp, dfFeat], axis=1)

                    if sNodeFeat in f:
                        f.append(sNodeFeat, dfTmp, format='table', ignore_index=True, index=False, data_columns=True)
                    else:
                        f.put(sNodeFeat, dfTmp, format='table', append=True, ignore_index=True, index=False, data_columns=True)
            
            
            
            ## loop through all remaining cycles, now all feature nodes must exist
            for i in range(1, dfCycles.shape[0]):
			
                if (i % 10 == 0):
                    print('    ' + str(i) + '/' + str(dfCycles.shape[0]))
                
                dfCyc = dfCycles.iloc[[i],:]
			
                #tsCT = dfCyc.iloc[i].create_time
                #iID = dfCyc.iloc[i].ID
                #iCh = dfCyc.iloc[i].channel
                tsCT = dfCyc.create_time[i]
                iID = dfCyc.ID[i]
                iCh = dfCyc.channel[i]
												
                dfTS = f.select(sNodeTS, columns=['idx','at'], where=('(create_time=Timestamp("' + str(tsCT) + '")) and (ID=' + str(iID) + ') and (channel=' + str(iCh) + ')'))
                dfTS.sort_values(by=['idx'], inplace=True)
            
                ## now calculate the features
                #for feat_fct, args, sNodeFeat, sCols in listFeatures:
                #for feat_fct, kwargs, sNodeFeat in listFeatures:
                for j in range(len(listFeatures)):
                    feat_fct, kwargs, sNodeFeat = listFeatures[j]
								
                    if (intersect_df(dfCyc, listCycEx[j], sHeadersKey).shape[0] == 0):								# if the current cycle is NOT in the cycles for which the current feature is already calculated
                        dfFeat = feat_fct(dfTS.loc[:,'at'], **kwargs)
                        
                        iN = dfFeat.shape[0]
                        dfTmp = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [iN, 1]))
                        dfTmp.set_index(dfFeat.index, inplace=True)                                            
                        dfTmp.columns = sHeadersKey                                                                
                        
                        for s in sHeadersKey:
                            dfTmp[s] = dfTmp[s].astype(dfCycles[s].dtype)
                        
                        #dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')                                        
                        #dfTmp['ID'] = dfTmp['ID'].astype(int)
                        #dfTmp['channel'] = dfTmp['channel'].astype(int)                        
                        
                        dfTmp = pd.concat([dfTmp, dfFeat], axis=1)

                        f.append(sNodeFeat, dfTmp, format='table', ignore_index=True, index=False, data_columns=True)
                                   
    
    return(sMsg)
      
