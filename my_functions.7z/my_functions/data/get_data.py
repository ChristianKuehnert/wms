# -*- coding: utf-8 -*-
"""
function to get the combined data from several nodes in the file, applying filters
while retrieving

Parameters:
-----------

list_nodes : list containing pairs of strings like [name_of_node, filter_criteria],
i.e. the name of the node combined with a filter string, e.g. [['cdef', 'omega_mean>0 and 'pitch_sigma<5', ['power_mean', 'create_time', ']], ['label', 'label in [0,1]']]
The filter string must be in a format which can be directly used as value for the hdfstore.select-where-parameter

Example:
    sDB = 'cmrblba_bc_t_02758'
    sNode_cdef = 'cdef'
    sNode_ts_startstop = 'raw_data/ts/startstop'
    listNodes = [[sNode_cdef, []], 
                 [sNode_ts_startstop, ['channel in [0,1,2]']]]
    listCols = ['create_time', 'ID', 'channel', 'omega_mean', 'std_dev', 'std_dev_abs']
    dfData = get_data(list_nodes = listNodes, list_columns = listCols)                      # get (filtered) cdef-data

Christian Kuehnert, 2019-1-11
"""

import pandas as pd


def get_data(sDB, sPathData, list_nodes, list_columns, sHow = 'inner'):
    
    ## combine with production data                                                               
    sFN_hd5 = sPathData + '\\' + sDB + '.hd5'
    
    bOk = True
    # neue Variante, funktioniert aber noch nicht richtig, ausserdem unklar, ob sie
    # prinzipiell mit vielen Feature-Daten (d.h. vielen Indices) funktioniert
    # --> deshalb erstmal die "alte" Variante unten verwendet    
    #bNew = False
    #if bNew:                
        #with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:            
            #for sNode, sCols, sKeyCols, sHow in listNodes:            
            #    sListMultiIdx = np.unique(dfFeat.set_index(sKeyCols).index)
            #    sWhere =  ','.join(sKeyCols) + ' in [' + ','.join(sListMultiIdx) + ']'                                    
            #    dfTmp = f.select(sNode, where=sWhere, columns=sCols).set_index(sKeyCols)                                                                        
            #    dfFeat = pd.merge(dfFeat, dfTmp.loc[:,sKeyCols + sCols], how=sHow, on=sKeyCols)

    #else:
            
    ## combine with production data                                           
    # TODO 2018-12-5: im folgenden koennte man auch erst die Spalten aller interessierenden nodes abfragen mit
    # f.get_storer('df').attrs['non_index_axes'], dann daraus diejenigen bestimmen, die fuer das Merging relevant
    # sind, sie mit den in listColumns angeforderten Spalten kombineren und dann erst die Daten auslesen (und 
    # dabei in "select(...)" entsprechend nur die benoetigten columns abfragen. Waere vielleicht hinsichtlich des
    # Auslesens aus hdfstore eleganter und evtl. schneller, hier aber aus Gruenden der einfacheren Implementierung
    # erstmal nicht umgesetzt

    ## first read in all nodes (if they exist)    
    lData = []
    i=0
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        while bOk and (len(list_nodes)>i):
            
            sNode, sFilter = list_nodes[i]
            i += 1
                
            if sNode in f:
                if len(sFilter)==0:
                    lData.append(f.select(key=sNode))                
                else:
                    lData.append(f.select(key=sNode, where=sFilter))
            else:
                bOk = False
        
        
                
    ## combine the found nodes
    if bOk and (len(lData)>0):    
        dfRes = lData[0]
        i=1
        while bOk and (len(lData)>i):
            dfTmp = lData[i]            
            i += 1
            #if dfTmp.shape[0]>0:               
            sKeyCols = list(set(dfRes.columns).intersection(set(dfTmp.columns)))
            dfRes = pd.merge(dfRes, dfTmp, how=sHow, on=sKeyCols)
            #else:
            #    dfRes = pd.DataFrame()                                          
                
            bOk = (dfRes.shape[0]>0) & (i < len(lData))
            
        if (dfRes.shape[0]>0) and (len(list_columns)>0):
            dfRes = dfRes.loc[:, list_columns]  
                
    else:
        if len(list_columns)>0:
            dfRes = pd.DataFrame(columns=list_columns)
        else:
            dfRes = pd.DataFrame()


    return dfRes
    
    



