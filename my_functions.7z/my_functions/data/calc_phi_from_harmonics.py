# -*- coding: utf-8 -*-
"""
Created on Wed May  8 16:16:57 2019

function to calculate the angle from the given time series under the assumption 
that this series is sth. like data ~ cos(\phi + \alpha_0)


parameters:
-----------

counterclockwise:   if True, it is assumed that the turbine rotates anticlockwise 
                    (seen from standing in front of the wtg), so this means for 
                    a sinus-wave-curve starting from 0 the highest point (12 o'clock position) 
                    is at \pi/2 (if 0 direction points along the r.h.s., still 
                    seen from a viewpoint in front of the wtg), the maximum is 
                    at the 9 o'clock position, then next 0 at the 6 o'clock position
                    and the next 0 at the 3 o'clock position.
                    However, the calculation will be done as if the phi=0-value
                    is at the top position, the pi/2 will be added in the end.
                    This is valid for offset==0, the offset value will be added
                    to phi in the end
                    
                  



@author: w012028
@modified: 2021-2-3
"""
import math
import numpy as np
from scipy.signal import savgol_filter



def calc_phi_from_harmonics(at, samples_per_second=1000, wdw_size=None, 
                            min_amp=1000, min_pi_duration=1000, 
                            apply_low_pass_filter=False, calc_phi=True, 
                            counterclockwise = True, offset = 0,
                            show_msgs=False):
    
    n = len(at)
    
    ## Mitteln und Nullstellen finden
    bOk = (n>0)
        
    f_mean = np.nan
    f_sigma = np.nan
    zero_transitions = []
            
    if calc_phi:
        phi = np.empty(n)
        phi.fill(np.nan)
    

    if not(bOk):
        if show_msgs:
            print('time series is empty')

    else:
    
        # minimal system value
        # TODO 2019-5-8: noch generisch bestimmen
        eps = 1e-16
                        
        if wdw_size is None:
            wdw_size = int(np.floor(samples_per_second/2))   # window size
        
        if wdw_size % 2 == 0:
            wdw_size += 1
            if show_msgs:
                print('add 1 to windowsize to make it odd')
            
         
        vect = savgol_filter(at, wdw_size, 2)   # smoothing with savgol filter
        vect = vect - vect[wdw_size:-wdw_size].mean()               # by filter shift of 
                
        #max_amp = np.floor(max(abs(vect)))
        max_amp = max(abs(vect))
        if max_amp < min_amp:
            
            bOk = False
            if show_msgs:
                print('insufficient amplitude of smoothed time series for omega '
                      f'calculation {max_amp} < {min_amp}')
            
        
        if bOk:
            # optional: Hochpass anwenden
            if apply_low_pass_filter:
                # TODO: Hochpassfilter anwenden
                if show_msgs:
                    print('TODO: Hochpassfilter anwenden [nicht Tiefpass???]')
                # at = at - vect
            
            signs = np.sign(vect)
            #delta_signs = np.insert(np.diff(signs), 0, 0)
            delta_signs = np.append(np.diff(signs), 0)
            btmp = (abs(signs)<eps) | (abs(delta_signs) >=2 - eps)
            zero_transitions = np.where(btmp)[0] + 1                    # +1 in order to prepare for later use, where the transition index + 1 is needed
        
            n_trans = len(zero_transitions)
        
            
            bOk = (n_trans>1)                  # at least 2 zero-points needed
            if bOk:
                idx0 = zero_transitions[0]
                if idx0 >= (n - wdw_size/2 - 1):
                    bOk = False
                    if show_msgs:
                        print('zero points only in end region - not used for '
                              'determination of rotation frequency')

            else:
                if show_msgs:
                    print('no zero points found')
                # TODO 2019-5-28: hier koennte man noch einen cos-Fit oder sowas versuchen, um noch was zu retten
                
        
        if bOk:
            period = np.diff(zero_transitions)
            frequencies = samples_per_second/(2*period)
            f_mean = np.mean(frequencies)
            f_sigma = np.std(frequencies)
            
            ## now determine rotation angle
            if counterclockwise:
                fac = 2 * math.pi
            else:
                fac = -2 * math.pi
                
                
            if calc_phi:            
                
                # TODO 2019-5-28: noch Konsistenzchecks machen
                
                # first part between the start and the first 0-transitions
                # TODO 2019-5-28: noch pruefen, ob das fuer counterclockwise==False auch richtig ist
                f = frequencies[0] * fac
                 
                ## only here this assignment because the first values will be calculated "backwards"
                # TODO 2019-5-28: hier muss unbedingt noch die Drehrichtung beachtet werden!
                # TODO 2019-11-21: Fall abfangen, dass genau 0, dann folgende signs pruefen
                # TODO 2019-11-21: alles moeglichst noch vektorisieren
                # TODO 2019-11-21: wdw_size automatisch anpassen, wenn periode < 10101 (bzw. generell generisch bestimmen)
                # TODO 2019-11-21: gleich noch die Nullpunkte mit zurueckgeben! (also die Indizees der Beginnzeitpunkte einer
                # jeden neuen Schwingung)
                # TODO 2019-11-21: vielleicht frequenz auch anhand acf bestimmen, daraus dann die "Raender" ermitteln und dann die
                # Daten verschieben auf den Nullpunkt
                if signs[0]==-1:
                    phi0 = 2*math.pi
                else:
                    phi0 = math.pi
                    
                #phi0 = (1-signs[0]) * math.pi/2
                phi[0:idx0+1] = [f * (i-idx0)/samples_per_second + phi0 for i 
                                   in range(idx0+1)]
                    
                
                if signs[0]==-1:
                    phi0 = 0

                ## middle parts between the first and last zero transition                
                idx1 = idx0 + 1
                period = 0
                ## now loop through the other periods
                for idx2 in zero_transitions[1:]:
                    
                    f = frequencies[period] * fac                        # get rotation frequency for that period
                                        
                    phi[idx1:idx2+1] = [f * (i-idx1) / samples_per_second + 
                                       phi0 for i in range(idx1, idx2+1)]
                    
                    phi0 = (1-signs[idx2+1]) * math.pi/2
                               
                    period += 1
                    idx1 = idx2+1   
            
                
                # last part between the last 0-transitions and the end of the time series
                idx2 = len(at)
                f = frequencies[-1] * fac                                

                phi[idx1:idx2] = [f * (i-idx1)/samples_per_second + phi0 for i 
                                   in range(idx1,idx2)]



            
    dict_res = {'f_mean': f_mean,
                'f_sigma': f_sigma,
                'zero_transitions': zero_transitions}
        
    if calc_phi:
        dict_res.update({'phi': phi + offset})
                    
        
    return(bOk, dict_res)
    
