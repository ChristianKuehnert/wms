# -*- coding: utf-8 -*-
"""
function to transform the given time (which can be of different types) into string

Note: in case of dt is a string already, it just will be returned without changes
(even if its format differs from sFormat)

Created on Wed Mar 27 10:25:13 2019

@author: christian kuehnert
@modified: 2018-12-7
"""
import pandas as pd

def time_to_string(dt, sFormat='%Y%m%d%H%M%S'):
    
    if dt is pd.NaT:
        return('')
        
    elif isinstance(dt, str):
        return(dt)
        
    elif isinstance(dt, pd.datetime):
        return(dt.strftime(sFormat))
        
    elif isinstance(dt, pd.Timestamp):
        return(dt.dt.strftime(sFormat))
        
    else:
        return(None)
                

