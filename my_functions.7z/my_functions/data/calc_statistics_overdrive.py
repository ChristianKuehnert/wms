# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 08:22:00 2019

@author: Christian K"uhnert

"""


"""
function to calculate some statistics for the given time series

"""
from collections import Counter

def calc_statistics_overdrive(dTS):
    
    min_val = min(dTS)
    max_val = max(dTS)
    n_total = len(dTS)
    tmp = Counter(dTS)
    part_min = tmp[min_val] / n_total
    part_max = tmp[max_val] / n_total

    #return({'n_total': n_total,
    #        'min_val': min_val,
    #        'max_val': max_val,
    #        'part_min': part_min,
    #        'part_max': part_max])
    return([n_total, min_val, max_val, part_min, part_max])
