# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 14:01:42 2019

function to parse (filter) tuples, only numeric, None or missing values 
will be set to -Inf or Inf


@author: Christian Kuehnert
@modified: 2019-9-4

TODO 2019-9-3: bei Gelegenheit eleganter machen, mit map oder sowas
"""
import numpy as np

def parse_tuple(tup):
    if len(tup)==1:
        x = tup[0]
        y = np.Infinity
    else:        
        if (tup[0] is None):
            x = -np.Infinity
        else:
            x = tup[0]
        
        if (tup[1] is None):
            y = np.Infinity
        else:
            y = tup[1]
            
    return(x, y)
