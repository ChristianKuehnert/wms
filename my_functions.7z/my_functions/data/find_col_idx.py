# -*- coding: utf-8 -*-
"""
function to find the positions of the elements of sListSearch in the list sList

Created on Wed Apr 24 18:23:34 2019

@author: Christian Kuehnert, 2018-10-16
"""

def find_col_idx(sListSearch, sList):

    return [sList.index(el) if el in sList else None for el in sListSearch]
        


