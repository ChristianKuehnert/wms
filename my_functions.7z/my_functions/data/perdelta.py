# -*- coding: utf-8 -*-
"""
function to generate the days in the given time interval


@author: see https://stackoverflow.com/questions/10688006/generate-a-list-of-datetimes-between-an-interval

2019-2-8

"""
def perdelta(start, end, delta):
    curr = start
    while curr < end:
        yield curr
        curr += delta
   
    