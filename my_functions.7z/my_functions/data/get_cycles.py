# -*- coding: utf-8 -*-
"""
function to get the cycles for a given period with given where clause for a certain database

input:
------
    
- db:            string, database name including 'cmrblba_'
- start_time:    datetime, start time (included) of desired cycles
- end_time:      datetime, end time (included) of desired cycles
- columns:       list of strings, columns that should be retrieved from table ba_cycle_status
- where:         string, where clause to be applied for MySQL-request
- power_min:     float, minimum value of power for cycles to be included


@author: Christian Kuehnert
@modified: 2019-3-13

"""

#import data.whereClause_from_timeInterval
#import data.get_data_from_db
import data as mfdata

def get_cycles(db, table='ba_cycle_measurement_cycle', start_time=None, end_time=None, columns=['create_time', 'ID', 'power_mean'], where='available_data>1', power_min=None):
    
    # create where clause
    lw = []
            
    if where:
        lw.append(where)
        
    if power_min:
        lw.append('power_mean>=' + str(power_min))
                
    tmp = mfdata.whereClause_from_timeInterval(time_start=start_time, time_end=end_time)
    if tmp:
        lw.append(tmp)
        
    ## now combine to string        
    if len(lw)>1:
        where_clause = '(' + ') and ('.join(lw) + ')'
    elif len(lw)==1:
        where_clause = lw[0]
    else:
        where_clause=None
                           
    dfCDEF = mfdata.get_data_from_db(db, table, where_clause=where_clause, columns=columns)

    return(dfCDEF)


