# -*- coding: utf-8 -*-
"""
function to get the intersection of df1 and df2, regarding to the values
in columns sHeaders


Created on Wed Apr 24 18:27:52 2019

@author: Christian Kuehnert, 2018-11-6
"""
import pandas as pd

def intersect_df(df1, df2, sHeaders):
    
    dfInter = pd.merge(df1, df2, how='inner', on=sHeaders)
    dfInter.dropna(inplace = True)
    return(dfInter)

