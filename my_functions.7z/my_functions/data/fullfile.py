# -*- coding: utf-8 -*-
"""
function to combine the given strings to a file name with full path (or to a path)

@author: Christian Kuehnert, 2018-10-15
"""

def fullfile(listNames):
    return '\\'.join(listNames)

