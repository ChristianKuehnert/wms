# -*- coding: utf-8 -*-
"""
function to get the time series for a the list of files (these must be the 
complete files for a channel in the right order, 
there will be no test on this within this function)

input:
------
- db:               string, database name including 'cmrblba_'    
- create_time:      timestamp, create_time of the time series
- iID:              integer, cycle-id
- channel:          integer, channel number
- count_meas_base:  integer, base length for measurement


@author: Christian Kuehnert
@modified: 2019-11-18

"""

from .fullfile import fullfile
from .update_hd5 import read_gz
from .update_hd5 import combine_ts
#import data as mfdata


def get_ts_from_files(folder, files, count_meas_base=8192):
                   
    iTS = None
                                              
    try:    

        ## aggregate the files
        listTS = []
        for sFN0 in files:
            #listTS.append(mfdata.read_gz(mfdata.fullfile((folder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
            listTS.append(read_gz(fullfile((folder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                 
        ## combine the measurements if possible
        #iTS, iOL = mfdata.combine_ts(listTS, count_meas_base)
        iTS, iOL = combine_ts(listTS, count_meas_base)
            
        if len(iTS)==0:
            print(f'Einzelzeitreihen ungleich lang oder keine Vielfachen von {count_meas_base}')
            iTS = None # TODO 2019-3-13: noch function 'combine_ts' so umstellen, dass automatisch None rauskommt, wenn irgendwas schief laeuft

    except Exception:                
        print(f'Probleme mit Entpacken oder Zusammenfuegen')
                                    
  
    return(iTS)



