# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 17:58:15 2019

@author: w012028
"""


# from https://gist.github.com/igniteflow/1632798
# 2018-8-21
def remove_none_elements_from_list(list):
    return [e for e in list if e is not None]
	

