# -*- coding: utf-8 -*-
"""
function to extract the cycle-keys (create_time and cycle-ID) from
 the data in node sNode in the hd5-file. This node must contain the
 columns in sHeadersKey

 
@author: Christian Kuehnert, 2018-11-6

 TODO 2018-10-26: ist noch sehr langsam - schnellere Variante finden (am besten gleich nur DISTINCT-Datensaetze aus dem 
 hd5-file auslesen, wenn das irgendwie geht)

"""

import pandas as pd


def extract_cycleKeys_from_node(f, sNode, sHeadersKey, iChunkSize = 1000000):
    
    lCycKeys = []
        
    iterator = f.select(sNode, chunksize=iChunkSize, columns=sHeadersKey)
        
    for i, dfChunk in enumerate(iterator):  
        #print('    chunk ' + str(i))                      
        lCycKeys.append(dfChunk.drop_duplicates())
            
    if lCycKeys:
        dfCycKeys = pd.concat(lCycKeys, axis=0)
        dfCycKeys.drop_duplicates(subset=sHeadersKey, inplace=True)                             # necessary again, because different chunks can contain the same keys
    else:
        dfCycKeys = []
        #dfCycKeys = pd.DataFrame(columns=sHeadersKey)
                        
    return(dfCycKeys)


