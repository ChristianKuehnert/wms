# -*- coding: utf-8 -*-
"""
function to import a .csv-label-file and update the label-df in
 the hd5-file with these labels
 
 label==0: normal state (usually 'ok')
 label==1: failure (or sth. similar)
 label==9: unknown/not yet labelled

 
@author: Christian Kuehnert, 2018-10-25

"""
import os
import pandas as pd
from data import fullfile


def label_from_csv(sDB, sPathData, sPathLabelFile):
        
    sNodeLabel = 'raw_data/label'

    sHeadersKey = ['create_time', 'ID', 'channel']

    sFN_label = sPathLabelFile + '\\' + sDB + '_label.csv'
    
    if os.path.isfile(sFN_label):
        
        dfLabel = pd.read_csv(sFN_label, header=[0], sep=';', index_col=False)
            
        if dfLabel.shape[0]>0:
    
            sFN_hd5 = fullfile(sPathData, sDB + '.hd5')
            with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
                        
                #if '/'+ sNodeLabel in f.keys():
                if sNodeLabel in f:
                    f.put(sNodeLabel, dfLabel, format='table', append=True, data_columns=True, index=False)                        
                    
                else:
                    
                    dfLabel_ex = f.select(sNodeLabel)
                                    
                    dfLabel_ex.set_index(sHeadersKey)               # set index to combination of create_time, ID and channel
                    dfLabel.set_index(sHeadersKey)                  # set index to combination of create_time, ID and channel
#HIER WEITER 2018-10-26                   
                    ## if there are entries in dfLabel that are not in dfLabel_ex so 
                    ## just add them to dfLabel_ex but print a warning
                    iIdxDiff = dfLabel.index - dfLabel_ex.index                        # set difference of the indices
                    if len(iIdxDiff)>0:
                        print(sFN_label + ' has entries not in ' + sFN_label + ', this may indicate inconsistencies regarding the labels - please check!')                
                        f.append(sNodeLabel, dfLabel[iIdxDiff], format='table', ignore_index=True, index=False, data_columns=True)

                    ## TODO 2018-10-25: Testen, ob im .csv-file Eintraege mit 9 sind, die im
                    ## hd5-file einen anderen Wert haben, dann warning geben
#                    idx = dfLabel_ex.index[dfLabel_ex['label'] != 9].tolist()      # find index of already existing labels (i.e. that not equal 9)
                    #dfLabel[idx].label = dfLabel_ex[idx].label      # set labels of new label file to these indices
                    #dfLabel[idx].last_changed = dfLabel_ex[idx].last_changed
                    f[sNodeLabel][dfLabel.index]
     
    return(dfLabel)
    

