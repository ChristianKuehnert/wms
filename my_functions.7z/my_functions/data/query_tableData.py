# -*- coding: utf-8 -*-
"""
function to retrieve data from a given table

@author: Christian Kuehnert
@modified: 2020-3-20


Holt alle Daten der Tabelle der angegebenen Datenbank. Es kann eine where-clause angegeben werden


Input:
      sDB:                Name der Datenbank, aus der die Daten geholt werden sollen
      sTable:             Name der Tabelle, aus der die Daten geholt werden sollen
      fields:             list, list of fields of table to be retrieved
      sWC:                where clause
      sLimit:             limit-Angaben, kann natuerlich die where clause nochmal einschraenken

Output:
      dfData:             pandas.DataFrame mit den geholten Daten

Verwendung:
sDB = 'cmrblba_bc_t_00835'
sTable = 'ba_cycle_externals'
sWC = ''
sLimit = '
dfCycle = query_tableData(sDB, sTable, sWC)
"""

import pandas as pd
import numpy as np

#from data import query_MySQL2
#from data import get_fields_MySQL
#from data import query_MySQL2, get_fields_MySQL
from .query_MySQL2 import query_MySQL2
from .get_fields_MySQL import get_fields_MySQL
#from . import query_MySQL2
#from . import get_fields_MySQL


def query_tableData(sDB, sTable, fields = None, sWC=None, sLimit=None):
    
    listMsg = []
    
    df = get_fields_MySQL(sDB, sTable)  # fields of the table
    
    if not(fields is None):
        df = df[df.Field.isin(fields),:]
        
    listFields = df.Field
    listTypes = df.Type
            
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if not(sWC is None):
        if (len(sWC.strip())>0):
            sSQL += ' where ' + sWC.strip()
            
    if sLimit:
        if (len(sLimit.strip())>0):
            sSQL += ' limit ' + sLimit
        
    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
    
    if not(dfData.empty):
        dfData.columns = listFields
    
        # TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
        # diese jeweils category (oder was besseres?) setzen)    
        #dfData['appendix'] = dfData['appendix'].astype('str')
        
        ## set all timestamp-datatypes to pd.datetime
        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
        sCols = listFields[iPos]
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in sCols:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

    else:
        listMsg.append('keine Daten gefunden')
        dfData = pd.DataFrame(columns=listFields)
    
    return dfData, listMsg
    






## old version, modified: 2020-3-17
def query_tableData_old(sDB, sTable, dict_fields = None, sWC=None, sLimit=None):
    
    listMsg = []
    
    if (dict_fields is None):
        listTmp = get_fields_MySQL(sDB, sTable)
        listFields = listTmp.Field
        listTypes = listTmp.Type
    else:
        listFields = dict_fields.keys()
        listTypes = dict_fields.values()
        
    
    sSQL = 'SELECT ' + ','.join(listFields) + ' from ' + sTable
    
    if sWC:
        if (len(sWC.strip())>0):
            sSQL += ' where ' + sWC.strip()
            
    if sLimit:
        if (len(sLimit.strip())>0):
            sSQL += ' limit ' + sLimit
        
    dfData = pd.DataFrame(data=np.array(query_MySQL2(sDB, sSQL, params=None))).infer_objects()
    
    if dfData.shape[0]>0:
        dfData.columns = listFields
    
        # TODO 2018-10-18: im Moment noch "hart verdrahtet", ersetzen durch generischen code (nach allen text-Typen suchen und
        # diese jeweils category (oder was besseres?) setzen)    
        #dfData['appendix'] = dfData['appendix'].astype('str')
        
        ## set all timestamp-datatypes to pd.datetime
        iPos = [i for i in range(len(listTypes)) if listTypes[i]=='timestamp']
        sCols = listFields[iPos]
        #dfData[sCols] = pd.to_datetime(dfData[sCols], errors='coerce')
        for s in sCols:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

    else:
        listMsg.append('keine Daten gefunden')
        dfData = pd.DataFrame(columns=listFields)
    
    return dfData, listMsg
    
