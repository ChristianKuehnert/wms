# -*- coding: utf-8 -*-
"""
function to append new data sets from ts (and later - to be implemented - from sda) to label-dataframe

@author: Christian Kuehnert, 2019-1-21

TODO 2018-11-19: eigentlich noch Spalte einfuehren, ob zu dem cycle auch TS-Daten vorhanden sind (einfaches 0-1-flag),
um spaeter das gleiche Labelfile fuer sda- und ts-Daten verwenden zu koennen aber gleichzeitig auch z.B. nur die TS-Daten
labeln zu koennen. Erstmal aber damit warten und nur implementieren, wenn es relevant wird

"""

import numpy as np
import pandas as pd
import datetime as dt


from data import set_dtype_headersKey
from data import extract_cycleKeys_from_node
from data import setdifference_df
from data import fullfile



def update_label_intern(sDB, sPathData):
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])

    sNodeLabel = 'raw_data/label'
    sNode_ts = 'raw_data/ts'    

    sHeadersKey = ['create_time', 'ID', 'channel']

    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        dfLabel_ts = extract_cycleKeys_from_node(f, sNode_ts, sHeadersKey)                
        dfLabel_ts = set_dtype_headersKey(dfLabel_ts)
        
        ## if there are already labels in the hd5-store, then only take new labels (and append them later to the existing labels)
        if sNodeLabel in f:
            dfLabel_ex = f.select(sNodeLabel)
            
            if dfLabel_ex.shape[0]>0:                      
                dfLabel_ex = set_dtype_headersKey(dfLabel_ex)
                dfLabel_ts = setdifference_df(dfLabel_ts, dfLabel_ex, sHeadersKey)      # newly found ts-keys
                                
        ## add datebase and last-changed-time                                        
        # TODO 2019-1-21: nochmal pruefen, ob alles so richtig!
        iN = dfLabel_ts.shape[0]
        if iN>0:
            iIdx = dfLabel_ts.index
            dfLabel_ts['database'] = pd.Series(np.tile(sDB, [iN,]), index=iIdx)
            dfLabel_ts['label'] = pd.Series(np.tile(9, [iN,]), index=iIdx, dtype=int)
            dfLabel_ts['last_changed'] = pd.Series(np.tile(dt.datetime.now(), [iN,]), index=iIdx)          # Spalte mit dem Zeitpunkt der letzten Aenderung
    
            dfLabel_ts['last_changed'] = pd.to_datetime(dfLabel_ts['last_changed'], errors='coerce')

            f.append(sNodeLabel, dfLabel_ts, format='table', ignore_index=True, index=False, data_columns=True)
            
        dfLabel = f[sNodeLabel]
        
    return(dfLabel)
        

    
    