# -*- coding: utf-8 -*-
"""
function to retrieve data from database

@author: Christian Kuehnert
@modified: 2019-5-29
"""
import pandas as pd
import numpy as np

#from data import get_fields_MySQL
#from data import query_MySQL2
import data as mfdata


def get_data_from_db(db, table, where_clause=None, columns=None):
        
    # TODO 2019-3-13: Fall abfangen, dass Spalten aus columns nicht enthalten sind    
    if not(columns):
        columns = mfdata.get_fields_MySQL(db, table).Field

    select_clause = ','.join(columns)                
    
    if where_clause:
        tmp = f" where {where_clause}"
    else:
        tmp=''
    
    query = f"select {select_clause} from {table}{tmp};"

    tmp = np.array(mfdata.query_MySQL2(db, query, params=None))
    
    if tmp.shape[0]==0:
        dfData = pd.DataFrame(columns=columns)
    else:
        dfData = pd.DataFrame(data=tmp, columns = columns).infer_objects()
    
    return(dfData)
    #if dfData.shape[0]>0:
    #    dfData.columns = columns
