# -*- coding: utf-8 -*-
"""
function to read from hd5-file


Created on Wed Apr 24 18:12:40 2019

@author: w012028, 2018-8-13
"""
import os
import pandas as pd

def readHD5(sFN_hd5, sKey):		   
    
    if os.path.isfile(sFN_hd5):        
        hf = pd.HDFStore(sFN_hd5, 'r') 
        dfData = hf.get(sKey)                             
        hf.close()
        del hf

    else:
        dfData = []
		
    return dfData
		

		