# -*- coding: utf-8 -*-           
"""    
function that gets the bit at a specified position in a given string

Parameters:
-----------

varDual:  character array representing dual numbers OR the dual number 
          as integer in decimal system
iPos:     position of the interesting bit, indexing starts with 1
          (i.e. at iPos==1 is bit b0 with b0*2^0, at iPos==2 is
          bit b1 with b1*2^1 etc.)
varargin: only valid if varDual is string or character;             if 'left' it is assumed that the dual number in varDual
          starts from the left, otherwise (also if missing or empty) it is
          assumed to start from the right

 
Features:
---------

iBit:   integer vector containing the value of bit at (0-based) iPos, if 
        the rows in varDual have less than iPos characters, 
        bBit=0 is returned, if varDual can't be processed (or 
        other error occur), NaN is returned


 Christian Kuehnert, 2018-12-9

usage:
sDual = ['00110'; ...
         '11111'; ...
         '01000'];
iPos = 2;
function iBit = getBit(varDual, iPos, varargin)
"""

import numpy as np


def get_bit(varDual, iPos, bFromLeft=False):    

    if isinstance(varDual, int) or isinstance(varDual, float):
    
        try:
            #iBit = (floor(varDual/2^(iPos-1)) % 2)            
            iBit = int((int(np.floor(varDual)) & (1 << (iPos - 1)))>0)
        except:
            iBit = np.nan
    
    
    elif isinstance(varDual, str):
        try:
            iL = len(varDual)               
            if (iL < iPos):
                iBit = 0
            else:                       
                if bFromLeft:
                    iTmp = iPos
                else:
                    iTmp = iL-(iPos-1)

                #iTmp = iL-(iPos-1)
                iBit = int(varDual[iTmp-1])  # -1 because 1 based vs. 0-based
   
        except:
            iBit = np.nan
        

    else:
        print('Can''t process input variables of class ' + type(varDual))
        iBit = np.nan
        
    return(iBit)
        
    