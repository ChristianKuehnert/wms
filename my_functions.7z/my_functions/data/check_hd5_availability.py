# -*- coding: utf-8 -*-
"""
function to check the availability (start date and end date, total number) 
of data stored in the hd5 files (drive W:)

@author: Christian Kuehnert
@modified: 2019-11-22
"""
import os
import fnmatch
import pandas as pd
import numpy as np


TODO 2019-11-22: fertig implementieren


def check_hd5_availability(db, path_hd5=r'W:', 
                           check_types=['af','at', 'dynl', 'ext', 'sda']):

    db_short = db.replace('cmrblba_', '')
    path = f"{path_hd5}\\{db_short}\\_current"
    
    for ch in check_types:
        pattern = f'{db_short}_{ch}_*.h5'
        files = [f'{path}\\{s}' for s in os.listdir(path) if  fnmatch.fnmatch(s, pattern)]
        
        for fn in files:
            with pd.HDFStore(fn, 'a') as f:
                
                data = f.select()
                
                ind = store.select_as_coordinates(
                    'st', Where(where).to_pdhdf_select())

                st = store.select('st', where=ind)
                se = store.select('se', where=ind)
            elif create_times is not None:
                create_times = pd.Index(create_times)

                # get create_time index in hdfstore
                stct = store.select_column('st', 'index')

                # set create_times to index, integer locations as values
                ind = stct.reset_index().set_index('index').iloc[:, 0]

                # get the integer locations of matching create_times
                # this was about 20 times faster than
                # ind.loc[ind.index.intersection(create_times)].values
                ind = ind.reindex(create_times).dropna().astype(int).values

                # load corresponding rows from hdfstore
                st = store.select('st', where=ind)
                se = store.select('se', where=ind)
   
                
                
                
                
                
        dfSS = f[sNode_ts_startstop]

        bConsistent = (dfSS.loc[:,['start','stop']].values.min()>=0) \
                        and (dfSS.loc[:,['start','stop']].values.max() == f.get_storer(sNode_ts_data).nrows) \
                        and (len(np.unique(dfSS.loc[:,['start']].values))==dfSS.shape[0]) \
                        and (len(np.unique(dfSS.loc[:,['stop']].values))==dfSS.shape[0])

        if bConsistent:
            # dfSS durchgehen
            for idx, row in dfSS.iterrows():
            
                # zugehoerige dfTS laden
                dtDate = row['create_time']
                iID = row['ID']
                iCh = row['channel']
                iStart = row['start']
                iStop = row['stop']
                
                bConsistent = bConsistent and (iStart>=0) and (iStop>0)    
    
                if bConsistent:
                    dfTS = f.select(sNode_ts_data, start=iStart, stop=iStop)
                                     
                    dfTmp = dfTS.drop_duplicates(subset=['create_day','ID','channel'], inplace=False)
                    bConsistent = bConsistent and (dfTmp.shape[0]==1) and (dfTmp.iloc[0,:].loc['create_day'] == pd.to_datetime(dtDate.date())) and (dfTmp.iloc[0,:].loc['ID']==iID) and (dfTmp.iloc[0,:].loc['channel']==iCh) and (dfTS.shape[0] % 8192 == 0)
                
                
    return(bConsistent)        



