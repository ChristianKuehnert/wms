# -*- coding: utf-8 -*-
      
#TODO 2019-2-7: evtl. zu einem zusammenfassen (mit Option bUpdateHD5 oder mit sDestination
#                                              = 'hd5', 'df', 'both' und den entsprechenden
#                                              weiteren Variablen)  
    
   

"""
Function to read from mysql tables and store it to dataframe
@author: Christian Kuehnert
2019-2-7

TODO 2019-2-7: pruefen, ob auch synchron mit update of hd5 und anschliessendem Auslesen

"""
import pandas as pd
import numpy as np


from data import read_from_table_old


# TODO 2019-2-7: hier noch function uebergeben mit kwargs, und auf die einzelnen chunks anwenden (wenn nicht ==None)
def read_mysql_toDF(sDB, sTable, sWC=None, iChunkSize=10**5):

    #tmp = read_from_table(sDB, sTable, sWC=sWC, iChunkSize=iChunkSize)
    tmp = read_from_table_old(sDB, sTable, sWC=sWC, iChunkSize=iChunkSize)
            
    i=0
    lData = []
    for chunk in tmp['sql_reader']:
        i += 1
        print('chunk ' + str(i))
        dfData = pd.DataFrame(data=np.array(chunk)).infer_objects()            
        dfData.columns = tmp['listFields']
        
        for s in tmp['sColsTimeStamp']:    
            dfData[s] = pd.to_datetime(dfData[s], errors='coerce')    

        lData.append(dfData)
    
    dfData = pd.concat(lData, axis=0).reset_index(drop=True)
        
    return(dfData)
    
    
    