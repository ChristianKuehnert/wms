# -*- coding: utf-8 -*-
"""
 function to collect time series as well as cdef data
 NOTE: the ts-data (data and startstop) contain create_day (not create_time) which only contains the day!

 
# TODO 2018-12-4: aufspalten in update_ts_fromCDEF(sDB, sPathData, dfCDEF) wo nur die in dfCDEF uebergebenen cycles upgedatet werden, und update_ts() wo die dfCDEF-cycles
# wie hier implementiert bestimmt werden, und dann darauf update_ts_fromCDEF anwenden. D.h. 
# TODO 2018-12-7: hier noch so implementieren, dass entweder 1) die sNode_ts_startstop eine Spalte enthaelt, ob ein folder ueberhaupt ts-daten enthaelt, der zugehoerige dataframe
# ist dann bzgl. der Keys eine Kopie von dfCDEF, bei sloppy=True werden dann wirklich nur noch neue cycles durchsucht, oder 2) einen weitere node sNode_cycles anlegen, welche
# eben alle cycles von dfCDEF enthaelt und jeweils eine spalte mit true/false oder 1/0 fuer ts-Daten und eine entsprechend fuer sda-Daten, dann mit dieser entsprechend arbeiten


Created on Wed Mar 27 10:21:02 2019

@author: christian kuehnert
@modified: 2019-6-17
"""

import os
import fnmatch
import pandas as pd
import numpy as np

from os import listdir

#from data import class_hd5Nodes as sNodes
#from data import fullfile, get_folder, read_gz, combine_ts, setdifference_df, whereClause_from_timeInterval
from data.class_hd5Nodes import hd5Nodes as sNodes
import data.fullfile as fullfile
import data.get_folder as get_folder
import data.read_gz as read_gz
import data.combine_ts as combine_ts
import data.setdifference_df as setdifference_df
import data.whereClause_from_timeInterval as whereClause_from_timeInterval
#from data import whereClause_from_timeInterval as whereClause_from_timeInterval



def update_ts(sDB, sPathData, time_start=None, time_end=None, iCntMeasBase = 8192, bSloppy=True):

    #lMsg = []
    lRes = []
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef               #  'raw_data/cdef'
    #sNode_ts = 'raw_data/ts'                                           # node where the time series data are stored
    sNode_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
    sNode_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
       
    sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                      # full hd5-file name
    
    
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

#TODO 2018-12-16: klaeren, ob die TS-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!            
            lWhere = ['available_data>2']                            # consider only cycles where sda-files were stored
            sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                
            if sWhere:
                lWhere.append(sWhere)
                
            sWhere = ' and '.join(lWhere)
                        
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                
            iCycles = dfCDEF.shape[0]                                          # number of cycles                

    
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2018-12-2: assume that always both sNode_ts and sNode_ts_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_ts_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_ts_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the ts-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=True - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'channel', 'overlap', 'start','stop'])
            
                                    
            iCycles = dfCDEF.shape[0]

            for i in range(iCycles):
                
                #tsCT = dfCDEF.create_time[i]                                       # current create_time
                #iID = dfCDEF.ID[i]                                                 # current ID
                tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                                    
                if (i % 20 == 0):
                    #                        print(sInfo)                   
                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID))


                if not ((iID==0) or pd.isnull(tsCT)):
                                    
#                    sInfo = sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                        
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                
                        if len(sFiles)>0:
                            iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
        
                            #if (i % 20 > 0):
                            #    print(sInfo)
                            
                            #print('    files exist')
                            create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                            
                            ## find all ts-files in that folder that match the search pattern
                            ## and are not already stored in the .hd5-file
                            if bCycEx:                                              # if there are already existing time series
                                
                                #dfCycEx = f.select(sNode_ts, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                #dfCycEx = dfCycTSEx[(dfCycTSEx.create_day==create_day) & (dfCycTSEx.ID==iID)]
                                dfCycEx = dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID)]

                                if dfCycEx.shape[0]>0:
                                    iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                    #print('    already data, ' + str(len(iChannels)) + ' new channels')
                            
                            # TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                            lChAdded = []
                            for iCh in iChannels:
                                        
                                sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
        
                                ## sort files by the measure-number
                                iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                         
                                try:    

                                    ## now aggregate the remaining files                                
                                    listTS = []
                                    for sFN0 in sFilesCh:                    
                                        listTS.append(read_gz(fullfile((sFolder, sFN0))))                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                     
                                    ## combine the measurements if possible
                                    iTS, iOL = combine_ts(listTS, iCntMeasBase)                        
                                    
                                    iCntTS = len(iTS)
                                    if iCntTS>0:  
                                        
                                        #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df1 = pd.DataFrame(data=(np.tile([create_day, iID, iCh], [iCntTS,1])), columns = sHeadersKey)
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                        df2.columns = ['idx', 'a_t']
                                        dfTmp = pd.concat((df1,df2), axis=1)

                                        dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        dfTmp['channel'] = dfTmp['channel'].astype(int)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                        
                                        #iStart = f.get_storer(sNode_ts_data).nrows
                                        f.append(sNode_ts_data, dfTmp, format='table', data_columns = True, index=False)    
                                        
                                        # now add row numbers for start and stop for this time series
                                        iStop = f.get_storer(sNode_ts_data).nrows
                                        iStart = iStop - dfTmp.shape[0]
                                        
                                        dfMap = pd.DataFrame(data=[[tsCT, iID, iCh, iOL, iStart, iStop]], columns = ['create_time','ID','channel','overlap','start','stop'])
                                        dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                        dfMap['ID'] = dfMap['ID'].astype(int)
                                        dfMap['channel'] = dfMap['channel'].astype(int)
                                        dfMap['overlap'] = dfMap['overlap'].astype(int)
                                        dfMap['start'] = dfMap['start'].astype(np.int64)
                                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                        f.append(sNode_ts_startstop, dfMap, format='table', data_columns = True, index=False)    
                                        
                                        lRes.append(dfMap)
                                        
                                        #lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        #print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                        lChAdded.append(str(iCh))
                    
                                    #else:
                                    #    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                
                                except Exception as ex:
                                    #lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
                                    print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')

                            # information if time series were added
                            #if len(lChAdded)>0:
                            #    print(sInfo + ': ts for channels ' + ','.join(lChAdded) + ' added')
                 
    if len(lRes)==0:
        return(pd.DataFrame(columns=['create_time','ID','channel','overlap','start','stop']))
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        return(dfRes)


    #return(lMsg)


