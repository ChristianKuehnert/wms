# -*- coding: utf-8 -*-
"""
function to collect sda series and store them to .hd5-file
NOTE: the ts-data (data and startstop) contain create_day (not create_time) which only contains the day!

Created on Thu Apr 25 11:38:54 2019

@author: Christian Kuehnert
@modified: 2019-6-25

"""


import os
import fnmatch
import numpy as np
import pandas as pd

#from data import class_hd5Nodes as sNodes
#from data import fullfile, whereClause_from_timeInterval, setdifference_df, get_folder, read_gz
from data.class_hd5Nodes import hd5Nodes as sNodes
import data.fullfile as fullfile
import data.get_folder as get_folder
import data.read_gz as read_gz
import data.setdifference_df as setdifference_df
import data.whereClause_from_timeInterval as whereClause_from_timeInterval
#from data import whereClause_from_timeInterval as whereClause_from_timeInterval
#from . import whereClause_from_timeInterval


def update_sda(sDB, sPathData, time_start=None, time_end=None, bSloppy=True):

    lRes = []
    
    sDTFormat_hd5='%Y%m%d%H%M%S'
    
    sNode_cdef = sNodes.cdef  #'raw_data/cdef'
    sNode_sda_data = sNodes.sda_data     # sNode_sda + '/data'                                 # subnode with sda data
    sNode_sda_startstop = sNodes.sda_startstop     # sNode_sda + '/startstop'                        # subnode with row numbers of start and stop of each sda series
       
    #sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])                      # full hd5-file name
    
    
    iCycles = 0        

#TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

            #TODO 2018-12-16: klaeren, ob die sda-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!
            lWhere = ['available_data>=2']                            # consider only cycles where sda-files were stored
            sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                
            if sWhere:
                lWhere.append(sWhere)
                
            sWhere = ' and '.join(lWhere)
                        
            dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                            
            iCycles = dfCDEF.shape[0]                                          # number of cycles
    
    
    
    if iCycles>0:
                   
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

            ## create flag that indicates if the node already exists and has the correct type and (if
            ## all this is true) get the row numbers in the dataframe

            ## TODO 2019-6-25: assume that always both sNode_sda and sNode_sda_startstop are existent and synchronous, or both are not existent. 
            ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
            if (sNode_sda_data in f):
                #if (type(f[sNode_ts]) is pd.DataFrame):
                #bCycEx = True
                #iStop = f.get_storer(sNode_ts_data).nrows
                dfCycTSEx = f.select(key=sNode_sda_startstop)			
                
                ## if only new cycles should be checked ...
                ## NOTE: in case one or more channels from a cycle where not stored yet in 
                ## the sda-node, bSloppy=True will prevent this function to add them to this node
                ## For fast run assume that all cycles that are already in the sda-node are complete in the sense, that
                ## they contain already all correct data. If you want complete check for new data also in the folders
                ## from which already some data were read, then set bSloppy to False
# 2018-12-5: Funktion noch testen mit bSloppy=False - Option
                if bSloppy:
                    dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                
                            
            else:		# perhaps here otherwise create this node with empty set but correct columns
                #bCycEx = False
                #iStop = -1
                dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'filename', 'blade', 'direction', 'start','stop'])
            
                                    
            iCycles = dfCDEF.shape[0]

            count = 0
            #for i in range(iCycles):
            for idx, cdef in dfCDEF.iterrows():
                
                count += 1
                
                #tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                #iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                tsCT = cdef['create_time']
                iID = cdef['ID']                 
                   
                if (count % 100 == 0):
                    print(sDB + '  ' + str(count) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID))


                if not ((iID==0) or pd.isnull(tsCT)):
                                                            
                    sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                        
                    if os.path.isdir(sFolder):
        
                        # TODO 2019-1-10: evtl. mit regex noch genauer spezifizieren
                        sFiles = fnmatch.filter(os.listdir(sFolder), 'af_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
        
                        for sFN in sFiles:
#TODO 2019-7-16: hier auch hub_axial usw. mitnehmen, moeglichst generisch!                            
                            sFN_short = sFN.replace('af_', '').replace('.csv.gz', '')       # remove 'af_' and ending from file name
                            
                            ## check if already stored in the .hd5-file
                            #if bCycEx:                                              # if there are already existing time series
                                
                            # if there is no entry for this cycle and channel:
                            if (dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID) & (dfCycTSEx.filename==sFN_short)].shape[0]==0):
                        
                                parts = sFN_short.split('_')      # split (short) file name by '_'
                        
                                iBlade = int(parts[-1])-100
                                sDirection = parts[0]
                                #if (parts[1]=='axial') and not((sDirection=='edge') or (sDirection == 'flap')):
                                #if (parts[1]=='axial'):
                                if parts[1].isalpha():
                                    sDirection = sDirection + '_' + parts[1]
                                                                                                                   
                                create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                                                                                          
                                try:    

                                    ## now aggregate the remaining files                                
                                    dSDA = read_gz(fullfile((sFolder, sFN)), tType=np.float64)                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                                                     
                                    iCnt = len(dSDA)
                                    if iCnt>0:  
                                    
                                        #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                        df1 = pd.DataFrame(data=(np.tile([create_day, iID, sFN_short], [iCnt,1])), columns = ['create_day', 'ID', 'filename'])
                                        df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCnt)), dSDA), axis=1)))
                                        df2.columns = ['idx', 'a_f']
                                        dfTmp = pd.concat((df1,df2), axis=1)

                                        dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                        #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                        dfTmp['ID'] = dfTmp['ID'].astype(int)
                                        #dfTmp['filename'] = dfTmp['filename'].astype(string)
                                        dfTmp['idx'] = dfTmp['idx'].astype(int)
                                        #dfTmp['a_f'] = dfTmp['a_f'].astype(float)
                                        
                                        #iStart = f.get_storer(sNode_ts_data).nrows
                                        f.append(sNode_sda_data, dfTmp, format='table', data_columns = True, index=False, min_itemsize={'filename': 40})
                                        
                                        # now add row numbers for start and stop for this time series
                                        iStop = f.get_storer(sNode_sda_data).nrows
                                        iStart = iStop - dfTmp.shape[0]
                                        
                                        dfMap = pd.DataFrame(data=[[tsCT, iID, sFN_short, iBlade, sDirection, iStart, iStop]], columns = ['create_time','ID','filename','blade', 'direction','start','stop'])
                                        dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                        dfMap['ID'] = dfMap['ID'].astype(int)
                                        dfMap['blade'] = dfMap['blade'].astype(int)
                                        #dfMap['filename'] = dfMap['filename'].astype(str)
                                        #dfMap['direction'] = dfMap['direction'].astype(str)
                                        dfMap['start'] = dfMap['start'].astype(np.int64)
                                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                        f.append(sNode_sda_startstop, dfMap, format='table', data_columns = True, index=False, min_itemsize={'filename': 40})    
                                        
                                        lRes.append(dfMap)

                                                                        
                                except Exception:
                                    print(sDB + '  ' + str(count) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', file ' + sFN + ': Probleme mit Entpacken oder Einlesen')

                 
    if len(lRes)==0:
        return(pd.DataFrame(columns=['create_time', 'ID', 'filename', 'blade', 'direction', 'start','stop']))
    else:
        dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
        return(dfRes)


    #return(lMsg)

