# -*- coding: utf-8 -*-
"""
Created on Wed Mar 27 10:30:02 2019

function to get folder names for retrieving ts data or sda data


@author: christian kuehnert
@modified: 2018-10-16
"""
from data import get_BcDataPath, fullfile

def get_folder(sDB, tsCT, dID):

    #dTmp = matlab2datetime(dCreateTime)    
    #return fullfile(get_BcDataPath(sDB, dCreateTime), dTmp.year, dTmp.month, dTmp.day, dID)    
    #return fullfile([get_BcDataPath(sDB, tsCT), sDB, str(tsCT.year), str(tsCT.month), str(tsCT.day), str(dID)])    
    return fullfile([get_BcDataPath(sDB, tsCT), sDB.replace('cmrblba_',''), tsCT.strftime('%Y\\%m\\%d'), str(dID)])



