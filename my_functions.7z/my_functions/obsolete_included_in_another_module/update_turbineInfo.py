# -*- coding: utf-8 -*-
"""
function to save turbine info in hd5-file if not already there


Created on Wed Apr 24 18:25:14 2019

@author: Christian Kuehnert, 2019-1-11
"""
import pandas as pd

#from data import fullfile, query_pit
import data.fullfile as fullfile
import data.query_pit as query_pit

 
def update_turbineInfo(sDB, sPathData):
    
    sNode = 'turbine_info'

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])    
    
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:

        if not (sNode in f):
            # retrieve relevant data (farm, turbine etc.) from pit   
            sTmp = 'SELECT Windpark_WEA#Windparkname as farm,WEA_Name as turbine,WEA_Typ#Name as turbine_type,Datenbankname as turbine_database,Beginn_Datenspeicherung as begin_data,Inbetriebnahme_abgeschlossen as operational FROM VIEW_Windkraftanlagen WHERE Datenbankname=\'' + sDB + '\''
            dfTmp = query_pit(sTmp)
            #f.append(sNode, dfTmp, format='table', data_columns = True, index=False)
            #f.append(sNode, dfTmp, format='table', data_columns = True)
            f.put(sNode, dfTmp, format='table', data_columns=True, index=False)                           

