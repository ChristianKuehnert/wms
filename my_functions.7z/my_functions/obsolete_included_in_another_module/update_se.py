# -*- coding: utf-8 -*-
"""
function to update cdef data


Created on Thu Apr 25 02:03:56 2019

@author: Christian Kuehnert, 2019-2-6
"""
from data import class_hd5Nodes as sNodes
from data import update_hd5fromDB

def update_se(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.sig_energy
    #sTable = 'sig_energies'
    sTable = 'ba_cycle_sig_energies'
    sHeadersKey = ['create_time', 'cycle_id', 'measure_number', 'start_f']
    dictTypes={'cycle_id': int}
    iLimit = 500000
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)

    #return(dfData)
        
