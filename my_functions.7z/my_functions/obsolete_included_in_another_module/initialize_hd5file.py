# -*- coding: utf-8 -*-
"""
function to create the file and to add all relevant groups 


Created on Wed Apr 24 18:24:07 2019

@author: Christian Kuehnert, 2019-1-7
"""

import os
import pandas as pd

#from data import fullfile, update_turbineInfo
#import data.fullfile as fullfile
#import data.update_turbineInfo as update_turbineInfo
from data import fullfile as fullfile
from data import update_turbineInfo as update_turbineInfo


def initialize_hd5file(sDB, sPathData):
    
    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
    
    if not os.path.isfile(sFN_hd5):             # if no such hd5-file exists            
        with pd.HDFStore(sFN_hd5, mode="w", complevel=9, complib='blosc:lz4') as f:        # create empty hd5-file
            f.close()
            
    update_turbineInfo(sDB, sPathData) 
        
