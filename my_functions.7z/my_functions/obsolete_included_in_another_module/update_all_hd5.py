# -*- coding: utf-8 -*-
"""
function to update one the hd5-file of the given turbine
@author: Christian Kuehnert

2019-2-6

Example:
--------
sDB = 'cmrblba_bc_t_mb_bw48'
sPathData = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\data\hd5_files'
update_all_hd5(sDB, sPathData)


"""

from data import update_cdef as update_cdef
from data import update_status as update_status
from data import update_se as update_se
from data import update_sda as update_sda
from data import update_ts as update_ts


def update_all_hd5(sDB, sPathData, time_start=None, time_end=None):
    
    print('updating ' + sDB + ':')
    
    print('       update cdef')
    update_cdef(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update status')
    update_status(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update se')
    update_se(sDB, sPathData, time_start=time_start, time_end=time_end)        
    
    print('       update sda')
    update_sda(sDB, sPathData, time_start=time_start, time_end=time_end)
    
    print('       update ts')
    update_ts(sDB, sPathData, time_start=time_start, time_end=time_end)
         
