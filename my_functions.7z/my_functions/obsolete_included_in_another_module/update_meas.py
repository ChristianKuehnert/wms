# -*- coding: utf-8 -*-
"""
function to update data in table 'ba_cycle_measurement'

Created on Thu Apr 25 02:01:35 2019

@author: Christian Kuehnert, 2019-2-6
"""
from data import class_hd5Nodes as sNodes
from data import update_hd5fromDB


def update_meas(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cycle_measurement
    sTable = 'ba_cycle_measurement'
    #dictTypes={'ID': int, 'appendix': str}
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int}
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
 