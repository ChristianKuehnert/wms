# -*- coding: utf-8 -*-
"""
function to update cdef data
 
@author: Christian Kuehnert, 2019-6-17
"""
#import data.update_hd5fromDB as update_hd5fromDB
from . import update_hd5fromDB# as update_hd5fromDB

from data.class_hd5Nodes import hd5Nodes as sNodes
#import update_hd5fromDB
#import class_hd5Nodes as sNodes

def update_cdef(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cdef
    sTable = 'ba_cycle_measurement_cycle'
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int, 'appendix': str}
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB.update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
     