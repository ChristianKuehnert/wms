# -*- coding: utf-8 -*-
"""
Created on Wed Mar 27 10:31:28 2019

function to get the drive for the .csv-data from the date

input:
      - sDB:     database name of the turbine of interest
      - tsCT:    create time as pandas...time stamp

output:
      - sDir:    directory containing the files with ts and sda data



@author: christian kuehnert
@modified: 2019-3-15

"""
import pandas as pd

def get_BcDataPath(sDB, tsCT):

    #dTimeChange = 736760.4416666666511446237564                 # matlab date number, equals datenum( 2017,3,6,10,36,0)
    tsChange_to_bcdata2 = pd._libs.tslibs.timestamps.Timestamp('2017-03-06 10:36:00')    
    tsChange_to_bcdata3 = pd._libs.tslibs.timestamps.Timestamp('2019-03-12 17:17:00')       # todo 2019-3-15: ggf. nochmal genau von jmd. geben lassen, ist erstmal empirisch aus webAna bestimmt
#    if (sDB in ['cmrblba_vid_reinsdorf', 'cmrblba_bc_t_01761_b', 'cmrblba_bc_t_01305_strain']):
#        #sDir = '\\10.41.52.54\\bcdata'   
#        sDir = 'Z:'
#    else:
    if (tsCT > tsChange_to_bcdata2):
        if (tsCT > tsChange_to_bcdata3):
            sDir = 'Z:'
        else:
            sDir = 'X:'
    else:
        sDir = 'Y:'
                    
    return sDir


