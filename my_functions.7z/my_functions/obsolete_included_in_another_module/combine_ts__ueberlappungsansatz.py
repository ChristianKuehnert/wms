# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 13:27:48 2019

@author: w012028
"""



"""
TODO: in extra-modul auslagern (extra fuer special query), dann nur noch minimalen
Rest in der turbine-class behalten oder vielleicht sogar diese ableiten und die
Funktion dort hinzufuegen


 implemented only for special query from 20190805 (see email from SW from this
 date)
 
 function to combine the ts-data from the single gz-files for one channel into 
 one time series
 search for overlapping parts of the time series and combine there, if no such parts are found than 
 just append the time series from the single files
 if the series have different lengths then return error message

 input:
       - listTS:           list of series of integers (i.e. time series of the sensors)
       - iCntMeasBase:     integer, base lenght of measurement

 output:


Created on Wed Mar 27 10:15:25 2019

@author:  Christian Kuehnert
@modified: 2019-8-9
"""

from statistics import mode

def combine_at_old(path, list_files, iCntMeasBase=8192):
    
    # TODO 2018-11-1: Fall abfangen, dass eine Sensorstrecke (streckenweise) 
    # konstant ist, dann vielleicht an den iOLs der 
    # anderen Sensoren orientieren
    # am besten aber vielleicht doch alle Teilabschnitte EINZELN abspeichern 
    # und dann nur mit gemeinsamen gruppenindizes versehen, 
    # die im fail-Fall = None oder so sind
    # TODO 2019-7-18: noch besser: Anhand der gespeicherten!!! Startzeitpunkte
    # die DAten synchronisieren (so wie SB, AK machen) -> geht hier nicht, da
    # keine cycle-Daten vorhanden!
    
    ## extract channels that are in these data
    ltmp = []
    for fn in list_files:
        sid, sch = fn.replace('at_', '').replace('.csv.gz', '').split('_')
        ltmp.append({'channel': sch, 'csv_id': int(sid), 'file': fn})
        
    df = pd.DataFrame.from_records(ltmp)
        
    groups = df.groupby(by=['channel'])
    
    dict_res = {}
    for channel, df_g in groups:
        df_g.sort_values(by=['csv_id'], inplace=True)  # sort values
        
        list_ts = []
        for fn in df_g.file:
            list_ts.append(read_gz(f'{path}\\{fn}'))
                 
        iTS, iOL = combine_ts(list_ts, iCntMeasBase)          # combine the data
        dict_res.update({channel: (iTS, iOL)})
            
    dict_ol = {}
    for k, (_ts, iOL) in dict_res.items():
        dict_ol.update({k: iOL})
        
    channels_check = []
    
    list_ol = [s for k, s in dict_ol] 
    
    if len(np.unique(list_ol)) != 1:
        
        print('Problem bei Kombination von ts-Daten')
        # TODO 2019-8-9: in spaeterem Iterationsschritt: pruefen, ob es Daten
        # mit haeufigen Wiederholungen desselben Wertes gibt und andere, die
        # ok sind, dann die iOL von den ok-ZRn auf die defekten anwenden
        # TODO 2019-8-9: obiges falsch, TODO ist, lieber richtig mit Zeiten
        # machen (so wie SB+AK), d.h. anhand der ID-Nr. im filenamen die
        # Zeitpunkte festzulegen und anhand dieser zu kombinieren!!!
        try:
            iBest = mode(list_ol)
            channels_check = [k for k, s in dict_ol if s==iBest]
            dict_res = {k:v for k,v in dict_res if not(k in channels_check)}
        except:
            channels_check = dict_res.keys()
            dict_res = {}

            
    return(dict_res, channels_check)

