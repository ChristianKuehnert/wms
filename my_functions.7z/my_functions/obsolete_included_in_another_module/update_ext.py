# -*- coding: utf-8 -*-
"""
function to update cdef data


Created on Thu Apr 25 02:02:49 2019

@author: Christian Kuehnert, 2019-2-6
"""

from data import class_hd5Nodes as sNodes
from data import update_hd5fromDB

def update_ext(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.externals
    sTable = 'ba_cycle_externals'
    sHeadersKey = ['create_time']
    dictTypes=None
    
    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)

    #return(dfData)
           
    