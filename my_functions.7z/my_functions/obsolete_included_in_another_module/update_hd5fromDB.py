# -*- coding: utf-8 -*-
"""

function to update data in hd5-file directly from database
@author: Christian Kuehnert

2019-6-17

"""

import os
import pandas as pd

from . import fullfile
from . import initialize_hd5file
from . import get_data_fromDB
from . import setdifference_df
from . import append_to_hd5Table
#from . import fullfile, initialize_hd5file, get_data_fromDB, setdifference_df, append_to_hd5Table
#import fullfile
#import initialize_hd5file
#import get_data_fromDB
#import setdifference_df
#import append_to_hd5Table


def update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=None, time_start=None, time_end=None, iLimit=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
       
    if not os.path.isfile(sFN_hd5):               # if no such hd5-file exists      
        initialize_hd5file(sDB, sPathData)        # create it hd5-file

    bHD5Data = False
    with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

        if sNode in f:
        
            dfData = f[sNode]
        
            if not isinstance(dfData, pd.DataFrame):
                f.remove(sNode)
            else:
                bHD5Data = True
                                
            
        dfData_sql = get_data_fromDB(sDB, sTable, dictTypes=dictTypes, listCols=None, time_start=time_start, time_end=time_start)
        if dfData_sql.shape[0]>0:
            if bHD5Data:
                dfAppend = setdifference_df(dfData_sql, dfData, sHeadersKey).reset_index(drop=True)
                
                if dfAppend.shape[0]>0:
                    # try to append the newly queried data, if that is not possible, combine the data outside, remove the original node and put it then newly
                    try:            
                        f.append(sNode, dfAppend, index=False)
                    except:                        
                        dfAppend = dfData_sql.reset_index(drop=True)
                        f.remove(sNode)
                        
            else:
                dfAppend = dfData_sql.reset_index(drop=True)
            
            append_to_hd5Table(f, sNode, dfAppend, sHeadersKey)

        f.close()                                                
    
   
