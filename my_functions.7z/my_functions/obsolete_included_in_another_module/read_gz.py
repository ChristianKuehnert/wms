# -*- coding: utf-8 -*-
"""
function to read in the ts-data from the gz-files
 
Created on Wed Mar 27 10:10:52 2019

@author: Christian Kuehnert
@modified: 2018-10-23

"""
import pandas as pd
import numpy as np

def read_gz(sFN, tType = np.int32):
    dRes = pd.read_csv(sFN, compression='gzip', header=None, sep=';', quotechar='"', 
                       index_col=False, usecols=[0], squeeze = True, dtype=tType)
    return dRes

