# -*- coding: utf-8 -*-
"""

 function to combine the ts-data from the single gz-files for one channel into 
 one time series
 search for overlapping parts of the time series and combine there, if no such parts are found than 
 just append the time series from the single files
 if the series have different lengths then return error message

 input:
       - listTS:           list of series of integers (i.e. time series of the sensors)
       - iCntMeasBase:     integer, base lenght of measurement

 output:


Created on Wed Mar 27 10:15:25 2019

@author:  Christian Kuehnert
@modified: 2018-11-1
"""

import numpy as np
import pandas as pd
import math


def combine_ts(listTS, iCntMeasBase):                     
    
    # TODO 2018-11-1: Fall abfangen, dass eine Sensorstrecke (streckenweise) konstant ist, dann vielleicht an den iOLs der 
    # anderen Sensoren orientieren
    # am besten aber vielleicht doch alle Teilabschnitte EINZELN abspeichern und dann nur mit gemeinsamen gruppenindizes versehen, 
    # die im fail-Fall = None oder so sind
    
    
    iTS = []
    lOL = []                                # list of numbers of overlapping values
    #bOk = False
#    lMsg = []
    
    ## test if all parts have the same length that must be integer multiple of measurement length
    # TODO 2018-10-30: die ZRn liessen sich wohl auch dann zuammenfuegen, wenn diese Tests entfallen wuerden, ggf. muesste
    # man dafuer noch testen, ob die verwendeten Indizes nicht die Anzahl der Werte uebersteigen
    iN = [len(iV) for iV in listTS]
    if (len(np.unique(iN))==1) & all([iNn % iCntMeasBase == 0 for iNn in iN]):

        ## first try simple approach: assume 50% overlap of subsequent sub-ts, if this is not correct than do full search        
        iL = iN[0]
        iOL = int(iL/2)            
        bOk = True
        i = 0
        while bOk & (i<len(listTS)-1):
            #iDiff=np.asarray(listTS[i][iOL:iL])-np.asarray(listTS[i+1][0:iOL])
            iDiff=listTS[i][iOL:iL].values-listTS[i+1][0:iOL].values
            bOk = bOk & all(iDiff==0)
            i=i+1
        
        
        if bOk:                                                         # if overlap is 50% ...
            #iTS = pd.concat(listTS[0::2], ignore_index = True)          #   ... combine every second element
            if (len(listTS) % 2 ==0):                                   # if number of ts in list is not odd ...
                listTS.append(listTS[-1][iOL:iL])                       #    ... add last part of the last ts in the list
#                lMsg.append('info: even number of ts parts')
              
            iTS = pd.concat(listTS[0::2], ignore_index = True)
            #iTS = np.concatenate(listTS[0::2])          #   ... take only every second element in the list
          
              
        else:                                                           # otherwise - here comes the cavalry:
            
            iTS = listTS[0]
            i=1
            lOL = []                                                    # list of overlap-lengths
            while (i<len(listTS)):
                                                    
                iNext = listTS[i]
                iNext.index = range(len(iNext))
                # find all positions of last element of iTS in iNext
                listPos = iNext[iNext == iTS.iloc[-1]].index                
                listPos = [i for i in listPos if math.gcd(i+1, 8192) > 100]       # keep only those positions where overlap is at least 100ms
                #listPos = [i for i in range(len(iNext)) if iNext[i]==iTS[-1]]
                
                if len(listPos)>0:

                    ## now test for all positions if remaining elements in iTS agree with elements in iNext
                    bOk2 = False
                    iIdx = len(listPos)-1
                    while (not bOk2) & (iIdx >=0):
                                   
                        iOL = listPos[iIdx] + 1                                 # position where overlap starts (= overlap length)
                        #iDiff = np.asarray(iTS[len(iTS)-iOL:]) - np.asarray(iNext[0:iOL]) # calculate differences of overlap region
                        iDiff = iTS[len(iTS)-iOL:].values - iNext[0:iOL].values # calculate differences of overlap region
                        bOk2 = all(iDiff == 0)                                  # check if all are 0
                        iIdx = iIdx - 1                                         # set index of next position
                
                    ## if such a position is found, cut the value in listTS[i+1] until this point and append it to the iTS
                    if (not bOk2):                                              # if no overlap was found ...
                        iOL = 0                                               #   ... set it to 0 (appending the ts parts without overlap)
                                            
                else:
                    iOL = 0
                
                ## now combine parts up to here and append to lists                
                iTS = pd.concat((iTS, iNext[iOL:]), ignore_index = True)
                #iTS = np.concatenate((iTS, iNext[iOL:]))
                iTS.index = range(len(iTS))
                
                lOL.append(iOL)
                    
                i = i+1                                                         # next part of the ts
            
            ## assume that sth. is incorrect if not all overlap lengths are the same
            ## one could also return the combination, but only give a warning!
            # TODO 2018-10-30: nochmal ueberlegen, ob diese Variante die beste Loesung ist            
            if (len(np.unique(lOL))>1):
#                lMsg.append('overlap lengths not unique')                
                iTS = []
                iOL = []
            else:
                iOL = lOL[0]
                                                            
    #return iTS, lOL, ', '.join(lMsg)
    return iTS, iOL

