# -*- coding: utf-8 -*-
"""
function to update data in table 'ba_cycle_status'

@author: Christian Kuehnert, 2019-2-6
"""
from data import class_hd5Nodes as sNodes
from data import update_hd5fromDB
#import class_hd5Nodes as sNodes
#import update_hd5fromDB

def update_status(sDB, sPathData, time_start=None, time_end=None):
    
    sNode = sNodes.cycle_status
    sTable = 'ba_cycle_status'
    #dictTypes={'ID': int, 'appendix': str}
    sHeadersKey = ['create_time', 'ID']
    dictTypes={'ID': int}
    iLimit = 500000

    #dfData = update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end)
    update_hd5fromDB(sDB, sPathData, sTable, sNode, sHeadersKey, dictTypes=dictTypes, time_start=time_start, time_end=time_end, iLimit=iLimit)

    #return(dfData)
 
