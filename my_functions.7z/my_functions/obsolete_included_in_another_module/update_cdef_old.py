# -*- coding: utf-8 -*-
"""
function to update cdef data

@author: Christian Kuehnert, 2018-12-4

TODO 2018-10-19: bei HDFStore ist das Problem, dass die files immer groesser werden, selbst wenn ein node geloescht wird 
(da der Speicherplatz dabei nicht freigegeben wird) -> dieses Problem noch loesen! Trotzdem erstmal so gemacht, um  erstmal
zu starten -> vielleicht spaeter mit Patricks tools sowieso obsolet/geloest
"""

import os
import pandas as pd

from data import fullfile
from data import whereClause_from_timeInterval
from data import setdifference_df
from data import initialize_hd5file
from data import query_tableData



#def update_cdef(sDB, sPathData, listTimeIntervals=[-np.Infinity, np.Infinity]):
def update_cdef_old(sDB, sPathData, time_start=None, time_end=None):

    sFN_hd5 = fullfile([sPathData, sDB + '.hd5'])
    
    sHeadersKey = ['create_time', 'ID']
    
    sNode = 'raw_data/cdef'
    
    # if no such hd5-file exists
    if not os.path.isfile(sFN_hd5):                        
        initialize_hd5file(sDB, sPathData)        # create it hd5-file


    # retrieve all cdef-data in the given time interval
    sWC = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = '%Y%m%d%H%M%S')
    #sWC = ''

        
    dfCDEF_sql, sMsg = query_tableData(sDB, 'ba_cycle_measurement_cycle', sWC)    
                                        
    #dfCDEF_sql['create_time'] = pd.to_datetime(dfCDEF_sql['create_time'], errors='coerce')
    dfCDEF_sql['ID'] = dfCDEF_sql['ID'].astype(int)    

    # if there are any data then append them to cdef data already in hd5 file
    if dfCDEF_sql.shape[0] > 0:
        
        #with h5py.File(sFN_hd5, 'a') as f:
        with pd.HDFStore(sFN_hd5, mode='a', complevel=9, complib='blosc:lz4') as f:

            #if ('/' + sNode in f.keys()):
            if sNode in f:
                
                dfCDEF = f[sNode]
                #if dfCDEF:
                
                if isinstance(dfCDEF, pd.DataFrame):
                                        
                    # add new cdef-data to current cdef-data  
                    # TODO 2018-10-17: evtl. schneller machen - nicht erst alles auslesen sondern gleich nur die, die fuer die Auswahl
                    # der neu hinzukommenden gebraucht werden                    
                    #dfCDEF = dfCDEF.set_index(sHeadersKey, drop=False)                    
                    #dfCDEF_sql = dfCDEF_sql.set_index(sHeadersKey, drop=False)
                    #dfAdd = dfCDEF_sql.loc[dfCDEF_sql.index.difference(dfCDEF.index)]                    
                    dfAdd = setdifference_df(dfCDEF_sql, dfCDEF, sHeadersKey)
 
                    # der Zweig unter bNew funtioniert nicht richtig, deshalb der etwas (beim Ausfuehren) aufwaendigere
                    # andere Zweig aktiviert
                    bNew = False
                    if bNew:                        
                        # TODO 2018-10-17: ggf. noch sortieren
                        f.append(sNode, dfAdd.reset_index(drop=True), index=False)
                    else:
                        if dfAdd.shape[0] > 0:
                            dfComb = pd.concat((dfCDEF, dfAdd), axis=0, ignore_index=True)
                            # TODO 2018-11-2: noch eleganter machen, ist eigentlich unnoetig wenn dfAdd=0 ist, ggf. reicht auch reset innerhalb der .hd5-Datei                            
                            f.remove(sNode)
                            f.put(sNode, dfComb.reset_index(drop=True), format='table', append=True, data_columns=True, index=False)                        
                            #f.put(sNode, dfComb, format='table', append=True, data_columns=True)    
                        #else:
                        #    dfComb = dfCDEF

                else:
                    dfAdd = dfCDEF_sql.reset_index(drop=True)
                    f.remove(sNode)
                    f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
                                
            else:
                dfAdd = dfCDEF_sql.reset_index(drop=True)
                f.put(sNode, dfAdd, format='table', append=True, data_columns=True, index=False)
                
            f.close()                                                
    
    else:       
        dfAdd = pd.DataFrame()

    return(dfAdd)
           


