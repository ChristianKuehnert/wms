# -*- coding: utf-8 -*-
"""
Created on Tue Aug  6 12:57:09 2019

special query von SW vom 2019-8-5 (s. mail vom selben Tag)



@author: w012028
@modified: 2019-8-6
"""

import sys

sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian\wms\dbs'
#sModulePath = r'C:\Repositories\python\functions'
sys.path.append(sModulePath)    

from class_turbine import turbine as cls_tb

#tb = cls_tb.from_db('cmrblba_bc_t_01812')
#print(vars(tb))

tb = cls_tb.from_farm_and_name('Borkum West II', 'Adwen BW42')
print(vars(tb))


