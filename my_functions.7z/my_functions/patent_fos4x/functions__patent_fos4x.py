# -*- coding: utf-8 -*-
"""

functions for modelling the prediction of cmi according to patent application
of fos4x


Created on Sun Jun 7 2020

@author: Christian Kuehnert
"""

import sys
import pandas as pd
import numpy as np
#from copy import deepcopy
from datetime import datetime as dt
from datetime import timedelta
#from sklearn.model_selection import KFold
from sklearn.preprocessing import PolynomialFeatures
from sklearn import linear_model
import matplotlib.gridspec as gs


from os import listdir


sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions')        # path to modules
from data import filter_data
from data.myprint import myprint
#from data import get_data_from_db
from data.update_hd5 import update_cdef, update_sda
from data.class_hd5Nodes import hd5Nodes as nodes

#sys.path.append(r'M:/03-Projekte/Eis-Algorithmus-Eispeakeinstellung/500_Arbeitsunterlagen/Transfer_CK/Repositories/python/my_functions')
from plot.myFunctions_plot import myplot_fast2

sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian')        # path to modules
from wms.dbs import weadbs


sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_MarkusGeiger')        # path to modules  
#sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions_lastWorkingVersion_20190806')  # temporary path to modules as long as new functions are not yet implemented completely
#from my_abfrage_class import sqlModul, select_period, data_to_pkl, load_data
from my_abfrage_class import load_data





class fos4x():
    
    
    t_ref = dt(1970,1,1)
    
    
    
    
    def __init__(self, db, features = ['create_time_epoch'], target = 'actual_avg_freq',
                 list_checks = [(1,1), (2,2), (4,4)],
                 lower_thres = 30, upper_thres = 100,
                 path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuerz20200528'):
    
        self.db = db
        self.features = features
        self.target = target
        
        self.model = PolynomialFeatures(degree=1)
        self.reg = linear_model.LinearRegression()
            
        self.list_checks = list_checks
        self.lower_thres = lower_thres
        self.upper_thres = upper_thres
        
        self.legend_str = ''
    
        self.path = path
        self.df =  load_data("mysql", self.db, self.path, save_in_cases = True)
        self.df.reset_index(drop=False, inplace=True)
        self.df['create_time'] = pd.to_datetime(self.df['create_time'], errors='coerce')
        tmp = self.df.create_time - self.t_ref
        self.df = self.df.assign(create_time_epoch = tmp.apply(lambda x: x.total_seconds()/3600/24))

        #self.df = self.df.assign(create_time_epoch = self.df.loc[:, 'create_time'].values.astype(np.int64) / 10**9)
        #self.df = self.df.loc[:, self.features + [self.target]]






    def score(self, df):
        X = self.model.fit_transform(df.loc[:, self.features])
        y = df.loc[:, self.target]
        return(self.reg.score(X, y))


    def scores(self):
        if self.__scores == []:
            print("Noch keine Scores berechnet. Methode cross_val ausführen.")
            # return self.scores
        else:
            self.display_scores(pd.Series(self.__scores))


    def get_power_ratio(self, df):
        try:
            return ((df[self.target] / self.pred(df)) * 100)
        except:
            print("Modell noch nicht gefitted. fit-Methode aufrufen.")



    """
    function to train the model for the given period
    
    @modified: 2020-6-7
    """    
    def fit(self, period=None):
        
        if period is None:            
            X = self.model.fit_transform(self.df[self.features])
            y = self.raw_df[self.target]
            
        else:
            df = self.df.copy()
            if not(period[0] is None):
                df = df[df.create_time >= period[0]]
                
            if not(period[1] is None):
                df = df[df.create_time <= period[1]]
                
            X = self.model.fit_transform(df.loc[:, self.features])
            y = df[self.target]

        self.reg.fit(X, y)
        return(self.reg.score(X, y))

    
    
    
    
    def fit_delta(self, t0, delta_t):
        pass
    
    
    
    """
    function to load the data in the given period
    
    @modified: 2020-6-7
    """
    def load_data(self, period=None):
        pass


    
    
    """
    function to predict the value for datetime argument
    @modified: 2020-6-11
    """
    def predict_dt(self, time):
                
        tmp = time - self.t_ref
        val = self.predict(np.array(tmp.total_seconds() / 3600 / 24).reshape(1,-1))

        return(val[0])
        
    
    
    
    """
    function to predict the value for the given period
    @modified: 2020-6-7
    """
    def predict_delta(self, time, delta_train=4, delta_pred=4):
        
        #df = self.df.copy()
        # fit model with data from training period
        self.fit((time - timedelta(hours=delta_train), time))
        
        tmp = time - self.t_ref + timedelta(hours = delta_pred)
        val = self.predict(np.array(tmp.total_seconds() / 3600 / 24).reshape(1,-1))
        
        #val = self.predict(np.array(tmp.astype(np.int64) / 10**9))

        return(val[0])
        
         
        
        
    """
    function to predict the values for all periods
    @modified: 2020-6-29
    """
    def predict_all_periods(self, time):
        res = list()
        for (delta_train, delta_pred) in self.list_checks:
            res.append(self.predict_delta(time, 
                                          delta_train = delta_train, 
                                          delta_pred = delta_pred))
        
        return(tuple(res))
        
        
        
        
        
    """
    function to test if predicted value over/undergoes threshold 
    @modified: 2020-6-7
    """
    def check_values(self, time):
        
        list_lower = list()
        list_upper = list()
        for (delta_train, delta_pred) in self.list_checks:
            
            val = self.predict_delta(time, delta_train = delta_train, 
                                     delta_pred = delta_pred)
            
            list_lower.append(val < self.lower_thres)
            if (val < self.lower_thres):
                print('untere Schwelle unterschritten in {delta_pred} h')
                #list_lower.append()
            
            list_upper.append(val > self.upper_thres)
            if (val > self.upper_thres):
                print('obere Schwelle unterschritten in {delta_pred} h')
            
        return({'lower': list_lower, 'upper': list_upper})

    
    
    
    
    
    """
    function to predict the value after a certain 
        - se data from database
    
    both types of data will be stored in an hd5-file of "my structure type", 
    i.e. dfcdef as normal dataframe, se with one table for start/stop values and
    one with the actual data
    
    2020-3-11
    """
    
    def predict(self, data):
        tmp = self.model.fit_transform(data)
        return self.reg.predict(tmp)
    
    
    
    """
    function to plot the data like in patent application
    @modified: 2020-6-9
    """
    def plot_example(self, time):
        
        # factor for 'margin' of plot
        factor = 1.05
        
        # add elements for raw data to plotlist
        max_train = max([x[0] for x in self.list_checks])
        max_pred = max([x[1] for x in self.list_checks])
        
        plot_start = time - timedelta(hours = factor * max_train)
        #plot_end = time + timedelta(hours = factor * max_pred)
        
        df_tmp = self.df[(self.df.create_time >= plot_start) & \
                         (self.df.create_time <= time)]
        list_plots = [(df_tmp.create_time, df_tmp.loc[:, self.target], 
                       {'ls': '-', 'color': 'black'})]
        

        ## last datetime
        idx0 = df_tmp.create_time.idxmax()
        time0 = df_tmp.loc[idx0, 'create_time']
        epoch0 = df_tmp.loc[idx0, self.features]
        legend = ['meas']

        colors = ['red', 'blue', 'green']
        i=0        
        for (delta_train, delta_pred) in self.list_checks:

            # fit model with training period
            self.fit((time - timedelta(hours=delta_train), time))

            # add regression line to plotlist
            idx1 = df_tmp[df_tmp.create_time >= time-timedelta(hours=delta_train)].create_time.idxmin()
            time1 = df_tmp.loc[idx1, 'create_time']
            epoch1 = df_tmp.loc[idx1, self.features]
            pred1 = self.predict(np.array(epoch1).reshape(1,-1))
            pred0 = self.predict(np.array(epoch0).reshape(1,-1))
            list_plots.append(([time1, time0], 
                                [pred1, pred0], {'ls': '-.', 'color': colors[i]}))            
            legend.append(f'training {delta_train} h')
            
            # add line to predicted value to plotlist
            time2 = time + timedelta(hours=delta_pred)
            pred2 = self.predict_dt(time2)
            
            list_plots.append(([time0, time2], 
                                [pred0, pred2], {'ls': '--', 'color': colors[i]}))
            legend.append(f'prediction {delta_pred} h')

            i += 1
            
            
        s_title = f'{self.db}, Vorhersage fuer {time}'
        myplot_fast2(list_plots,  
                     legend = legend, s_title = s_title,
                     figsize = (9,6))
        
    
    
    
    

    """
    function to plot the data like in patent application
    @modified: 2020-6-9
    """
    def plot_period(self, period, plots = ['high', 'low', 'sum']):
        
        # get data for this period
        df_tmp = self.df[(self.df.create_time >= period[0]) & \
                         (self.df.create_time <= period[1])]

        # predict for each time the value for all three time periods
        res = list()
        for _i, row in df_tmp.iterrows():
            myprint(f'{len(res)}/{df_tmp.shape[0]}')
            time = row['create_time']
            meas = row[self.target]
            pred = self.predict_all_periods(time)
            high = list(map(int, [x >= self.upper_thres for x in pred]))
            low = list(map(int, [x <= self.lower_thres for x in pred]))
            high[0] = high[0]
            high[1] = high[1]+0.01
            high[2] = high[2]+0.02
            high = tuple(high)
            low[0] = -low[0]
            low[1] = -low[1]-0.01
            low[2] = -low[2]-0.02
            low = tuple(low)
            res.append(tuple([time,meas]) + high + low + tuple([sum(high), sum(low)]))
            
        df = pd.DataFrame.from_records(res, columns = ['create_time', 'meas', 'h1', 'h2', 'h3', 'l1', 'l2', 'l3', 'sum_high', 'sum_low'])
        
        
        # factor for 'margin' of plot
        #factor = 1.05
        
        # add elements for raw data to plotlist        
        if len(plots)>0:
            meas = df.meas.div(df.meas.abs().max())
            legend = ['cmi normiert'] + [f'train {x[0]} h, pred. {x[1]} h' for x in self.list_checks]

        if 'high' in plots:        
            list_plots = [(df.create_time, meas, {'color': 'black'}), 
                          (df.create_time, df.h1, {'ls': '-', 'color': 'orange'}),
                          (df.create_time, df.h2, {'ls': '-', 'color': 'red'}),
                          (df.create_time, df.h3, {'ls': '-', 'color': 'brown'})]
            #legend = ['cmi normiert', 'period 1', 'period 2', 'period 3']
            s_title = f'{self.db}, Vorhersage {period[0]}-{period[1]} high'
            myplot_fast2(list_plots,  
                         legend = legend, s_title = s_title,
                         figsize = (9,6), xticksrot = 70)
        
        if 'low' in plots:
            list_plots = [(df.create_time, meas, {'color': 'black'}), 
                          (df.create_time, df.l1, {'ls': '-', 'color': 'orange'}),
                          (df.create_time, df.l2, {'ls': '-', 'color': 'red'}),
                          (df.create_time, df.l3, {'ls': '-', 'color': 'brown'})]
            #legend = ['cmi normiert', 'period 1', 'period 2', 'period 3']        
            s_title = f'{self.db}, Vorhersage {period[0]}-{period[1]} low'
            myplot_fast2(list_plots,
                         legend = legend, s_title = s_title,
                         figsize = (9,6), xticksrot = 70)

        if 'sum' in plots:
            list_plots = [(df.create_time, meas, {'color': 'black'}), 
                          (df.create_time, df.sum_high, {'ls': '-', 'color': 'orange'}),
                          (df.create_time, df.sum_low, {'ls': '-', 'color': 'brown'})]
            legend = ['cmi normiert', 'high', 'low']        
            s_title = f'{self.db}, Vorhersage {period[0]}-{period[1]}'
            myplot_fast2(list_plots,
                         legend = legend, s_title = s_title,
                         figsize = (9,6), xticksrot = 70)
    
        return(df)
    
    
## Bsp.-Anwendung:
#path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\specialQuery\specialQuerz20200528'
#
## db name of Stor-Rotliden    
#db = 'cmrblba_vst_str_001'
#
## create class
#clf4x = fos4x(db)
#
## load data for give period
#period = (dt(2019,6,1), dt(2020,6,1))
##cls4x.load_data(period)
##
### plot curves like in patent application for a given date
#dt_example = dt(2020,4,7,12,0,0)
#clf4x.plot_example(dt_example)
##
### predict values for the single times within period
##cls4x.predict()
##
### plot period with prediction
#df = clf4x.plot_period((dt(2019,11,1), dt(2020,3,1)))
#fn = f'{path}\\{db}__high_low.csv'
#df.to_csv(fn)




