# -*- coding: utf-8 -*-
"""

functions for criteria development for crack in blade trailing edge


Created on Wed Mar  4 02:58:52 2020

@author: christian_2
"""
import sys
import pandas as pd
import numpy as np
#from copy import deepcopy
from datetime import datetime as dt
from datetime import timedelta
#from sklearn.model_selection import KFold
#from sklearn.preprocessing import PolynomialFeatures
#from sklearn import linear_model
import matplotlib.gridspec as gs


from os import listdir

from data import filter_data
#from data import get_data_from_db
from data.update_hd5 import update_cdef, update_sda
from data.class_hd5Nodes import hd5Nodes as nodes

#sys.path.append(r'M:/03-Projekte/Eis-Algorithmus-Eispeakeinstellung/500_Arbeitsunterlagen/Transfer_CK/Repositories/python/my_functions')
from plot.myFunctions_plot import myplot_fast2

sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian')        # path to modules
from wms.dbs import weadbs



"""
function to collect the data:
    - cdef data from database
    - se data from database

both types of data will be stored in an hd5-file of "my structure type", 
i.e. dfcdef as normal dataframe, se with one table for start/stop values and
one with the actual data

2020-3-11
"""
def collect_data(db, path_hd5, start_time = None, end_time = None, types=['se']):

#     now load all data and write start and end times and numbers 
#     TODO 2020-3-11: create intuitive picture that displays data 
#     availability, combined with ticket times            
    
    if (end_time is None):
        end_time = dt.now()
        
    if (start_time is None):
        start_time = end_time - timedelta(months = 6)
                       
        
    if 'se' in types:
        print('updating se')
        try:
            tmp = end_time + timedelta(days=1)
            cls_sed = weadbs.SEData.from_db(db, where = {'create_time': 
                (start_time.strftime('%Y-%m-%d'), 
                 tmp.strftime('%Y-%m-%d'))}, 
                hdfpath = f'{path_hd5}\\{db}_sed.hd5')
       
        except:
            print(f'problem with updating se data for {db}')
 
         
    try:
        ## for one wtg:
        update_cdef(db, path_hd5, time_start=start_time, time_end=end_time)
    except:
        print(f'problem with updating cdef data for {db}')
        
        
    if 'sda' in types:
        print('updating sda')
        try:
            update_sda(db, path_hd5, time_start=start_time, 
                              time_end=end_time, bSloppy=True)
        
        except:
            print(f'problem with updating sda data for {db}')

        

    ## TODO 2019-10-24: noch konsistent machen mit Funktionen, so dass der
    ## filename zum verwendeten File sicher passt, ist aber sehr nachrangig        
    return(f'{path_hd5}\\{db}.hd5')




"""
function to describe the data within the given period

TODO 2020-3-12: noch bessere Anzeige machen, Verfuegbarkeiten gut graphisch darstellen

@modified: 2020-3-12
"""
def describe_data(db, fn_hd5, node, columns = None, 
                  period = (None, None), bshow = True):
   
    with pd.HDFStore(fn_hd5, mode='a') as fh:
        df = fh.select(node)
            
    if not(columns is None):
        cols = set(columns).intersection(df.columns)
        df = df.loc[:, cols]
        
    if not((period[0] is None) and (period[1] is None)):
        
        lok = []
        if ('create_time' in df.columns):
            if not(period[0] is None):
                lok.append(df.create_time >= period[0])
                
            if not(period[1] is None):
                lok.append(df.create_time <= period[1])
                
            if len(lok) > 1:
                bok = [lok[0][i] & lok[1][i] for i in range(lok[0])]
            
            else:
                bok = lok
                
            df = df[bok]
            
        else:
            print(f'data table not contains column create_time (or is of '
                  'other type than period), cannot select period, '
                  'use all data')
                
    df_desc = df.describe()
    
    if bshow:
        print(df_desc)
        
    return(df_desc, df)


# --> vmtl. schon vorhanden (aerodyn imbalance?)




### function to filter data: mfdata.filter_data



"""
function to add datetime-values to a period-tuple if 1 or 2 of its elements
are None

@modified: 2020-3-4
"""
def complete_period(period, start_time = dt(1970,1,1), end_time = dt.now()):
    if period[0] is None:
        period[0] = start_time
    
    if period[1] is None:
        period[1] = end_time

    return(period)






"""
id-function

"""
def f_id(df):
    return(df)





"""
function that returns all files of the my-hd5-file-type with data within the 
given period    

@modified: 2020-3-4
"""
def get_files_in_period(db, period, path):
    # select all files that fit the period
    tmp = [fn for fn in listdir(path) if (fn.find(db)>-1)]
    
    period = complete_period(period)
        
    files = list()
    for fn in tmp:
        tmp = fn.replace(db, '').replace('_se_', '').replace('.hd5', '').split('_')        
        if (dt.strptime(tmp[1], '%Y%m')>=period[0]) and \
            (dt.strptime(tmp[0], '%Y%m') <= period[1]):
            
            files.append(fn)
    
    return(files)
    
    
    



"""
function to aggregate the signal energy in the given band (tuple)

this function is taken from Sebastian's wms.dbs.weadbs.SED-class and
slightly modified

@modified: 2020-3-6
"""
def fct_agg(df, fbands, aggfun = f_id):
    
#    @staticmethod
#    def _freq_agger(specs, fbands, aggfun, *agg_args, **agg_kws):
#        """Does the actual work for frequency aggregation.
#
#        as staticmethod to keep this close to the callers from_specs and
#        agg_freq
#        """
    freqs = df.columns.get_level_values(1)

    # prevents issues with partially overlapping intervals: if there is an
    # interval in freqs which is partially overlapping with an interval in
    # fbands and partially overlapping with the following interval in
    # fbands, then pd.cut will return two entries for the interval in freqs
    # but this will produce an error down the line as the shapes don't
    # match anymore
    if isinstance(freqs, pd.IntervalIndex):
        freqs = freqs.mid

        if pd.api.types.is_scalar(fbands):
            fbands = np.linspace(freqs.min(), freqs.max(), fbands)
        if not isinstance(fbands, pd.IntervalIndex):
            fbands = pd.IntervalIndex.from_breaks(
                    fbands, closed='left', name='freq')

        # Creates flat grouping index based on channel x freq index.
        # I didn't find another, pandas built-in way to handle index tuples
        # with freq==nan in the groupby. This happens when the requested
        # frequency bands don't cover all frequencies. For a flat index with
        # nan-values this was no problem, but pandas couldn't handle index
        # items like ('101_edge', nan) during aggregation within groups.
        ind = pd.MultiIndex.from_arrays(
                [df.columns.get_level_values(0),
                 pd.cut(freqs, fbands)])

        cols = {}
        vals = np.zeros(ind.size, dtype=float)
        newval = 0
        for i, (ch, f) in enumerate(ind):
            if pd.isna(f):
                vals[i] = np.nan
            else:
                if (ch, f) in cols:
                    vals[i] = cols[(ch, f)]
                else:
                    vals[i] = newval
                    cols[(ch, f)] = newval
                    newval += 1

        cols = {val: key for key, val in cols.items()}

        grp = df.groupby(vals, axis=1)

        #se = grp.agg(aggfun, *agg_args, **agg_kws)
        se = grp.agg(aggfun)

        # set aggregated values to NaN where only NaNs were input - this is
        # only for aggregation with 'sum', because this will by default return
        # 0 for data only containing NaNs; in principle you should also be able
        # to pass skipna=False as kwarg to get the same result, but this did
        # not work at the time of writing, because of a bug in pandas
        # (https://github.com/pandas-dev/pandas/issues/29481)
        if aggfun == 'sum':
            se.where(grp.count() > 0, inplace=True)

        se.columns = pd.MultiIndex.from_tuples(
                [cols[val] for val in se.columns],
                names=['channel', 'freq'])

        return se




"""
function to load the data for the given period from my own hd5 storage type

parameters:
-----------
    - db:       string, database of turbine
    - period:   tuple (start-time, end-time), desired period
    - filters:  dict {column name: (min, max)}, filters for the cdef data, min
                or max values can be None which means no filter
    - tup_fct:  tuple (function (function), kwargs (dictionary)), function to
                be applied to the signal energy
    - path_hd5: string, path to (my) hd5-file containing the data


@modified: 2020-3-22, noch nicht fertig
"""
def load_data_myHD5(db, cols_cdef = ['create_time', 'ID', 'temperature_mean',
                                     'wind_mean', 'pitch_mean', 'omega_mean',
                                     'power_mean'], 
                            period = (None, None), filters = None, 
                            tup_fct = None, 
        path_hd5=r'C:\Users\w012028\Documents\CK\data\crack_trailing_edge'):
   
     
    tmp = list()
    if not(period[0] is None):
        stmp = period[0].strftime('%Y%m%d%H%M%S')
        tmp.append(f"create_time>='{stmp}'")
        
    if not(period[1] is None):
        stmp = period[1].strftime('%Y%m%d%H%M%S')
        tmp.append(f"create_time<='{stmp}'")
        
    if len(tmp)>0:
        where_clause = '(' + ') and ('.join(tmp) + ')'
    else:
        where_clause = None

    fn = f'{db}.hd5'

    
    # load cdef data for the period from pickle-file
    #df_cdef = get_data_from_db(db, 'ba_cycle_measurement_cycle', 
    #                                      where_clause=where_clause)
    try:
        with pd.HDFStore(f'{path_hd5}\\{fn}', mode = 'a') as fh:
            df_cdef = fh.select(key=nodes.cdef, where = where_clause)
    
        df_cdef.set_index('create_time', inplace=True)
        if not(cols_cdef is None):
            df_cdef = df_cdef.loc[:, cols_cdef]
    
        df_cdef, sfilters = filter_data(df_cdef.drop_duplicates().dropna(how='all', 
                                    axis=1).dropna(how='all', axis=0), filters)
    
    except:
        df_cdef = pd.DataFrame(columns = cols_cdef)
        
        
    res = list()

    if df_cdef.empty:
        print('cdef-Daten konnten nicht aus Datenbank gelesen werden')
        
    else:    
        
        ## create multiindex columns for cdef part in order to avoid problems when
        ## merging
        df_cdef.columns=pd.MultiIndex.from_product([['cdef'], df_cdef.columns])
        
        if (tup_fct is None):            
            func = f_id
            kwargs = {}
        
        else:            
            func = tup_fct[0]
            kwargs = tup_fct[1]
                    
        ##load data
        try:
            pass
        # TODO 2020-3-22: hier weiter, sda-vektoren einzeln auslesen, function anwenden und 
        # dann am Ende Kombination mit cdef-DAten in .pkl-Datei speichern
            with pd.HDFStore(f'{path_hd5}\\{fn}', mode = 'a') as fh:
                df = fh.select(key='se', where = where_clause)
                
            df_comb = pd.concat([df_cdef, df], axis=1, join='inner')
                                
            ## apply function            
            res.append(func(df_comb, **kwargs))
                
        except:
            print(f'problem with file {fn}')
                
    return(np.vstack(res))
        
        




def load_se_band(path_main, db, sband):
    fn_pkl = f'{db}_se_{fbands[0]}_{fbands[1]}_20150101_20200312.pkl'
    df_se = pd.read_pickle(f'{path_main}\\{fn_pkl}')

    ## reset column names
    df_se.columns = df_se.columns.values
    df_se.reset_index(inplace=True)
    return(df_se)



"""
function to plot se(band) ~ production data variable in a plot array for all
bands (vertically) and production variables (horizontally)

@modified: 2020-3-27
"""
def plot_band_vs_cdef(path_main, db, bands, cdef, direction, filters = None,
                      period = (dt(2019,1,1), dt(2019,5,15))):

    line_type = 'o-'
    marker_size = 2
    line_width = 1    
    color = 'black'
    pagewidth = 20
    
    nx, ny = len(cdef), len(bands)

    fh = plt.figure(figsize = (pagewidth, ny*3))
    g = gs.GridSpec(nx, ny)

    fig, axs = plt.subplots((lenx, leny), sharex='col', sharey='row',
                                        gridspec_kw={'hspace': 5, 'wspace': 5})
            
#
#    if not(x_lim):
#        min_x = min([min(x[0]) for x in list_plot_data])
#        max_x = max([max(x[0]) for x in list_plot_data])
#        x_lim = [min_x, max_x]        

    #(ax1, ax2), (ax3, ax4) = axs
    fig.suptitle('se(band) ~ cdef var. for several bands and cdef variables')
#    ax1.plot(x, y)
#    ax2.plot(x, y**2, 'tab:orange')
#    ax3.plot(x + 1, -y, 'tab:green')
#    ax4.plot(x + 2, -y**2, 'tab:red')
    
    for ib, band in pd.Series(bands):
        
        df_se = load_se_band(path_main, db, band)
        
        df_se = df_se[(df_se.create_time <= period[0])]
        
        for iv, var in pd.Series(cdef).items():
            ax = plt.subplot(g[ib, iv])
            ax.plot(df_se.loc[:, var], df_se.loc[:, f'se_{band[0]}_{band[1]}'],
                    color=color, line_type=line_type, marker_size = marker_size)
            ax.set_xlabel(var)
            ax.set_ylabel(f'{band}')
    
#    
#    
#    axis = []
#    i=0            
#    for x, y, color, title, y_label in list_plot_data:
#        
#        ax = plt.subplot(g[i,0])
#        #lines = ax.plot(x, y, line_type, markersize=marker_size, linewidth=line_width)
#        ax.plot(x, y, line_type, color=color, markersize=marker_size, linewidth=line_width)
#        ax.set_title(title)
#        ax.set_xlim(x_lim)
#        ax.tick_params(axis='x',
#                       which='both',
#                       bottom=False,
#                       top=False,
#                       labelbottom=False)
#        ax.tick_params(axis='x', which='minor')
#        ax.grid(True)
#        axis.append(ax)
#        i += 1
#    
#    axis[-1].tick_params(axis='x', 
#                        which='both',
#                        bottom=True,
#                        labelbottom=True)
#    
#    hf.autofmt_xdate()
#
    plt.tight_layout()
#    
    if fn:
        plt.savefig(fn, dpi=350)
        plt.close(fh)
    else:
        plt.show()
#        
    
    
    
    
    
    
    
    
    
"""
function to plot edge and flap vs. the given list of cdef variables

@modified: 2020-5-26
"""
def plot_se_vs_cdef(df, features, 
                    colors_targets = {'flap3': {'color': 'lightgreen', 'ls': '-', 'marker': '.'},
                                      'edge3': {'color': 'green', 'ls': '-', 'marker': '.'}},
                    wdwsz = 1, 
                    figsize = (9.5,4), iFontSizeTitle = 16, bxticksrot = True):

    for feat in features:
        df2 = df.sort_values(by=feat)
        x = df2.loc[:, feat]
        plots = list()
        leg = list()
    
        for tar, pltopt in colors_targets.items():
            plots.append((x, df2.loc[:, tar].rolling(wdwsz).mean(), pltopt))
            leg.append(tar)
        
        xtr=0
        if bxticksrot:
            if ('time' in feat):
                xtr=30
        
        myplot_fast2(plots, 
                     figsize=(9.5,4), sXLabel = feat, sYLabel = ', '.join(leg),
                     legend=leg, iFontSizeTitle = 16, xticksrot=xtr)
    
    
    
    

        
"""
function that uses pitch angle as dummy variable

@modified:2020-3-30
"""
def create_pitch_dummy(df):
    pass

#
#   
#               'physical_model': fct__physical_model,
#               'poly_power_ord1': fct__poly_power_ord1,
#               'poly_power_ord2': fct__poly_power_ord2,
#               'poly_power_ord3': fct__poly_power_ord3,
#               'poly_ord1': fct__poly_power_ord1,
#               'poly_ord2': fct__poly_power_ord2,
#               'poly_ord3': fct__poly_power_ord3}    
    
    
    
    
    
    
    
    
    
    

"""
function to load the data from the "official" hd5 files

@modified: 2020-3-4
"""
def load_data_hd5(db, period, filters, fct):
    pass



    
    