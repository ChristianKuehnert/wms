# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 10:44:03 2019

@author: w012028
"""

    
"""
function to plot several diagrams synchronized on one page

list_plot_data: list of dictionaries of datas (and style parameters) to be plotted



@author: Christian Kuehnert
@last_modified: 2020-1-6


""" 
import matplotlib.pyplot as plt
import matplotlib.gridspec as gs
#def plot_multiple(file_name, list_plot_data, sTitle, x_label, x_lim=None):
def plot_multiple(list_plot_data, x_label, x_lim=None, y_lim = None,
                  bLegend = True, file_name = None):
    
    #line_type = 'o-'
    #marker_size = 2
    #line_width = 1
    
    #iFontSize = 18
    #iFontSizeTitle = 22
    #iAxisLabelSize = 16
    iLegendSize = 16

    
    #if not(color):
    #    color = 'black'
    
    #iN = len(list_plot_data)
    rows = [x[2] for x in list_plot_data]
    cols = [x[3] for x in list_plot_data]
        
    n_r = max(rows)+1      
    hf = plt.figure(figsize=(19, n_r*2.5))
    g = gs.GridSpec(n_r, max(cols)+1)

    if not(x_lim):
        #min_x = min([min(x[1][list(x[1].keys())[0]][0]) for x in list_plot_data])
        #max_x = max([max(x[1][list(x[1].keys())[0]][0]) for x in list_plot_data])
        lmin = []
        lmax = []
        for x in list_plot_data:
            tmp = x[1][list(x[1].keys())[0]][0]
            if tmp.shape[0]>0:
                lmin.append(min(tmp.values))
                lmax.append(max(tmp.values))                                
        
        x_lim = [min(lmin), max(lmax)]        
    
    
    axis = []
    #for x, y, color, title, y_label in list_plot_data:
    #for title, dict_data in list_plot_data:
    for title, dict_data, iy, ix in list_plot_data:
                        
        ax = plt.subplot(g[iy,ix])
        #lines = ax.plot(x, y, line_type, markersize=marker_size, linewidth=line_width)
          
        llegend = []
        #j = 0
        for key, var in dict_data.items():
            bTmp = False
            if len(var)>2:
                if not(var[2] is None):
                    bTmp = True
                    kwargs = var[2]
                
            if bTmp:
                ax.plot(var[0], var[1], **kwargs)
            else:
                ax.plot(var[0], var[1])

            llegend.append(key)
            #j += 1
              
        if bLegend:
            ax.legend(llegend, fontsize=iLegendSize, loc=2)
            
        #ax.plot(x, y, line_type, color=color, markersize=marker_size, linewidth=line_width)
        ax.set_title(title)

        ax.set_xlim(x_lim)
        if y_lim:            
            ax.set_ylim(y_lim)
            # all images are synchronized, so exclude y-ticks except for
            # leftmost diagrams
            ## TODO 2020-1-6: Achtung: funktioniert nur, wenn Diagramme auch
            ## bei 0 beginnen, fuer andere Faelle noch entsprechend erweitern!
            if (ix>0):
                ax.tick_params(axis='y',
                               which='both',
                               left=False,
                               right=False,
                               labelleft=False)
            

        
        if (iy<n_r):
            ax.tick_params(axis='x',
                           which='both',
                           bottom=False,
                           top=False,
                           labelbottom=False)
            #ax.tick_params(axis='x', which='minor')

        else:            
            ax.tick_params(axis='x', 
                           which='both',
                           bottom=True,
                           labelbottom=True)
            ax.set_xlabel(x_label)

            
    

        ax.grid(True)
        axis.append(ax)
    
    
    hf.autofmt_xdate()

    plt.tight_layout()
    
    if file_name:
        plt.savefig(file_name, dpi=150)
        plt.close(hf)
        
    else:
        plt.show()
    






### old version, 2020-1-6
#def plot_multiple(list_plot_data, x_label, x_lim=None, y_lim = None,
#                  bLegend = True, file_name = None):
#    
#    #line_type = 'o-'
#    #marker_size = 2
#    #line_width = 1
#    
#    iFontSize = 18
#    iFontSizeTitle = 22
#    iAxisLabelSize = 16
#    iLegendSize = 16
#
#    
#    #if not(color):
#    #    color = 'black'
#    
#    iN = len(list_plot_data)
#    
#    hf = plt.figure(figsize=(19, iN*2.5))
#    g = gs.GridSpec(iN,1)
#
#    if not(x_lim):
#        #min_x = min([min(x[1][list(x[1].keys())[0]][0]) for x in list_plot_data])
#        #max_x = max([max(x[1][list(x[1].keys())[0]][0]) for x in list_plot_data])
#
#        lmin = []
#        lmax = []
#        for x in list_plot_data:
#            tmp = x[1][list(x[1].keys())[0]][0]
#            if tmp.shape[0]>0:
#                lmin.append(min(tmp.values))
#                lmax.append(max(tmp.values))                                
#        
#        x_lim = [min(lmin), max(lmax)]        
#    
#    
#    axis = []
#    i=0            
#    #for x, y, color, title, y_label in list_plot_data:
#    #for title, dict_data in list_plot_data:
#    for title, dict_data in list_plot_data:
#                        
#        ax = plt.subplot(g[i,0])
#        #lines = ax.plot(x, y, line_type, markersize=marker_size, linewidth=line_width)
#          
#        llegend = []
#        #j = 0
#        for key, var in dict_data.items():
#            bTmp = False
#            if len(var)>2:
#                if not(var[2] is None):
#                    bTmp = True
#                    kwargs = var[2]
#                
#            if bTmp:
#                ax.plot(var[0], var[1], **kwargs)
#            else:
#                ax.plot(var[0], var[1])
#
#            llegend.append(key)
#            #j += 1
#              
#        if bLegend:
#            ax.legend(llegend, fontsize=iLegendSize, loc=2)
#            
#        #ax.plot(x, y, line_type, color=color, markersize=marker_size, linewidth=line_width)
#        ax.set_title(title)
#
#        ax.set_xlim(x_lim)
#        if y_lim:
#            ax.set_ylim(y_lim)
#            
#        ax.tick_params(axis='x',
#                       which='both',
#                       bottom=False,
#                       top=False,
#                       labelbottom=False)
#        ax.tick_params(axis='x', which='minor')
#        ax.grid(True)
#        axis.append(ax)
#        i += 1    
#    
#    axis[-1].tick_params(axis='x', 
#                        which='both',
#                        bottom=True,
#                        labelbottom=True)
#    
#    axis[-1].set_xlabel(x_label)
#    
#    
#    hf.autofmt_xdate()
#
#    plt.tight_layout()
#    
#    if file_name:
#        plt.savefig(file_name, dpi=150)
#        plt.close(hf)
#        
#    else:
#        plt.show()
#    
  