# -*- coding: utf-8 -*-
"""
Created on Thu Nov  1 15:00:33 2018

    functions for plotting and visualization

@author: w012028
"""



import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.dates as mdates
from textwrap import wrap
from textwrap import fill
from sklearn.decomposition import PCA
import seaborn as sb
from matplotlib.dates import AutoDateFormatter, AutoDateLocator
from datetime import datetime as dt

#import mpld3
#from mpld3 import plugins, utils
#from matplotlib.dates import date2num








# function that provides the Tableau20-Colorblind-colors
# code copied from  http://www.randalolson.com/2014/06/28/how-to-make-beautiful-data-visualizations-in-python-with-matplotlib/, 
# on 2018-9-17
# TODO 2018-9-17: noch mit geeigneten Namen versehen
#
# Christian Kuehnert, 2018-9-17
#
def provideColors():

    #These are the "Tableau 20" colors as RGB.    
    tableau20 = [(31, 119, 180), (174, 199, 232), (255, 127, 14), (255, 187, 120),
                 (44, 160, 44), (152, 223, 138), (214, 39, 40), (255, 152, 150),    
                 (148, 103, 189), (197, 176, 213), (140, 86, 75), (196, 156, 148),    
                 (227, 119, 194), (247, 182, 210), (127, 127, 127), (199, 199, 199),    
                 (188, 189, 34), (219, 219, 141), (23, 190, 207), (158, 218, 229)]    
  
    # Scale the RGB values to the [0, 1] range, which is the format matplotlib accepts.    
    for i in range(len(tableau20)):    
        r, g, b = tableau20[i]    
        tableau20[i] = (min(r / 255., 1), min(g / 255., 1), min(b / 255., 1))  


    return(tableau20)
    
    
    
    
#    
#"""
#function to plot several diagrams synchronized on one page
#
#@author: Christian Kuehnert
#@last_modified: 2019-3-7
#
#
#""" 
#import matplotlib.pyplot as plt
#import matplotlib.gridspec as gs
#def myPlot_multiple(file_name, list_plot_data, sTitle, x_label, x_lim=None):
#    
#    line_type = 'o-'
#    marker_size = 2
#    line_width = 1
#    
#    #if not(color):
#    #    color = 'black'
#    
#    iN = len(list_plot_data)
#    
#    hf = plt.figure(figsize=(19, iN*2.5))
#    g = gs.GridSpec(iN,1)
#
#    if not(x_lim):
#        min_x = min([min(x[0]) for x in list_plot_data])
#        max_x = max([max(x[0]) for x in list_plot_data])
#        x_lim = [min_x, max_x]        
#    
#    
#    axis = []
#    i=0            
#    for x, y, color, title, y_label in list_plot_data:
#        
#        ax = plt.subplot(g[i,0])
#        #lines = ax.plot(x, y, line_type, markersize=marker_size, linewidth=line_width)
#        ax.plot(x, y, line_type, color=color, markersize=marker_size, linewidth=line_width)
#        ax.set_title(title)
#        ax.set_xlim(x_lim)
#        ax.tick_params(axis='x',
#                       which='both',
#                       bottom=False,
#                       top=False,
#                       labelbottom=False)
#        ax.tick_params(axis='x', which='minor')
#        ax.grid(True)
#        axis.append(ax)
#        i += 1
#    
#    axis[-1].tick_params(axis='x', 
#                        which='both',
#                        bottom=True,
#                        labelbottom=True)
#    
#    hf.autofmt_xdate()
#
#    plt.tight_layout()
#    
#    if file_name:
#        plt.savefig(file_name, dpi=150)
#        plt.close(hf)
#    
    
    
    
# 
# function to plot filled curves
#
# Christian Kuehnert, 2018-11-28
# nach http://www.randalolson.com/2014/06/28/how-to-make-beautiful-data-visualizations-in-python-with-matplotlib/
#
def myPlot_fill(sFN, dX, dMean, dMin, dMax, sTitle, sXLabel, sYLabel, dYLim = [-0.02, 1.02]):
        
    iFontSize = 18
    iFontSizeTitle = 22
    
    
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                
    #ax.spines["top"].set_visible(False)      
    #ax.spines["right"].set_visible(False)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                            
    plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
                            
    #plt.fill_between(dX, dMin, dMax, color="#3F5D7D")
    plt.fill_between(dX, dMin, dMax, color="lightgrey")
    #plt.plot(dX, dMean, color="white", lw=2)  
    #plt.plot(dX, dMean, color="black", lw=2)  
    plt.plot(dX, dMean, color="dimgray", lw=2, marker = '+')  
                     
    plt.grid(True)
                     
    #plt.title(sTitle, fontsize=12)
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))))

    fh.tight_layout()
    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    
                            
    plt.savefig(sFN, dpi=350)
    plt.close(fh)
                            
    
    
    

# 
# function to plot the points
#
# Christian Kuehnert, 2018-11-28
#
#def myPlot_points(sFN='', dfVals=[], dfLabel=[], dThreshold=[], dfX=[], sTitle='', sXLabel='', sYLabel='', dYLim = []):
def myPlot_points(sFN='', dfX=[], dfVals=[], dfLabel=[], dThreshold=[], sTitle='', sXLabel='', sYLabel='', dYLim = []):
          
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 18
    
    
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                    
    #ax.spines["top"].set_visible(False)      
    #ax.spines["right"].set_visible(False)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                            
    if dYLim:
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
    
    bIdx = (dfLabel['label']==0)
    dfX0 = dfX.loc[bIdx]
    df0 = dfVals.loc[bIdx]
    
    bIdx = (dfLabel['label']==1)
    dfX1 = dfX.loc[bIdx]
    df1 = dfVals.loc[bIdx]
    

    plt.plot(dfX0, df0, color="green", marker='*', linestyle='')
    plt.plot(dfX1, df1, color="orange", marker='o', linestyle='')
        

    llegend = ['label 0', 'label 1']
    if len(dThreshold)>=1:
        ax.axhline(min(dThreshold[:]), linewidth=2, linestyle='--')
        llegend.append('min(threshold)')

        ax.axhline(np.mean(dThreshold[:]), linewidth=2, linestyle='-')
        llegend.append('mean(threshold)')

        ax.axhline(max(dThreshold[:]), linewidth=2, linestyle='--')
        llegend.append('max(threshold)')


              
    plt.grid(True)
    plt.legend(llegend, fontsize=iLegendSize)                         

    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)
    
    
    #plt.title(sTitle, fontsize=12)    
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)

    #fh.tight_layout()
    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    
    #fh.tight_layout(pad=0.4, w_pad=0.5, h_pad=.8)
    fh.tight_layout()
                            
    plt.savefig(sFN, dpi=350)
    plt.close(fh)
                        
      
       
    


# 
# function to plot the points
#
# Christian Kuehnert, 2019-1-16
#
def myPlot_pointsPCA(sFN='', dfVals=[], dictLabels = None, dLabel=[], dThreshold=[], sTitle='', sXLabel='pc1', sYLabel='pc2', dYLim = []):
          
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 18


    iN = dfVals.shape[1]
    if iN>2:
        #print('zuviele Dimensionen zum zeichnen!')
        # PCA durchfuehren und die ersten 2 HK zeichnen        
        pca = PCA(n_components=2)
        dfX = pd.DataFrame(data = pca.fit_transform(dfVals), columns=['pc1', 'pc2'], index = dfVals.index)
        
        sTitle = sTitle + ', pc1: ' + str(round(pca.explained_variance_ratio_[0])*100) + ' % of variance, pc2: ' + str(round(pca.explained_variance_ratio_[1])*100) + ' % of variance'
        
    else:
        dfX = dfVals
        if (sXLabel=='pc1'):
            sXLabel = dfVals.columns[0]
            
        if (sYLabel=='pc2'):
            sYLabel = dfVals.columns[1]
        
        
        
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                    
    #ax.spines["top"].set_visible(False)      
    #ax.spines["right"].set_visible(False)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                            
    if dYLim:
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
    
    llegend = []
    for key, var in dictLabels.items():
    
        df = dfX.loc[dLabel==key]            
        plt.plot(df.iloc[:,0], df.iloc[:,1], color = var[1], marker="*", linestyle='')
        
        llegend.append(var[0])


    if len(dThreshold)>=1:
        ax.axhline(min(dThreshold[:]), linewidth=2, linestyle='--')
        llegend.append('min(threshold)')

        ax.axhline(np.mean(dThreshold[:]), linewidth=2, linestyle='-')
        llegend.append('mean(threshold)')

        ax.axhline(max(dThreshold[:]), linewidth=2, linestyle='--')
        llegend.append('max(threshold)')


              
    plt.grid(True)
    plt.legend(llegend, fontsize=iLegendSize)                         
    
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    #plt.title(sTitle, fontsize=12)
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)

    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
                            
    plt.savefig(sFN, dpi=350)
    plt.close(fh)
                        
          
    
    

# 
# function to plot the points
#
# Christian Kuehnert, 2018-11-28
#
def myPlot_pointsPCA_old(sFN='', dfVals=[], dfLabel=[], dThreshold=[], sTitle='', sXLabel='pc1', sYLabel='pc2', dYLim = []):
          
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 18


    iN = dfVals.shape[1]
    if iN>2:
        #print('zuviele Dimensionen zum zeichnen!')
        # PCA durchfuehren und die ersten 2 HK zeichnen        
        pca = PCA(n_components=2)
        dfX = pd.DataFrame(data = pca.fit_transform(dfVals), columns=['pc1', 'pc2'], index = dfVals.index)
        
        sTitle = sTitle + ', pc1: ' + str(round(pca.explained_variance_ratio_[0])*100) + ' % of variance, pc2: ' + str(round(pca.explained_variance_ratio_[1])*100) + ' % of variance'
        
    else:
        dfX = dfVals
        if (sXLabel=='pc1'):
            sXLabel = dfVals.columns[0]
            
        if (sYLabel=='pc2'):
            sYLabel = dfVals.columns[1]
        
        
        
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                    
    #ax.spines["top"].set_visible(False)      
    #ax.spines["right"].set_visible(False)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                            
    if dYLim:
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
    
    df0 = dfX.loc[dfLabel['label']==0]
    df1 = dfX.loc[dfLabel['label']==1]
    #df0 = dfX[dfLabel['label']==0]
    #df1 = dfX[dfLabel['label']==1]

    plt.plot(df0.iloc[:,0], df0.iloc[:,1], color="green", marker="*", linestyle='')
    plt.plot(df1.iloc[:,0], df1.iloc[:,1], color="orange", marker="o", linestyle='')
        

    llegend = ['label 0', 'label 1']
    if len(dThreshold)>=1:
        ax.axhline(min(dThreshold[:]), linewidth=2, linestyle='--')
        llegend.append('min(threshold)')

        ax.axhline(np.mean(dThreshold[:]), linewidth=2, linestyle='-')
        llegend.append('mean(threshold)')

        ax.axhline(max(dThreshold[:]), linewidth=2, linestyle='--')
        llegend.append('max(threshold)')


              
    plt.grid(True)
    plt.legend(llegend, fontsize=iLegendSize)                         
    
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    #plt.title(sTitle, fontsize=12)
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))))

    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
                            
    plt.savefig(sFN, dpi=350)
    plt.close(fh)
                        
          

    

# 
# function to histogram of the points
#
# Christian Kuehnert, 2018-11-28
# 
# TODO 2018-10-8: spaeter vielleicht weglassen und lieber plotHist so flexibel gestalten, dass es diese Funktion hier abdeckt
#
def myPlot_pointsHist(sFN='', dfX=[], dfLabel=[], dThreshold=[], dBins=100, sTitle='', sXLabel='', sYLabel='Haeufigkeit', dYLim = []):
                 
    iFontSize = 18
    iFontSizeTitle = 22


    if dfX.shape[1]>2:
        print('zuviele Dimensionen zum zeichnen!')
        # TODO 2018-10-6: spaeter PCA durchfuehren und die ersten 2 HK zeichnen

    elif dfX.shape[1] == 2:
        print('Histogramme fuer 2D kann ich noch nicht zeichnen')
        
    else:
        
        llegend = []
        
        fh = plt.figure(figsize=(12,9))
        ax=plt.subplot(111)
                                    
        #sb.reset_orig()
        
        #ax.spines["top"].set_visible(False)      
        #ax.spines["right"].set_visible(False)
                                
        ax.get_xaxis().tick_bottom()  
        ax.get_yaxis().tick_left()   
                                
        if dYLim:
            plt.ylim(dYLim)
                                
        plt.xlabel(sXLabel, fontsize = iFontSize)
        plt.ylabel(sYLabel, fontsize = iFontSize)
        
        df0 = dfX.loc[dfLabel['label']==0]
        df1 = dfX.loc[dfLabel['label']==1]

        plt.hist(df0.values, bins=dBins, alpha=0.5)
        plt.hist(df1.values, bins=dBins, alpha=0.5)
        #plt.hist(df0, bins=dBins, color="green", alpha=0.5, label='label 0')
        #plt.hist(df1, bins=dBins, color="orange", alpha=0.5, label='label 1')
        if len(dThreshold)>=1:
            ax.axvline(min(dThreshold[:]), linewidth=2, linestyle='--')
            llegend.append('min(threshold)')

            ax.axvline(np.mean(dThreshold[:]), linewidth=2, linestyle='-')
            llegend.append('mean(threshold)')

            ax.axvline(max(dThreshold[:]), linewidth=2, linestyle='--')
            llegend.append('max(threshold)')
        
        llegend.append('label 0')
        llegend.append('label 1')
                                        
        plt.grid(True)
        plt.legend(llegend)                         
                                 
        #plt.title(sTitle, fontsize=12)
        title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    
        fh.tight_layout()
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        
                                
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
             
        
#TODO 2018-10-6: noch routine fuer Histogram anlegen, fuer beide labels Verteilungen malen sowie die Grenze ebenfalls ggf. mit einzeichnen
#im Hauptskript dann auf die abs(dDQ_d1) anwenden!



    
    
# 
# function to plot curves for precision and recall
#
# Christian Kuehnert, 2018-11-28
#    
def myPlot_precison_recall(sFN, dX, dStats_precision, dStats_recall, sTitle, sXLabel):
                 
    iFontSize = 18
    iFontSizeTitle = 22

    sYLabel = 'Precision, Recall'

    cols = provideColors()
                            
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                                                                                           
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                                                    
    plt.ylim(-0.05, 1.05)
                                                    
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
                                                    
    plt.fill_between(dX, dStats_precision.minmax[0], dStats_precision.minmax[1], color=cols[3])
    plt.plot(dX, dStats_precision.mean, color=cols[6], lw=2, marker = '+')  
                            
    plt.fill_between(dX, dStats_recall.minmax[0], dStats_recall.minmax[1], color=cols[5])
    plt.plot(dX, dStats_recall.mean, color=cols[4], lw=2, marker = '*')  
                            
    plt.legend(['precision', 'recall'])
                            
    plt.grid(True)
                                             
    #plt.title(sTitle, fontsize=12)
    title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)

    fh.tight_layout()
    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
                                                    
    plt.savefig(sFN, dpi=350)
    plt.close(fh)

    
  

# 
# function to plot stacked bars
#
# Christian Kuehnert, 2018-11-28
#
def myPlot_fillBars(sFN, dX, dMin, dMean, dMax, sTitle, sXLabel, sYLabel, dYLim = []):
                 
    iFontSize = 18
    iFontSizeTitle = 22
        
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                
    #ax.spines["top"].set_visible(False)      
    #ax.spines["right"].set_visible(False)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                            
    if dYLim:
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
                            
    plt.bar(dX, dMax, color="lightgrey", width=.99)
    plt.bar(dX, dMin, color="white", width=.99)
    
    plt.plot(dX, dMean, color="dimgray", lw=2, marker = '+')  
                     
    plt.grid(True)
                     
    
    #plt.title(sTitle, fontsize=12)
    title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)

    fh.tight_layout()
    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    
                            
    plt.savefig(sFN, dpi=350)
    plt.close(fh)
                            
    
    
    









# create 2D-plots with grouped data, marking each group differently
#
# Example:
#
#        dfData = pd.concat((dfACF_d1.iloc[:,0], dfACF_d1.iloc[:,1], dfBoolPitchStand), axis=1)
#        sHeaderX = 'acf_d1_lag1'
#        sHeaderY = 'acf_d1_lag2'
#        sHeadersGroups = 'state'
#        dfGroupColMap = pd.DataFrame(data=[['Trudeln', 'black'],['Stand', 'red']], columns = ['group','color'])
#        sTitle = 'test'
#        sXLabel = 'acf_d1(1)'
#        sYLabel = 'acf_d1(2)'
#        dXLim = [-1,1]
#        dYLim = [-1,1]
#        sLineTypes = ['o','o']        
#        sFN_save = sPathSave + '\\test.png'
#        myPlotGroups(sFN_save, dfData, sHeaderX, sHeaderY, sHeadersGroups, dfGroupColMap, sTitle, sXLabel, sYLabel, dXLim, dYLim, sLineTypes)
#
# Christian Kuehnert, 2018-8-19
#
def myPlotGroups(sFN, dfData, sHeaderX, sHeaderY, lHeadersGroups, dfGroupColMap, sTitle, sXLabel, sYLabel, dXLim, dYLim, dXTicks, dYTicks, sLineTypes):

     # group by header(s) given in sHeadersGroups
    #grpsPlot = dfData.groupby(['state'])
    grpsPlot = dfData.groupby(lHeadersGroups)

    lX = []
    lY = []
    lLeg = []
    lColors = []
    
    for gr, dfGr in grpsPlot:
        
        bCol = (dfGroupColMap.group==gr)
        if any(bCol):
            lColors.append(dfGroupColMap[bCol].color.tolist()[0])
            #lColors.append(dfGroupColMap.iloc[iCol].color)            
        else:
            lColors.append('black')
            
                                      
        lX.append(dfGr.loc[:,sHeaderX])
        lY.append(dfGr.loc[:,sHeaderY])
        #listLeg.append(groups)
        lLeg.append(str(gr))
        #listColos.append(mapColorGroups[])  # noch richtig machen!
        
    #sLegends = np.concat(lLeg)
    #sLegends = pd.concat(lLeg)
    #sColors = np.concat(lColors)
    #sColors = np.vstack(lColors)
        
    myPlot(sFN, lX, lY, sTitle, sXLabel, sYLabel, dXLim, dYLim, dXTicks, dYTicks, sLineTypes, lLeg, lColors)






"""
simple plotting function for fast plots (mainly interactive) of list of triples
containing x, y and a dictionary with the plotting style parameters

parameters:
-----------

- list_of_triples:     list of type (x, y, dict_plots_styles) with the data to
                       be plotted (y ~ x) with the given plot-styles (can be
                       none, then the default style will be used)
                       


@author: Christian Kuehnert
@modified: 2019-9-10

"""
# TODO 2019-9-10: noch so machen, dass statt der Einzelsachen wie title, xlim 
# etc. ein dictionary mitgegeben wird - insbesondere, wenn man dieses gleich
# beim Aufruf der plot-Funktion uebergeben kann
def myplot(sFN, list_of_triples, s_title = None, legend = None, x_lim = None,
           y_lim = None, sXLabel = None, sYLabel = None):
                 
    plt.rcParams['agg.path.chunksize'] = 10000
    
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 16

    default_dict_style = {'linestyle': '-', 'marker': 'None'}
               
    
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    if isinstance(sXLabel, str):
        plt.xlabel(sXLabel, fontsize = iFontSize)
        
    if isinstance(sYLabel, str):
        plt.ylabel(sYLabel, fontsize = iFontSize)
   
    if x_lim:
        plt.xlim(x_lim)
    
    if y_lim:
        plt.ylim(y_lim)


    for (x, y, dict_style) in list_of_triples:
        if (dict_style is None):
            plt.plot(x, y, **default_dict_style)
        
        else:
            plt.plot(x, y, **dict_style)
            

    if legend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        #llegend = [str(i) for i in range(iN)]
        plt.legend(legend, fontsize=iLegendSize)


    if s_title:
        iFontSizeTitle = 22
        title = ax.set_title(fill(s_title, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
          
    if not(sFN is None):
        plt.savefig(sFN, dpi=350)
    else:
        plt.show()
    
    plt.close(fh)

                  
      



"""
simple plotting function - new version, each element in dict_data contains x-values as well as y-values (must be consistent of course)

@author: Christian Kuehnert

2019-3-22

"""
def myPlot_old3(sFN, dict_data, sTitle='', sXLabel='index', sYLabel='', dXLim = None, dYLim = None, bLegend = True):
          
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 16


    #iN = dY.shape[1]
        
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
    
    #tmp_cols = provideColors()[0:len(dict_data)]
                        
    if dXLim:
        plt.xlim(dXLim)
    
    if dYLim:
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
    
    llegend = []
    i = 0
    for key, var in dict_data.items():
        #plt.plot(dX, var, color = colors[0], marker="*", linestyle='')        
#        if var[2] is None:
#            col = tmp_cols[i]
#        else:
#            col = var[2]
#
#        s_marker = 'None'
#        if len(var)>3:            
#            if not(var[3] is None):
#                s_marker = var[3]
#        
#        s_linestyle = 'None'
#        if len(var)>4:
#            if not(var[4] is None):
#                s_linestyle = var[4]
#                
#        mfc = 'None'
#        if len(var)>5:
#            if not(var[5] is None):
#                mfc = var[5]
                                                

        #if (i % 2==0):                       
        #if (i==0) or (i==2) or (i==4):
        bTmp = False
        if len(var)>2:
            if not(var[2] is None):
                bTmp = True
                kwargs = var[2]
                
        if bTmp:
            #col = tmp_cols[i]
            plt.plot(var[0], var[1], **kwargs)
        else:
            #col = var[2]
            plt.plot(var[0], var[1])
        #else:
        #    plt.plot(var[0], var[1], color=col, marker=s_marker, linestyle=s_linestyle)


        llegend.append(key)
        i += 1
              
        
    plt.grid(True)
    
    if bLegend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        plt.legend(llegend, fontsize=iLegendSize)
    
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    #plt.title(sTitle, fontsize=12)
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)

    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    mpl.rcParams['agg.path.chunksize'] = 10000
    
    #if not(sFN is None):
    plt.savefig(sFN, dpi=350)
    #else:
    #    plt.show()
    plt.close(fh)
                        
          






"""
simple plotting function for fast plots (mainly interactive) of list of triples
containing x, y and a dictionary with the plotting style parameters

parameters:
-----------

- list_of_triples:     list of type (x, y, dict_plots_styles) with the data to
                       be plotted (y ~ x) with the given plot-styles (can be
                       none, then the default style will be used)
                       


@author: Christian Kuehnert
@modified: 2020-7-7

"""
def myplot_fast2(list_of_triples, fn = None, s_title = None, projection = None,
                 legend = None, x_lim = None, y_lim = None, sXLabel = None, 
                 sYLabel = None, figsize = (12,9), iFontSizeTitle = 22, 
                 iAxisLabelSize = 16, iLegendSize = 16, iFontSize = 18,
                 xticksrot = 0, x_time_interval = None, date_format = None):
                     

    if isinstance(list_of_triples, tuple):
        list_of_triples = [list_of_triples]

    default_dict_style = {'linestyle': '-', 'marker': 'None'}
    
    
    fh = plt.figure(figsize=figsize)
    ax=plt.subplot(111, projection = projection)
    
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    if isinstance(sXLabel, str):
        plt.xlabel(sXLabel, fontsize = iFontSize)
        
    if isinstance(sYLabel, str):
        plt.ylabel(sYLabel, fontsize = iFontSize)
   
    
    if x_lim:
        plt.xlim(x_lim)

    if y_lim:
        plt.ylim(y_lim)

    for (x, y, dict_style) in list_of_triples:
        if (dict_style is None):
            plt.plot(x, y, **default_dict_style)
        
        else:
            plt.plot(x, y, **dict_style)
            
    if (xticksrot!=0):
#        xticklabels = ax.get_xticklabels()
#            if feature == 'create_time':
        plt.xticks(rotation=xticksrot)

#        ax.set_xticklabels(xticklabels, rotation = xticklabelsrot, ha="right")

    if isinstance(x[0],dt):
        
        try:
            if not(x_time_interval is None):
                xtick_locator = ticker.MultipleLocator(x_time_interval)
            else:
                xtick_locator = AutoDateLocator(interval_multiples=False)
            ax.xaxis.set_major_locator(xtick_locator)
                    
        
            if not(date_format is None):
                try:
                    xtick_formatter = mdates.DateFormatter(date_format)
                except:
                    xtick_formatter = AutoDateFormatter(xtick_locator) 
            else:
                xtick_formatter = AutoDateFormatter(xtick_locator)
                
            ax.xaxis.set_major_formatter(xtick_formatter)
            fh.autofmt_xdate()
            
        except:
            pass        
        

    if legend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        #llegend = [str(i) for i in range(iN)]
        if (projection=='polar'):
            plt.legend(legend, loc='center left', bbox_to_anchor=(1, 0.5),
                       fontsize=iLegendSize)
        else:
            plt.legend(legend, fontsize=iLegendSize)
            


    if s_title:
        title = ax.set_title(fill(s_title, int(round(120/iFontSizeTitle*12))), 
                             fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        #fh.subplots_adjust(top=0.9)
        #fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    if (fn is None):
        plt.show()
    else:
        #if not(sFN is None):
        plt.savefig(fn, dpi=350)
        plt.close(fh)

    #plt.close(fh)
                        
      
    


"""
function to plot the relative deviation of the signal energy

@modified: 2020-3-27
"""
def myplot_fast3(df, var_x, var_y, var_colors = None, fn = None,
                 title = None, 
                 projection = None, legend = None, y_lim = None, sXLabel= None, 
                 sYLabel = None,
                 figsize = (12,9), iFontSizeTitle = 22,
                 iAxisLabelSize = 16, iLegendSize = 16, iFontSize = 18):
            
    # df_fltrd = df[df['power'] > 100]
#    if (feat is None):
#        feat = 'create_time'
            
    cmap = plt.cm.get_cmap('jet')
    fh, ax = plt.subplots(figsize=figsize)
    fh.canvas.set_window_title(title)
    # im = ax.scatter(raw_df['actual_avg_freq'], ratio.rolling(len(ratio.index)), s=2, color='green', zorder=1)
    # ax.scatter(df_fltrd['actual_avg_freq'], ratio_poly.rolling(10).mean(), s=2, color='red', zorder=1)
    #ax.scatter(df[feat], df[self.col_y], s=2, color='grey', zorder=-1)
    # im = ax.scatter(df['wind'], self.pred(df), c=df['temperature'].values, s=1,
    #                 cmap=cmap, zorder=-1)
#        im = ax.scatter(df_fltrd['create_time'], df_fltrd['pwr_pred'], c=df_fltrd['temperature'].values, s=1,
#                        cmap=cmap, zorder=-1)
    
    if (var_colors is None):
        im = ax.scatter(df[var_x], df[var_y], zorder=-1)
        
    else:
        im = ax.scatter(df[var_x], df[var_y], c=df[var_colors].values, 
                        cmap=cmap, zorder=-1, s=5)
        cbar = fh.colorbar(im, ax=ax, format='%d')
        cbar.set_label(var_colors)
    
    if not(title is None):
        #plt.title(title)
        
        title = ax.set_title(fill(title, int(round(120/iFontSizeTitle*12))), 
                             fontsize=iFontSizeTitle)    
        title.set_y(1.05)

        
        
        
        
    if not(legend is None):
        plt.legend(legend)

    if var_x == 'create_time':
        plt.xticks(rotation = 70)

    plt.xlabel(var_x)
    plt.ylabel(var_y)
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()

    
    
    if (fn is None):
        plt.show()
    else:
        #if not(sFN is None):
        plt.savefig(fn, dpi=350)
        plt.close(fh)



    
    



"""
simple plotting function for fast plots (mainly interactive) - old version,
color can't be selected in dict_style

@author: Christian Kuehnert

2020-2-5

"""
def myplot_fast(dX, s_title = None, legend = None, y_lim = None, 
                sXLabel = None, sYLabel = None, dict_style = {'linestyle': '-', 
                'marker': 'None'}, fn=None):
                 
    iAxisLabelSize = 16
    iLegendSize = 16
    iFontSize = 18
    
    
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    colors = provideColors()
    
    if isinstance(sXLabel, str):
        plt.xlabel(sXLabel, fontsize = iFontSize)
        
    if isinstance(sYLabel, str):
        plt.ylabel(sYLabel, fontsize = iFontSize)

    
    
    if y_lim:
        plt.ylim(y_lim)

    if isinstance(dX, tuple) or isinstance(dX, list):            
#        if len(dX)>2:
#            for idx in range(1,len(dX)):
#                # TODO 2019-4-3: funktioniert noch nicht richtig
#                plt.plot(dX[0], dX[idx], color=colors[idx])
#        else:
#            plt.plot(dX[0], dX[1])
        iN = len(dX)
        for idx in range(1,iN):
            plt.plot(dX[0], dX[idx], color = colors[idx], **dict_style)                

            #llegend.append(str(idx))


    elif isinstance(dX, pd.DataFrame):
        iN = dX.shape[1]
        plt.plot(dX.iloc[:,0], dX.iloc[:,1:].values, **dict_style)        
                
    else:        
        
        bMulti = False
        if len(dX.shape)>1:
            iN = dX.shape[1]
            if (iN>0):
                bMulti = True
        else:
            iN = 1
                
        if bMulti:
            plt.plot(dX[:,0], dX[:,1:], **dict_style)

        else:
            dI = pd.Series(range(dX.shape[0]))
            plt.plot(dI, dX)


    if legend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        #llegend = [str(i) for i in range(iN)]
        plt.legend(legend, fontsize=iLegendSize)


    if s_title:
        iFontSizeTitle = 22
        title = ax.set_title(fill(s_title, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    if (fn is None):
        plt.show()
    else:
        #if not(sFN is None):
        plt.savefig(fn, dpi=350)
        plt.close(fh)

    #plt.close(fh)
                        
      









"""
simple plotting function

@author: Christian Kuehnert

2019-3-14

"""
def myPlot_old(sFN, dX, dictY, sTitle='', sXLabel='index', sYLabel='', dXLim = None, dYLim = None, colors = None, bLegend = True):
          
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 18


    #iN = dY.shape[1]
        
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
    
    if not(colors):
        colors = provideColors()[0:len(dictY)]
                        
    if dYLim:
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel(sYLabel, fontsize = iFontSize)
    
    llegend = []
    i = 0
    for key, var in dictY.items():
        #plt.plot(dX, var, color = colors[0], marker="*", linestyle='')        
        plt.plot(dX, var, color=colors[i], linestyle='-')
        llegend.append(key)
        i += 1
              
        
    plt.grid(True)
    
    if bLegend:
        plt.legend(llegend, fontsize=iLegendSize)                         
    
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    #plt.title(sTitle, fontsize=12)
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)

    title.set_y(1.05)
    #fh.subplots_adjust(top=0.8)
    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    mpl.rcParams['agg.path.chunksize'] = 10000
    
    #if not(sFN is None):
    plt.savefig(sFN, dpi=350)
    #else:
    #    plt.show()
        
    plt.close(fh)
                        
          



# input: listX and listY must have same no. of elements
# 
# Christian Kuehnert, 2018-11-28
#
def myPlot_old2(sFN, listX, listY, sTitle, sXLabel, sYLabel, dXLim, dYLim, dXTicks, dYTicks, sLineTypes, sLegends, lColors):

    plt.style.use('seaborn-whitegrid')
    
    fig = plt.figure()
    ax = plt.axes()
        
    for i in range(len(listX)):
        ax.plot(listX[i].values, listY[i].values, sLineTypes[i], color=lColors[i], label=sLegends[i], markersize = 1)
        #ax.plot(listX[i], listY[i], sLineTypes, color=lColors[i], label=sLegends[i], markersize = 1)        
        
    plt.grid(True)
    
    #if dYLim:
    if not (not dYLim):
        plt.ylim(dYLim)
        
    if not (not dXLim):
        plt.xlim(dXLim)

    if not (not dXTicks):
        plt.xticks(dXTicks)      
        
    if not (not dXTicks):
        plt.yticks(dYTicks)
            
    ax.set(title=sTitle)
    plt.xlabel(sXLabel)
    plt.ylabel(sYLabel + ', edge')    
    plt.legend()
    fig.savefig(sFN, dpi=350)
    plt.close(fig)
    






  
# 
# function to plot histograms
#
# Christian Kuehnert, 2018-10-5
# nach http://www.randalolson.com/2014/06/28/how-to-make-beautiful-data-visualizations-in-python-with-matplotlib/
#
def myPlot_hist_old(sFN, dX, sTitle, sXLabel, dBins=100, bRelative=False, dRange=[], dYLim=[]):
                                 
    iFontSize = 18
    iFontSizeTitle = 22

    
    if not dRange:
        dRange = [np.floor(min(dX)), np.ceil(max(dX))]
        if isinstance(dBins, list):
            if len(dBins)>=2:
                dRange=[dBins[0], dBins[-1]]
                xticks = dBins
    
   
    
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                
    #ax.spines["top"].set_visible(False)      
    #ax.spines["right"].set_visible(False)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
                 
    if dYLim:           
        plt.ylim(dYLim)
                            
    plt.xlabel(sXLabel, fontsize = iFontSize)
    plt.ylabel('frequency', fontsize = iFontSize)
                            
    plt.hist(dX, color="#3F5D7D", bins = dBins, range = dRange, edgecolor="white")
                     
    #plt.xticks(dBins)
    
    plt.grid(True)
                     
    title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)

    fh.tight_layout()
    title.set_y(1.05)
    fh.subplots_adjust(top=0.9)
                     
    if sFN is None:
        plt.show()
    else:           
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
                 
    


# 
# function to histogram of the points with flexible number of labels
#
# Christian Kuehnert, 2019-1-11
# 
# TODO 2018-10-8: spaeter vielleicht weglassen und lieber plotHist so flexibel gestalten, dass es diese Funktion hier abdeckt
#
def myPlot_hist(sFN='', dfX=[], dLabel=[], dictLabels=[], dBins=100, sTitle='', sXLabel='', sYLabel='Haeufigkeit', dYLim = [], bDensity=False, bWithCounts=True):
                 
    iFontSize = 18
    iFontSizeTitle = 22
    plt.rc('text', usetex=False)


    if dfX.shape[1]>2:
        print('zuviele Dimensionen zum zeichnen!')
        # TODO 2018-10-6: spaeter PCA durchfuehren und die ersten 2 HK zeichnen

    elif dfX.shape[1] == 2:
        print('Histogramme fuer 2D kann ich noch nicht zeichnen')
        
    else:
        
        llegend = []
        
        fh = plt.figure(figsize=(12,9))
        ax=plt.subplot(111)
                                    
        #sb.reset_orig()
        
        #ax.spines["top"].set_visible(False)      
        #ax.spines["right"].set_visible(False)
                                
        ax.get_xaxis().tick_bottom()  
        ax.get_yaxis().tick_left()   
                                
        #if dYLim:
        #    plt.ylim(dYLim)
                                
        plt.xlabel(sXLabel, fontsize = iFontSize)
        plt.ylabel(sYLabel, fontsize = iFontSize)
        
        for key, value in dictLabels.items():
            #df = dfX.loc[dfLabel['label']==key]                                        # names in the dictionary must be the label values
            bTmp = (dLabel==key)
            bTmp.index=dfX.index
            dVals = dfX[bTmp].dropna().values                                        # names in the dictionary must be the label values
            
            # sort the values outside dYLim (if existent) into the next classes
            if dYLim:
                dVals[dVals<dYLim[0]] = dYLim[0]
                dVals[dVals>dYLim[1]] = dYLim[1]
                            
            plt.hist(dVals, bins=dBins, label=[value[0]], color = value[1], alpha=0.2, density=bDensity, histtype = 'barstacked')
            if bWithCounts:
                llegend.append(value[0] + ' (n=' + str(dVals.shape[0]) + ')')
            else:
                llegend.append(value[0])
            
#        df0 = dfX.loc[dfLabel['label']==0]
#        df1 = dfX.loc[dfLabel['label']==1]
#
#        plt.hist(df0.values, bins=dBins, alpha=0.5)
#        plt.hist(df1.values, bins=dBins, alpha=0.5)
#        #plt.hist(df0, bins=dBins, color="green", alpha=0.5, label='label 0')
#        #plt.hist(df1, bins=dBins, color="orange", alpha=0.5, label='label 1')
#        
#        llegend.append('label 0')
#        llegend.append('label 1')
                                        
        plt.grid(True)
        plt.legend(llegend)                         
                                 
        #plt.title(sTitle, fontsize=12)
        #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
        title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)

        title.set_y(1.05)
        fh.subplots_adjust(top=0.9)
        
        fh.tight_layout()
                                
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
                  
               
    
#        title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)
#    
#        title.set_y(1.05)
#        #fh.subplots_adjust(top=0.8)
#        fh.subplots_adjust(top=0.9)
#        fh.tight_layout()
#                 
#        plt.savefig(sFN, dpi=350)
#        plt.close(fh)

        



# 
# function to create density plots with flexible number of labels
#
# Christian Kuehnert, 2019-2-7
# 
def myPlot_dist(sFN='', dfX=[], dLabel=[], dictLabels=[], sTitle='', sXLabel='', sYLabel='Density', dYLim = [], bWithCounts=True):
                 
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 18
    plt.rc('text', usetex=False)
    #dBW = .2

    if dfX.shape[1]>1:
        print('zuviele Dimensionen zum zeichnen!')
        # TODO 2018-10-6: spaeter PCA durchfuehren und die ersten 2 HK zeichnen
        
    else:
        
        llegend = []
        
        fh = plt.figure(figsize=(12,9))
        ax=plt.subplot(111)
                                    
        #sb.reset_orig()
        
        #ax.spines["top"].set_visible(False)      
        #ax.spines["right"].set_visible(False)
                                
        ax.get_xaxis().tick_bottom()  
        ax.get_yaxis().tick_left()   
                                
        if dYLim:
            plt.ylim(dYLim)
                                
        plt.xlabel(sXLabel, fontsize = iFontSize)
        plt.ylabel(sYLabel, fontsize = iFontSize)
        
        for key, value in dictLabels.items():
            #df = dfX.loc[dfLabel['label']==key]                                        # names in the dictionary must be the label values
            bTmp = (dLabel==key)
            bTmp.index=dfX.index
            dVals = dfX[bTmp].dropna().iloc[:,0]                                           # names in the dictionary must be the label values            
            #sb.kdeplot(dVals, shade=True, color=value[1], ax=ax)
            #sb.kdeplot(dVals, shade=True, color=value[1], ax=ax, bw=dBW)
            #sb.distplot(dVals, color=value[1], rug=True, hist=False)
            if bWithCounts:
                sLeg = value[0] + ' (n=' + str(dVals.shape[0]) + ')'
            else:
                sLeg = value[0]
                
            sb.distplot(dVals, color=value[1], rug=True, hist=False, kde=True, kde_kws={"color": value[1], "alpha": 0.2, "linewidth": 5, "shade":True}, label=sLeg)

            #llegend.append(sLeg)
                         

        plt.grid(True)
        #plt.legend(llegend, fontsize=iLegendSize)                      
        plt.legend(fontsize=iLegendSize)
        
        plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)
    
        #plt.title(sTitle, fontsize=12)
        #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
        title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)
    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()

                   
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
                  
        
        



"""
simple plotting function for fast plots of df
containing x, y and a dictionary with the plotting style parameters

parameters:
-----------
    - df:               dataframe, containing the data
    - features:         list of strings, names of the features to be plotted
    - target:           str, name of the target to be plottet vs. each feature
    - fn:               str, name of the file to be saved
    - figsize:          tuple of int, figure size of whole figure
    - iFontSizeTitle:   int, size of font title                       


@author: Christian Kuehnert
@modified: 2020-3-24

"""
def myPlot_targetVsFeat(df, features = None, target= None, fn = None,
                        figsize = (16,9), iFontSizeTitle = 22):
                 
    
    iAxisLabelSize = 16
    iLegendSize = 16
    iFontSize = 18

    #default_dict_style = {'linestyle': '-', 'marker': 'None'}
    fh = plt.figure(figsize=figsize)
    
    fh, ax = plt.subplots(figsize=(10, 4))
    fh.canvas.set_window_title(f'plots target ~ features')
#HIER WEITER 2020-3-24
    ax=plt.subplot(111)
    
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    if isinstance(sXLabel, str):
        plt.xlabel(sXLabel, fontsize = iFontSize)
        
    if isinstance(sYLabel, str):
        plt.ylabel(sYLabel, fontsize = iFontSize)
   
    
    if y_lim:
        plt.ylim(y_lim)

    for (x, y, dict_style) in list_of_triples:
        if (dict_style is None):
            plt.plot(x, y, **default_dict_style)
        
        else:
            plt.plot(x, y, **dict_style)
            

    if legend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        #llegend = [str(i) for i in range(iN)]
        plt.legend(legend, fontsize=iLegendSize)


    if s_title:
        title = ax.set_title(fill(s_title, int(round(120/iFontSizeTitle*12))), 
                             fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    if (fn is None):
        plt.show()
    else:
        #if not(sFN is None):
        plt.savefig(fn, dpi=350)
        plt.close(fh)

    #plt.close(fh)
                        
    
    
    
    
    
    
    
# 
# function to create density plots with flexible number of labels
#
# Christian Kuehnert, 2019-2-7
# 
def myPlot_kde(sFN='', dfX=[], dLabel=[], dictLabels=[], sTitle='', sXLabel='', sYLabel='Density', dYLim = [], bWithCounts=True):
                 
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    iLegendSize = 18
    plt.rc('text', usetex=False)
    #dBW = .2

    if dfX.shape[1]>1:
        print('zuviele Dimensionen zum zeichnen!')
        # TODO 2018-10-6: spaeter PCA durchfuehren und die ersten 2 HK zeichnen
        
    else:
        
        llegend = []
        
        fh = plt.figure(figsize=(12,9))
        ax=plt.subplot(111)
                                    
        #sb.reset_orig()
        
        #ax.spines["top"].set_visible(False)      
        #ax.spines["right"].set_visible(False)
                                
        ax.get_xaxis().tick_bottom()  
        ax.get_yaxis().tick_left()   
                                
        if dYLim:
            plt.ylim(dYLim)
                                
        plt.xlabel(sXLabel, fontsize = iFontSize)
        plt.ylabel(sYLabel, fontsize = iFontSize)
        
        for key, value in dictLabels.items():
            #df = dfX.loc[dfLabel['label']==key]                                        # names in the dictionary must be the label values
            bTmp = (dLabel==key)
            bTmp.index=dfX.index
            dVals = dfX[bTmp].dropna().iloc[:,0]                                           # names in the dictionary must be the label values            
            sb.kdeplot(dVals, shade=True, color=value[1], ax=ax)
            #sb.kdeplot(dVals, shade=True, color=value[1], ax=ax, bw=dBW)

            if bWithCounts:
                llegend.append(value[0] + ' (n=' + str(dVals.shape[0]) + ')')
            else:
                llegend.append(value[0])
                         

        plt.grid(True)
        plt.legend(llegend, fontsize=iLegendSize)                         
        
        plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)
    
        #plt.title(sTitle, fontsize=12)
        #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
        title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)
    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()

                   
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
                  
        
        
        
        
        


"""
 function to histogram of the points without labels#
 Christian Kuehnert, 2020-1-10
 
"""
def myPlot_hist2(sFN='', dfX=[], dBins=100, sTitle='', color='black', sXLabel='', 
                 sYLabel='Haeufigkeit', dYLim = [], bDensity=False, 
                 bWithCounts=True):
                 
    iFontSize = 20
    iFontSizeTitle = 22
    iAxisTickLabelSize =  18
    plt.rc('text', usetex=False)
    alpha = 1

    if dfX.shape[1]>2:
        print('zuviele Dimensionen zum zeichnen!')
        # TODO 2018-10-6: spaeter PCA durchfuehren und die ersten 2 HK zeichnen

    elif dfX.shape[1] == 2:
        print('Histogramme fuer 2D kann ich noch nicht zeichnen')
        
    else:
        
        col = dfX.columns[0]
        
        llegend = []
        
        fh = plt.figure(figsize=(12,9))
        ax=plt.subplot(111)
                                    
        #sb.reset_orig()
        
        #ax.spines["top"].set_visible(False)      
        #ax.spines["right"].set_visible(False)
                                
        ax.get_xaxis().tick_bottom()  
        ax.get_yaxis().tick_left()   
                                
        #if dYLim:
        #    plt.ylim(dYLim)
                                
        plt.xlabel(sXLabel, fontsize = iFontSize)
        plt.ylabel(sYLabel, fontsize = iFontSize)
        
        
        dVals = dfX.dropna().values
            
        # sort the values outside dYLim (if existent) into the next classes
        if dYLim:
            dVals[dVals<dYLim[0]] = dYLim[0]
            dVals[dVals>dYLim[1]] = dYLim[1]
                            
        
        #plt.hist(dVals, bins=dBins, color = color, alpha=alpha, density=bDensity, 
        #         histtype = 'barstacked')
        sb.distplot(dVals, kde=False, bins = dBins, color=color, 
                     norm_hist=bDensity)


        ax.tick_params(axis='both', which='major', labelsize=iAxisTickLabelSize)
        ax.tick_params(axis='both', which='minor', labelsize=iAxisTickLabelSize)
        
        if bWithCounts:
            llegend.append(f'{col} (n={dVals.shape[0]})')
        else:
            llegend.append(col)
                                        
        plt.grid(True)
#        plt.legend(llegend)                         
                                 
        #plt.title(sTitle, fontsize=12)
        #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
        title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)

        title.set_y(1.05)
        fh.subplots_adjust(top=0.9)
        
        fh.tight_layout()
                                
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
                  
       
        

# 
# function to create boxplots of the points with flexible number of labels
#
# Christian Kuehnert, 2019-1-17
# 
def myPlot_boxplot(sFN='', dfX=[], dLabel=[], dictLabels=[], sTitle='', sYLabel=None, bWithCounts=True, bShowFliers = True, dWhis=1.5):
                 
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    plt.rc('text', usetex=False)

    if dfX.shape[1]>1:
        print('zuviele Dimensionen zum zeichnen!')
        # TODO 2018-10-6: spaeter PCA durchfuehren und die ersten 2 HK zeichnen
        
    else:
                
        fh = plt.figure(figsize=(12,9))
        ax=plt.subplot(111)
                                                                    
        ax.get_xaxis().tick_bottom()  
        ax.get_yaxis().tick_left()   
                        
        if sYLabel:                                        
            plt.ylabel(sYLabel, fontsize = iFontSize)
        
        lData = []
        lxlabels = []        
        for key, value in dictLabels.items():
            bTmp = (dLabel==key)
            bTmp.index=dfX.index        
            df = dfX.loc[bTmp].dropna()                                                  # names in the dictionary must be the label values
            
#            q1 = df.quantile(.25)
#            q3 = df.quantile(.75)
#            iCntFl = df.between(q1, q2, inclusive=True)
            
            lData.append(np.ravel(df.values[:,0]))                                                          # names in the dictionary must be the label values

            if bWithCounts:
                lxlabels.append(value[0] + ' (n=' + str(df.shape[0]) + ')')
            else:
                lxlabels.append(value[0])            

        bp = plt.boxplot(lData, showfliers = bShowFliers, whis=dWhis)                            
                                        
#        if bWithCounts:
#            tmp = bp['fliers']
#            for i in range(len(tmp)):                
#                iCnt = len(tmp[i].get_data()[1])
#                lxlabels[i] = lxlabels[i] + ', incl. ' + str(iCnt) + ' outliers)'

        ax.set_xticklabels(lxlabels)
        
        
        plt.grid(True)
        
        plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)
    
        #plt.title(sTitle, fontsize=12)
        #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
        title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)
    
        title.set_y(1.05)

        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
                 
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
                  
        
        
        
"""
function to bin the given data with the given bins and plot the given 
statistical functions over these bins

@modified: 2019-12-10

"""
def myPlot_binned_stats(fn=None, list_dfs = [], bins = None, list_stat_fcts=[np.mean, min, max],
                xlabel=None, ylabel = None, 
                dictLabels=[], sTitle='', bWithCounts=True, bShowFliers = True, dWhis=1.5):
                 
    iFontSize = 18
    iFontSizeTitle = 22
    iAxisLabelSize = 16
    plt.rc('text', usetex=False)
    
    
    
    
    

    ax.set_xticklabels(lxlabels)
    
    
    plt.grid(True)
    
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    #plt.title(sTitle, fontsize=12)
    #title = ax.set_title("\n".join(wrap(sTitle, 120)), fontsize=iFontSizeTitle)
    title = ax.set_title(fill(sTitle, int(round(120/iFontSizeTitle*12))), fontsize = iFontSizeTitle)

    title.set_y(1.05)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()


    if (fn is None):
        plt.show()
    else:
        plt.savefig(sFN, dpi=350)
        plt.close(fh)
        
        
    