# -*- coding: utf-8 -*-
"""
Created on Mon Dec  3 14:41:30 2018

class for data processing of turbines
desired use cases (among other):
    - offset calculation
    - base class for monitoring
    - special statistical queries with short timeline


@author: Christian Kuehnert (w012028)
@last modified: 2020-7-4


Properties:
-----------
    
    path_hd5 :  path to the folder cotaining the ('new') .hd5-files for that
                turbine


"""

import os
import sys
import pathlib
import pandas as pd
import numpy as np
import datetime as dt
from datetime import timedelta



sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian'
sys.path.append(sModulePath)
from wms.dbs import hdf5


#import weadbs
sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
sys.path.append(sModulePath)


#import myFunctions_data as mfdata
import data.query_tableData_PIT as query_tableData_PIT
import data.query_MySQL2 as query_MySQL2
#import data.update_hd5 as update_hd5_aux
from data.class_hd5Nodes import hd5Nodes as sNodes
from data import read_gz
from data import combine_ts
from data import detect_extreme_plateaus
from data.update_hd5 import combine_at, update_cdef, update_sda
from data.update_hd5 import initialize_hd5file
from plot.myFunctions_plot import myplot_fast2
#from monitor import get_relevant_tickets
import monitor as mfmon

#import data.update_hd5.update_cdef as update_cdef
#from data.update_hd5 import update_status
#from data.update_hd5 import update_se
#from data.update_hd5 import update_sda
#from data.update_hd5 import update_ts
#from data.update_hd5 import update_ext
#import data.set_dtype_headersKey as set_dtype_headersKey
#import data.setdifference_df as setdifference_df
#import data.get_data as get_data



#
#"""
#function to calculate the interval starting points from thet start times of the
#measurements
#it is a step before combining ts-data.
#The ts-data are stored in the files t_<startdatetime>_measurement.csv.gz in the
#a table like, e.g.
#
#cycle_create_time	ID	cycle_id	create_time	create_millisec
#2.01908E+13	84763	9419	2.01908E+13	74
#2.01908E+13	84764	9419	2.01908E+13	170
#2.01908E+13	84765	9419	2.01908E+13	266
#2.01908E+13	84766	9419	2.01908E+13	362
#2.01908E+13	84767	9419	2.01908E+13	458
#2.01908E+13	84768	9419	2.01908E+13	554
#2.01908E+13	84769	9419	2.01908E+13	650
#2.01908E+13	84770	9419	2.01908E+13	746
#2.01908E+13	84771	9419	2.01908E+13	842
#
#The ID relates to the ID in the names of the single ts-files, e.g.
#at_84771_4.csv.gz
#
#
#parameters:
#-----------
#
#    - fn_meas: .csv.gz-file containing the dataframe with ID and create_time and 
#               create_millisec as above.
#               NOTE: the df must be chronologically ordered (create_time +
#                     create_millisec)
#
#
#results:
#--------
#
#    - dict_lengths: dictionary {ID: length} giving the lenghts of the time
#                    series in the ts-file(s) for the ID, i.e. the combined ts
#                    contains a length-long sequence from the beginning of the 
#                    data in that file
#                    The last single ts-file will be included in the combined
#                    ts files completely
#                    
#    - id_last:      ID of the last measurement-part
#
#@author: Christian Kuehnert
#@modified: 2019-8-12
#
#
#"""
#def get_single_ts_lengths(fn_meas):
#    
#    
#    df = pd.read_csv(fn_meas, compression='gzip', sep=',', 
#                       quotechar='"', index_col=False, 
#                       dtype={'create_time': str, 'create_millisec': int})
#
#    times = [dt.datetime.strptime(s, "%Y%m%d%H%M%S") for s in 
#             df.create_time.values] 
#    
#    ## TODO 2019-8-12: evtl. hier schon sicherstellen, dass int herauskommt
#    difft = [d.total_seconds()*1000 for d in np.diff(times)] + np.diff(
#            df.create_millisec)
#    
#    if len(np.unique(difft))!=1:
#        print('error: multiple time differences between single ts-data files!')
#
#        
#    ## TODO 2019-8-12: noch so verbessern, dass die minimale Anzahl an single-
#    ## ts-files zur Kombination verwendet wird! Dafuer aber wahrscheinlich noch
#    ## laenge der single-ts notwendig
#    dict_lengths = {}
#    for i in range(len(difft)):
#        dict_lengths.update({df.iloc[i, :].loc['ID']: int(round(difft[i]))})
#
#    id_last = df.iloc[-1,:].loc['ID']
#        
#    
#    return(dict_lengths, id_last, times[0] + dt.timedelta(milliseconds=int(
#            df.iloc[0,:].loc['create_millisec'])))
#    
#    
#    
#    
#
#"""
#TODO: in extra-modul auslagern (extra fuer special query), dann nur noch minimalen
#Rest in der turbine-class behalten oder vielleicht sogar diese ableiten und die
#Funktion dort hinzufuegen
#
#
# implemented only for special query from 20190805 (see email from SW from this
# date)
# 
# function to combine the ts-data from the single gz-files for one channel into 
# one time series
# search for overlapping parts of the time series and combine there, if no such parts are found than 
# just append the time series from the single files
# if the series have different lengths then return error message
#
# input:
#       - listTS:           list of series of integers (i.e. time series of the sensors)
#       - iCntMeasBase:     integer, base lenght of measurement
#
# output:
#
#
#Created on Wed Mar 27 10:15:25 2019
#
#@author:  Christian Kuehnert
#@modified: 2019-8-12
#"""
#def combine_at(path):
#    
#    # check if file t_*_measurement.csv.gz exists
#    # TODO 2019-8-9: andernfalls in spaeterem Iterationsschritt die Daten wie
#    # bisher anhand ueberlappender Bereiche kombinieren
#    critical_channels = []
#    dict_res = {}
#    
#    list_info = [fn for fn in os.listdir(path) if 
#               ('_measurement.csv.gz' in fn)]
#    
#    if len(list_info)==1:
#
#         # calculate lengths of the contributions from the single parts                                                            
#        dict_sl, id_last, t0 = get_single_ts_lengths(f'{path}\\{list_info[0]}')
#
#        # get 'at_'-files
#        list_files = [fn for fn in os.listdir(path) if ('at_' in fn)]
#
#        ## extract channels that are in these data
#        ltmp = []
#        for fn in list_files:
#            sid, sch = fn.replace('at_', '').replace('.csv.gz', '').split('_')
#            ltmp.append({'channel': sch, 'csv_id': int(sid), 'file': fn})
#        
#        df = pd.DataFrame.from_records(ltmp)
#        
#        groups = df.groupby(by=['channel'])
#    
#        for channel, df_g in groups:
#
#            list_ts = []
#            try:
#                for _idx, row  in df_g.sort_values(by=['csv_id']).iterrows():
#                    fn = row['file']
#                    meas_id = row['csv_id']
#                    tmp = read_gz(f'{path}\\{fn}')
#                    # add the last single-ts sequence completely, the others
#                    # only until the given stop-index
#                    if meas_id==id_last:
#                        list_ts.append(tmp)
#                        iTS = pd.concat(list_ts, ignore_index=True)
#                        times = [t0 + dt.timedelta(milliseconds=i) for i in 
#                                 range(len(iTS))]
#                        dfTS = pd.DataFrame(data={'time': times,
#                                                  'a_t': iTS})
#                    else:
#                        list_ts.append(tmp[:dict_sl[meas_id]])
#                                                    
#                dict_res.update({channel: (dfTS)})
#        
#            except:
#                critical_channels.append(channel)
#                #print('Problem bei Kombination von ts-Daten')
#            
#    return(dict_res, critical_channels)
#






    
class turbine:
       
    sDTFmt = '%Y%m%d_%H%M%S'      # format of datetime used in names of folders and files
    stf = '%d.%m.%Y %H:%M:%S'   # datetime string format

#IDEE: in dieser Klasse festlegen, welche Spalten benoetigt werden, das dann als map nach draussen geben (koennen), damit dann PIT-Abfrage steuern, dann wieder zurueckschreiben    
    
    colormap = {'e_101_edge': 'red', 
                'e_102_edge': 'blue',
                'e_103_edge': 'green',
                'e_101_flap': 'red',
                'e_102_flap': 'blue',
                'e_103_flap': 'green'}
    
    dict_directions = {'edge': ['e_101_edge', 'e_102_edge', 'e_103_edge'],
                       'flap': ['e_101_flap', 'e_102_flap', 'e_103_flap']}


    """
    get the turbine info from database name via PIT
        
    Christian Kuehnert, 2019-8-6
    """
    @classmethod
    def init_from_PIT(self, sWC_wt, btickets=False):

        dict_res = {'farm': None,
                    'name': None,
                    'db': None,
                    'wtg_type': None,
                    'manufacturer': None,
                    'begin_data': None,
                    'begin_operational': None,
                    'tickets': None
                    }

        
        dictMap = {'farm': 'Windpark_WEA#Windparkname', 
                   'name': 'WEA_Name',
                   'db': 'Datenbankname',
                   'wtg_type': 'WEA_Typ#Name',
                   'manufacturer': 'WEA_Typ#Hersteller#Firmenname',
                   'begin_data': 'Beginn_Datenspeicherung',                            
                   'begin_operational': 'Inbetriebnahme_abgeschlossen',
                   'id': 'o_ContainerID',
                   'id_farm': 'Windpark_WEA#'}

        listCols = [v + ' as ' + k for k,v in dictMap.items()]
                
        try:
            df = query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)
    
            n = df.shape[0]
            if n==0:
                print(f'no result for PIT-query with {sWC_wt}')
        
    
            elif n==1:
                
                dict_res = {k: df.iloc[0].loc[k] for k in ['farm', 'name', 'db', 
                            'wtg_type', 'manufacturer', 'begin_data', 
                            'begin_operational']}
                                                            
                if btickets:
                    ## find all tickets
                    dictMap_tickets =  {'sTitle': 'Titel',
                                        'sDescription': 'Beschreibung',
                                        'sStatus': 'Status',
                                        'sFarm': 'Windpark#Windparkname',
                                        'weasImWP': 'WEAs_im_Windpark',                            
                                        'sTicketID': 'TicketID',
                                        'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                                        'dtCreated': 'Beginn_am',
                                        'dtClosed': 'Geschlossen_am',
                                        'dtErrorFixed': 'Behebung_des_Fehlers'}
        
                    listCols_tickets = [dictMap_tickets[i] + ' as ' + i for i in dictMap_tickets]
                       
                    sWC_tickets = f"Windpark#='{df.id_farm[0]}'"
                    dfTickets = query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets)
                    
                    dfTickets.column_names = dictMap_tickets.keys
                
                    ## prepare list of ticket IDs combined with indices of weas im Windpark
                    ## in order to split tickets to single turbines
                    sContainerID = str(df.id[0])
#                    for i in range(dfTickets.shape[0]):
#                        dfT = dfTickets.iloc[i,:]
#                        sWiW = dfT.weasImWP          
#                        if (len(sWiW)>0):
#                            lTmp = sWiW.split(',')
#                            if sContainerID in lTmp:
#                                lTickets.append(dfT)
                    btmp = [sContainerID in c.split(',') for c in 
                            dfTickets.loc[:, 'weasImWP']]
                                
                    #dict_res.update({'tickets': pd.concat(lTickets, axis=0)})
                    dict_res.update({'tickets': dfTickets[btmp]})
                    
    
            else:
                print(f'more than one entries found in PIT for {sWC_wt}')
            
        except:
            print(f'error querying PIT for {sWC_wt}')
            
            
        return(dict_res)



   
    """
    initialization
    
    @modified: 2019-9-19
    """
    def __init__(self, farm = None, name = None, db = None, wtg_type = None,
                 manufacturer = None, begin_data = None, 
                 begin_operational = None, tickets = None, path_hd5 = None,
                 map_channels = {0: 'e_101_flap',
                                 1: 'e_102_flap',
                                 2: 'e_103_flap',
                                 3: 'e_101_edge',
                                 4: 'e_102_edge',
                                 5: 'e_103_edge'}):

        self.farm = farm
        self.name = name
        self.db = db
        self.wtg_type = wtg_type
        self.manufacturer = manufacturer
        self.begin_data = begin_data
        self.begin_operational = begin_operational
        self.tickets = tickets
        self.map_channels = map_channels
        
        if (path_hd5 is None):
            if (db is None):
                self.path_hd5 = None
            else:
                self.path_hd5 = pathlib.Path('W:') / self.db.replace(
                                            'cmrblba_', '') / '_current'
        else:
            self.path_hd5 = path_hd5

        self.prefs = {}
        self.sens_status = None
        self.sed = None

        info, info_fn = self.get_info()
        self.info = info
        self.info_fn = info_fn





    @classmethod
    def from_db(cls, db, btickets = True, path_hd5 = None, 
                map_channels = {0: 'e_101_flap',
                                1: 'e_102_flap',
                                2: 'e_103_flap',
                                3: 'e_101_edge',
                                4: 'e_102_edge',
                                5: 'e_103_edge'}):
        ("Initialize turbine from database name - existing values for farm, "
         "name, wtg_type, manufacturer, begin_data, begin_operational, tickets" 
         " will be overwritten without warning")        
        sWC_wt = 'Datenbankname=\'' + db + '\''        
        kwargs = cls.init_from_PIT(sWC_wt, btickets = btickets)
        kwargs.update({'path_hd5': path_hd5, 'map_channels': map_channels})
        return cls(**kwargs)
        

    @classmethod
    def from_farm_and_name(cls, farm, name, btickets = True, path_hd5 = None,                                          
                           map_channels = {0: 'e_101_flap',
                                           1: 'e_102_flap',
                                           2: 'e_103_flap',
                                           3: 'e_101_edge',
                                           4: 'e_102_edge',
                                           5: 'e_103_edge'}):
        ("Initialize turbine from farm and name - existing values for db, "
         "manufacturer, begin_data, begin_operational, tickets will be "
         "overwritten without warning")
        sWC_wt = (f"(Windpark_WEA#Windparkname='{farm}') "
                     f"and (WEA_Name='{name}')")
        kwargs = cls.init_from_PIT(sWC_wt, btickets = btickets)
        kwargs.update({'path_hd5': path_hd5, 'map_channels': map_channels})
        return cls(**kwargs)





    """
    get basic information and combine them to strings for text and for name parts of files and folders
    
    Christian Kuehnert, 2020-7-5
    """
    def get_info(self):                     
                
        #sFarm = self.farm
        #sName = self.name
        #sDB = self.db
        try:
            sFarm = self.farm.__str__()
        except:
            sFarm = 'None'
            
        try:
            sName = self.name.__str__()
        except:
            sName = 'None'
            
        try:
            sDB = self.db.__str__()
        except:
            sDB = 'None'
        
        info = f'{sFarm}, {sName} ({sDB})'
        info_fn = f'{sFarm}__{sName}__{sDB}'.replace(' ', '_').replace(
                '(','_').replace('(','_').replace(',','_')
        
        return info, info_fn
        
              
    
    """
    get preferences
    
    Christian Kuehnert, 2019-8-6
    """
    def get_preferences(self, list_prefs = None):
        
        #sSQL = 'SELECT name, value FROM preferences;'
        #tmp = mfdata.query_MySQL2(self.sDB, sSQL)
        if list_prefs is None:
            sql = 'select name,value from preferences;'
        else:
            sql = ('select name,value ' 
                   'from preferences '
                   'where name in ("' + '","'.join(list_prefs) + '");')
                   
        tmp = query_MySQL2(self.db, sql)
        self.prefs = dict(tmp)
        return(self)
    
    





    """
    get relevant prefs
    
    Christian Kuehnert, 2021-1-5
    """
    def get_sens_status(self):
        
        #dict_prefs = mfdata.get_preferences(db)
        try:
            self.get_preferences()
            
            chs = self.get_channel_list(self.dict_directions)
            
            activity = [self.prefs[f"Sensor.Blade#{ch.replace('e_10','').replace('_edge', '.Edge').replace('_flap', '.Flap')}@Activity"] for ch in chs]
            offsets = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}Offset"] for ch in chs]
            warnlevel = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}WarnLevel"] for ch in chs]
            alarmlevel = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}AlarmLevel"] for ch in chs]
                                                       
            df = pd.DataFrame({'activity': activity, 
                               'offsets': offsets,
                               'warnlevel': warnlevel,
                               'alarmlevel': alarmlevel}, 
                                index=chs)
        
#            self.sens_status = df
            
        except Exception:
            #self.sens_status = None
            df = pd.DataFrame(columns = ['activity', 'offsets', 'warnlevel', 
                                         'alarmlevel'])
#            df = None
        self.sens_status = df
        

#        return(df)
    


    
    """
    add column with database name to the given dataframe
    
    Christian Kuehnert, 2019-8-6
    """
    def add_db_column(self, dfData, sColName='db'):

        iN = dfData.shape[0]
        
        if iN>0:         
                           
            dfDB = pd.DataFrame(np.tile(self.db, [iN,]), columns=['db'], index = dfData.index)        # create dataframe with database name                             
            dfRes = pd.concat([dfDB, dfData], axis=1)
        
        else:
            dfRes = pd.DataFrame(columns=['db'] + dfData.columns)
        
        return(dfRes)
    
    


    
    """
    get the range for the given variable (in the given type of data)
    
    parameters:
    -----------
        - tablepattern:     str, pattern to select the table
        - columns:          list of str, names of the columns the ranges
                            are to be get for, of course the columns should be
                            in the table with the given pattern, otherwise 
                            empty tuples will be returned
                            
    return:
    -------
        - dict of ranges (tuples) for the given columns
        
    
    Christian Kuehnert, 2019-8-6
    TODO 2019-8-6: implement!
    """
    def get_range(self, tablepattern = '_at_', colums = ['create_time']):
        print('not yet implemented')
        return({})
        
#        sFN_hd5 = self.path_hd5 + '\\' + self.db + '.hd5'
#        try:
#            with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
#                dfTmp = f.select(sNode, columns=[sColTime])
#            
#            dfTmp.dropna(subset=[sColTime], inplace=True)            
#            return(dfTmp.loc[:,[sColTime]].max()[0])
#            
#        except Exception:
#            return(pd.NaT)
            
         
    """
    function to get list of channels from channel dictionary
    2020-7-4
    """
    def get_channel_list(self, dict_directions=None):        
        if (dict_directions is None):
            dict_directions = self.dict_directions
        return([el for sublist in dict_directions.values() for el in sublist])

        
        
    """    
    get the relevant tickets for the given data period and the channels, for 
    which these tickets are relevant
        
    2020-7-6
    """
    #def check_channels(self, include_all=True):
    def check_channels(self, start_time, end_time):
        map_inv = {v:k for k,v in self.map_channels.items()}

#        if include_all:
        chs = self.get_channel_list()
#        else:
#            chs = self.get_channel_list(self.remaining_channels())
#            map_inv = {k:v for k,v in map_inv.items() if k in chs}
            
        res = {ch: None for ch in chs}
        
        ## get tickets for the channels without regarding the period
        dfTksCrit, dict_ch_tks = mfmon.get_relevant_tickets(self.tickets, 
                                                sType = 'all_rbl_related')
            
        for ch in chs:
            [bFail, df_rel] = dict_ch_tks[map_inv[ch]]
            if bFail:
                df = df_rel[((df_rel.dtFirstOcc <= end_time) & \
                        (~(df_rel.sStatus == 'erledigt')) | \
                        (df_rel.dtErrorFixed >= start_time))]
            
                if not(df.empty):
                    res[ch] = df

        return(res, dfTksCrit)


        



    ## old update-variants, but needed e.g. for special query from 20190806
    
    """
    initialize hd5-file
    
    Christian Kuehnert, 2019-11-29    
    """
    def initialize_hd5file(self):
        initialize_hd5file(self.db, self.path_hd5)
    
    

    """
    update the cdef-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    TODO 2020-8-6: so anpassen, dass liste von periods uebergeben werden kann
    
    Christian Kuehnert, 2019-11-29
    """
    def update_cdef(self, time_start=None, time_end=None):
        return(update_cdef(self.db, self.path_hd5, time_start, time_end))
#
#
#
#
#    """
#    update the data from ba_cycle_status the hd5-file that contains the raw data for this turbine
#    
#    Christian Kuehnert, 2019-1-17
#    """
#    def update_status(self, time_start=None, time_end=None):
#        #mfdata.update_status(self.sDB, self.sPathData, time_start, time_end)
#        update_status(self.db, self.path_data, time_start, time_end)
#
#
#
#    """
#    update the data from ba_cycle_sig_energies the hd5-file that contains the raw data for this turbine
#    
#    Christian Kuehnert, 2019-1-17
#    """
#    def update_se(self, time_start=None, time_end=None):
#        #mfdata.update_se(self.sDB, self.sPathData, time_start, time_end)
#        update_se(self.db, self.path_data, time_start, time_end)
#
#
#
#
#
#
    """
    update the sda-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    Christian Kuehnert, 2019-1-17        
    """
    def update_sda(self, time_start=None, time_end=None, bSloppy=True):        
        return(update_sda(self.db, self.path_hd5, time_start, time_end, 
                          bSloppy))
#
#
#
#
#    """
#    update the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
#    
#    Christian Kuehnert, 2018-12-4
#    """
#    def update_ts(self, time_start=None, time_end=None, iCntMeasBase = 8192, bSloppy=True):
#        #return(mfdata.update_ts(self.sDB, self.sPathData, time_start, time_end, iCntMeasBase, bSloppy))
#        return(update_ts(self.db, self.path_data, time_start, time_end, iCntMeasBase, bSloppy))
#
#
#
#
#    """
#    update the externals-data in the hd5-file that contains the raw data (cdef, ts, sda, ...) for this turbine
#    
#    Christian Kuehnert, 2019-1-21
#    """
#    def update_externals(self, time_start = None, time_end = None):
#        #mfdata.update_ext(self.sDB, self.sPathData, time_start, time_end)
#        update_ext(self.db, self.path_data, time_start, time_end)
#


    """
    function to reorder the tuples with folders and files to dictionary with
    tuples (y,m,d,id) as keys and list of files as values
    
    @author: christian kuehnert
    @modified: 2019-8-7
    
    """
    ## TODO 2019-8-7: zu data transferrieren!
    import numpy as np
    def get_folders_and_files(list_af):
        
        list_pn = np.unique([x[0] for x in list_af])
        return {pn: [x[1] for x in list_af if x[0]==pn] for pn in list_pn}
        





        
    """
    creates link to turbine data in webVis
    
    Christian Kuehnert, 2019-9-19
    """          
    def create_link(self, sTool = 'IV', time_start = dt.datetime.now()-dt.timedelta(days=30), time_end = dt.datetime.now()):
                
        sStartLink = str(np.floor((max(time_end - dt.timedelta(days=30), time_start)).timestamp())*1000)
        sEndLink = str(np.ceil(time_end.timestamp())*1000)

        # TODO 2019-1-27: links noch fuer alle 3 (oder mehr) tools richtig machen
        if (sTool == 'GH'):
            sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.sDB + r'&s=' + sStartLink + '&e=' + sEndLink + r'&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'            

        elif (sTool == 'SE'):
            sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.sDB + r'&s=' + sStartLink + '&e=' + sEndLink + r'&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'
            
        else:
            print('konnte Tool-Kuerzel nicht einordnen, verwende IceVis fuer Link')
            sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.sDB + r'&s=' + sStartLink + '&e=' + sEndLink + r'&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'
                
        sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + self.sDB + f'&s={sStartLink}&e={sEndLink}&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'

        return(sLink)





    
    """
    function to collect sda and ts series and store them to .hd5-file, tailored
    for special query from SW, 2019-8-5
        
    parameters:
    -----------
        - path_csvs:        main directory with csv files (for all wtgs, the
                            data for the current wtg are in path_csvs/db 
                            [without 'cmrblba_'])
        - path_hd5:         destination directory where the hd5-files shall be
                            stored
                            note: NOT the directory W://... given above!!!
                                  the hd5-files here are different from them
                                  and only an auxiliary intermediate solution
                                  to analyse at least something that is
                                  available
        - time_start:       time from which the data should be updated
        - time_end:         time until which the data should be updated
    
    
    @author: Christian Kuehnert
    @modified: 2019-8-12
    
    """
    def update_sda_and_ts_SW20190805(self, path_csvs, path_dest, time_start=None, time_end=None, 
                   bSloppy=True):
    

        #lRes = []
        dict_stats = {'db': self.db}                 # return statistics about the data
        channels_to_check = []
        
        node_startstop = sNodes.startstop     # subnode for bookkeeping
        node_af = sNodes.af                 # subnode for sda                 
        node_at = sNodes.at                  # subnode for ts
        
        
        fn_hd5 = f'{path_dest}\\{self.db}.hd5'               # full hd5-file name
                    
        # test if existent, otherwise create it and initialize it
        # initialization function is somewhat different from that in 
        # update_hd5.py    
        try:        
            if not os.path.isfile(fn_hd5):                # if no such hd5-file
                with pd.HDFStore(fn_hd5, mode="w", complevel=9, 
                                 complib='blosc:lz4') as f:  # create empty hd5
                    f.close()
                                
            node = sNodes.turbine_info
        
            with pd.HDFStore(fn_hd5,'a',complevel=9, complib='blosc:lz4') as f:
    
                if not (node in f):
                    # set relevant data (farm, turbine etc.)
                    dict_info = {'farm': self.farm,
                                 'name': self.name,
                                 'db': self.db,
                                 'wtg_type': self.wtg_type,
                                 'manufacturer': self.manufacturer,
                                 'begin_data': self.begin_data,
                                 'begin_operational': self.begin_operational}
                
                    df_info = pd.DataFrame.from_records(dict_info, index=[0])
                    
                    f.put(node, df_info, format='table', data_columns=True, 
                          index=False)
                    
                bOk = True
    
        except:
            bOk = False

        
        
        # now update sda and ts
        
        # idee: EINEN Buchhaltungs-df, dort start und stop fuer sda und ts
        # diese jeweils darueber auslesen
        if not bOk:
            
            dict_stats.update({'files_af': np.NaN,
                               'files_at': np.NaN})
            
        else:
            
            fn_exist_at = []
            fn_exist_af = []
                
             # open hd5-file
            with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
    
                if (node_startstop in f):
                    df_ss = f.select(key=node_startstop)

                    ## TODO 2019-8-7: alles folgende noch eleganter und v.a. 
                    ## schneller machen!, z.B. mit (y,m,d,id, channel)-tupels als 
                    ## index fuer die Daten-Dataframes
                    ## 
                    ## create list of existing files, seperately for at and af
                    ## because af and at require different processing:
                    ## at has multiple files for one time series in the current
                    ## directory, af has one file for each spectrum in the given
                    ## directory. So the set differences for at comprise the 
                    ## folder names year/month/day/id only, the subfolders for 
                    ## af also the file names
                    for _idx, row in df_ss[df_ss.datatype=='at'].iterrows():                
                        #fn_exist.append((row['year'], row['month'], row['day'], f"at_{row['id']}_{row['channel']}"))
                        #fn_exist_at.append((f"{row['year']}/{row['month']}/{row['day']", fn_tmp) for fn_tmp in row['files']))
                        tmp = row['create_time']
                        fn_exist_at.append(row['create_time'].strftime(
                                '%Y\\%m\\%d\\') + f"{row['ID']}")
                        
                    for _idx, row in df_ss[df_ss.datatype=='af'].iterrows():
                        tmp = row['create_time']
                        fn_exist_af.append((row['create_time'].strftime(
                                '%Y\\%m\\%d\\') + f"{row['ID']}", row['file']))
    
    
                map_db = {'cmrblba_vid_v219441': 'vid_anstadblaheia_219441',
                          'cmrblba_vid_v219445': 'vid_anstadblaheia_219445',
                          'cmrblba_vid_v220933': 'vid_osterild_220933',
                          'cmrblba_vid_v228051': 'vid_osterild_228051',
                          'cmrblba_vid_v228051_1': 'vid_osterild_228051_1',
                          'cmrblba_vid_v228051_2': 'vid_osterild_228051_2',
                          'cmrblba_vid_v228051_3': 'vid_osterild_228051_3',
                          'cmrblba_vid_v216174': 'vid_roan_216174',
                          'cmrblba_vid_v216220': 'vid_roan_216220'}
    
    
                #path_files = f'{path_csvs}\\vid_{self.farm.replace(" - Testfeld", "").lower()}_{self.db.split("_")[-1].replace("v", "")}'     # String speziell fuer die special query 20190805
                path_files = f'{path_csvs}\\{map_db[self.db]}'
                print(path_files)
                                        
                # find all files
                list_af = []
                list_at = []
                for top, _cur, files in os.walk(path_files):                                        
                    tmp = top.replace(path_files + '\\', '')
                    #year, month, day, iid = top.replace(path_files).split('\\')
                    #list_af = [f'{path_files}/{fn}' for fn in files if (fn[:3]=='af_')]
                    #list_at = [f'{path_files}/{fn}' for fn in files if (fn[:3]=='at_')]
                    [list_af.append((tmp, fn)) for fn in files if ('af_' in fn)]
                    if any([('at_' in fn) for fn in files]):
                        list_at.append(tmp)
                    
                    
                dict_stats.update({'files_af': len(list_af),
                                   'files_at': len(list_at)})
                
                # new files
                list_af = list(set(list_af)-set(fn_exist_af))
                list_at = list(set(list_at)-set(fn_exist_at))
                
                
                # sort lists
                                                                                
                ## combine af-files, if any
                cnt = 1
                for (pn, fn) in list_af:
                    
                    if cnt % 100 == 0:
                        print(f'af: {cnt} / {len(list_af)}')
                    cnt += 1
                    
                    syear, smon, sday, siid = pn.split('\\')
                    tsCT = dt.datetime(int(syear), int(smon), int(sday))
                    try:
                        iid = int(siid)
                    except:
                        print('wait')
                    
                    fn_short = fn.replace('af_', '').replace('.csv.gz', '')      # remove 'af_' and 
                                                        # ending from file name
                                                                                                                
                    parts = fn_short.split('_')      # split (short) file name by '_'
                                                    
                    if parts[0] in ['edge', 'flap', 'radius']:
                        channel = f'{parts[0]}_{parts[-1]}'
                                
                    else:
                        # TODO 2019-8-7: alle numerischen '_..." entfernen (per regex?) und was uebrig ist als channel nehmen
                        n = len(parts)
                        if n==3:
                            channel = parts[0]
                        else:
                            channel = '_'.join(parts[0:n-3])
                                    
                    ## now aggregate the remaining files
                    try:
                        
                        dSDA = read_gz(f'{path_files}\\{pn}\\{fn}', tType=np.float64)                                 # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                                     
                        iCnt = len(dSDA)
                        if iCnt>0:
                            create_day = tsCT
                            # TODO 2019-8-8: create_day, id und filename dienen hier nur als doppelte Sicherheit, sie koennen
                            # weggelassen werden, wenn alles einwandfrei funktioniert
                            #df1 = pd.DataFrame(data=(np.tile([create_day, iID, sFN_short], [iCnt,1])), columns = ['create_day', 'ID', 'filename'])
                            df1 = pd.DataFrame(data=(np.tile([create_day, iid, fn], [iCnt,1])), columns = ['create_time', 'ID', 'file'])
                            df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCnt)), dSDA), axis=1)))
                            df2.columns = ['idx', 'a_f']
                            dfTmp = pd.concat((df1,df2), axis=1)

                            dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')                                        
                            dfTmp['ID'] = dfTmp['ID'].astype(int)
                            dfTmp['idx'] = dfTmp['idx'].astype(int)
                            
                            #iStart = f.get_storer(sNode_ts_data).nrows
                            f.append(node_af, dfTmp, format='table', 
                                     data_columns = True, index=False, 
                                     min_itemsize={'file': 50})
                            
                            # now add row numbers for start and stop for this time series
                            iStop = f.get_storer(node_af).nrows
                            iStart = iStop - dfTmp.shape[0]
                        
                        else:
                            iStart = -1
                            iStop = -1
      
                    except:
                        iStart = -1
                        iStop = -1
                        
                        
                    dfMap = pd.DataFrame(data=[[tsCT, iid, channel, 'af', fn, iStart, iStop]], 
                                         columns = ['create_time','ID','channel','datatype','file','start','stop'])
                    dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                    dfMap['ID'] = dfMap['ID'].astype(int)
                    dfMap['start'] = dfMap['start'].astype(np.int64)
                    dfMap['stop'] = dfMap['stop'].astype(np.int64)
                    f.append(node_startstop, dfMap, format='table', 
                             data_columns = True, index=False, 
                             min_itemsize={'channel': 30, 'file': 50})
                                                                                                                                                                                                                                                                                                                                
                                
                        
                ## combine at-files, if any
                cnt = 1              
                for pn in list_at:
                                    
                    if cnt % 100 == 0:
                        print(f'at: {cnt} / {len(list_at)}')
                    cnt += 1
                    
                    #if pn == '2019\\07\\31\\5596':
                    #    print('jetzt')
                         
                    path_tmp = f'{path_files}\\{pn}'
                       
                    syear, smon, sday, siid = pn.split('\\')
                    tsCT = dt.datetime(int(syear), int(smon), int(sday))
                    try:
                        iid = int(siid)
                    except:
                        print('wait')


                    
                    dict_at, channels_check = combine_at(path_tmp)
                    
                    for ch in channels_check:
                        print(f'{self.db}: channel {ch} kritisch (bei combine_ts fuer {path_tmp})!')
                        channels_to_check.append({'db': self.db, 
                                                  'channel': ch, 
                                                  'path': path_tmp})

                    for channel, df_at in dict_at.items():
                        try:

                            iCntTS = df_at.shape[0]
                            
                            if iCntTS>0:  

                                df1 = pd.DataFrame(data=(np.tile([tsCT, iid, channel], [iCntTS,1])), 
                                                   columns = ['create_time','ID','channel'])
                                
                                dfTmp = pd.concat((df1,df_at), axis=1)
        
                                dfTmp['create_time'] = pd.to_datetime(dfTmp['create_time'], errors='coerce')                                        
                                dfTmp['ID'] = dfTmp['ID'].astype(int)
                                dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                
                                f.append(node_at, dfTmp, format='table', 
                                         data_columns = True, index=False,
                                         min_itemsize={'channel': 30})

                                # now add row numbers for start and stop for this time series
                                iStop = f.get_storer(node_at).nrows
                                iStart = iStop - dfTmp.shape[0]
                                
                            else:
                                iStart = -1
                                iStop = -1
                          
                        except:
                            iStart = -1
                            iStop = -1
                            

                        dfMap = pd.DataFrame(data=[[tsCT, iid, channel, 'at', 
                                                    '', iStart, iStop]], 
                                             columns = ['create_time','ID',
                                                        'channel','datatype',
                                                        'file','start','stop'])
                        
                        dfMap['create_time'] = pd.to_datetime(
                                dfMap['create_time'], errors='coerce')
                        
                        dfMap['ID'] = dfMap['ID'].astype(int)
                        dfMap['start'] = dfMap['start'].astype(np.int64)
                        dfMap['stop'] = dfMap['stop'].astype(np.int64)
                        
                        f.append(node_startstop, dfMap, format='table', 
                                 data_columns = True, index=False, 
                                 min_itemsize={'channel': 30, 'file': 50})                

        return(dict_stats, channels_to_check)
    
    
    
    
    
    """
    implemented only for special query from 20190805 (see email from SW from 
    this date)
 
    
    function to update the ts data
    
    
    # TODO 2018-12-4: aufspalten in update_ts_fromCDEF(sDB, sPathData, dfCDEF) wo nur die in dfCDEF uebergebenen cycles upgedatet werden, und update_ts() wo die dfCDEF-cycles
    # wie hier implementiert bestimmt werden, und dann darauf update_ts_fromCDEF anwenden. D.h. 
    # TODO 2018-12-7: hier noch so implementieren, dass entweder 1) die sNode_ts_startstop eine Spalte enthaelt, ob ein folder ueberhaupt ts-daten enthaelt, der zugehoerige dataframe
    # ist dann bzgl. der Keys eine Kopie von dfCDEF, bei sloppy=True werden dann wirklich nur noch neue cycles durchsucht, oder 2) einen weitere node sNode_cycles anlegen, welche
    # eben alle cycles von dfCDEF enthaelt und jeweils eine spalte mit true/false oder 1/0 fuer ts-Daten und eine entsprechend fuer sda-Daten, dann mit dieser entsprechend arbeiten
    
    
    @modified: 2019-7-18
    
    """
    def update_ts(sDB, sPathData, time_start=None, time_end=None, iCntMeasBase = 8192, bSloppy=True):
    
        #lMsg = []
        lRes = []
        
        sDTFormat_hd5='%Y%m%d%H%M%S'
        
        sNode_cdef = sNodes.cdef               #  'raw_data/cdef'
        #sNode_ts = 'raw_data/ts'                                           # node where the time series data are stored
        sNode_ts_data = sNodes.ts_data          # sNode_ts + '/data'                                 # subnode with ts data
        sNode_ts_startstop = sNodes.ts_startstop          # sNode_ts + '/startstop'                        # subnode with row numbers of start and stop of each ts
           
        sHeadersKey = ['create_day', 'ID', 'channel']                     # headers of the columns that relate the ts data to the cdef data (except for create_day, here create_time is the opponent)
        
        sFN_hd5 = f'{sPathData}\\{sDB}.hd5'                 # full hd5-file name
        
        
        iCycles = 0        
    
    #TODO 2018-12-2: hier testen, ob so funktioniert, start und stop times muessen pd.Timestamps sein (auch testen, auch in dok schreiben!)
        with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
            if sNode_cdef in f:
    
    #TODO 2018-12-16: klaeren, ob die TS-Daten-Verfuegbarkeit auch hinterher in die Tabelle richtig eingetragen wird, falls die DAten erst nachtraegliche manuell per webVis geholt werden!!!            
                lWhere = ['available_data>2']                            # consider only cycles where sda-files were stored
                sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)
                                    
                if sWhere:
                    lWhere.append(sWhere)
                    
                sWhere = ' and '.join(lWhere)
                            
                dfCDEF = f.select(key=sNode_cdef, where=sWhere).copy()
                    
                iCycles = dfCDEF.shape[0]                                          # number of cycles                
    
        
        
        if iCycles>0:
                       
            with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
    
                ## create flag that indicates if the node already exists and has the correct type and (if
                ## all this is true) get the row numbers in the dataframe
    
                ## TODO 2018-12-2: assume that always both sNode_ts and sNode_ts_startstop are existent and synchronous, or both are not existent. 
                ## but to make this sure/have the possibility to check this, implement methods to check this synchronicity
                if (sNode_ts_data in f):
                    #if (type(f[sNode_ts]) is pd.DataFrame):
                    bCycEx = True
                    #iStop = f.get_storer(sNode_ts_data).nrows
                    dfCycTSEx = f.select(key=sNode_ts_startstop)			
                    
                    ## if only new cycles should be checked ...
                    ## NOTE: in case one or more channels from a cycle where not stored yet in 
                    ## the ts-node, bSloppy=True will prevent this function to add them to this node
                    ## For fast run assume that all cycles that are already in the ts-node are complete in the sense, that
                    ## they contain already all correct data. If you want complete check for new data also in the folders
                    ## from which already some data were read, then set bSloppy to False
    # 2018-12-5: Funktion noch testen mit bSloppy=True - Option
                    if bSloppy:
                        dfCDEF = setdifference_df(dfCDEF, dfCycTSEx, ['create_time', 'ID'])
                    
                                
                else:		# perhaps here otherwise create this node with empty set but correct columns
                    bCycEx = False
                    #iStop = -1
                    dfCycTSEx = pd.DataFrame(columns = ['create_time', 'ID', 'channel', 'overlap', 'start','stop'])
                
                                        
                iCycles = dfCDEF.shape[0]
    
                for i in range(iCycles):
                    
                    #tsCT = dfCDEF.create_time[i]                                       # current create_time
                    #iID = dfCDEF.ID[i]                                                 # current ID
                    tsCT = dfCDEF.iloc[i,:].loc['create_time']                          # current create_time
                    iID = dfCDEF.iloc[i,:].loc['ID']                                    # current ID
                                        
                    if (i % 20 == 0):
                        #                        print(sInfo)                   
                        print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID))
    
    
                    if not ((iID==0) or pd.isnull(tsCT)):
                                        
    #                    sInfo = sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID)
                            
                        sFolder = get_folder(sDB, tsCT, iID)                     # get folder for this create_time and ID
                                            
                        if os.path.isdir(sFolder):
            
                            sFiles = fnmatch.filter(listdir(sFolder), 'at_*_*.csv.gz')    # find files in folder that match the time-series-files-format                                                        
                                    
                            if len(sFiles)>0:
                                iChannels = np.unique([int(s.replace('.csv.gz','').split('_')[-1]) for s in sFiles])
            
                                #if (i % 20 > 0):
                                #    print(sInfo)
                                
                                #print('    files exist')
                                create_day = pd.to_datetime(tsCT.date(), errors='coerce')            # day of create_time
                                
                                ## find all ts-files in that folder that match the search pattern
                                ## and are not already stored in the .hd5-file
                                if bCycEx:                                              # if there are already existing time series
                                    
                                    #dfCycEx = f.select(sNode_ts, stop = iStop, columns = sHeadersKey, where=('(create_time=Timestamp("' + str(tsCT) + '")) and (index=' + str(iID) + ')'))                   # dataframe with cycle keys
                                    #dfCycEx = dfCycTSEx[(dfCycTSEx.create_day==create_day) & (dfCycTSEx.ID==iID)]
                                    dfCycEx = dfCycTSEx[(dfCycTSEx.create_time==tsCT) & (dfCycTSEx.ID==iID)]
    
                                    if dfCycEx.shape[0]>0:
                                        iChannels = list(set(iChannels)-set(dfCycEx.channel))                                
                                        #print('    already data, ' + str(len(iChannels)) + ' new channels')
                                
                                # TODO 2018-11-2: so umstellen, dass die Einzel-ZRn synchron betrachtet werden und dann der Overlap anhand der synchronen Einzelzeitreihen bestimmt wird                                    
                                lChAdded = []
                                for iCh in iChannels:
                                            
                                    sPattern = 'at_*_' + str(iCh) + '.csv.gz'           # pattern for the current channel
                                    sFilesCh = fnmatch.filter(sFiles, sPattern)         # all files in sFiles for that channel
            
                                    ## sort files by the measure-number
                                    iMeas = [int(s.replace('at_', '').replace('_'+str(iCh)+'.csv.gz', '')) for s in sFilesCh]
                                    sFilesCh = [sFilesCh[i] for i in np.argsort(iMeas)]                # sort list of these files, because order is importent for combining the data
                                             
                                    try:    
    
                                        ## now aggregate the remaining files                                
                                        listTS = []
                                        for sFN0 in sFilesCh:                    
                                            listTS.append(read_gz(f'{sFolder}\\{sFN0}'))     # unpack and load them, combine them to one long series each and then to one block of data
                                                                                                         
                                        ## combine the measurements if possible
                                        iTS, iOL = combine_ts(listTS, iCntMeasBase)                   
                                        
                                        iCntTS = len(iTS)
                                        if iCntTS>0:  
                                            
                                            #df1 = pd.DataFrame(data=(np.tile([tsCT, iID, iCh, iOL], [iCntTS,1])), columns = sHeadersKey + ['overlap'])
                                            df1 = pd.DataFrame(data=(np.tile([create_day, iID, iCh], [iCntTS,1])), columns = sHeadersKey)
                                            df2 = pd.DataFrame(data=(pd.concat((pd.Series(range(iCntTS)), iTS), axis=1)))
                                            df2.columns = ['idx', 'a_t']
                                            dfTmp = pd.concat((df1,df2), axis=1)
    
                                            dfTmp['create_day'] = pd.to_datetime(dfTmp['create_day'], errors='coerce')                                        
                                            #dfTmp['create_time'] = dfTmp['create_time'].astype(pd.Timestamp)
                                            dfTmp['ID'] = dfTmp['ID'].astype(int)
                                            dfTmp['channel'] = dfTmp['channel'].astype(int)
                                            dfTmp['idx'] = dfTmp['idx'].astype(int)
                                            dfTmp['a_t'] = dfTmp['a_t'].astype(float)
                                            
                                            #iStart = f.get_storer(sNode_ts_data).nrows
                                            f.append(sNode_ts_data, dfTmp, format='table', data_columns = True, index=False)    
                                            
                                            # now add row numbers for start and stop for this time series
                                            iStop = f.get_storer(sNode_ts_data).nrows
                                            iStart = iStop - dfTmp.shape[0]
                                            
                                            dfMap = pd.DataFrame(data=[[tsCT, iID, iCh, iOL, iStart, iStop]], columns = ['create_time','ID','channel','overlap','start','stop'])
                                            dfMap['create_time'] = pd.to_datetime(dfMap['create_time'], errors='coerce')
                                            dfMap['ID'] = dfMap['ID'].astype(int)
                                            dfMap['channel'] = dfMap['channel'].astype(int)
                                            dfMap['overlap'] = dfMap['overlap'].astype(int)
                                            dfMap['start'] = dfMap['start'].astype(np.int64)
                                            dfMap['stop'] = dfMap['stop'].astype(np.int64)
                                            f.append(sNode_ts_startstop, dfMap, format='table', data_columns = True, index=False)    
                                            
                                            lRes.append(dfMap)
                                            
                                            #lMsg.append(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                            #print(sInfo + ', ch ' + str(iCh) + ': new ts added')
                                            lChAdded.append(str(iCh))
                        
                                        #else:
                                        #    lMsg.append(sInfo + ', ch ' + str(iCh) + ': Einzelzeitreihen ungleich lang oder keine Vielfachen von ' + str(iCntMeasBase))
                                    
                                    except Exception as ex:
                                        #lMsg.append(sInfo + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
                                        print(sDB + '  ' + str(i) + '/' + str(iCycles) + ', day ' + tsCT.strftime('%Y\\%m\\%d') + ', ID ' + str(iID) + ', ch ' + str(iCh) + ': Probleme mit Entpacken oder Zusammenfuegen')
    
                                # information if time series were added
                                #if len(lChAdded)>0:
                                #    print(sInfo + ': ts for channels ' + ','.join(lChAdded) + ' added')
                     
        if len(lRes)==0:
            return(pd.DataFrame(columns=['create_time','ID','channel','overlap','start','stop']))
        else:
            dfRes = pd.concat(lRes, axis=0, ignore_index=True).reset_index()
            return(dfRes)
    
    
    
    

    """
    use the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine to calculate features
    with the passed function (handle)
    
    Parameters:
    -----------
    
    dfCyc :         pd.DataFrame containing the create_times/cycles for which the features should be calculated
    feat_fct :      function handle for feature-function
    feat_kwargs :   further parameters for the function handle
    
    
        
    Christian Kuehnert, 2019-1-2
    """
    def calc_features_from_ts(self, dfCyc=None, feat_fct=None, feat_kwargs=None):
        
        sHeadersKey = ['create_time', 'ID', 'channel']

        if isinstance(dfCyc, pd.DataFrame):
            
            if (dfCyc.shape[0]>0) and (set(sHeadersKey + ['start', 'stop']).issubset(dfCyc.columns)):
                
                ## now calculate and add features
                # TODO 2018-11-9: eleganter machen								
                lFeat = []
                sFN_hd5 = self.sPathData + '\\' + self.sDB + '.hd5'
                with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
                    for idx in range(dfCyc.shape[0]):
                    
                        ## TODO 2018-12-6: den Block hier kann man bestimmt auch noch schneller machen (z.B. dataframe erst NACH zusammenfuegen aller Werte)
                        ## --> ggf. modifizieren, falls (gemaess profiling) tatsaechlich bottleneck
                        tsCT, iID, iCh, iStart, iStop = dfCyc.loc[:, sHeadersKey + ['start', 'stop']].iloc[idx,:]
                        iTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t']).values[:,0]
                        #dfTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t'])
                        
                        #dfFeat = feat_fct(iTS, **kwargs['kwargs'])
                        #kwargs = feat_kwargs['kwargs']
                        kwargs = feat_kwargs
                        #dfFeat = feat_fct(iTS, **kwargs)
                        lFeat.append(feat_fct(iTS, **kwargs))
                    
#                        dfTmpF = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [dfFeat.shape[0], 1]))
#                        dfTmpF.set_index(dfFeat.index, inplace=True)                                            
#                        dfTmpF.columns = sHeadersKey
                    
                        #dfTmpF['create_time'] = pd.to_datetime(dfTmpF['create_time'], errors='coerce')                                        
                        #dfTmpF['ID'] = dfTmpF['ID'].astype(int)
                        #dfTmpF['channel'] = dfTmpF['channel'].astype(int)                                                                                            
                        
#                        lFeat.append(pd.concat([dfTmpF, dfFeat], axis=1))
                        

                dRes = np.vstack(lFeat)
                        
#                dfRes = pd.concat(lFeat, axis=0)
#                
#                dfRes['create_time'] = pd.to_datetime(dfRes['create_time'], errors='coerce')                                        
#                dfRes['ID'] = dfRes['ID'].astype(int)
#                dfRes['channel'] = dfRes['channel'].astype(int)                                                                                            
            
            else:
                print('dfCyc must not be empty and must contain the columns ' + ', '.join(sHeadersKey) + ', start, stop')
                # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
#                dfRes = pd.DataFrame(columns=sHeadersKey)
                dRes = np.array()
                                
        else:
            # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
            #dfRes = pd.DataFrame(columns=sHeadersKey)
            dRes = np.array()
            
            
        return(dRes)
        



    

    """
    use the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine to calculate features
    with the passed function (handle)
    
    Parameters:
    -----------
    
    dfKeys :    pd.DataFrame containing the create_times/cycles for which the features should be calculated
    fctHdl :    function handle for feature-function
    **kwargs :  further parameters for the function handle
    
    
        
    Christian Kuehnert, 2018-12-6
    """
    def calc_features_from_ts_old(self, dfCyc=None, feat_fct=None, feat_kwargs=None):
        
        sHeadersKey = ['create_time', 'ID', 'channel']        

        if isinstance(dfCyc, pd.DataFrame):
            
            if (dfCyc.shape[0]>0) and (set(sHeadersKey + ['start', 'stop']).issubset(dfCyc.columns)):
                
                ## now calculate and add features
                # TODO 2018-11-9: eleganter machen								
                lFeat = []
                sFN_hd5 = self.sPathData + '\\' + self.sDB + '.hd5'
                with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
                    for idx in range(dfCyc.shape[0]):
                    
                        ## TODO 2018-12-6: den Block hier kann man bestimmt auch noch schneller machen (z.B. dataframe erst NACH zusammenfuegen aller Werte)
                        ## --> ggf. modifizieren, falls (gemaess profiling) tatsaechlich bottleneck
                        tsCT, iID, iCh, iStart, iStop = dfCyc.loc[:, sHeadersKey + ['start', 'stop']].iloc[idx,:]
                        iTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t']).values[:,0]
                        #dfTS = f.select(self.__sNode_ts_data, start=iStart, stop=iStop, columns=['a_t'])
                        
                        #dfFeat = feat_fct(iTS, **kwargs['kwargs'])
                        #kwargs = feat_kwargs['kwargs']
                        kwargs = feat_kwargs
                        dfFeat = feat_fct(iTS, **kwargs)
                        #dfFeat = feat_fct(dfTS, **kwargs)
                    
                        dfTmpF = pd.DataFrame(data=np.tile([[tsCT, iID, iCh]], [dfFeat.shape[0], 1]))
                        dfTmpF.set_index(dfFeat.index, inplace=True)                                            
                        dfTmpF.columns = sHeadersKey
                                            
                        lFeat.append(pd.concat([dfTmpF, dfFeat], axis=1))
                        
                        
                dfRes = pd.concat(lFeat, axis=0)
                
                dfRes['create_time'] = pd.to_datetime(dfRes['create_time'], errors='coerce')                                        
                dfRes['ID'] = dfRes['ID'].astype(int)
                dfRes['channel'] = dfRes['channel'].astype(int)                                                                                            
            
            else:
                print('dfCyc must not be empty and must contain the columns ' + ', '.join(sHeadersKey) + ', start, stop')
                # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
                dfRes = pd.DataFrame(columns=sHeadersKey)
                                
        else:
            # TODO 2018-12-6: noch die Ergebnis-columns von feat_fct hinzufuegen
            dfRes = pd.DataFrame(columns=sHeadersKey)
            
            
        return(dfRes)
        



#
#    """
#    predict sensor state from the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
#    
#    Parameters:
#    -----------    
#        
#    Christian Kuehnert, 2018-12-6
#    """
#    def predict_sensor_state(self, sensor_classificator, sTimeStart = '', sTimeEnd = ''):
#
#        lTmp = []
#        if len(sTimeStart.strip()) == 0:
#            lTmp.append('create_time>=\'' + sTimeStart)
#        if len(sTimeEnd.strip()) == 0:
#            lTmp.append('create_time<=\'' + sTimeEnd)
#            
#        if len(lTmp)>0:
#            sFilterCDEF = ' and '.join(lTmp)
#        else:
#            sFilterCDEF = []
#                            
#                
#        dfCyc = self.get_data(list_nodes=[[self.__sNode_cdef, sFilterCDEF], [self.__sNode_ts_startstop, []]],
#                        list_columns=['create_time', 'ID', 'channel', 'omega_mean', 'wind_mean', 'power_mean', 'start', 'stop'],
#                        how='inner')
#
#        dfFeat = self.calc_features_from_ts(dfCyc=dfCyc, feat_fct=sensor_classificator.feat_fct, kwargs = sensor_classificator.feat_kwargs)
#                
#        iPred = sensor_classificator.model.predict(data=dfFeat)
#
#        return(iPred, dfCyc, dfFeat)


    """
    predict sensor state from the ts-data in the hd5-file that contains the raw data (cdef, ts, sda) for this turbine
    
    Parameters:
    -----------    
        
    Christian Kuehnert, 2018-12-17
    """
    def predict_sensor_state(self, dfCyc = None, sensor_classificator = None):
                                                   
        dfFeat = self.calc_features_from_ts(dfCyc=dfCyc, feat_fct=sensor_classificator.feat_fct, feat_kwargs = sensor_classificator.feat_kwargs)
    
        try:                
            iPred = sensor_classificator.predict(dfFeat)
        
        except:
            print('probleme mit prediction by model, perhaps not trained and no default?')
            iPred = np.tile(np.nan, [dfCyc.shape[0],1])
                    
            
        return(iPred, dfFeat)






    """
    check the sensor states for the special query from 2019-8-5, see email from
    that date
    
    
    Parameters:
    -----------
    
    dfCyc :         pd.DataFrame containing the create_times/cycles for which the features should be calculated
    feat_fct :      function handle for feature-function
    feat_kwargs :   further parameters for the function handle
    
    
        
    Christian Kuehnert, 2019-8-12
    """
    def check_sensor_states_specialQuery20190805(self):
    
        
        sHeaders= ['db', 'channel', 'create_time', 'iID', 'n', 'v_min',
                   'longest_plateau_min', 'count_min', 'v_max',
                   'longest_plateau_max', 'count_max']

        ## first check time series (if available)
        fn_hd5 = f'{self.path_hd5}\\{self.db}.hd5'    
                
        node_startstop = sNodes.startstop     # subnode for bookkeeping
        #node_af = sNodes.af                 # subnode for sda                 
        node_at = sNodes.at                  # subnode for ts

        # calculate and add features
        lFeat = []
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        
            tmp = f.select(node_startstop)
            dfCyc = tmp[tmp.datatype=='at']
            
            for idx, row in dfCyc.iterrows():
                    
                tsCT = row['create_time']
                iID = row['ID']
                channel = row['channel']
                                                
                iTS = f.select(node_at, 
                               start=row['start'], 
                               stop=row['stop'], 
                               columns=['a_t']).values[:,0]
                        
                # test for constance/defect
                #lFeat.append((self.db, channel, tsCT, iID, np.std(iTS)))
                if len(iTS)>0:
                    [length_data, v_min, longest_plateau_min, count_min, v_max, 
                     longest_plateau_max, count_max] = detect_extreme_plateaus(iTS)

                else:
                    length_data = 0
                    v_min = np.NaN
                    longest_plateau_min = np.NaN
                    count_min = np.NaN
                    v_max = np.NaN
                    longest_plateau_max = np.NaN
                    count_max = np.NaN


                lFeat.append((self.db, channel, tsCT, iID, length_data, v_min,
                              longest_plateau_min, count_min, v_max, 
                              longest_plateau_max, count_max))
 

               # test for overrun
                # test for ts-imbalance
                
                
#                kwargs = feat_kwargs
#                lFeat.append(feat_fct(iTS, **kwargs))
                                            
        #dRes = np.vstack(lFeat)
        if len(lFeat)>0:
            dfRes = pd.DataFrame.from_records(np.vstack(lFeat),
                                              columns = sHeaders)

        else:
            dfRes = pd.DataFrame(columns=sHeaders)
                                                                      
        return(dfRes)
        





    """
    get tickets by special keywords/text parts
    
    Christian Kuehnert, 2018-12-17
    """
    def get_tickets(self, sType = ''):
        
        if sType=='check_measLines':
            # TODO 2018-12-18: zunaechst 1:1-Nachbildung der Matlab-Fkt. 'getSensorStates.m', spaeter vereinfachen/eleganter/anders machen

            if self.dfTickets.shape[0]>0:
                
                sT = self.dfTickets.loc[:,'sTitle'].copy()
                sT.replace('(Eissensor Rotorblatt)(cmrbl)(100)(BLADEcontrol)(bladecontrol)(Bladecontrol)', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                
                #dfT.strip(inplace=True)
                
                sT.replace('([rR][bB][lL])', 'RBL', regex=True, inplace=True)
                sT.replace('([fF][lL][aA][pP])', 'Flap', regex=True, inplace=True)
                sT.replace('([eE][dD][gG][eE])', 'Edge', regex=True, inplace=True)
                
                sT.replace('(((vorrangig)(vor\sallem)(v\.a\.)(v\.\sa\.))(\s)*((Edge)(Flap)))', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
#                
                sT.replace('((Rotorblatt)(Blade:*))', 'RBL', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

                sT.replace('(R\-1\/2\/3)', 'RBL1,RBL2,RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                sT.replace('(((Blatt)(RBL)R)(\s|\-)?1)', 'RBL1', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                sT.replace('(((Blatt)(RBL)R)(\s|\-)?2)', 'RBL2', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                sT.replace('(((Blatt)(RBL)R)(\s|\-)?3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
                #dfT.replace('([(Blatt)|(RBL)|(RBL\-)|(R)|(R\-)]\s*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

                # Reduktion des cellarray mit den Ticket-Titeln auf die
                # Elemente, die relevante strings enthalten
                bI = sT.str.contains('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', regex=True, case=False)
#
#                % Tickets mit wenigstens einem der folgenden Ausdrücke
#                % werden ignoriert:
                sTmp = '(Falscheismeldung .*Peak ung.*nstig)' \
                    + '((alle )[0-9]*.?(ECU))' \
                    + '(alle Messprogramme)' \
                    + '(alle WEA ohne Eis am RBL)' \
                    + '((ECU).*(alle) ((im WP)(im PW))?(gleichzeitig))' \
                    + '(neue Werte alle)' \
                    + '((falsche Zeit).*( alle))' \
                    + '(nach Stromabschaltung)' \
                    + '((Datenl)((ue)(ü))(cken))' \
                    + '(keine externals)' \
                    + '(geringes Signal\-Rausch)' \
                    + '((Zuordnung).*(<->).*(Firewall vertauscht))' \
                    + '((alle)n?( WEA))'
                                        
                bI2 = sT.str.contains(sTmp, case=False, regex=True)
                
                bI3 = sT.str.contains('((RBL).*(def))', case=False, regex=True)
                
                bTmp = ~(bI | bI2) & bI3
                
                dfRel = self.dfTickets[bTmp]                                     # relevant tickets
                            

        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach
        elif sType =='check_DataAvailablility':
            
            sPatternRegEx = ['(ext.*fix)|( n\.e)|( externals )|(nicht erreichbar)|(mi[(ss)|ß]t nicht)|(keine externals)|',
                             '(eingefrorene Betriebsdaten)|(Betriebsdaten eingefroren)]']
            bTmp = sT.str.contains(sPatternRegEx, regex=True, case=False)                
            dfRel = self.dfTickets[bTmp]                                     # relevant tickets
                            


        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach        
        elif sType == 'check_TPV':
            
            sPatternRegEx = '((rbl|rotorbl*).*(def|tpv|tiefpass))'        
            bTmp = sT.str.contains(sPatternRegEx, regex=True, case=False)                
            dfRel = self.dfTickets[bTmp]                                     # relevant tickets

        else:
            print('unknown check-Type for Ticket finding')
            dfRel = pd.DataFrame(columns = self.dfTickets.columns)


        return(dfRel)
        
        
        
      
    """
    function to find the sensors with valid data, what 'valid' means is
    defined by the type of the fails type_fail
    
    Christian Kuehnert, 2019-8-15
    """    
    def get_valid_channels(self, type_fails = 'defekt_oder_TPV', 
                           map_channels = {0: 'e_101_flap',
                                           1: 'e_102_flap',
                                           2: 'e_103_flap',
                                           3: 'e_101_edge',
                                           4: 'e_102_edge',
                                           5: 'e_103_edge'}):
    
        # tickets for measure lines with problems
        # TODO 2019-8-15: urspruenglich so gedacht, pruefen, ob das mit dem 
        # untenstehenden auch richtig funktioniert!!!
        #dfTicketsCrit, dict_ch_tickets = get_relevant_tickets(df_tickets, 
        #                                                  sType = type_fails)
        dfTicketsCrit, dict_ch_tickets = self.get_tickets(sType = type_fails)
    
        channels_ok = []
        for k, [bFail, dfRelTickets] in dict_ch_tickets.items():
            if ~bFail:
                channels_ok.append(map_channels[k])
            else:
                if dfRelTickets[~(dfRelTickets.sStatus=='erledigt')].shape[0]==0:
                    channels_ok.append(map_channels[k])
    
        return(channels_ok)
            

  
    """
    function to load (se + cdef-) data from the hd5 files created by DS
    
    Christian Kuehnert, 2019-8-30
    """
    ## TODO 2019-8-30: erstmal Rumpffunktion, damit ich nicht jedesmal nachsehen muss, wie das Einlesen der .hd5-files
    ## funktioniert, spaeter noch mit dem Rest der Klasse zu verbinden usw.
    def load_data_from_hd5(self, time_interval = ('1970-01-01', '2100-01-01'), 
                           fband = None):

        loader = hdf5.SDALoader(self.path_hd5, fband=fband)
        self.sed = loader.load(time_interval)

    
    
    
    
       

    """
    plot ts of relative signal energy
    The dataframe df must have the create_time as index and the column headers
    e_101_edge etc. for the signal energies (at least the columns related to
    the direction)
    
    2020-7-7
    
    """
    @classmethod
    def plot_se(self, df, direction, tup_constants = None, xline = None,
                fn_img = None, title = '', xlim = None, ylabel=''):
        #, time_margin = timedelta(hours = .5)):

        try:
            ctime = df.index
            if (xlim is None):
                xlim = [ctime.min(), ctime.max()]
                
            cols_se = df.columns
            
#            colormap = {'e_101_edge': 'red',
#                        'e_102_edge': 'blue',
#                        'e_103_edge': 'green',
#                        'e_101_flap': 'red',
#                        'e_102_flap': 'blue',
#                        'e_103_flap': 'green'}
            
            # diagram for se without offsets
            #title = f'SE {direction}, {mode} offsets (n={df.shape[0]})'
            list_plot = [(ctime, df.loc[:, c].values, 
                {'ls': '-', 'color': self.colormap[c]}) for c in df.columns]
            legend = cols_se.to_list()
    
            for name, v, col in tup_constants:
                #legend.append(name)
                list_plot.append((xlim, [v, v], 
                                    {'ls': '--', 'color': col}))
                
            ymax = max(2, max([x[1] for x in tup_constants]))+.2
            if not(xline is None):
                list_plot.append(([xline, xline], [0, ymax], 
                                    {'ls': '--', 'color': 'black'}))
    
            dur = xlim[1]-xlim[0]
    
            if dur>= timedelta(days=10):
                fmt = '%#d.%#m.%#Y'
            else:
                fmt = '%#d.%#m.%#Y %#H:%M'
            
            myplot_fast2(list_plot, fn_img, s_title = title, 
                         legend=legend, figsize = (10,6),
                         x_lim = xlim,
                         y_lim = [0, ymax], sYLabel = ylabel, xticksrot = 30,
                         date_format = fmt)
  
        except:
            print('problem in function plot_se')
    
    