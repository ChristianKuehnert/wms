# -*- coding: utf-8 -*-
"""

@author: christian
"""

    
"""
creates instance of the issue class

Created on Tue Mar 26 02:22:23 2019
    
@author: Christian Kuehnert
@modified: 2019-7-30
"""          

#from monitor import class_issue
from monitor.class_issue import issue   #import class_turbine_mon as ctum

def create_issue(sDB, sErrorMsg = '', sAction = '', sLink = '', sTool = '', 
                 sTypeMail='', sLinkMail = '', bShort = True):
    
    return(issue(sDB = sDB, sErrorMsg = sErrorMsg, sAction = sAction, 
                 sLink = sLink, sTool = sTool, sTypeMail = sTypeMail, 
                 sLinkMail = sLinkMail, bShort = bShort))

