# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 01:37:35 2019

read parameter file and save result in dictionary

@author: Christian Kuehnert
@last_modified: 2020-2-10

"""
import sys
import ast
import pandas as pd
from os import path as osp
from dateutil import parser


# TODO 2019-2-20: evtl. noch default-dict uebergeben mit allen Parametern, die benoetigt werden, und dort dann nur diejenigen ersetzen, die in der Parameter-Datei gefunden werden
# TODO 2020-2-10: generischer machen, einfach dict mit allen key-value-Paaren
# zurueckgeben, die enthalten sind
def read_parameter_file(sFN):

    dfPar = pd.read_csv(sFN, index_col=['parameter'], sep=';', header=0, 
                        quotechar = '"', comment='#')
     
    # TODO 2020-2-10: auf neue Variante umstellen
    bNew = True
    if bNew:      
        res = {idx: row['value'] for idx, row in dfPar.iterrows()}
    
    else:
        res = {}
        res.update({'sWC_wt': ast.literal_eval(dfPar.loc['sWC_wt'].value)})
        res.update({'sPathSaveMain': ast.literal_eval(dfPar.loc['sPathSaveMain'].value)})
        res.update({'sPathData': ast.literal_eval(dfPar.loc['sPathData'].value)})
        res.update({'sPathTemplates': ast.literal_eval(dfPar.loc['sPathTemplates'].value)})
        res.update({'sPathClassificators': ast.literal_eval(dfPar.loc['sPathClassificators'].value)})
        
        try:
            bNoFileUpdate = not(ast.literal_eval(dfPar.loc['bUpdateDataFile'].value))
        except:
            bNoFileUpdate = True
        res.update({'bNoFileUpdate': bNoFileUpdate})
    
        try:
            ignore_file = ast.literal_eval(dfPar.loc['ignore_file'].value)
        except:
            ignore_file = None
        res.update({'ignore_file': ignore_file})
         
        try:
            dtTimeStart = parser.parse(ast.literal_eval(dfPar.loc['sTimeStart'].value))
            #bNoTimeStart = False
        except:
            dtTimeStart = None
            #bNoTimeStart = True
        #res.update({'dtTimeStart': dtTimeStart})
        res.update({'start_time': dtTimeStart})
        #res.update({'bNoTimeStart': bNoTimeStart})
    
        try:
            dtTimeEnd = parser.parse(ast.literal_eval(dfPar.loc['sTimeEnd'].value))
        except:
            dtTimeEnd = None
        res.update({'end_time': dtTimeEnd})

    
        try:
            bIceOnly = ast.literal_eval(dfPar.loc['bIceOnly'].value)
        except:
            bIceOnly = False
        res.update({'bIceOnly': bIceOnly})   
    
        try:
            dict_repeat = ast.literal_eval(dfPar.loc['dict_repeat'].value)
        except:
            dict_repeat = None
        res.update({'dict_repeat': dict_repeat})


    return(res)
    
    
    
    
    
        
"""
function to read in parameters from parameter file (TODO 2018-11-2: create GUI)

@modified: 2020-2-10
"""
def read_parameters(fn = 'parameters.csv', app_path = None):

    try:
        if (app_path is None):
            
            #### from https://stackoverflow.com/questions/404744/determining-application-path-in-a-python-exe-generated-by-pyinstaller     and    
            ####      https://stackoverflow.com/questions/17057544/how-can-i-extract-the-folder-path-from-file-path-in-python
            if getattr(sys, 'frozen', False):
                # If the application is run as a bundle, the pyInstaller bootloader
                # extends the sys module by a flag frozen=True and sets the app 
                # path into variable _MEIPASS'.
                app_path = sys._MEIPASS
            else:
                tmp = sys._getframe(1).f_globals
                #app_path = osp.dirname(osp.abspath(tmp['__file__']))
                app_path = osp.dirname(tmp['__file__'])
            
            
        df = pd.read_csv(app_path + '\\' + fn, index_col=['parameter'], 
                         sep=';', header=0, quotechar = '"', comment='#')
     
        pars = {idx: row['value'] for idx, row in df.iterrows()}

        bOk = True
        
    except:
        print(f'parameters from file {app_path}\\{fn} could not be read in')
        
        pars = None
        bOk = False
        
    return(pars, bOk)



"""
function to get parameter from parameters, if contained, otherwise return None

@modified: 2020-2-11
"""
def get_param(params, key, alternative = None, fct = None):
    try:
        if (fct is None):
            return(params[key])
        else:
              return(fct(params[key]))
            
    except:
        return(alternative)

