# -*- coding: utf-8 -*-

import os
import win32com.client as win32


"""
creates mail for customers
TODO 2019-2-25: eleganter und generischer machen!

Created on Wed Feb 20 16:32:04 2019
@author: Christian Kuehnert
@modified: 2019-7-30
"""        
#def create_mail(tb, sType, sRecipients, sRecipientsCC):
def create_email(sFarm, sWT, sRecipients, sRecipientsCC, sPath_oft, 
                 sType='data_fix', sLanguage='deu'):
                
    ## TODO 2019-2-25: hier evtl. header-dictionary definieren
    #dict_header = {'ECUne_eng':  ...}
    sMailType = sType + '__' + sLanguage
    
    
    sFN = sPath_oft + '\\' + sMailType + '.htm'
    if os.path.isfile(sFN):    
    
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
                
        if sRecipients:
            mail.To = sRecipients
            
        if sRecipientsCC:
            mail.CC = sRecipientsCC
    
        sText = ''
        with open(sFN, 'r') as f_template:
            sText = f_template.read()            
            mail.HtmlBody = (sText.replace('<REPLACE_FARM>', sFarm)
                                    .replace('<REPLACE_TURBINE>', sWT))
            
    else:
        mail = None

    return(mail)
    

