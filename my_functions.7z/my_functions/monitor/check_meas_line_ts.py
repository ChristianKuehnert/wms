# -*- coding: utf-8 -*-
"""
function to check if measuring line are ok by ts method

Created on Tue Mar 26 02:38:28 2019

@author: Christian Kuehnert
@last_modified: 2019-3-26


example:
--------
  
import numpy as np
import pandas as pd
import datetime as dt
import sys

sys.path.append(r'C:\Repositories\python\functions')        # path to modules  
import myFunctions_data as mfdata
import myFunctions_monitor as mfmon
sys.path.append(r'C:\Repositories\python\sensor_classification')
import class_sensor_classificator as csc
   

db = 'cmrblba_bc_t_02758'
channels = [3,4,5]
start_time = dt.datetime(2018,12,2,4,0,0)
end_time = start_time + dt.timedelta(days=2)
sPathData = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\data\hd5_files'
sc = csc.classifierTemplate(name = 'asym', param=None, feat_fct = mfdata.asym_feat, feat_kwargs = {'iOrderDiff': 1, 'dQ': 0.99}, predict_fct = mfdata.asym_predict, predict_kwargs = {'dThreshold': 0.0015})
#sc = csc.classifierTemplate(name = 'ts', ... param=None, feat_fct = mfdata.ts_feat, feat_kwargs = {'iOrderDiff': 1, 'dQ': 0.99}, predict_fct = mfdata.asym_predict, predict_kwargs = {'dThreshold': 0.0015})
dfRes, issues = mfmon.check_meas_line_ts(db, channels, start_time, end_time, sPathData=sPathData, sensor_classificator=sc)

"""

import datetime as dt
import pandas as pd
import numpy as np
import data as mfdata
import class_turbine as ctb

#from class_issue import issue   #import class_turbine_mon as ctum
from data.class_hd5Nodes import hd5Nodes as sNodes
from monitor import create_link, create_issue


def check_meas_line_ts(db, channels, start_time, end_time, sPathData = '', sensor_classificator = None):
	
    issues = []
    sTool = 'SE'
    
    #bUpdate = True
	
    # TODO 2019-2-28: spaeter ersetzen durch Abfrage von Dirks hd5-file
#    if bUpdate:
    mfdata.update_ts(db, sPathData, time_start=start_time, time_end=end_time)
    sWC = mfdata.whereClause_from_timeInterval(time_start=start_time, time_end=end_time)
    dfCyc = mfdata.get_data(db, sPathData, [[sNodes.ts_startstop, sWC + ' and channel<6']], ['create_time', 'ID', 'channel','start','stop'])    
    
#	else:						## ohne update:
#		lWC = [get_wc_from_time_interval(start_time, end_time), 
#				"available_data>=3", 
#				"cycle_id IS NOT NULL", 
#				"create_time IS NOT NULL", 
#				"channel<6"]				
#		sWC = " AND ".join(lWC)
#		dfCyc = get_data_fromDB(db, 'ba_cycle_measurement_cycle', sWC)
						
						
    if dfCyc.shape[0]==0:
        issues.append(create_issue(db,
                                   sErrorMsg='keine Zeitdaten gefunden',
                                   sAction='manuell ansehen',
                                   sLink=create_link(db, sTool=sTool, 
                                                     start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), 
                                                     end_time = end_time+dt.timedelta(hours=4)),
                                                     sTool=sTool))
    else:
								
        try:
            tb =  ctb.turbine(sPathData=sPathData) 
            tb.init_from_db(db)
            iPred, dfFeat = tb.predict_sensor_state(dfCyc, sensor_classificator)
								
            # TODO 2019-1-17: stimmt das so???
            bCrit = [i==1 for i in iPred]
								
            # if any errornous channels were detected ..
            if any(bCrit):									
                dfCyc = dfCyc[bCrit]
                dfCyc = dfCyc.assign(origin=pd.Series(np.tile('ts', (dfCyc.shape[0],))).values)          # add column with method (ts)
														
        except:
            issues.append(create_issue(db,
                                       sErrorMsg='unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode',
                                       sAction='manuell ansehen',
                                       sLink=create_link(db, sTool=sTool, 
                                                         start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), 
                                                         end_time = end_time+dt.timedelta(hours=4)),
                                                         sTool=sTool))
                        
            #print('unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode')
            dfCyc = None
								    
    return dfCyc, issues

