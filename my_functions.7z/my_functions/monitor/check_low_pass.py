# -*- coding: utf-8 -*-
"""
function to check if low-pass behaviour occurs

Created on Tue Mar 26 02:57:28 2019

@author: Christian Kuehnert
@last_modified: 2019-2-20

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_low_pass(db, tickets, checks, issues, start_time, end_time):
    pass
    #issues = []    
    
    #return issues

