# -*- coding: utf-8 -*-
"""
get basic information and combine them to strings for text and for name parts of files and folders
    
Created on Tue Mar 26 01:44:58 2019

@author: Christian Kuehnert
@last_modified: 2019-2-20
"""
import re
from dateutil import parser

def get_start_time(tb):
    sTmp = tb['dtLastMonitoring']
    if sTmp:
        sLastMon =re.sub(r'(:[a-zA-ZäöüßÄÖÜ0-9: ]+)]*','', sTmp)
        time_last_mon = parser.parse(sLastMon)
    else:            
        time_last_mon = tb['dtStartCollectData']
  
    return(time_last_mon)

