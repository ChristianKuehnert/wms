# -*- coding: utf-8 -*-
"""
Created on Mon Dec 10 11:06:59 2018

@author: Christian Kuehnert (w012028)
@modified: 2019-7-30

"""
class issue:
    
    def __init__(self,
                 sFarm = '',
                 sWT = '',
                 sDB = '',
                 #sSystem = None,        # Condition Monitoring System, Ice Detector etc.
                 sTool = '',          # which webVis-tool generates the permalink? (GH - graphical history, SE - signal energy etc.)
                 sErrorMsg = '',
                 #iErrorClass = None,
                 sAction = '',
                 sLink = '',
                 bShort = True,
                 sTypeMail = '',
                 sLinkMail = ''):
                 #sText = None):
        
        
        self.farm = sFarm
        self.wt = sWT
        self.db = sDB
        #self.system = sSystem
        self.tool = sTool
        self.error_msg = sErrorMsg
        #self.error_class = iErrorClass
        self.action = sAction
        self.link = sLink
        self.short = bShort
        self.type_mail = sTypeMail
        self.link_mail = sLinkMail
        #self.text = sText
        
        
        
        
    """
    create text to be send by mail to SW, DB etc.
    
    2019-7-30
    """
    def create_text(self):
        lText = []
        sFarm = self.farm.__str__()
        sWt = self.wt.__str__()
        sDB = self.db.__str__()
        sErrorMsg = self.error_msg.__str__()
        #sSystem = self.system.__str__()
        sAction = self.action.__str__()
        sTool = self.tool.__str__()
        sLink = self.link.__str__()        
        
        
        if len(self.action)>0:
            lText.append(f'-{sFarm}, {sWt} ({sDB}): {sErrorMsg} -> {sAction}')
        else:            
            lText.append(f'-{sFarm}, {sWt} ({sDB}): {sErrorMsg}')
            
        #lText.append('Permalink: ' + sSystem + ' - ' + sFarm + ', ' + sWt + ' (' + sTool + ')')
        lText.append(f'Permalink: {sFarm}, {sWt} ({sTool})')
        lText.append(sLink)
        
        #return('\n'.join(lText))
        return('<br />'.join(lText))
                
    