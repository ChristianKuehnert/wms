# -*- coding: utf-8 -*-
"""
class for turbine for automatic offset calculation

Created on Thu Dec  6 2018
last modified: 2019-10-2

@author: Christian Kuehnert (w012028)


Properties:
-----------
    
    
"""

    
#from myFunctions_data import combine_filters\
import pandas as pd
import numpy as np
import datetime as dt
import gc
import sys
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from mpl_toolkits.axes_grid1 import make_axes_locatable
#from scipy.signal import savgol_filter


       
#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\functions'
sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
sys.path.append(sModulePath)    

import data as mfdata
from class_turbine import turbine
import monitor as mfmon
#import plot as mfplot
#import plot.myFunctions_plot as mfplot

sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht')
from functions_aeroimb import collect_hd5_data, load_data_multiple_hd5files
from functions_aeroimb import get_begin_end


#all_channels = [item for sublist in dict_directions.values() for item in sublist]



"""
class for calculating the offset values

2020-7-4
"""
class turbine_offset(turbine):

    """
    initialization
    
    Christian Kuehnert, 2019-9-19
    
    for offset calculation some more information are necessary then for e.g. 
    sensor failure classification
    
    """
    def __init__(self,
                 farm = None,
                 name = None,
                 db = None,
                 begin_data = None,
                 begin_operational = None,
                 manufacturer = None,
                 wtg_type = None,                    # WEA-Typ
                 system_type = None,              # Systemart (BC, V, ...)
                 tickets = pd.DataFrame(), 
                 path_hd5 = '',
                 band = [150, 350],
                 map_channels = {0: 'e_101_flap',
                                 1: 'e_102_flap',
                                 2: 'e_103_flap',
                                 3: 'e_101_edge',
                                 4: 'e_102_edge',
                                 5: 'e_103_edge'},  
                 periods = None,
                 start_time = None,
                 end_time = None,
                 cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                              'wind_mean', 'omega_sigma', 'power_sigma', 
                              'pitch_sigma', 'cyc_status_eval']):
                                
        turbine.__init__(self, farm = farm, name = name, db = db, 
                         wtg_type = wtg_type, manufacturer = manufacturer,
                         begin_data = begin_data, 
                         begin_operational = begin_operational,
                         tickets = tickets, path_hd5 = path_hd5,
                         map_channels = map_channels)
        
        #self.current_prefs = self.get_current_prefs()
        self.get_sens_status()

        self.band = band         # frequency range for which the offset will
                                 # be calculated
        self.df_se = None
        self.content = {}
        
        self.periods = [(None, None)]
        self.start_time = start_time            
        self.end_time = end_time
        
        self.cols_cdef = cols_cdef
        self.exclude = []

        #self.offsets_old = []
        
        
        
        
    """
    set times
    2019-9-19
    """
    def set_times(self, periods):
        
        self.periods = periods
        st, et = get_begin_end(periods)
    
        self.start_time = st
        self.end_time = et
 
#    def set_times(self, start_time, end_time):
#        self.start_time = start_time
#        self.end_time = end_time
# 
    

    """
    exclude channels
    2019-9-24
    """
    def exclude_channels(self, exclude):
        self.exclude = exclude




#    """
#    function to get list of channels from channel dictionary
#    2020-7-4
#    """
#    def get_channel_list(self, dict_directions=None):        
#        if (dict_directions is None):
#            dict_directions = self.dict_directions
#        return([el for sublist in dict_directions.values() for el in sublist])


    
    """
    function to return dictionary with the not-exluded channels
    2019-9-24
    """
    def remaining_channels(self):
#        exc = self.exclude
#        dci = self.dict_directions.items()
#        tmp = {k: list(set(v)-set(exc)) for k, v in dci}
#        
        return({k: sorted(list(set(v)-set(self.exclude))) for k, v in 
                self.dict_directions.items()})
        
        



#    """
#    ALTE VERSION, INZWISCHEN ZU class_turbine VERSCHOBEN
#
#
#    get relevant prefs
#    
#    Christian Kuehnert, 2019-9-24
#    """
#    def get_sens_status(self, include_all=True):
#        
#        #dict_prefs = mfdata.get_preferences(db)
#        try:
#            self.get_preferences()
#            
#            if include_all:
#                chs = self.get_channel_list(self.dict_directions)
#            else:
#                chs = self.get_channel_list(self.remaining_channels())
#                
#            
#            #'e_101_edge'
#            activity = [self.prefs[f"Sensor.Blade#{ch.replace('e_10','').replace('_edge', '.Edge').replace('_flap', '.Flap')}@Activity"] for ch in chs]
#            #offsets = [self.prefs[f"Sensor.Blade#{ch.replace('e_10','').replace('_edge', '.Edge').replace('_flap', '.Flap')}@Offset"] for ch in chs]
#            offsets = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}Offset"] for ch in chs]
#            warnlevel = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}WarnLevel"] for ch in chs]
#            alarmlevel = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}AlarmLevel"] for ch in chs]
#                        
#            #activity = [self.prefs[f'Sensor.Blade#{i}.Edge@Activity'] for i in range(1,4)] + [self.prefs[f'Sensor.Blade#{i}.Flap@Activity'] for i in range(1,4)]
#            #offsets = [self.prefs[f'Sensor.Blade#{i}.Edge@Offset'] for i in range(1,4)] + [self.prefs[f'Sensor.Blade#{i}.Flap@Offset'] for i in range(1,4)]
#            #warnlevel = [self.prefs[f'Sda10{i}EdgeWarnLevel'] for i in range(1,4)] + [self.prefs[f'Sda10{i}FlapWarnLevel'] for i in range(1,4)]
#            #alarmlevel = [self.prefs[f'Sda10{i}EdgeAlarmLevel'] for i in range(1,4)] + [self.prefs[f'Sda10{i}FlapAlarmLevel'] for i in range(1,4)]
#            #self.offsets_old = dict(zip(chs, offsets))
#                               
#            df = pd.DataFrame({'activity': activity, 
#                               'offsets': offsets,
#                               'warnlevel': warnlevel,
#                               'alarmlevel': alarmlevel}, 
#                                index=chs)
#        
#            self.sens_status = df
#            
#        except Exception:
#            self.sens_status = None
#            #self.offsets_old = {}
##        
##        return(df)
#    


        
        
#    """    
#    get the relevant tickets for the offset data period and the channels, for 
#    which these tickets are relevant 
#    
#    2020-7-6
#    """
#    #def check_channels(self, include_all=True):
#    def check_channels(self):
#
#        map_inv = {v:k for k,v in self.map_channels.items()}
#
##        if include_all:
#        chs = self.get_channel_list()
##        else:
##            chs = self.get_channel_list(self.remaining_channels())
##            map_inv = {k:v for k,v in map_inv.items() if k in chs}
#            
#        res = {ch: None for ch in chs}
#        
#        ## get tickets for the channels without regarding the period
#        dfTksCrit, dict_ch_tks = mfmon.get_relevant_tickets(self.tickets, 
#                                                    sType = 'all_rbl_related')
#                                                        
#        for ch in chs:
#            [bFail, dfRelTickets] = dict_ch_tks[map_inv[ch]]
#            if bFail:
#                df = dfRelTickets[((dfRelTickets.dtFirstOcc<=self.end_time) & \
#                        (~(dfRelTickets.sStatus=='erledigt')) | \
#                        (dfRelTickets.dtErrorFixed >= self.start_time))]
#            
#                if df.shape[0]>0:
#                    res[ch] = df
#                                    
#        return(res, dfTksCrit)




        
#    """    
#    get the relevant tickets for the offset data period and the channels, for 
#    which these tickets are relevant 
#    
#    2019-9-19
#    """
#    # TODO 2019-9-19: spaeter noch schoener gestalten, vielleicht in 1 Tab.
#    # zusammen mit den Preferences s.o. zusammenfassen und kritische Channels
#    # farblich hervorheben, jetzt erstmal allereinfachste Warnung
#    def check_channels_old(self, channels):
#        
#        ch_warn = []
#        
#        ## get tickets for the channels without regarding the period
#        dfTksCrit, dict_ch_tks = mfmon.get_relevant_tickets(self.tickets, 
#                                                    sType = 'all_rbl_related')
#                
#        if self.prefs is None:
#            ch_warn.append('keine Preferences gefunden, kann nicht pruefen, welche Kanaele aktiv sind')
#            
#        else:            
#            # note that activity is string format!
#            tmp = list(set(channels)-set(self.sens_status[self.sens_status
#                                               .activity=='1'].index))
#            if len(tmp)>0:
#                ch_warn.append('folgende der ausgewählten Kanäle sind nicht '
#                               + 'aktiv: ' + ', '.join(tmp))
#            
#                            
#        tmp = []
#        map_inv = {v:k for k,v in self.map_channels.items()}
#        for ch in channels:
#            [bFail, dfRelTickets] = dict_ch_tks[map_inv[ch]]
#            if bFail & ((dfRelTickets.dtFirstOcc <= self.end_time) & \
#                        (~(dfRelTickets.sStatus=='erledigt')) | \
#                        (dfRelTickets.dtErrorFixed >= self.start_time)).any():
#            
#                tmp.append(ch)
#                
#        if len(tmp)>0:
#            ch_warn.append('folgende der ausgewählten Kanäle haben für den '
#                         + 'betrachteten Zeitraum relevante Tickets: '
#                         + ', '.join(tmp))
#                            
#        #return(ch_warnings)
#        self.content.update({'channel_warnings': ch_warn})



    """
    save sda-data to split hd5-files
    
    @modified: 2019-9-19
    """
    def collect_data_hd5(self):
        collect_hd5_data(self.path_hd5, self.db, periods = self.periods)
        



    """
    function to load the data from the multiple hd5-files and combine them and 
    -if this option is selected- adjust the signal energy   
    
    @modified: 2019-12-5
    
    """
    def load_data_from_hd5(self, channels=None, filters={}):
                
        if channels is None:
            channels = self.get_channel_list(self.remaining_channels())    
        
        self.df_se = load_data_multiple_hd5files(self.path_hd5, self.db, 
                                                 channels, self.cols_cdef,
                                                 [(self.start_time, 
                                                  self.end_time)],
                                                 filters = filters, 
                                                 band = self.band)

    
    
    
    
    """
    function to calculate the offsets for the channels, excluding the 
    channels to be excluded (maximum 1 per direction)
    
    Properties:
    -----------
        - exclude:  list of names of channels to exclude
        - q:        value for percentile
    
    2019-10-2
    """
    def calc_offsets(self, se_min=None, se_max=None, bOldOffsets = True):
        
        msg = []
        dict_data = {}
        lres = []
                
        for d, cols_se in self.remaining_channels().items():
        
            if (len(cols_se)<2):
                msg.append((f'less than 2 channels for {d}, cannot calculate '
                            'relative signal energy'))
            
                dict_data.update({d: None})
                    
            else:
                
                ## TODO 2019-12-13: folgendes noch in Extra-Funktion auslagern,
                ## da auch von check_se_limits verwendet
                # filter for se-limits of the se-series
                df = self.df_se
                
                ltmp = []
                if se_min:
                    ltmp.append((df.loc[:, cols_se] <= se_min/498).any(axis=1))
                    
                if se_max:
                    ltmp.append((df.loc[:, cols_se] >= se_max/498).any(axis=1))
                                    
                if len(ltmp)>0:
                    btmp = np.vstack(ltmp).T.any(axis=1)            
                    if any(btmp):
                        idx = df[btmp].index
                        df.drop(index=idx, errors = 'ignore', inplace = True)

                if not(df.empty):
                    
                    #se_rel = mfdata.get_relative_se(df, cols_se)
                    se_rel = mfdata.get_relative_se(df.loc[:, cols_se].values)
                                    
                    se_rel_mean = se_rel.mean(axis=0)
                    se_rel_mean_mean = se_rel_mean.mean()
                    #offsets = [df_se_rel_mean.loc[:, col] - df_se_mean_mean.loc[:, col] for col in cols_se]
                    offsets = 1 - se_rel_mean/se_rel_mean_mean
        
                                                
                    # calculate the offsets
                    # mean for each channel, np.ndarrays
                    ctime = df.index
                    
                    ## shall the new ts with new offsets compared against ts
                    ## with the old offsets (True) or against the ts without
                    ## any offsets (False)
                    # TODO 2019-10-2: eleganter machen!
                    se_rel_old = se_rel.copy()
                    if bOldOffsets:
                        ix_col=0
                        for col in cols_se:                            
                            #offs = self.offsets_old[col]
                            offs = float(self.sens_status.offsets[col])
                            se_rel_old[:, ix_col] = se_rel[:, ix_col] + offs
                            ix_col += 1
                        
                    q99 = np.percentile(se_rel_old, 0.99, axis=0)    
                    df_rel = pd.DataFrame(se_rel_old, columns=cols_se, 
                                          index=ctime)            
                
                    counts = df.loc[:, cols_se].count(axis=0)
                    #counts = df.shape[0]
                    mins = df.loc[:, cols_se].min(axis=0)
                    means = df.loc[:, cols_se].mean(axis=0)
                    maxs = df.loc[:, cols_se].max(axis=0)
    
                    ## calculate the quantiles for the warning and alarm thresholds
                    se_rel_corr = se_rel + offsets
    
                    df_rel_corr = pd.DataFrame(se_rel_corr, columns=cols_se, 
                                               index=ctime)            
    
                    q99_corr = np.percentile(se_rel_corr, 0.99, axis=0)
                    max_corr = se_rel_corr.max(axis=0)
                    
                    #dict_res.update({d: [chs_calc, offsets, se_rel]})
                    lres.append(pd.DataFrame({'offset': offsets, 
                                              'count': counts,
                                              'se_min': mins,
                                              'se_means': means, 
                                              'se_max': maxs,
                                              'se_max_corr': max_corr,
                                              'se_rel_q99': q99, 
                                              'se_rel_corr_q99': q99_corr},
                                                  index = cols_se))
                
                    dict_data.update({d: {'df': df,
                                         #'df_rel_without': df_rel,
                                         #'df_rel_with': df_rel_corr#,
                                         'df_rel_old': df_rel,
                                         'df_rel_new': df_rel_corr#,
                                         #'df_stats': df_stats
                                         }})
            
            
        if len(lres)>0:        
            df_os = pd.concat(lres)            
        else:
            df_os = pd.DataFrame(columns = ['offset', 'count', 'se_min', 
                                            'se_means','se_max', 'se_max_corr',
                                            'se_rel_q99', 'se_rel_corr_q99'])
            
        return(df_os, dict_data)



    
    
    """
    function to plot histograms of production data

    2019-9-24
    """            
    def plot_hist(self, path_save, df, variable, title_part, bin_factor):
        fn = f'{path_save}\\{variable}_hist.png'
        title = f'{self.db}, Histogram {title_part}'
        itmp = int(np.ceil(df.loc[:, [variable]].max()*bin_factor))
        fig = (df.rename(columns={variable: title_part})
                    .hist(column=title_part, figsize=(20,15), 
                          bins = np.linspace(0, itmp/bin_factor, itmp+1)))
        fig.savefigure(fn)
        return({'filename': fn, 'caption': title})





    """
    function to plot time series of production data

    2019-9-24
    """            
    def plot_ts(self, path_save, df, variable, title_part):
        fn = f'{path_save}\\{variable}_ts.png'
        title = f'{self.db}, Zeitverlauf {title_part}'
        fig = self.plot(x = 'index', y = variable, figsize=(20,15), 
                              **{'title': title}).get_figure()

        fig.savefigure(fn)
        return({'filename': fn, 'caption': title})




   

    """
    plot ts of relative signal energy
    2020-7-3
    
    """
    def plot_ts_rel(self, df, direction, mode, path_save, fn_img):
        
        colormap = {'e_101_edge': 'red', 
                    'e_102_edge': 'blue',
                    'e_103_edge': 'green',
                    'e_101_flap': 'red',
                    'e_102_flap': 'blue',
                    'e_103_flap': 'green'}
        
        # diagram for se without offsets
        fn_img_full = f'{path_save}\\{fn_img}'
        #title = f'SE {direction}, {mode} offsets (n={df.shape[0]})'
        title = f'SE {direction}, with {mode} offsets'
        sYLabel = f'SE(150-350Hz), {direction}, with {mode} offsets'

        q99 = np.percentile(df.values, 99, axis=0)            
        tup_constants = [(df.columns[i], q99[i], colormap[df.columns[i]]) for i in range(len(df.columns))]        

        self.plot_se(df, direction, tup_constants = tup_constants, 
                     fn_img = fn_img_full, title = title, 
                     ylabel = sYLabel)
        
 
#    """
#    plot ts of relative signal energy
#    2019-9-24
#    
#    """
#    def plot_ts_rel(self, df, direction, mode, path_save, fn_img):
#
#        ctime = df.index
#        cols_se = df.columns
#        
#        colormap = {'e_101_edge': 'red',
#                    'e_102_edge': 'blue',
#                    'e_103_edge': 'green',
#                    'e_101_flap': 'red',
#                    'e_102_flap': 'blue',
#                    'e_103_flap': 'green'}
#        
#        # diagram for se without offsets
#        fn_img_full = f'{path_save}\\{fn_img}'
#        #title = f'SE {direction}, {mode} offsets (n={df.shape[0]})'
#        title = f'SE {direction}, with {mode} offsets'
#
#        q99 = np.percentile(df.values, 99, axis=0)            
#        
#        list_se = [(ctime, df.loc[:, c].values, 
#                {'ls': '-', 'color': colormap[c]}) for c in df.columns]
#
#        list_q = [([ctime.min(), ctime.max()], [q99[i], q99[i]], 
#                    {'ls': '--', 'color': colormap[df.columns[i]]}) 
#                    for i in range(df.shape[1])]
#
#        mfplot.myplot(fn_img_full, list_se + list_q, s_title = title, 
#                      legend = cols_se.to_list() + [s + ', q99' for s in cols_se], 
#                      y_lim = [0, 2],
#                sYLabel = f'SE(150-350Hz), {direction}, with {mode} offsets')

 

    """
    function to plot the deviations of the corrected rel. se vs. several
    production data
    
    2019-10-29
    """            
    def plot_deviations(self, path_save, fn_img, df, var_x, list_vars_y, 
                             count_bins=50, title='', ylim = None):
        
        ny = len(list_vars_y)
        
        #fn = f'{path_save}\\{var_x}_deviation.png'
        #title = f'{self.db}, Abweichung {title_part}'
        
        # create figure 
        fig = plt.figure(figsize=(24, 15), dpi= 300)
#        fig = plt.figure(figsize=(4, 2), dpi= 100)
        
        # create gridspec for 1+1 columns (diagrams + histograms se) and
        # number of rows = number of se-variables to be plotted + 1 for 
        # histogram production data
        widths = [1, 8]
        heights = list(np.tile(4, (ny,1))) + [ny]
                    
        gs = plt.GridSpec(nrows = ny + 1, ncols = 2, 
                          width_ratios=widths, height_ratios=heights, 
                          hspace=0.1, wspace=0.05)

        # range for se
        if (ylim is None):
            ylim = [df.loc[:, list_vars_y].min().min(),
                    df.loc[:, list_vars_y].max().max()]
        
        # Define the axes
        ir = 0
        for var_y in list_vars_y:

            # main histogram plot
            ax_main = fig.add_subplot(gs[ir, 1], xticklabels=[])
            hi = ax_main.hist2d(df.loc[:, var_x], df.loc[:, var_y], 
                               bins=(count_bins, count_bins),
                               cmap=plt.cm.jet, norm=mcolors.LogNorm())
            
            # TODO 2019-9-23: vmtl. hier noch zu umstaendlich, moeglichst 
            # direkt aus h[0] berechnen
            # TODO 2019-10-29: noch so machen, dass einheitliche ranges fuer
            # alle Diagramme
            tmp = hi[1]
            cut = pd.cut(df[var_x], tmp)
            meds = df.groupby(cut)[var_y].agg(['median'])
            tmp = tmp[:-1] + np.diff(tmp)
            ax_main.scatter(x=tmp, y=meds, s=100, linestyle='-', 
                            marker='+', color='black')
            
            ax_main.set_ylim(ylim)
            ax_main.grid()
            #ylim = ax_main.get_ylim()
            
            # hist. for se
            ax_left = fig.add_subplot(gs[ir, 0], yticklabels=[])
            
            ax_left.hist(df.loc[:, var_y], count_bins, histtype='stepfilled', 
                         orientation='horizontal', color='gray')
                            
            ax_left.invert_xaxis()
            ax_left.set_ylim(ylim)
            ax_left.grid()
            ax_left.tick_params(bottom = True, right=True, top=False, left=False)
            ax_left.set(ylabel=var_y)

            divider = make_axes_locatable(ax_main)
            cb = divider.append_axes("right", size="2%", pad=.05)            
            plt.colorbar(hi[3], cax=cb)

                    
            # set title
            if ir==0:
                #ax_main.set(title=f'{self.db}, {title_part}', xlabel='...', ylabel='hwy')            
                ax_main.set(title=title)
                xticks = ax_main.get_xticks().tolist()
                ax_main.set(xticks = xticks)    # set xticks also changes the 
                                                # x-range, so to be consistent 
                                                # with the following diagrams 
                                                # set these here too
                xticks_left = ax_left.get_xticks().tolist()
                ax_left.set(xticks=xticks_left)
                xlim_left = ax_left.get_xlim()
                
            else:
                ax_left.set(xticks=xticks_left)
                ax_left.set_xlim(xlim_left)
                ax_main.set(xticks=xticks)
                                    

            if ir == ny-1:
                xlabels = ax_main.get_xticks().tolist()
                ax_main.set(xlabel=var_x)
                ax_main.set_xticklabels(xlabels)
                #xticks = ax_main.get_xticks().tolist()
                xlim = ax_main.get_xlim()
            else:                    
                ax_left.set_xticklabels([])
                
            ir += 1
           

        # histogram of the production data
        ax_bottom = fig.add_subplot(gs[-1, 1], xticklabels=[])
        ax_bottom.hist(df.loc[:, var_x], count_bins, histtype='stepfilled', 
                       orientation='vertical', color='gray')
        ax_bottom.set_xticks(xticks)
        ax_bottom.set_xlim(xlim)
        ax_bottom.set_xlabel(var_x)
        ax_bottom.grid()
        ax_bottom.tick_params(bottom = False, right=False, top=True, left=True)
        #ax_bottom.invert_yaxis()
            
        divider = make_axes_locatable(ax_bottom)
        caxb = divider.append_axes("right", size="2%", pad=.05)            
        caxb.remove()

        fn_img_full = f'{path_save}\\{fn_img}'
                    
        fig.savefig(fn_img_full)
        plt.close(fig)

        return({title: fn_img})
        
        

 
     
    
        
    """
    prepare content for .html-report
    2019-10-16
    """
    def prepare_content(self, filters, path_save, notes = '', 
                        cols_describe = ['wind_mean', 'wind_sigma', 
                                         'temperature_mean', 
                                         'temperature_sigma', 
                                         'ambient_temperature_mean', 
                                         'pitch_mean', 'pitch_sigma', 
                                         'omega_mean', 'omega_sigma', 
                                         'power_mean', 'power_sigma']):

        bOK = True
        msg = ''
        
        # meaning of numbers in preferences.activity
        map_act = {'0': 'off', '1': 'on', '2': 'idle'}

        
        ## store the general content
        content = {'user': 'Christian Kühnert',
                   'date': dt.datetime.now().strftime('%d.%m.%Y'),
                   'farm': self.farm,
                   'wtg': self.name,
                   'db': self.db,
                   'wtg_type': self.wtg_type,
                   'channels': ', '.join(self.get_channel_list(self.remaining_channels())),
                   'notes': notes}



        ## do the actual calculations                        
        try:
            self.load_data_from_hd5(filters = filters)        # load data    
        except:
            bOK = False
            msg = 'Problem beim Dateneinlesen'
        
        
        
        
        if (self.start_time is None)  or (self.start_time is pd.NaT):
            try:
                cc_st = self.df_se.index.min()
            except:
                cc_st = dt.datetime(1970,1,1)
        else:
            cc_st = self.start_time
                

        if (self.end_time is None)  or (self.end_time is pd.NaT):
            try:
                cc_et = self.df_se.index.max()
            except:
                cc_et = dt.datetime.now()
        else:
            cc_et = self.end_time
        
        ## check the preferences and tickets
        res_cc, dfTicketsGeneral = self.check_channels(cc_st, cc_et)                                                            
        df = self.sens_status.replace({'activity': map_act})
        #df = df.assign(farm=tb.farm).assign(wtg=tb.name)
        df = df.assign(relevante_tickets = '')
        for c,v in res_cc.items():
            if (v is None):
                df.loc[c, 'relevante_tickets'] = ''
            else:
                v.replace({'dtErrorFixed': {pd.NaT: 'not fixed'}}, inplace=True)
                tmp = [f"[{r['sTicketID']}] {r['sTitle']}: {r['dtFirstOcc']}-{r['dtErrorFixed']}" for _ix, r in v.iterrows()]
                df.loc[c, 'relevante_tickets'] = ', '.join(tmp)       
        
        content.update({'preferences': df.to_html(index=True)})        
        content.update({'tickets': dfTicketsGeneral.sort_values(by='sTicketID',
                                                               ascending=False)
                                                    .to_html(index = False,
                                                     columns = ['sTicketID', 
                                                                'sStatus', 
                                                                'sTitle', 
                                                                #'sDescription', 
                                                                'dtFirstOcc', 
                                                            'dtErrorFixed'])})
                        


        if bOK:
            try:    
                df_os, dict_res = self.calc_offsets()                   # calculate offsets            
                                
                if df_os.empty:
                    bOK = False
                    msg = 'kein Ergebnis bei Offset-Berechnung'
                                
            except:
                bOK = False
                msg = 'Problem bei Offset-Berechnung'
                
        if bOK:
            
            try:
        
                ## data info
                if (self.start_time is None):
                    sstart = 'None'
                else:
                    sstart = self.start_time.strftime(self.stf)
                
                if (self.end_time is None):
                    send = 'None'
                else:
                    send = self.end_time.strftime(self.stf)
                    
                data_info = {'vorgegebener Zeitraum': f'{sstart} - {send}'}
                data_info.update({f'{k}': f'{v[0]} <= {k} <= {v[1]}' for k, v in filters.items()})

                tmp = []
                data_info.update({'vorhandene (gefilterte) Daten': ''})
                for d, dict2 in dict_res.items():
                    df = dict2['df']
                    #tmp.append(f'{d}: {df.index.min().strftime(self.stf)} - {df.index.max().strftime(self.stf)}: n={df.shape[0]}')
                    data_info.update({f'{d}:': f'{df.index.min().strftime(self.stf)} bis {df.index.max().strftime(self.stf)}, Anzahl n={df.shape[0]}'})
                
#                data_info.update({'vorhandene (gefilterte) Daten': tmp})
                
                #data_info.update({'P': f'{p_min} <= P <= {p_max}'})
                #data_info.update({f'{k}': f'{v[0]} <= {k} <= {v[1]}' for k, v in filters.items() if not(k=='power_mean') and (k in df.columns)})
                content.update({'data_info': pd.DataFrame.from_dict(data_info, 
                                                                orient='index')
                                                .to_html(index=True, header=False)})

                cols = [c for c in cols_describe if c in self.df_se.columns]  # not use of intersection of sets to keep the order
                content.update({'data_description': self.df_se.loc[:, cols].describe().to_html(index=True, header=True)})
                # round the numbers, sort the rows because in webService the
                # order ist e1, f1, e2, f2, e3, f3 and it is much easier to
                # input the values when this table has the same order
                content.update({'results': df_os.sort_index().round(3)
                                                .to_html(index=True)})

            except:
                bOK = False
                msg = 'Problem bei weiterer Auswertung der Offsets'
                
            
        if bOK:            
            try:
                ## create the diagrams of signal energy                    
                for direction, dict2 in dict_res.items():            
                    for mode in ['old', 'new']:   # w/o and with offsets                                   
                        fn_img = f'{self.db}_{direction}_{mode}_offsets__se_rel.png'            
                        self.plot_ts_rel(dict2[f'df_rel_{mode}'], direction, mode, path_save, 
                                         fn_img)
                        content.update({f'fn_{direction}_{mode}_os': f'"{fn_img}"'})

            except:
                bOK = False
                msg = 'Problem bei Erzeugen der SE-Darstellungen'

                
        if bOK:
            try:                
                ## create the remaining diagrams
                images = {}
                for direction, dict2 in dict_res.items():
                    for var_x in ['wind_mean', 'omega_mean']:
                        #for mode in ['without', 'with']:
                        for mode in ['old', 'new']:
                            
                            df = pd.concat((dict2[f'df_rel_{mode}'], 
                                            dict2['df'].loc[:, [var_x]]), 
                                            axis=1)
                            
                            fn_img = f'{self.db}_{direction}_{mode}_offsets__dev_vs_{var_x}.png'
                            tmp, _tmp2 = self.get_info()
                            
                            #title = f'{tmp}, {direction}: rel. SE {mode} offsets vs. {var_x} (n={df.shape[0]})'
                            title = f'{tmp}, {direction}: rel. SE with {mode} offsets vs. {var_x}'
                            
                            list_y = dict2[f'df_rel_{mode}'].columns
                 
                            images.update(self.plot_deviations(path_save, 
                                                               fn_img, df, 
                                                               var_x, list_y, 
                                                               count_bins=50, 
                                                               title=title))
            
                content.update({'images': images})
            except:
                bOK = False
                msg = 'Problem bei Erzeugen der Abweichungs-Diagramme'
                
        del(dict_res)
        gc.collect()
        
        return(content, bOK, msg)

    
        
        
                      