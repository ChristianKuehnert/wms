# -*- coding: utf-8 -*-
"""

@author: christian
"""



"""
creates link to turbine data in webVis



input:
------
        - ...
        - cols_gh:            dictionary with table and variables to be displayed in graphical history, only relevant for sTool=='GH' (will be ignored for all other tools)
        
Created on Tue Mar 26 02:59:59 2019

@author: Christian Kuehnert
@last_modified: 2021-2-22

"""          

import numpy as np
import datetime as dt


def create_link(db, sTool='IV',
                cols_gh={'ba_cycle_status': ['omega_mean', 'power_mean', 'pitch_mean', 'wind_mean'],
                         'ba_cycle_externals': ['err_code']},
                start_time=dt.datetime.now()-dt.timedelta(days=30),
                end_time=dt.datetime.now() + dt.timedelta(hours=3), kwargs = None):

    try:
        start_link = str(int(np.floor((max(end_time - dt.timedelta(days=30), start_time)).timestamp())*1000))
        end_link = str(int(np.ceil(end_time.timestamp())*1000))

        # TODO 2019-1-27: links noch fuer alle 3 (oder mehr) tools richtig machen
        if sTool == 'GH':
            tmp = [[key + '%3A' + val for val in cols_gh[key]] for key in cols_gh.keys()]
            tmp2 = '&col%5B%5D='.join([s for sl in tmp for s in sl])
            link = r'https://10.41.52.54/WebVis/gr_hist?dbName=' + db + f'&s={start_link}&e={end_link}&col%5B%5D={tmp2}'

        elif sTool == 'SE':
            link = r'https://10.41.52.54/WebVis/se_chart?dbName=' + db + f'&s={start_link}&e={end_link}&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'

        elif sTool == 'SE_abs':
            try:
                fstart = kwargs['freq'][0]
            except:
                fstart = 80

            try:
                fend = kwargs['freq'][1]
            except:
                fend = 110

            link = r'https://10.41.52.54/WebVis/se_chart?dbName=' + db + f'&s={start_link}&e={end_link}&fmn={fstart}&fmx={fend}&n=Nothing&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'

        else:
            # print('konnte Tool-Kuerzel nicht einordnen, verwende IceVis fuer Link')
            link = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + db + f'&s={start_link}&e={end_link}&it%5B%5D=R1F0&it%5B%5D=R2F0&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'

    except:
        link = 'link could not be created'

    return link

