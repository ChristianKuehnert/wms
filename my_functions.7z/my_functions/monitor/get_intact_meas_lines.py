# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 11:18:48 2019

function to return the intact meas lines for the given database,
depending on the type of evaluation



@author: christian
@modified: 2019-7-21
"""
from . import get_relevant_tickets

def get_intact_meas_lines(db, tickets, stype = 'defekt_oder_TPV',
                          period = None,
                          map_channels = {0: 'e_101_flap',
                                          1: 'e_102_flap',
                                          2: 'e_103_flap',
                                          3: 'e_101_edge',
                                          4: 'e_102_edge',
                                          5: 'e_103_edge'}):
                
    # tickets for measure lines with problems    
    dfTicketsCrit, dict_ch_tickets = get_relevant_tickets(tickets, 
                                                          sType = stype, 
                                                          period = period)

    channels_ok = []
    channels_ok_idx = []
    for k, [bFail, dfRelTickets] in dict_ch_tickets.items():
        if ~bFail:
            channels_ok.append(map_channels[k])
            channels_ok_idx.append(k)
        else:
            if dfRelTickets[~(dfRelTickets.sStatus=='erledigt')].shape[0]==0:
                # TODO 2019-7-12: noch Datumspruefung einfuehren, 
                # d.h. auch bei alten geschlossenen Tickets ggf. 
                # den Kanal ausschliessen, wenn sich die 
                # betrachteten Zeiten mit dem Ticketzeitraum 
                # ueberschneiden
                channels_ok.append(map_channels[k])
                channels_ok_idx[k]
                
    return(channels_ok)
