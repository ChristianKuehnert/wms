# -*- coding: utf-8 -*-
"""
function as get_valid_channels, but gets db as parameter and retrieves
tickets first


Created on Thu Aug 15 11:45:25 2019

@author Christian Kuehnert
@modified: 2019-8-15

"""
from . import get_valid_channels
from .data import query_tableData_PIT

TODO 2019-8-15: weiter implementieren
def get_valid_channels_db(db, map_channels = {0: 'e_101_flap',
                                              1: 'e_102_flap',
                                              2: 'e_103_flap',
                                              3: 'e_101_edge',
                                              4: 'e_102_edge',
                                              5: 'e_103_edge'},
                        type_fails = 'defekt_oder_TPV'):

    ## find all tickets
    dictMap_tickets =  {'sTitle': 'Titel',
                        'sDescription': 'Beschreibung',
                        'sStatus': 'Status',
                        'sFarm': 'Windpark#Windparkname',
                        'weasImWP': 'WEAs_im_Windpark',                            
                        'sTicketID': 'TicketID',
                        'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                        'dtCreated': 'Beginn_am',
                        'dtClosed': 'Geschlossen_am'}

    listCols_tickets = [dictMap_tickets[i] + ' as ' + i for i in dictMap_tickets]
       
    #sWC_tickets = f"Windpark#='{df.id_farm[0]}'"
    dfTickets = query_tableData_PIT('VIEW_Tickets', listCols_tickets, '')
    
    dfTickets.column_names = dictMap_tickets.keys

    ## prepare list of ticket IDs combined with indices of weas im Windpark
    ## in order to split tickets to single turbines
    sContainerID = str(df.id[0])
#                    for i in range(dfTickets.shape[0]):
#                        dfT = dfTickets.iloc[i,:]
#                        sWiW = dfT.weasImWP          
#                        if (len(sWiW)>0):
#                            lTmp = sWiW.split(',')
#                            if sContainerID in lTmp:
#                                lTickets.append(dfT)
    btmp = [sContainerID in c.split(',') for c in 
            dfTickets.loc[:, 'weasImWP']]
                
    #dict_res.update({'tickets': pd.concat(lTickets, axis=0)})
    dict_res.update({'tickets': dfTickets[btmp]})
                    









    
    # tickets for measure lines with problems
    dfTicketsCrit, dict_ch_tickets = get_relevant_tickets(df_tickets, 
                                                          sType = type_fails)


    channels_ok = []
    for k, [bFail, dfRelTickets] in dict_ch_tickets.items():
        if ~bFail:
            channels_ok.append(map_channels[k])
        else:
            if dfRelTickets[~(dfRelTickets.sStatus=='erledigt')].shape[0]==0:
                channels_ok.append(map_channels[k])

    return(channels_ok)