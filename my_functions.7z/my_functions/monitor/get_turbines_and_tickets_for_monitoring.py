# -*- coding: utf-8 -*-
"""
Created 2019-2-21

function to get the turbines and related tickets from PIT


@author: Christian Kuehnert

@modified: 2020-1-24
"""

import pandas as pd
import data as mfdata
#from data import query_tableData_PIT


## info zu den sensitivities: aus Matlab-Programm:
#    sSC = ['Sensor_Rotorblatt_1#z_Sensitivität,Sensor_Rotorblatt_2#z_Sensitivität,Sensor_Rotorblatt_3#z_Sensitivität,', ...
#           'Sensor_Rotorblatt_1#x_Sensitivität,Sensor_Rotorblatt_2#x_Sensitivität,Sensor_Rotorblatt_3#x_Sensitivität']; 
#    sWC = ['(Datenbankname = ''', sDB, ''')'];    
#    [cWEA] = queryPIT('VIEW_Windkraftanlagen', sSC, sWC, '');
#
#    iN = size(cWEA,1);       
#    if (iN == 1)      
#            
#        % get sensitivities
#        cSensEdge = cWEA(1,1:3);
#        cSensFlap = cWEA(1,4:6);
#            
#        dSens = str2double(cSensEdge);            
#        dFacEdge = dSens/mean(dSens);
#           
#        dSens = str2double(cSensFlap);            
#        dFacFlap = dSens/mean(dSens);             
#                        
#    else
#        disp([num2str(iN), ' WEAs zur Datenbank ', sDB, ' gefunden, bitte prüfen']);                       
#        cSensEdge = {'','',''};
#        cSensFlap = {'','',''};
#        dFacEdge = nan(1,3);
#        dFacFlap = nan(1,3);




#def get_turbines_and_tickets(dictWT, sWC_wt, dictTickets, sWC_tickets):
#def get_turbines_and_tickets(dictWT, sWC_wt=None, dictTickets, sWC_tickets=None):
#def get_turbines_and_tickets(sWC_wt=None, sWC_tickets=None):
def get_turbines_and_tickets_for_monitoring(sWC_wt=None, sWC_tickets=None):
        
    dictWTsTickets = {}
    dEps = 1e-6
    
    ## query turbine data
    dictCols_wt = {'sName': 'WEA_Name',
                   'sFarm': 'Windpark_WEA#Windparkname',
                   'sDB': 'Datenbankname',
                   'sType': 'WEA_Typ#Name',
                   'sManufacturer': 'WEA_Typ#Hersteller#Firmenname',
                   'dtLastMonitoring': 'Monitoring_zuletzt_durchgeführt',
                   'dtStartCollectData': 'Beginn_Datenspeicherung',
                   'dtOperational': 'Inbetriebnahme_abgeschlossen',
                   'ssh_port': 'ssh_port',
                   'email_customer': 'Ansprechpartner_Kunde#E_Mail_Adresse',
                   'monitoring_type': 'Systemart#Bezeichnung',
                   'monitoring_short': 'Systemart#Kürzel_Monitor',
                   'turbine_in_monitoring': 'Anlage_im_Monitoring',
                   'contract_status': 'Gesamtstatus_Überwachungsaufträge',
                   'sens_e1': 'Sensor_Rotorblatt_1#z_Sensitivität',
                   'sens_f1': 'Sensor_Rotorblatt_1#x_Sensitivität',
                   'sens_e2': 'Sensor_Rotorblatt_2#z_Sensitivität',
                   'sens_f2': 'Sensor_Rotorblatt_2#x_Sensitivität',
                   'sens_e3': 'Sensor_Rotorblatt_3#z_Sensitivität',
                   'sens_f3': 'Sensor_Rotorblatt_3#x_Sensitivität',
                   'id': 'o_ContainerID',
                   'id_farm': 'Windpark_WEA#',
                   'revision': 'revision'}
        
    listCols = [dictCols_wt[i] + ' as ' + i for i in dictCols_wt]
                
    dfWTs = mfdata.query_tableData_PIT('VIEW_Windkraftanlagen', listCols, sWC_wt)
    
    if ('sFarm' in listCols and 'sName' in listCols):
        dfWTs.sort_values(by=['sFarm', 'sName'], inplace=True)
    
    ## query ticket data
#    dictCols_tickets =  {'sTitle': 'Titel',
#                         'sDescription': 'Beschreibung',
#                         'sStatus': 'Status',
#                         'sFarm': 'Windpark#Windparkname',
#                         'weasImWP': 'WEAs_im_Windpark', 
#                         'sTicketID': 'TicketID',
#                         'dtFirstOcc': 'Erstauftreten_des_Fehlers',
#                         'dtCreated': 'Beginn_am',
#                         'dtErrorFixed': 'Behebung_des_Fehlers',
#                         'dtClosed': 'Geschlossen_am',
#                         'id_farm': 'Windpark#'}


    # TODO 2019-7-15: wieder entfernen, nur zum ausfiltern der Tickets fuer Ernst
    dictCols_tickets =  {'sTitle': 'Titel',
                         'sDescription': 'Beschreibung',
                         'sStatus': 'Status',
                         'sFarm': 'Windpark#Windparkname',
                         'weasImWP': 'WEAs_im_Windpark', 
                         'sTicketID': 'TicketID',
                         'dtFirstOcc': 'Erstauftreten_des_Fehlers',
                         'dtCreated': 'Beginn_am',
                         'dtErrorFixed': 'Behebung_des_Fehlers',
                         'dtClosed': 'Geschlossen_am',
                         'id_farm': 'Windpark#',
                         'loesungsklasse': 'Lösungsklasse#',
                         'loesungsklasse_bez_de':'Lösungsklasse#Bezeichnung_DE',
                         'loesungsklasse_zugehoerigkeit_zu_fehlerhaftem_System':'Lösungsklasse#Zugehörigkeit_zu_fehlerhaftem_System#',
                         'loesungsklasse_bez_en':'Lösungsklasse#Bezeichnung_EN',
                         'loesungsklasse_beschreibung_en':'Lösungsklasse#Beschreibung_EN',
                         'loesungsklasse_beschreibung_de': 'Lösungsklasse#Beschreibung_DE',                                                                        
                         }



    listCols_tickets = [dictCols_tickets[i] + ' as ' + i for i in dictCols_tickets]    
    
    dfTickets = mfdata.query_tableData_PIT('VIEW_Tickets', listCols_tickets, sWC_tickets);
    #dfTickets.column_names = dictCols_tickets.keys


    ## loop through turbines to find and assign the tickets    
    for idx, row in dfWTs.iterrows():
        
        #sFarm = row['sFarm']
        #sName = row['sName']
        sDB = row['sDB']
        id_farm = row['id_farm']
        id_wt = row['id']            
        
        ## now find tickets for that wt
        dfTmp = dfTickets[abs(dfTickets.id_farm-id_farm)<3*dEps]        ## consider only tickets referring to the same wind farm
        lTicketsWT = []        
        for idx2, dfT in dfTmp.iterrows():
            sWiW = dfT.weasImWP
            if not(sWiW is None):
                if (len(sWiW)>0):
                    lTmp = sWiW.split(',')
                    if str(id_wt) in lTmp:
                        lTicketsWT.append(idx2)
            
        dfTicketsWT = dfTmp.loc[lTicketsWT,:]
        dfTicketsWT.drop(columns=['id_farm'], inplace=True)
        dfTicketsWT['dtCreated'] = pd.to_datetime(dfTicketsWT['dtCreated'], errors='coerce')
        dfTicketsWT['dtFirstOcc'] = pd.to_datetime(dfTicketsWT['dtFirstOcc'], errors='coerce')
        dfTicketsWT['dtErrorFixed'] = pd.to_datetime(dfTicketsWT['dtErrorFixed'], errors='coerce')
        dfTicketsWT['dtClosed'] = pd.to_datetime(dfTicketsWT['dtClosed'], errors='coerce')
 
        dictWTsTickets.update({sDB: dfTicketsWT})
        
        
    return({'tickets': dictWTsTickets, 'turbines': dfWTs})
