# -*- coding: utf-8 -*-
"""
function to check one single time series/measuring data row for sensor defect

Created on Tue Mar 26 02:53:38 2019

@author: Christian Kuehnert
@last_modified: 2019-5-16

"""

from sensor_classification import class_classifier_ts as csc

def check_sensor_one_date(db, check_date, name_cls, path_cls):
    
    try:
        ## load classifier
        sc = csc.sensor_classifier(name=name_cls, pickle_path=path_cls)
        sc.load()
        iPred = sc.predict_for_periode(db, start_time=check_date)
        
        ## predict for this time point
    except Exception as ex:
        print('error occurred in function check_sensor_date')
        iPred = None
    
    return(iPred)

