# -*- coding: utf-8 -*-
"""
function to get valid channels from the given tickets for the given type
of failure


Created on Thu Aug 15 11:08:16 2019

@author: w012028
@modified: 2019-8-15

"""

from . import get_relevant_tickets

def get_valid_channels(df_tickets, map_channels = {0: 'e_101_flap',
                                                   1: 'e_102_flap',
                                                   2: 'e_103_flap',
                                                   3: 'e_101_edge',
                                                   4: 'e_102_edge',
                                                   5: 'e_103_edge'},
                        type_fails = 'defekt_oder_TPV'):
    
    # tickets for measure lines with problems
    dfTicketsCrit, dict_ch_tickets = get_relevant_tickets(df_tickets, 
                                                          sType = type_fails)


    channels_ok = []
    for k, [bFail, dfRelTickets] in dict_ch_tickets.items():
        if ~bFail:
            channels_ok.append(map_channels[k])
        else:
            if dfRelTickets[~(dfRelTickets.sStatus=='erledigt')].shape[0]==0:
                channels_ok.append(map_channels[k])

    return(channels_ok)
    
    
    