# -*- coding: utf-8 -*-
"""
function to check if preferences can be read and are ok

Created on Tue Mar 26 02:25:10 2019

@author: Christian Kuehnert
@last_modified: 2019-10-18

input:
------
        - db: database name (including 'cmrblba_')
"""

from data import get_preferences
from data import get_bit

#from . import create_issue
#from monitor.class_issue import issue
#from monitor import create_issue
#from . import create_issue
from monitor.class_issue import issue


def check_prefs(db, tickets, checks, issues):
    #issues = []   
                             
    lMsg = []
                        
    prefs = get_preferences(db)
        
    bMaskEval = (get_bit(prefs['Turbine@UseDefaultSVEval'].replace(' ',''), 
                         10) == 1)    # Bit fuer Maskierung eval-bit                                
    if bMaskEval:
        lMsg.append('ice-eval-Bit maskiert')
                                   
    bMaskAlarm = (get_bit(prefs['Turbine@UseDefaultSVAlarm'].replace(' ',''), 
                          10) == 1)   # Bit fuer Maskierung Alarm-Bit
    if bMaskAlarm:
        lMsg.append('ice-alarm-Bit maskiert')
        
    bMaskWarning = (get_bit(prefs['Turbine@UseDefaultSVWarning'].replace(' ', 
                            ''), 10) == 1)
    if bMaskWarning:
        lMsg.append('ice-warning-Bit maskiert')
        
        
    if bMaskEval or bMaskAlarm or bMaskWarning:        
        #issues.append(create_issue(db, sErrorMsg = ', '.join(lMsg), 
        #                           sAction = 'demaskieren'))
        issues.append(issue(sDB = db,
                            sErrorMsg = ', '.join(lMsg), 
                            sAction = 'demaskieren'))
    
    #return issues

