# -*- coding: utf-8 -*-
"""
function to check if improper externals occur

Created on Tue Mar 26 02:30:23 2019

@author: Christian Kuehnert
@last_modified: 2019-3-26

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_improper_ext(db, tickets, checks, issues, start_time, end_time):
    #issues = []    
    pass
    #return issues

