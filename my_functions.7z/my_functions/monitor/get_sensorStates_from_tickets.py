# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 11:53:27 2019

@author: w012028
"""



"""
function to find out the channels the given tickets are related

Anhand der Einträge in den PIT-Tickets wird ermittelt, welche Sensorstrecken i.O. und welche defekt sind. Dies
wird als Vektor [edge1, edge2, edge3, flap1, flap2, flap3] zurückgegeben mit Wert 0, falls die Sensorstrecke defekt ist, und 
mit Wert 1, falls kein diesbezüglicher Eintrag vorliegt

Input:
		- tabTickets: pandas.DataFrame with tickets, must contain the fields
						- Ticket_TicketID
						- Ticket_Titel
						- Ticket_Beschreibung
						- Ticket_Status
						- Ticket_Beginn_am
						- Ticket_Erstauftreten_des_Fehlers
						- Ticket_Behebung_des_Fehlers
						- Ticket_Geschlossen_am

		- bOnlyOpenTickets: if True, only tickets that are not in state 'erledigt' will be included, otherwise all tickets


 Output:
		- dictionary with relevant tickets:
           - dictRelTickets = {'f1': dfRelTicket_f1, 'f2': dfRelTickets_f2, 'f3': dfRelTickets_f3, 'e1': dfRelTickets_e1, ...}
           - dfStates: dataframe with states for the several channels, i.e. dataframe with columns:
               - channel_name ('f1', 'f2', 'f3', 'e1', ...)
               - sensor_state: True if open ticket(s) exist for that channel, False if not
               - ticketIDs: IDs of the relevant tickets
               - start_time: 1x9-Array (Reihenfolge wie bei cVars) mit den Zeiten (Matlab-Zeitformat),
                             bis zu denen kein Ticket für die jeweilige Sensorstrecke existiert.
                             Ist kein Ticket für die Sensorstrecke vorhanden, wird der Wert auf
                             Inf gesetzt. Ist ein Ticket für die Sensorstrecke vorhanden, wird
                             der Zeitpunkt von 'Beginnt am' bzw. -falls nicht vorhanden- von 'Erstauftreten
                             des Fehlers' genommen. Sind auch hierfür keine Zeitangaben eingetragen,
                             wird der Wert anhand der Ticket-ID bestimmt und als allerletzte Möglichkeit
                             wird der Zeitpunkt auf NaN gesetzt.
               - end_time: 1x9-Array (Reihenfolge wie bei cVars) mit den Zeiten (Matlab-Zeitformat),
                           ab denen kein offenes Ticket für die jeweilige Sensorstrecke existiert.
                           Ist kein Ticket für die Sensorstrecke vorhanden, wird der Wert auf
                           -Inf gesetzt. Ist ein Ticket für die Sensorstrecke vorhanden, wird
                           der Zeitpunkt von 'Behebung_des_Fehlers' bzw. -falls nicht vorhanden- von 'Geschlossen_am' 
                           Sind auch hierfür keine Zeitangaben eingetragen,
                           wird der Zeitpunkt auf Inf gesetzt.


Christian Kuehnert, 2019-1-21
"""
import re
import numpy as np
import pandas as pd

from monitor import get_ticket_times



def get_sensorStates_from_tickets(dfTickets, bOnlyOpenTickets = True):                            
    
    sChannelNames = ['f1','f2','f3','e1','e2','e3']
    try:
        
        # falls entsprechende Option gewaehlt, dann nur offene Tickets einbeziehen
        if bOnlyOpenTickets:
            dfTickets = dfTickets[dfTickets.sStatus == 'erledigt']
                                    
            
        if dfTickets.shape[0]==0:
            dfRes = pd.DataFrame.from_dict({'channel_name': sChannelNames, 'status': np.tile(True, (6,)), 'ticketIDs': np.tile('', (6,)), 'start_time': np.tile(pd.NaT, (6,)), 'end_time': np.tile(pd.NaT, (6,))})
            dictRes = {'f1': None, 'f2': None, 'f3': None, 'e1': None, 'e2': None, 'e3': None}
                                            
        else:
    
            sTicketStrings = dfTickets.sTitle
                            
            # TODO 5-7: pruefen, wie am besten auch die Beschreibung einbezogen werden kann. Vielleicht wie naechste Zeile, mit Anpassung der weiteren Bearbeitungsschritte
            # cTTitles = [tabTickets.Ticket_Titel, tabTickets.Ticket_Beschreibung];		% Kombination aus Titel und Beschreibung
        
            # TODO 2017-6-21: noch vereinfachen, ohne Ersetzen (evtl. auch ohne erase) gleich
            # Indizees der gefundenen Tickets bestimmen
            # TODO 2019-1-21: alles nochmal ueberarbeiten, besser machen mit bewaehrten Textmining-Methoden, ausserdem mit geeigneteren regex-Ausdruecken weniger Zeilen benoetigen
            sT = [s.replace('Eissensor Rotorblatt', '') for s in sTicketStrings]
            sT = [s.replace('cmrbl', '') for s in sT]
            sT = [s.replace('100', '') for s in sT]

            sT = [re.sub('bladecontrol', '', s, flags=re.IGNORECASE) for s in sT]

            sT = [s.strip() for s in sT]
            
            sT = [re.sub('rbl', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('flap', 'Flap', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('edge', 'Edge', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('(vor allem |v.a. |v. a. |vorrangig)(Edge|Flap)', '', s, flags=re.IGNORECASE) for s in sT]
            
            #                cTs = cellfun(@(x) erase(x, 'vor allem Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'vor allem Edge'), cTs, 'UniformOutput', false); 
            #                cTs = cellfun(@(x) erase(x, 'v.a. Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'v.a. Edge'), cTs, 'UniformOutput', false); 
            #                cTs = cellfun(@(x) erase(x, 'v. a. Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'v. a. Edge'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'vorrangig Flap'), cTs, 'UniformOutput', false);
            #                cTs = cellfun(@(x) erase(x, 'vorrangig Edge'), cTs, 'UniformOutput', false); 
            
            sT = [re.sub('Rotorblatt', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blade', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blade:', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('Blatt 1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blatt 2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('Blatt 3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('RBL 1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('RBL 2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('RBL 3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('RBL-', 'RBL', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('R1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('R-1', 'RBL1', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R-2', 'RBL2', s, flags=re.IGNORECASE) for s in sT]
            sT = [re.sub('R-3', 'RBL3', s, flags=re.IGNORECASE) for s in sT]
            
            sT = [re.sub('R-1/2/3', 'RBL1,RBL2,RBL3', s, flags=re.IGNORECASE) for s in sT]
    
            # now find relevant search patterns in modified ticket strings             
            #bI = cell2mat(cellfun(@(x) isempty(regexp(x, '(RBL)|(alle )|( allen)|((Sensoren )*( falsch angeschlossen))|(vertausch)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false));
            #cTs = cTs(~bI);
            #idxRel = find(~bI);        
            #bI = [not(re.match('(.*?)(RBL)|(alle )|( allen)|((Sensoren )*( falsch angeschlossen))|(vertausch)(.*?)', s) is None) for s in sT]
            bI = [not(re.match('(.*?)(RBL|alle | allen|(Sensoren )*( falsch angeschlossen)|vertausch)(.*?)', s) is None) for s in sT]
            idxRel = [i for i, x in enumerate(bI) if x]     # index of relevant tickets (related to dfTickets)
            sT = list(pd.Series(sT)[bI])
            
            # Tickets mit wenigstens einem der folgenden Ausdrücke werden ignoriert:
    #        bI2 = all([cell2mat(cellfun(@(x) isempty(regexp(x, '(Falscheismeldung .*Peak ung.*.*nstig)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle )[0-9]*.?(ECU)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle Messprogramme)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle WEA ohne Eis am RBL)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(ECU).*(alle) (im WP|im PW)? (gleichzeitig)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(neue Werte alle)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(falsche Zeit).* (alle)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(nach Stromabschaltung)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(Datenl)(ue|ü)(cken)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(keine externals)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(geringes Signal-Rausch)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(Zuordnung).*(<->).*(Firewall vertauscht)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(alle)[n]? (WEA)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(Ticket aus Versehen erstellt)', 'match','ignorecase','ONCE')), cTs, 'UniformOutput', false)), ...
    #                          cell2mat(cellfun(@(x) isempty(regexp(x, '(schadensbericht)', 'match', 'ignorecase','ONCE')), cTs, 'UniformOutput', false))], 2);
    
            # create regex-pattern for search, tickets containing one of those patterns will be ignored because they are not related to measure line defects
            lPattern = []
            lPattern.append('Falscheismeldung .*Peak ung.*.*nstig')
            lPattern.append('(alle )[0-9]*.?(ECU)')
            lPattern.append('alle Messprogramme')
            lPattern.append('alle WEA ohne Eis am RBL')
            lPattern.append('(ECU).*(alle) (im WP|im PW)? (gleichzeitig)')
            lPattern.append('neue Werte alle')
            lPattern.append('(falsche Zeit).* (alle)')
            lPattern.append('nach Stromabschaltung')
            lPattern.append('(Datenl)(ue|ü)(cken)')        
            lPattern.append('keine externals')
            lPattern.append('geringes Signal-Rausch')
            lPattern.append('(Zuordnung).*(<->).*(Firewall vertauscht)')
            lPattern.append('(alle)[n]? (WEA)')
            lPattern.append('Ticket aus Versehen erstellt')
            lPattern.append('schadensbericht')
            sPatternRegEx = re.compile('(.*?)(' + ')|('.join(lPattern) + ')(.*?)', re.IGNORECASE)
    
            bI2 = [not(re.match(sPatternRegEx, s) is None) for s in sT]
            
            if all(bI2):                                  # wenn keines der Tickets relevant ist ...
    
                #print('no relevant tickets found')        
                dfRes = pd.DataFrame.from_dict({'channel_name': sChannelNames, 'status': np.tile(True, (6,)), 'ticketIDs': np.tile('', (6,)), 'start_time': np.tile(pd.NaT, (6,)), 'end_time': np.tile(pd.NaT, (6,))})
                dictRes = {'f1': None, 'f2': None, 'f3': None, 'e1': None, 'e2': None, 'e3': None}
    
            else:                                            # andernfalls ...
                bI3 = [not(b) for b in bI2]
                sT = list(pd.Series(sT)[bI3])
                            
                idxRel = [i for i, x in enumerate(bI) if x]     # index of relevant tickets (related to dfTickets)

                dfRelTickets = dfTickets.iloc[pd.Series(idxRel)[bI3],:]       # TODO 2017-6-23: evtl. noch weiter einschraenken auf die Tickets, die zum u.g. bOK beitragen
    					
#                iRelTickets = dfRelTickets.shape[0]
    					
                #cRelevantTickets = table2cell(dfRelTickets);
           
                ## Ableitung der Sensorstates aus den relevanten Tickets
                # Tickets mit Teilstrings, die darauf schließen lassen, dass sie alle Sensorstrecken betreffen
                serT = pd.Series(sT)
                bAll = serT.str.contains('alle', case=False, regex=False)
        
                # Tickets mit Teilstrings, die darauf schließen lassen, dass sie nur einzelne Rotorblätter betreffen
#HIER WEITER 2019-1-21, NOCH 'def', 'defekt' ODER SO MIT ABFRAGEN!
                bRBL = serT.str.contains('( RBL)(RBL )', case=False, regex=True)
                            
                b1 = serT.str.contains('RBL1', case=False, regex=False)
                b2 = serT.str.contains('RBL2', case=False, regex=False)
                b3 = serT.str.contains('RBL3', case=False, regex=False)

                bRBL = bRBL & ~(b1 | b2 | b3)                                          # wenn nur "RBL" vorkommt, z.B. "diverse RBL" in Ticket 201007-004
                
                # Auswertung nach Edge/Flap-Richtung
                bEdge = serT.str.contains('Edge', case=False, regex=False)
                bFlap = serT.str.contains('Flap', case=False, regex=False)
        
                # weitere Prüfung auf Tickets, die für alle Rotorblätter relevant sein könnten
                bAll2 = serT.str.contains('vertausch', case=False, regex=False) & bEdge & bFlap & ~(b1 | b2 | b3)
                            
                # Hilfsgrößen
                bTmp = bAll | bRBL
                bE = bEdge | ~(bFlap)
                bF = ~(bEdge) | bFlap
                                         
                # Bestimmung der Sensor-Zustände der einzelnen Messstrecken
                b1E = ((b1 | bTmp) & bE) | bAll2
                b2E = ((b2 | bTmp) & bE) | bAll2
                b3E = ((b3 | bTmp) & bE) | bAll2
                b1F = ((b1 | bTmp) & bF) | bAll2
                b2F = ((b2 | bTmp) & bF) | bAll2
                b3F = ((b3 | bTmp) & bF) | bAll2
        
                #bAllSensors = [b1F, b2F, b3F, b1E, b2E, b3E]           # which tickets (rows) contain information about which blades x direction (cols)
                bAllSensors = pd.concat((b1F, b2F, b3F, b1E, b2E, b3E), axis=1).values           # which tickets (rows) contain information about which blades x direction (cols)
                bRes = bAllSensors.any(axis=0)
            
                #iChannels = list(itertools.compress([0,1,2,3,4,5], bAllSensors))
                # create dictionary with relevant tickets for each channel
                dictRes = {}
                lTmp = []
                for iCh in range(6):
                    sCh = sChannelNames[iCh]
                    bTmp = bAllSensors[:,iCh]
                    if any(bTmp):
                        dfRT = dfRelTickets[bTmp]
                        dictRes.update({str(iCh): dfRT})
                        sIDs = ','.join(dfRT.sTicketID)
                        # TODO 2019-1-21: spaeter noch verfeinern, alle Zeiten beruecksichtigen, jetzt erstmal Anfangszeit vom letzten Ticket verwendet                    
                        dtStart = get_ticket_times(dfRT).start.max()
                        dtEnd = get_ticket_times(dfRT).end.max()
                    else:
                        sIDs = ''
                        dtStart = pd.NaT
                        dtEnd = pd.NaT
                        
                    lTmp.append([sCh, bRes[iCh], sIDs, dtStart, dtEnd])
                    
                dfRes = pd.DataFrame(lTmp, columns=['channel_name', 'status', 'ticketIDs', 'start_time', 'end_time'])
                                     
    # Wenn irgendein unbekannter Fehler auftritt, werden
    # sicherheitshalber alle Messstrecken als defekt angenommen
    except:

        #warning([ME.identifier, ': ', ME.message]);
        print('unknown error, assume that no relevant tickets exist, so user should check manually for problems')
        dfRes = pd.DataFrame.from_dict({'channel_name': sChannelNames, 'status': np.tile(True, (6,)), 'ticketIDs': np.tile('', (6,)), 'start_time': np.tile(pd.NaT, (6,)), 'end_time': np.tile(pd.NaT, (6,))})
        dictRes = {'f1': None, 'f2': None, 'f3': None, 'e1': None, 'e2': None, 'e3': None}
	
#    # Rückgabeobjekt
#    structRes.cVars = {'edge 1', 'edge 2', 'edge 3', 'flap 1', 'flap 2', 'flap 3', 'temp 1', 'temp 2', 'temp 3'};
#    structRes.bSensorStates = bOK;
#    structRes.dStartFailTimes = dStartFailTimes;
#    structRes.dEndFailTimes = dEndFailTimes;
#    structRes.bAllSensors = bAllSensors;
#    structRes.dFailTimes = dFailTimes;
#    structRes.cAllTickets = cAllTickets;
#    structRes.cRelevantTickets = cRelevantTickets;
           
    return([dictRes, dfRes])

