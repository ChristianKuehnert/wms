# -*- coding: utf-8 -*-
"""
function to check if measuring line are ok by ts method

Created on Tue Mar 26 02:38:28 2019

@author: Christian Kuehnert
@last_modified: 2019-5-29

"""

import datetime as dt
#import pandas as pd
#import numpy as np
#import data as mfdata
#import class_turbine as ctb

#from class_issue import issue   #import class_turbine_mon as ctum
#from data.class_hd5Nodes import hd5Nodes as sNodes
from monitor import create_link, create_issue


#sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
#sys.path.append(sModulePath)
import sensor_classification.class_classifier_asym as ca






def check_meas_line_asym(db, channels, start_time, end_time, kwargs):
	
    
    issues = []
    sTool = 'WA'

    
    tmp = ca.classifier_asym(**kwargs)

    try:
        pred = tmp.predict_for_period(db, channels, start_time=start_time, end_time=end_time)
 
        if pred.shape[0]==0:
            print('   keine Zeitdaten gefunden')
            
            
        #print(pred.loc[:, ['channel', 'value', 'prediction']])
        dfCyc = pred[pred.prediction==1].loc[:, ['create_time', 'id', 'channel']]
    
    
    except:
        dfCyc = None
    								
        issues.append(create_issue(db,
                                   sErrorMsg='Probleme beim Aufruf von predict_for_period',
                                   sAction='manuell ansehen',
                                   sLink=create_link(db, sTool=sTool,
                                                     start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), 
                                                     end_time = end_time+dt.timedelta(hours=4)),
                                                     sTool=sTool))
#        issues.append(create_issue(db,
#                                   sErrorMsg='keine Zeitdaten gefunden',
#                                   sAction='manuell ansehen',
#                                   sLink=create_link(db, sTool=sTool, 
#                                                     start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), 
#                                                     end_time = end_time+dt.timedelta(hours=4)),
#                                                     sTool=sTool))
    							    
    return dfCyc, issues

