# -*- coding: utf-8 -*-
"""
get tickets by special keywords/text parts

Created on Tue Mar 26 02:17:02 2019


parameters:
-----------

dfTickets:   dataFrame with tickets to be checked
sType:       name of the error the tickets shouldbe checked for


output:
-------

dfRel:       dataFrame with relevant tickets
dict_adds:   dictionary with additional information, depending on the failure 
             type the tickets should be checked for



@author: Christian Kuehnert
@modified: 2019-10-16
"""

import re
import pandas as pd
#from monitor import get_channels_from_str_series
import monitor.get_channels_from_str_series


def get_relevant_tickets(dfTickets, sType = '', period=None):

    additional_results = {}

    if period:
        
        start_period = period[0]
        end_period = period[1]
        
        ## now select tickets that are valid in the given period
        # TODO 2019-7-21: pruefen, ob es geschlossene Tickets gibt ohne dtErrorFixed bzw
        # Tickets ohne dtFirstOcc - falls ja, dann folgende Zeilen anpassen
        if start_period:
            dfTickets = dfTickets[dfTickets.dtErrorFixed >= start_period]

        if end_period:
            dfTickets = dfTickets[dfTickets.dtFirstOcc <= end_period]
            
        
   
    if dfTickets.shape[0]>0:
            
        sT = dfTickets.loc[:,'sTitle'].copy()

        # if necessary: replace None-values with ''
        sT[sT.isnull()] = ''


        if sType=='meas_lines':
            # TODO 2018-12-18: zunaechst 1:1-Nachbildung der Matlab-Fkt. 'getSensorStates.m', spaeter vereinfachen/eleganter/anders machen            
            sT.replace('(Eissensor Rotorblatt)(cmrbl)(100)(BLADEcontrol)(bladecontrol)(Bladecontrol)', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            
            #dfT.strip(inplace=True)
            
            sT.replace('([rR][bB][lL])', 'RBL', regex=True, inplace=True)
            sT.replace('([fF][lL][aA][pP])', 'Flap', regex=True, inplace=True)
            sT.replace('([eE][dD][gG][eE])', 'Edge', regex=True, inplace=True)
            
            sT.replace('(((vorrangig)(vor\sallem)(v\.a\.)(v\.\sa\.))(\s)*((Edge)(Flap)))', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
#                
            sT.replace('((Rotorblatt)(Blade:*))', 'RBL', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            sT.replace('(R\-1\/2\/3)', 'RBL1,RBL2,RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(R1)', 'RBL1', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(R2)', 'RBL2', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(R3)', 'RBL3', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(((Blatt)(RBL)R)(\s|\-)?1)', 'RBL1', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)(RBL)R)(\s|\-)?2)', 'RBL2', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)(RBL)R)(\s|\-)?3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            #dfT.replace('([(Blatt)|(RBL)|(RBL\-)|(R)|(R\-)]\s*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            # Reduktion des cellarray mit den Ticket-Titeln auf die
            # Elemente, die relevante strings enthalten
            #bI = sT.str.contains('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', regex=True, case=False)
            bI = pd.Series([not(re.search('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', s, re.IGNORECASE) is None) for s in sT])

#
#                % Tickets mit wenigstens einem der folgenden Ausdrücke
#                % werden ignoriert:
            sTmp = '(Falscheismeldung .*Peak ung.*nstig)' \
                + '((alle )[0-9]*.?(ECU))' \
                + '(alle Messprogramme)' \
                + '(alle WEA ohne Eis am RBL)' \
                + '((ECU).*(alle) ((im WP)(im PW))?(gleichzeitig))' \
                + '(neue Werte alle)' \
                + '((falsche Zeit).*( alle))' \
                + '(nach Stromabschaltung)' \
                + '((Datenl)((ue)(ü))(cken))' \
                + '(keine externals)' \
                + '(geringes Signal\-Rausch)' \
                + '((Zuordnung).*(<->).*(Firewall vertauscht))' \
                + '((alle)n?( WEA))'
                                    
            #bI2 = sT.str.contains(sTmp, case=False, regex=True)
            bI2 = pd.Series([not(re.search(sTmp, s, re.IGNORECASE) is None) for s in sT])
            
            #bI3 = sT.str.contains('((RBL).*(def))', case=False, regex=True)
            #bI3 = sT.str.contains('((RBL).*((def)|(Unterbrechungen)))', case=False, regex=True)
            bI3 = pd.Series([not(re.search(r'((RBL).*((def)|(Unterbrechungen)))', s, re.IGNORECASE) is None) for s in sT])
            
            bTmp = ~(bI | bI2) & bI3
            bTmp.index = dfTickets.index
            dfRel = dfTickets[bTmp]                                     # relevant tickets
                     
            ## old version before 2019-7-15:
            #bAllSensors = monitor.get_channels_from_str_series(sT)
            #dict_adds = {'dict_ch_fail_tickets': dict_ch_fail_tickets, 'b_ch_fail': b_ch_fail}
            #additional_results = {'dict_ch_fail_tickets': dict_ch_fail_tickets}

            if any(bTmp):
                bAllSensors = monitor.get_channels_from_str_series(sT[bTmp])
                
                # note: case bAllSensors = [] not possible since above tested dfTickets.shape[0]>0
                b_ch_fail = bAllSensors.any(axis=0)                                                                    # boolean vector indicating if there are fail-tickets for the respective channel
                additional_results = {iCh: [b_ch_fail[iCh], dfRel[bAllSensors[:,iCh]]] for iCh in range(6)}        # dict. of channels and related fail tickets (or empty dataFrame if there are none)

            else:
                #b_ch_fail = [False, False, False, False, False, False]
                additional_results = {iCh: [False, dfRel] for iCh in range(6)}
            

        ## TODO 2019-7-15: Variante zum Erkennen von Meas. lines mit Defekt
        ## oder TPV, um kritische lines beim Stick slip effect auszuschliessen
        ## gesamte Funktion noch stringenter, modularer und eleganter machen
        elif sType=='defekt_oder_TPV':
            # TODO 2018-12-18: zunaechst 1:1-Nachbildung der Matlab-Fkt. 'getSensorStates.m', spaeter vereinfachen/eleganter/anders machen            
            sT.replace('(Eissensor Rotorblatt)(cmrbl)(100)(BLADEcontrol)(bladecontrol)(Bladecontrol)', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            
            #dfT.strip(inplace=True)
            
            sT.replace('([rR][bB][lL])', 'RBL', regex=True, inplace=True)
            sT.replace('([fF][lL][aA][pP])', 'Flap', regex=True, inplace=True)
            sT.replace('([eE][dD][gG][eE])', 'Edge', regex=True, inplace=True)
            
            sT.replace('(((vorrangig)(vor\sallem)(v\.a\.)(v\.\sa\.))(\s)*((Edge)(Flap)))', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
#                
            sT.replace('((Rotorblatt)(Blade:*))', 'RBL', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            sT.replace('(R\-1\/2\/3)', 'RBL1,RBL2,RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(R1)', 'RBL1', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(R2)', 'RBL2', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(R3)', 'RBL3', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(((Blatt)|(RBL)|R)(\s|\-)*1)', 'RBL1', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)|(RBL)|R)(\s|\-)*2)', 'RBL2', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)|(RBL)|R)(\s|\-)*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            #dfT.replace('([(Blatt)|(RBL)|(RBL\-)|(R)|(R\-)]\s*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            # Reduktion des cellarray mit den Ticket-Titeln auf die
            # Elemente, die relevante strings enthalten
            #bI = sT.str.contains('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', regex=True, case=False)
            bI = pd.Series([not(re.search('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', s, re.IGNORECASE) is None) for s in sT])

#           Tickets mit wenigstens einem der folgenden Ausdrücke
#           werden ignoriert:
            sTmp = '(Falscheismeldung .*Peak ung.*nstig)' \
                + '((alle )[0-9]*.?(ECU))' \
                + '(alle Messprogramme)' \
                + '(alle WEA ohne Eis am RBL)' \
                + '((ECU).*(alle) ((im WP)(im PW))?(gleichzeitig))' \
                + '(neue Werte alle)' \
                + '((falsche Zeit).*( alle))' \
                + '(nach Stromabschaltung)' \
                + '((Datenl)((ue)(ü))(cken))' \
                + '(keine externals)' \
                + '(geringes Signal\-Rausch)' \
                + '((Zuordnung).*(<->).*(Firewall vertauscht))' \
                + '((alle)n?( WEA))'
                                    
            #bI2 = sT.str.contains(sTmp, case=False, regex=True, na=False)
            bI2 = pd.Series([not(re.search(sTmp, s, re.IGNORECASE) is None) for s in sT])

            #bI3 = sT.str.contains('((RBL).*(def))', case=False, regex=True)
            #bI3 = sT.str.contains('((RBL).*((def)|(Unterbrechungen)|(TPV)|(Tiefpass)))', case=False, regex=True, na=False)
            bI3 = pd.Series([not(re.search(r'((RBL).*((def)|(Unterbrechungen)|(TPV)|(Tiefpass)))', s, re.IGNORECASE) is None) for s in sT])

            
            bTmp = ~(bI | bI2) & bI3
            bTmp.index = dfTickets.index
            dfRel = dfTickets[bTmp]                                     # relevant tickets
                     
            ## old version before 2019-7-15:
            #bAllSensors = monitor.get_channels_from_str_series(sT)
            #dict_adds = {'dict_ch_fail_tickets': dict_ch_fail_tickets, 'b_ch_fail': b_ch_fail}
            #additional_results = {'dict_ch_fail_tickets': dict_ch_fail_tickets}

            if any(bTmp):
                bAllSensors = monitor.get_channels_from_str_series(sT[bTmp])
                
                # note: case bAllSensors = [] not possible since above tested dfTickets.shape[0]>0
                b_ch_fail = bAllSensors.any(axis=0)                                                                    # boolean vector indicating if there are fail-tickets for the respective channel
                additional_results = {iCh: [b_ch_fail[iCh], dfRel[bAllSensors[:,iCh]]] for iCh in range(6)}        # dict. of channels and related fail tickets (or empty dataFrame if there are none)

            else:
                #b_ch_fail = [False, False, False, False, False, False]
                additional_results = {iCh: [False, dfRel] for iCh in range(6)}
                                    

        ## TODO 2019-7-15: Variante zum Speichern der RBL-tickets fuer Ernst,
        ## ggf. wieder entfernen oder auskommentieren
        elif sType=='all_rbl_related':
            # TODO 2018-12-18: zunaechst 1:1-Nachbildung der Matlab-Fkt. 'getSensorStates.m', spaeter vereinfachen/eleganter/anders machen            
            sT.replace('(Eissensor Rotorblatt)(cmrbl)(100)(BLADEcontrol)(bladecontrol)(Bladecontrol)', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            
            #dfT.strip(inplace=True)
            
            sT.replace('([rR][bB][lL])', 'RBL', regex=True, inplace=True)
            sT.replace('([fF][lL][aA][pP])', 'Flap', regex=True, inplace=True)
            sT.replace('([eE][dD][gG][eE])', 'Edge', regex=True, inplace=True)
            
            sT.replace('(((vorrangig)(vor\sallem)(v\.a\.)(v\.\sa\.))(\s)*((Edge)(Flap)))', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
#                
            sT.replace('((Rotorblatt)(Blade:*))', 'RBL', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            sT.replace('(R\-1\/2\/3)', 'RBL1,RBL2,RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(R1)', 'RBL1', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(R2)', 'RBL2', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(R3)', 'RBL3', regex=True, inplace=True)                            # some tickets contain R1 (or R2 or R3) instead of RBL1, ...2, ...3
            sT.replace('(((Blatt)|(RBL)|R)(\s|\-)*1)', 'RBL1', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)|(RBL)|R)(\s|\-)*2)', 'RBL2', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)|(RBL)|R)(\s|\-)*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            #dfT.replace('([(Blatt)|(RBL)|(RBL\-)|(R)|(R\-)]\s*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            # Reduktion des cellarray mit den Ticket-Titeln auf die
            # Elemente, die relevante strings enthalten
#            bI = sT.str.contains('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', regex=True, case=False)

           # Tickets mit wenigstens einem der folgenden Ausdrücke
           # werden ignoriert:
#            sTmp = '(Falscheismeldung .*Peak ung.*nstig)' \
#                + '((alle )[0-9]*.?(ECU))' \
#                + '(alle Messprogramme)' \
#                + '(alle WEA ohne Eis am RBL)' \
#                + '((ECU).*(alle) ((im WP)(im PW))?(gleichzeitig))' \
#                + '(neue Werte alle)' \
#                + '((falsche Zeit).*( alle))' \
#                + '(nach Stromabschaltung)' \
#                + '((Datenl)((ue)(ü))(cken))' \
#                + '(keine externals)' \
#                + '(geringes Signal\-Rausch)' \
#                + '((Zuordnung).*(<->).*(Firewall vertauscht))' \
#                + '((alle)n?( WEA))'
            sTmp = '(RBL)[1|2|3]'
            #bI3 = sT.str.contains(sTmp, case=False, regex=True, na=False)
            bI3 = pd.Series([not(re.search(sTmp, s, re.IGNORECASE) is None) for s in sT])
            
            #bI = sT.str.contains('(ECU)|(HMU)|(n.(\s|\-)*e.)', case=False, 
            #                      regex=True, na=False)
            bI = pd.Series([not(re.search('(ECU)|(HMU)|(n\.(\s|\-)*e\.)|(nicht erreichbar)', 
                                          s, re.IGNORECASE) is None) for s in sT])
            #bI3 = sT.str.contains('((RBL).*((def)|(Unterbrechungen)|(TPV)|(Tiefpass)))', case=False, regex=True)
            
            bTmp = ~bI & bI3
            bTmp.index = dfTickets.index
            
            dfRel = dfTickets[bTmp]                                     # relevant tickets
                     
            ## old version before 2019-7-15:
            #bAllSensors = monitor.get_channels_from_str_series(sT)
            #dict_adds = {'dict_ch_fail_tickets': dict_ch_fail_tickets, 'b_ch_fail': b_ch_fail}
            #additional_results = {'dict_ch_fail_tickets': dict_ch_fail_tickets}
            if any(bTmp):
                bAllSensors = monitor.get_channels_from_str_series(sT[bTmp])
                
                # note: case bAllSensors = [] not possible since above tested dfTickets.shape[0]>0
                b_ch_fail = bAllSensors.any(axis=0)                                                                    # boolean vector indicating if there are fail-tickets for the respective channel
                additional_results = {iCh: [b_ch_fail[iCh], dfRel[bAllSensors[:,iCh]]] for iCh in range(6)}        # dict. of channels and related fail tickets (or empty dataFrame if there are none)

            else:
                #b_ch_fail = [False, False, False, False, False, False]
                additional_results = {iCh: [False, dfRel] for iCh in range(6)}
            
            
            

        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach
        elif sType =='data_fix':
            
            #sPatternRegEx = '(ext.*fix)|( n\.e)|( externals )|(nicht erreichbar)|(mi[(ss)|ß]t nicht)|(keine externals)|(eingefrorene Betriebsdaten)|(Betriebsdaten eingefroren)'
            sPatternRegEx = '(?:ext.*fix)|(?: n\.e)|(?: externals )|(?:nicht erreichbar)|(?:mi[(ss)|ß]t nicht)|(?:keine externals)|(?:eingefrorene Betriebsdaten)|(?:Betriebsdaten eingefroren)|(?:frozen externals)'
            #bTmp = ~sT.isnull() & sT.str.contains(sPatternRegEx, regex=True, case=False, na=False)                
            bTmp = pd.Series([not(re.search(sPatternRegEx, s, re.IGNORECASE) is None) for s in sT])
            bTmp.index = dfTickets.index

            dfRel = dfTickets[bTmp]                                      # relevant tickets
    
            if any(bTmp):
                bAllSensors = monitor.get_channels_from_str_series(sT[bTmp])
                
                # note: case bAllSensors = [] not possible since above tested dfTickets.shape[0]>0
                b_ch_fail = bAllSensors.any(axis=0)                                                                    # boolean vector indicating if there are fail-tickets for the respective channel
                additional_results = {iCh: [b_ch_fail[iCh], dfRel[bAllSensors[:,iCh]]] for iCh in range(6)}        # dict. of channels and related fail tickets (or empty dataFrame if there are none)

            else:
                #b_ch_fail = [False, False, False, False, False, False]
                additional_results = {iCh: [False, dfRel] for iCh in range(6)}

                         
    
        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach        
        elif sType == 'low_pass':
            
            sPatternRegEx = '((rbl|rotorbl*).*(def|tpv|tiefpass))'        
            #bTmp = sT.str.contains(sPatternRegEx, regex=True, case=False)                
            bTmp = pd.Series([not(re.search(sPatternRegEx, s, re.IGNORECASE) is None) for s in sT])
            bTmp.index = dfTickets.index
            
            dfRel = dfTickets[bTmp]                                     # relevant tickets
            
            if any(bTmp):
                bAllSensors = monitor.get_channels_from_str_series(sT[bTmp])
                
                # note: case bAllSensors = [] not possible since above tested dfTickets.shape[0]>0
                b_ch_fail = bAllSensors.any(axis=0)                                                                    # boolean vector indicating if there are fail-tickets for the respective channel
                additional_results = {iCh: [b_ch_fail[iCh], dfRel[bAllSensors[:,iCh]]] for iCh in range(6)}        # dict. of channels and related fail tickets (or empty dataFrame if there are none)

            else:
                #b_ch_fail = [False, False, False, False, False, False]
                additional_results = {iCh: [False, dfRel] for iCh in range(6)}
    
    
        else:
            print('unknown check-Type for Ticket finding, return no tickets')
            dfRel = pd.DataFrame(columns = dfTickets.columns)
            additional_results = {iCh: [False, dfRel] for iCh in range(6)}


    else:
        dfRel = pd.DataFrame(columns = dfTickets.columns)
        additional_results = {iCh: [False, dfRel] for iCh in range(6)}        
        
    return(dfRel, additional_results)
    
    