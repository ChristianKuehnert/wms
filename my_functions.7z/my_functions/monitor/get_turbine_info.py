# -*- coding: utf-8 -*-
"""
get basic information and combine them to strings for text and for name parts of files and folders
    
Created on Tue Mar 26 01:42:17 2019

@author: Christian Kuehnert
@last_modified: 2019-3-26
"""
def get_turbine_info(tb):
    
    sFarm = tb['sFarm'].__str__()
    sName = tb['sName'].__str__()
    sDB = tb['sDB'].__str__()
    
    sInfoText = sFarm + ', ' + sName + ' (' + sDB + ')'
    sInfoFN = sFarm + '__' + sName + '__' + sDB
    sInfoFN.replace(' ', '_').replace('(','_').replace('(','_').replace(',','_')
        
    return sInfoText, sInfoFN
        
