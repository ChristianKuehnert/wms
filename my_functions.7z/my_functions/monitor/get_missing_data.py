# -*- coding: utf-8 -*-
"""
function to find the last datetime with (non-fix) data in the given table in the
given database, after this date either no new data were stored or they have been fix

Created on Tue Mar 26 01:59:53 2019

@author: Christian Kuehnert, 2019-10-21


Parameters:
-----------

sDB:              database name
sTabName:         table name
sColTime:         name of the column containing the time
sColNames:        columns of the table (except time)
sColsToTest:      names of the columns that should be analysed for fixed/missing data
#t0:               end time
#tAllowedDelay:    allowed time intervall

Results:
--------

bDataFix:
tLastData:
tLastDataNotFix:  
dfTimes:       DataFrame with columns 1) name, containing the names of the columns (i.e. sColsToTest), 2) bDataFix: boolean flag indicating 
                  if the data are fix/missing for this column, 3) tLastData: 
sMsg:             result/error message

"""
import sys
import pandas as pd
import datetime as dt

sys.path.append(r'C:\Repositories\python\functions')        # path to modules  
sys.path.append(r'C:\Repositories\python\automatic_monitoring')
import data as mfdata
import monitor as mfmon


#def getMissingData(sDB, sTable, time_end, time_delta_allowed=dt.timedelta(days=1), col_time='create_time', cols_to_test=None, bExclNaN=True):
def get_missing_data(db, table, end_time, time_delta_allowed=dt.timedelta(days=1), col_time='create_time', cols_to_test=None):
    
    sMsg = ''
    sFormatDT = '%Y%m%d%H%M%S'
    last_times_not_ok = {}   #None
    bOk = True
    
    n_cols = len(cols_to_test)            # number of columns to test
	                
    if (n_cols == 0):        
        sMsg = 'keine Spalten zum Testen ausgewaehlt'
        
    else:
        
        ## first: query if there are at least two distinct values during the allowed period for all columns to test
        try:
#HIER WEITER 2019-2-22
            tmp = end_time - time_delta_allowed
            sStartTime = tmp.strftime(sFormatDT)                                                        # starting time for first test
            sEndTime = end_time.strftime(sFormatDT)
            
            tmp = [f"count(distinct {col})" for col in cols_to_test]                        
            sQuery = "select " + ','.join(tmp) + f" from {table} where ({col_time}>='{sStartTime}') and ({col_time}<='{sEndTime}')"
            res1 = mfdata.query_MySQL2(db, sQuery)[0]

            btmp = [x < 2 for x in res1]                               

            if any(btmp):
                cols_not_ok = list(pd.Series(cols_to_test)[btmp])        
                last_times_not_ok = mfmon.get_times_last_data(db, table, str_end_time=sEndTime, col_time='create_time', cols_to_test=cols_not_ok)
                                                  
        except Exception as e:            
            #sMsg = 'Zugriffsproblem ' + db + '.' + table + ', ' + logger.error(repr(e))
            sMsg = 'Zugriffsproblem ' + db + '.' + table + ', ' + str(e)
            bOk = False        


    return(last_times_not_ok, sMsg, bOk)
          
    
    