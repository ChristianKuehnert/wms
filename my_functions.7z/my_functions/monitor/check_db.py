# -*- coding: utf-8 -*-
"""
function to check if database exists
TODO 2019-2-21: later also check if this database contains the required tables

Created on Tue Mar 26 02:19:04 2019

@author: Christian Kuehnert
@modified: 2019-7-30

input:
------
        - db: database name (including 'cmrblba_')
"""

import pandas as pd
import numpy as np

import data as mfdata
from monitor import set_checks_to_false, create_issue

#from monitor.class_issue import issue

def check_db(db, tickets, checks, issues):
    
    #issues = []
    
    bTmp = isinstance(db, str)
    if bTmp:
        bTmp = (len(db.strip())>0)
            
    if not(bTmp):
        issues.append(create_issue(db, sErrorMsg = ('kein DB-Name im PIT '
                                                    'eingetragen')))
        set_checks_to_false(checks, checks.keys())
        #for key in checks.keys():
        #    checks[key] = False
        

    if checks['db']:
        try:                
            sTablesDB = pd.DataFrame(data=np.array(mfdata.query_MySQL2(db, 'SHOW TABLES;'))).infer_objects().iloc[:,0].tolist()
            
            #bTabOk = any([(s.find('ba_',0,3)>-1) for s in sTablesDB])                
            #if bTabOk:
                
            ## check for special required tables
            if not (('ba_cycle_measurement_cycle' in sTablesDB) or 
                    ('ba_cycle_measurement_cycle_state' in sTablesDB)):                        
                #checks['db'] = False
                #checks['meas_line'] = False
                #checks['low_pass'] = False
                set_checks_to_false(checks, ['db', 'meas_line', 'low_pass', 
                                             'stick_slip'])
                issues.append(create_issue(sErrorMsg = ('kein Check auf '
                                                        'Sensor TPV/defekt '
                                                        'möglich, Tab.n '
                                                        'ba_cycle_measurement_'
                                                        'cycle oder ba_cycle_'
                                                        'measurement_cycle_'
                                                        'state fehlen in DB')))
                    						                    
                
            if not ('ba_cycle_measurement_cycle' in  sTablesDB):
                #check['ice_eval'] = False
                set_checks_to_false(checks, ['db', 'ice_eval', 'stick_slip'])
                issues.append(create_issue(sErrorMsg = ('kein Check auf no ice'
                                                        ' eval möglich, Tab.n '
                                                        'ba_cycle_measurement_'
                                                        'cycle fehlt in DB')))
						                                               
            if not('ba_cycle_status' in sTablesDB):
                #check['db'] = False
                #check['imp_ext'] = False
                #check['data_fix'] = False
                set_checks_to_false(checks, ['db', 'imp_ext', 'data_fix', 
                                             'stick_slip'])
                issues.append(create_issue(sErrorMsg = ('kein Check auf '
                                                        'improper externals '
                                                        'und Produktionsdaten '
                                                        'fix möglich, Tabelle '
                                                        'ba_cycle_status fehlt'
                                                        'in DB')))
                    
            if not('ba_cycle_externals' in sTablesDB):
                #check['db'] = False
                #check['data_fix'] = False
                set_checks_to_false(checks, ['db', 'data_fix'])
                issues.append(create_issue(sErrorMsg = ('kein Check auf extern'
                                                        'als fix möglich, Tabe'
                                                        'lle ba_cycle_externa'
                                                        'ls fehlt in DB')))
                                                                                  
            if not('ba_cycle_icing_peak', sTablesDB):
                #check['db'] = False
                #check['ice_eval'] = False
                set_checks_to_false(checks, ['db', 'ice_eval'])
                issues.append(create_issue(sErrorMsg = ('kein Check auf ice '
                                                        'evaluation möglich, '
                                                        'Tabelle ba_cycle_'
                                                        'icing_peak fehlt in'
                                                        'DB')))
                                                                                                                                  
            if not('preferences', sTablesDB):
                #check['prefs'] = False
                #check['ice_eval'] = False
                set_checks_to_false(checks, ['db', 'prefs', 'ice_eval'])
                issues.append(create_issue(sErrorMsg = ('kein Check auf prefer'
                                                        'ences und ice evaluat'
                                                        'ion möglich, Tabelle '
                                                        'preferences fehlt in'
                                                        'DB')))
                                                                      
            #else:
#               #     self.lErrClass.append(?)
            #    lIssues.append(issue(sFarm = self.sFarm, sWT = self.sName, sDB = self.sDB, sErrorMsg = 'DB enthaelt keine Tab. mit \'ba_\'', iErrorClass = 12, sAction = '', sLink = '', bShort = True))
                                                                    
        except:

            set_checks_to_false(checks, checks.keys())
            issues.append(create_issue(sErrorMsg = 'DB n.e., SSHport: ' + 
                                       db['sSSH_port'].__str__()))
       
    
    #return issues
