# -*- coding: utf-8 -*-
"""
function to check if stick-slip effect occurred

Created on 2019-7-28

@author: Christian Kuehnert
@last_modified: 2019-7-30

input:
------
        - db: database name (including 'cmrblba_')
"""

import datetime as dt
import pandas as pd
import numpy as np
import gc
from scipy import stats


#from monitor import get_missing_data, create_issue, set_checks_to_false, 
#get_relevant_tickets, create_link
#from data import get_preferences
import data as mfdata
import monitor as mfmon
from monitor.class_issue import issue








## function to get the outliers
## first with extremely simple method
def get_outlier_candidates(df_se, channels = ['e_101_edge', 'e_102_edge', 
            'e_103_edge', 'e_101_flap', 'e_102_flap', 'e_103_flap']):
    
    th_e = 2000
    th_f = 500
    
    col_edge = list(set(channels) & {'e_101_edge', 'e_102_edge', 'e_103_edge'})
    col_flap = list(set(channels) & {'e_101_flap', 'e_102_flap', 'e_103_flap'})
    
    btmp = (df_se.loc[:, col_edge] \
                > th_e).any(axis=1).values & \
            (df_se.loc[:, col_flap] \
                > th_f).any(axis=1).values
    
    return(df_se[btmp])
    




## function to calulat the range of the given angular list
def range_angular(v):
    v_min = min(v)
    v_max = max(v)
    #if not 
#    max(azimuth)-min(azimuth)
#    if not (azimuth.mean()<=max(az))
    return(v_max-v_min)







## function to compare the neighborhoods
def compare_left_right(df_se, st, channels, threshold):
    
    bmax = (df_se.index == st)
    
    medians = df_se[~bmax].median(axis=0)                       
    
    medians_left = df_se[df_se.index < st].median(axis=0)
    medians_right = df_se[df_se.index > st].median(axis=0)                    
    
    rel = abs(medians_left-medians_right)/medians

    return(rel <= threshold)






## function to detect outliers
## df_se: df of signal energy for the considered interval
## st_peak: datetime of the peak
## channels: channels to include
## method_name: name of the method, later change to:
    ## fct: function of the method
    ## **kwargs: parameters
## 2019-7-13
#def detect_outliers(df_se, fct, **kwargs):
def detect_outliers(df_se, st_peak, channels, method_fct, kwargs):

    bout, df_out = method_fct(df_se, st_peak, channels, **kwargs)
                        
    return(bout, df_out)
    




## method to detect outliers by peak over ground ratio
# threshold_z: ratio peak/ground to identify as outlier
# allowed_dev_medians: relative deviation of medians to accept as sse-induced
# outlier
# 2019-7-14
def detect_outliers__peak_to_ground(df_se, st, channels, threshold_z=4, 
                                    allowed_dev_medians = 0.2):
        
    # TODO 2019-7-13: ggf. schneller machen und nur fuer die channels alles
    # berechnen
    bmax = (df_se.index == st)
    medians = df_se[~bmax].median(axis=0)
    df_tmp = df_se[bmax] / medians
                        
#    medians_left = df_se[df_se.index < st].median(axis=0)
#    medians_right = df_se[df_se.index > st].median(axis=0)                    
#    rel = abs(medians_left-medians_right)/medians

    blr = all(compare_left_right(df_se, st, channels, allowed_dev_medians)
                                                                    [channels])
                        
    ## peak is much larger than surrounding and left and
    ## right vicinities differ not more than 20% from total
    ## median
#    bout = (df_tmp.loc[:, channels].values >= threshold_z).all(axis=1)[0] \
#            & all(rel.loc[:, channels] <=allowed_dev_medians)

    bout = (df_tmp.loc[:, channels].values >= threshold_z).all(axis=1)[0] \
                & blr

    
    ## 
    df_out = df_se[[b & bout for b in bmax]]
#    if bout:
#        df_out = df_se[bmax]
#    else:
#        df_out = hier leeren df mit gleicher Struktur wie df_se
    
    return(bout, df_out)






## method to detect outliers by classical z-score but also check the relation
## between ground on lhs and rhs
# threshold_z: ratio peak/ground to identify as outlier
# allowed_dev_medians: relative deviation of medians to accept as sse-induced
# outlier
# 2019-7-13
def detect_outliers__zscore(df_se, st, channels, threshold_z=3, 
                            allowed_dev_medians = 0.2):
        
    # TODO 2019-7-13: ggf. schneller machen und nur fuer die channels alles
    # berechnen
    arr_tmp = stats.zscore(df_se.loc[:, channels])
    btmp = (arr_tmp >= threshold_z).all(axis=1)
    df_out = df_se[btmp]
       
    #bmax = (df_se.index == st)
    
    blr = all(compare_left_right(df_se, st, channels, allowed_dev_medians)
                                                                    [channels])
    
#    medians = df_se[~bmax].median(axis=0)                       
#    medians_left = df_se[df_se.index < st].median(axis=0)
#    medians_right = df_se[df_se.index > st].median(axis=0)                    
#    rel = abs(medians_left-medians_right)/medians
                        
    ## peak is much larger than surrounding and left and
    ## right vicinities differ not more than 20% from total
    ## median
#    bout = all((arr_tmp >= threshold_z).all(axis=1) \
#            & all(rel.loc[:, channels] <=allowed_dev_medians)

    bout = all(arr_tmp >= threshold_z) & blr
        
    df_out = df_se[[b & bout for b in btmp]]
#    if bout:
#        df_out = df_se[bmax]
#    else:
#        df_out = hier leeren df mit gleicher Struktur wie df_se
    
    return(bout, df_out)







# TODO 2019-7-29: vielleicht (bei allen checks) nicht konkret die speziellen
# parameter eintragen sondern **kwargs uebergeben
def check_stick_slip(db, df_tickets, checks, issues, start_time, end_time, 
                     margin = (dt.timedelta(seconds = 600), 
                    dt.timedelta(seconds = 600)), freq_range = (80, 110),
                    thresh = {'ratio_peak_to_median': 4,
                              'allowed_dev_medians': 0.2,
                              'azimuth': 10,
                              'pitch': 3},
                    map_channels = {0: 'e_101_flap', 1: 'e_102_flap',
                                    2: 'e_103_flap', 3: 'e_101_edge',
                                    4: 'e_102_edge', 5: 'e_103_edge'}):


    ## set where-clause regarding the time interval as first element in list
    ## of time clauses
    lwc = [mfdata.whereClause_from_timeInterval(
            time_start=start_time-margin[0], time_end=end_time-margin[1])]
    
    ## append where-clauses related to the frequency range to the list of
    ## where clauses
    lwc.append(f'(start_f>={freq_range[0]}) and (start_f<{freq_range[1]})')
    
    ## generate where clause
    s_wc = (' and '.join(lwc).replace('start_f', 'se.start_f')
                            .replace('create_time', 'se.create_time'))
    

    # TODO 2019-7-29: bei Zeit mal probieren, ob ERST group-Bildung bei sig_en
    # und ANSCHLIESSEND join schneller ist
    query = ('select se.create_time,avg(cd.pitch_mean),avg(cd.azimuth_mean),'
             'sum(se.e_101_edge),sum(se.e_102_edge),sum(se.e_103_edge),'
             'sum(se.e_101_flap),sum(se.e_102_flap),sum(se.e_103_flap) '
             'from ba_cycle_sig_energies se '
             'join ba_cycle_status cd '
             'on se.create_time=cd.create_time '            
             f'where {s_wc} '
             'group by se.create_time;')

    
    try:
        ## request the relevant signal energies
        tmp = np.array(mfdata.query_MySQL2(db, query, params=None))    

        ## if there are any ...
        if (tmp.shape[0]>0):
        
            columns = ['create_time', 'pitch_mean', 'azimuth_mean', 
                       'e_101_edge', 'e_102_edge', 'e_103_edge', 'e_101_flap', 
                       'e_102_flap', 'e_103_flap']

            df_se_band = (pd.DataFrame(data=tmp, columns = columns)
                            .infer_objects())
                     
            df_se_band.set_index('create_time', inplace=True)
            
            fac = freq_range[1] - freq_range[0]
            
            for c in ['e_101_edge', 'e_102_edge', 'e_103_edge', 'e_101_flap', 
                      'e_102_flap', 'e_103_flap']:
                
                df_se_band.loc[:, c] = df_se_band.loc[:, c]/fac
                        
            
            ## 1. find candidates
    
            ## consider only intact measuring lines
            # tickets for measure lines with problems    
            dfTicketsCrit, dict_ch_tickets = mfmon.get_relevant_tickets(
                    df_tickets, sType = 'defekt_oder_TPV')                     
    
            channels_ok = []
            for k, [bFail, dfRelTickets] in dict_ch_tickets.items():
                if ~bFail:
                    channels_ok.append(map_channels[k])
                else:
                    if dfRelTickets[~(dfRelTickets.sStatus=='erledigt')].shape[0]==0:
                        # TODO 2019-7-12: noch Datumspruefung einfuehren, 
                        # d.h. auch bei alten geschlossenen Tickets ggf. 
                        # den Kanal ausschliessen, wenn sich die 
                        # betrachteten Zeiten mit dem Ticketzeitraum 
                        # ueberschneiden
#                        -> bzw., 2019-7-28: bereits geaendertes get_relevant_tickets mit period hier richtig verwenden
                        channels_ok.append(map_channels[k])
                                             
    
            if len(channels_ok)>0:
            
                list_t = []
                
                ## here consider the time interval without the margins
                df_out = get_outlier_candidates(df_se_band[
                        (df_se_band.index>=start_time) & \
                        (df_se_band.index>=end_time)], channels = channels_ok)
                
                ## if candidates exist do further analysis, otherwise ok
                if df_out.shape[0]>0:
                    
                    stop_time = pd.Series(df_out.index)
                                            
                    ## now try z-score outlier detection as criterion                                                          
                    for st in stop_time:        
                        
                        # TODO 2019-7-9: noch verfeinern spaeter, z.B. ausschliessen, dass
                        # mit nachstem Intervall ueberlappt etc., Anfangs- und End-
                        # zeitraum ggf. besonders behandeln etc.
                        t1, t2 = st - margin[0], st + margin[1]   # period to consider
        
                        df_se = df_se_band[(df_se_band.index >= t1) & \
                                           (df_se_band.index <= t2)]
                        
                        ## check if maximum is at time st
                        # TODO 2019-7-11: pruefen, ob fuer alle Kanaele (lokales) 
                        # SE-Maximum vorliegt
                        if st in pd.to_datetime(df_se.idxmax().values):
                                            
                            btmp, df_out_se = detect_outliers(df_se,st,channels_ok, 
                                                   detect_outliers__peak_to_ground,
                                                   {'threshold_z': thresh[
                                                           'ratio_peak_to_median'],
                                                    'allowed_dev_medians': 
                                                        thresh[
                                                        'allowed_dev_medians']})
                            
                            if btmp:
                                
                                ## get azimuth range
                                azimuth = df_out_se[(df_out_se.index >= t1) & 
                                                  (df_out_se.index <= t2)].azimuth
                                    
                                ## get pitch range                            
                                pitch = df_out_se[(df_out_se.index >= t1) & 
                                                  (df_out_se.index <= t2)].pitch
                                    
                                if (range_angular(azimuth)>=thresh['azimuth']) & \
                                    (range_angular(pitch) < thresh['pitch']):
                                    
                                    list_t.append(df_out_se.index[0])
                                
                    ## if stick slip dates were found:
                    if len(list_t)>0:
                        sMsg = 'wahrscheinlich Öl auf Azimuthbremsen'
                        t_start_link = min(list_t) - dt.timedelta(hours = 12)
                        t_end_link = min(list_t) - dt.timedelta(hours = 12)
                                            
                    else:
                        sMsg = 'unklar bzgl. Öl auf Azimuthbremsen'
                        t_start_link = min(stop_time) - dt.timedelta(hours = 12)
                        t_end_link = min(stop_time) - dt.timedelta(hours = 12)
                                            
                    sLink = mfmon.create_link(db, sTool = 'SE_abs', cols_gh = None, 
                                              start_time = t_start_link, 
                                              end_time = t_end_link,
                                              kwargs = {'freq': (80,110)})
                                           
                    issues.append(create_issue(db,
                                               sErrorMsg = sMsg,
                                               sAction = '',
                                               sLink = sLink,
                                               sTool = 'SE'))
                                                                                      
            else:
                # TODO 2019-7-30: diesen Zweig bei issue-Ergebnis ggf. weg-
                # lassen, evtl. nur als Info in log-output oder so
                sMsg = ('alle Sensorstrecken mit Tickets - Auswertung auf '
                        'Stick-Slip-Effekt nicht möglich')
                
                t_start_link = min(start_time) - dt.timedelta(hours = 12)
                t_end_link = min(end_time) - dt.timedelta(hours = 12)

                sLink = mfmon.create_link(db, sTool = 'SE_abs', cols_gh = None, 
                                          start_time = t_start_link, 
                                          end_time = t_end_link,
                                          kwargs = {'freq': (80,110)})
                
                issues.append(issue(db,                                                sErrorMsg = sMsg,
                                                 sAction = '',
                                                 sLink = sLink,
                                                 sTool = 'SE'))
                
            
        else:
            sMsg = ('SE-Daten oder CDEF-Daten nicht gefunden - Auswertung auf '
                    'Stick-Slip-Effekt nicht möglich')
                
            t_start_link = min(start_time) - dt.timedelta(hours = 12)            
            t_end_link = min(end_time) - dt.timedelta(hours = 12)

            sLink = mfmon.create_link(db, sTool = 'SE_abs', cols_gh = None, 
                                      start_time = t_start_link, 
                                      end_time = t_end_link,
                                      kwargs = {'freq': (80,110)})
            
            issues.append(mfmon.create_issue(db,
                                             sErrorMsg = sMsg,
                                             sAction = '',
                                             sLink = sLink,
                                             sTool = 'SE'))
                    
    except:
        sMsg = ('unbekanntes Problem - Auswertung auf Stick-Slip-Effekt nicht '
                'möglich')
                
        t_start_link = min(start_time) - dt.timedelta(hours = 12)            
        t_end_link = min(end_time) - dt.timedelta(hours = 12)

        sLink = mfmon.create_link(db, sTool = 'SE_abs', cols_gh = None, 
                                  start_time = t_start_link, 
                                  end_time = t_end_link,
                                  kwargs = {'freq': (80,110)})
        
        issues.append(mfmon.create_issue(db,
                                         sErrorMsg = sMsg,
                                         sAction = '',
                                         sLink = sLink,
                                         sTool = 'SE'))

    gc.collect()
    
    
    #return issues
