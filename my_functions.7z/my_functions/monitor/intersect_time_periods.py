# -*- coding: utf-8 -*-
"""
Created on Thu Jul  4 12:10:06 2019

@author: w012028
@modified: 2019-7-4


function to combine the time periods of the given list to a list of periods


Input:
		- list_periods:  list of time periods (each period is a tuple
                         (start_time, end_time), both values can be pd.NaT but
                         then the result is (pd.NaT, pd.NaT) too

		- combination_type: can be 'any' or any other string, the letter case
                            will be interpreted as 'all'
                            'any' means that all periods will be combined to 
                            the set wich contains the same time-elements but 
                            has the least possible elements
                            'all' means that the elements of list_period will
                            be intersected, only times contained in all
                            list elements are returned
                            
                            


 Output:
		- list with time periods
        

"""
# TODO 2019-7-4: alle Ticket-Relevanten Funktionen mal in eine Klasse packen,
# die die Tickets zu den einzelnen WEAs enthaelt und dort die Auswertungen
# durchfuehrt

import re
import numpy as np
import pandas as pd

from monitor import get_ticket_times



def combine_ticket_times(list_periods, combination_type='any'):
    pass

# TODO 2019-7-4: noch implementieren, ggf. nur wrapper schreiben fuer schon
# vorhandene python-functions 
    
    
    
    
    
    
    
    
