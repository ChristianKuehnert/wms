# -*- coding: utf-8 -*-
"""
function to check if ice evaluation is working

Created on Tue Mar 26 02:31:11 2019

@author: Christian Kuehnert
@last_modified: 2020-1-29

input:
------
        - db: database name (including 'cmrblba_')
"""
import re
import datetime as dt
import pandas as pd
import numpy as np
import data as mfdata
#from monitor import create_link, create_issue
#import monitor as mfmon
from monitor.class_issue import issue






"""
function to check measuring program version, for newer programs the entries in
status table and ice peak table should be synchronous, for older not

@modified: 2020-1-29

TODOO 2020-1-29: eleganter machen
"""
def use_synchronized_data(revision):
    
    try:
        # first remove everything from 'release' onwards
        tmp = revision[:revision.find('release')].strip(' ')
        #ix = tmp.index('release')
        
        # find version number
        ver = re.findall("((?:cmrbl)\d+(?:.\d+)*)", tmp)[0]
        
        # find remaining revision
        rev = tmp.replace(ver, '').replace('rev', '').replace('(', '').replace(')', '').strip()
        
        ver_parts = [int(v) for v in ver.replace('cmrbl', '').split('.')]
              
        v1 = ver_parts[0]
        if (v1 > 2):
            bSync = True
        elif (v1<2):
            bSync = False
        else:  # case v1==2
            bSync = False
            if len(ver_parts)>1:            
                if (int(ver_parts[1])>= 4):                
                    try:
                        bSync = (int(rev)>=1111)
                    except:
                        bSync = True
                        # revsion number not integer
                        
    except:
        print('problem with evaluating revision')
        bSync = True
                
    return(bSync)








#def check_ice_eval(db, tickets, checks, issues, start_time, end_time):
def check_ice_eval(db, tickets, checks, issues, start_time, end_time, 
                   delta=dt.timedelta(hours=24), revision = ''):
    #issues = []
    
    sDTFormatDB='%Y%m%d%H%M%S'
                
    # TODO 2018-12-6: noch Tickets auswerten, ob schon entsprechendes vorhanden!            
    try:
        
        prefs = mfdata.get_preferences(db)

        if 'MinWindLevel' in prefs.keys():                                       
            sMinWindLevel = prefs['MinWindLevel']
            if len(sMinWindLevel.strip())==0:
                sMinWindLevel = '3'
        else:
            sMinWindLevel = '3'    
                        
        if 'Turbine@StopMinPitchAngle' in prefs.keys():                                       
            sPitchMax = prefs['Turbine@StopMinPitchAngle']
            if len(sPitchMax.strip())==0:
                sPitchMax = '75'
        else:
            sPitchMax = '75'    
                                    
        if 'Turbine@OmegaMinFreq' in prefs.keys():                                       
            sOmegaMin = prefs['Turbine@OmegaMinFreq']
            if len(sOmegaMin.strip())==0:
                sOmegaMin = '0.05'
        else:
            sOmegaMin = '0.05'    
        
        
        stype_mpr = ''
        
        # 2019-9-25: NOTE: for checking the ice evaluation only the interval
        # [end_time - delta, end_time] is considered (in order to react swiftly
        # enough)
        sStartTimeCheck = (end_time-delta).strftime(sDTFormatDB)
        sEndTime = end_time.strftime(sDTFormatDB)
                
        sHeadersKeys = ['create_time','ID']
        # TODO 2018-12-14: evtl. alles mit einer Abfrage erledigen und gleich die beiden Counts ausgeben
        sQuery = 'select distinct create_time,ID ' \
                + 'from ba_cycle_status ' \
                + 'where (create_time>=\'' + sStartTimeCheck + '\') and (create_time<=\'' + sEndTime + '\') ' \
                + 'and (wind_mean>' + sMinWindLevel + ') and (omega_mean>=' + sOmegaMin + ') and (pitch_mean<=' + sPitchMax + ');'                      
                
        tupTmp = mfdata.query_MySQL2(db, sQuery)
        if len(tupTmp)>0:                                                    
            dfStatus = pd.DataFrame(data=np.array(tupTmp), columns=sHeadersKeys).infer_objects()                        
        else:
            dfStatus = pd.DataFrame(columns=sHeadersKeys)                        
            
        iCtStatus = dfStatus.shape[0]
        
        
#            sQuery = 'select distinct create_time,cycle_id  ' \
#                    + 'from ba_cycle_icing_peak ' \
#                    + 'where (create_time>=\'' + sStartTimeCheck + '\') and (create_time <= \''  + sEndTime + '\') ' \
#                    + 'and (actual_freq > 0);'
        sQuery = 'select distinct create_time,cycle_id  ' \
                + 'from ba_cycle_icing_peak ' \
                + 'where (status>0) and (create_time>=\'' + sStartTimeCheck + '\') and (create_time <= \''  + sEndTime + '\') ' \
                + 'and (actual_freq > 0);'
            
        tupTmp = mfdata.query_MySQL2(db, sQuery)
        if len(tupTmp)>0:
            dfIcingPeak = pd.DataFrame(data=np.array(tupTmp), columns=sHeadersKeys).infer_objects()
            
            if use_synchronized_data(revision):
                iCtIcingPeak = mfdata.intersect_df(dfStatus, dfIcingPeak, sHeadersKeys).shape[0]
            else:
                iCtIcingPeak = dfIcingPeak.shape[0]
                stype_mpr = ' (unsynchronized)'
        else:
            iCtIcingPeak = 0

        if (iCtStatus > 0) and (iCtIcingPeak == 0):
            #sStartLink = str(int(np.floor((dt_time_start - dt.timedelta(hours = 6)).timestamp())*1000))
            #sEndLink = str(int(np.floor((dt_time_end + dt.timedelta(hours = 3)).timestamp())*1000))
            #sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + self.sDB + r'&s=' + sStartLink + r'&e=' + sEndLink + \
            #         r'&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'
            #sLink = mfmon.create_link(db, start_time = start_time - dt.timedelta(hours=6), end_time = end_time + dt.timedelta(hours=3))
            # TODO 2019-9-25: vorherige Zeile debuggen und wieder aktivieren
            sLink = ''
            #issues.append(mfmon.create_issue(db, sErrorMsg = 'Problem mit Eisauswertung! status=' + str(iCtStatus) + ', icing peak=' + str(iCtIcingPeak), sAction = '', sLink = sLink, sTool = 'IV'))
            issues.append(issue(sDB = db,
                        sErrorMsg = 'Problem mit Eisauswertung! status=' +\
                                    str(iCtStatus) + ', icing peak=' + \
                                    str(iCtIcingPeak) + stype_mpr, 
                        sAction = ''))

                                     
    except:
        #sStartLink = str(int(np.floor((dt_time_start - dt.timedelta(hours = 6)).timestamp())*1000))
        #sEndLink = str(int(np.floor((dt_time_end + dt.timedelta(hours = 3)).timestamp())*1000))
        #sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + self.sDB + r'&s=' + sStartLink + r'&e=' + sEndLink + \
        #         r'&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'
#        sLink = mfmon.create_link(db, start_time = start_time - dt.timedelta(hours=6), end_time = end_time + dt.timedelta(hours=3))                    
        # TODO 2019-9-25: vorherige Zeile debuggen und wieder aktivieren
        sLink = ''
        #issues.append(mfmon.create_issue(db, sErrorMsg = 'unbek. Fehler bei Check auf Eisauswertung', sAction = '', sLink = sLink, sTool = 'IV'))
        issues.append(issue(sDB = db,
                            sErrorMsg = 'unbek. Fehler bei Check auf Eisauswertung', 
                            sAction = ''))

                                           
    #return issues

