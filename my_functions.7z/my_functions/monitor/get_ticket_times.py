# -*- coding: utf-8 -*-
"""
function to find out the start and end times of the given ticket

Anhand der Zeiten des Tickets werden Start- und Endzeitpunkt ermittelt

Input:
		- dfTicket: pandas.DataFrame with tickets, must contain the fields
            - sTitle
            - sDescription
            - sStatus
            - sFarm
            - weasImWP
            - sTicketID
            - dtFirstOcc
            - dtCreated
            - dtClosed                      
            - id_farm
                                    
		- dtBuffer: 'safety period', datetime to make sure that, if thet start time is derived from ticket id    

 Output:
     - dictTimes with keys 'start' for start time and 'end' for end time


@author: Christian Kuehnert, 2020-7-29

"""

import numpy as np
import pandas as pd
import datetime as dt


def get_ticket_times(dfTickets, dtBuffer = dt.timedelta(days=30)):
    
    if dfTickets.empty:
        dfRes = pd.DataFrame(columns = ['sTicketID', 'start', 'end'])
        
    else:
        lTimes = []
        
        # TODO 2018-12-18: noch eleganter und vektorisiert machen!, jetzt erstmal
        # schnelle Variante
        for idx, row in dfTickets.iterrows():
                    
            bCont = True
            try:
                # 1.) Versuch, den Eintrag bei 'Beginn_am' als Zeitpunkt zu nehmen        
                dtStart = row['dtFirstOcc']
                #if isinstance(dtStart, dt.datetime):
    #HIER WEITER 2018-12-18 - DATENTYP NOCH NICHT RICHTIG (WIRD OFFENBAR BEIM EINLESEN DER TICKETS TROTZ EXPLIZITER UMWANDLUNG NICHT RICHTIG GEMACHT)
                if isinstance(dtStart, pd.datetime) or isinstance(dtStart, pd.Timestamp):
                    bCont = (dtStart is pd.NaT)
        
                # 2.) Versuch, den Zeitpunkt von 'Ticket erstellt am ...' zu verwenden
                if bCont:
                    dtStart = row['dtCreated']
                    if isinstance(dtStart, pd.datetime) or isinstance(dtStart, pd.Timestamp):
                        bCont = (dtStart is pd.NaT)
                                
                # 3.) Versuch, Zeitpunkt aus der 'TicketID' abzuleiten
                if bCont:
                    sTmp = row['sTicketID'][0:5]
                    dtStart = dt.strptime(sTmp, '%Y%m') - dtBuffer
    
    
            except Exception as e:
                dtStart = pd.NaT
                    
        
            ## jetzt auslesen End-Zeit aus 'Geschlossen_am'
            try:
                bCont = True
                dtEnd = row['dtErrorFixed']
                if isinstance(dtEnd, pd.datetime) or isinstance(dtEnd, pd.Timestamp):
                    bCont = (dtEnd is pd.NaT)
                
                if bCont:
                    # ii) try to use starting time of 'ticket geschlossen'
                    # TODO 2019-1-21: Beachten, dass manchmal Tickets geschlossen werden, obwohl der Fehler noch besteht!!! 
                    # das auch bei diesen Fehlertypen vorkommt und diesen Fall ggf. abfangen            
                    dtEnd = row['dtClosed']
                    #if dtEnd is None:
    #                if not(isinstance(dtEnd, pd.datetime) or isinstance(dtEnd, pd.Timestamp)):
    #                    dtEnd = pd.NaT
    
            except Exception as e:
                dtEnd = pd.NaT
                        
    
            lTimes.append([dtStart, dtEnd])
            del dtStart
            del dtEnd
            
        #dfTmp = pd.DataFrame((dfTickets.sTicketID, np.vstack(lTimes)), columns =['sTicketID', 'start', 'end'])
    #HIER WEITER 2018-12-19        
        dfTmp = pd.DataFrame(np.vstack(lTimes), columns =['start', 'end'])
        dfRes = pd.concat([dfTickets['sTicketID'], dfTmp.set_index(dfTickets.index)], axis=1)
        
    return(dfRes)

