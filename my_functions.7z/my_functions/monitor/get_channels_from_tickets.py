# -*- coding: utf-8 -*-
"""
function to find out the channels the given tickets are related

Parameters:
-----------

dfTickets:       relevant tickets, must contain column 'sTitle' with title strings    

@author: Christian Kuehnert, 2018-12-20
"""
import numpy as np
import pandas as pd


def get_channels_from_tickets(dfTickets):                            

    if dfTickets.shape[0]==0:
        
        bRes = [False, False, False, False, False, False]
        dfTmp = pd.DataFrame(columns= dfTickets.columns)
        dictRes = {}
        for iCh in range(6):
            dictRes.update({str(iCh): dfTmp})
                                    
        
        
    else:

        sTicketStrings = dfTickets.sTitle
            
        ## Ableitung der Sensorstates aus den relevanten Tickets
        # Tickets mit Teilstrings, die darauf schließen lassen, dass sie alle Sensorstrecken betreffen
        bAll = sTicketStrings.str.contains('alle', case=False, regex=False)

        # Tickets mit Teilstrings, die darauf schließen lassen, dass sie nur einzelne Rotorblätter betreffen
        bRBL = sTicketStrings.str.contains('( RBL)(RBL )', case=False, regex=True)
                    
        # Auswertung für die einzelnen Rotorblätter
#HIER WEITER 2019-1-18, ERKENNT Z.B. TICKET 201811-284 NICHT, DORT "Rbl 3 edge ... ztw. def."
        b1 = sTicketStrings.str.contains('RBL1', case=False, regex=False)
        b2 = sTicketStrings.str.contains('RBL2', case=False, regex=False)
        b3 = sTicketStrings.str.contains('RBL3', case=False, regex=False)

        bRBL = bRBL & ~(b1 | b2 | b3);                                          # wenn nur "RBL" vorkommt, z.B. "diverse RBL" in Ticket 201007-004
                    
        # Auswertung nach Edge/Flap-Richtung
        bEdge = sTicketStrings.str.contains('Edge', case=False, regex=False)
        bFlap = sTicketStrings.str.contains('Flap', case=False, regex=False)

        # weitere Prüfung auf Tickets, die für alle Rotorblätter relevant sein könnten
        bAll2 = sTicketStrings.str.contains('vertausch', case=False, regex=False) & bEdge & bFlap & ~(b1 | b2 | b3)
                    
        # Hilfsgrößen
        bTmp = bAll | bRBL
        bE = bEdge | ~bFlap
        bF = ~bEdge | bFlap
                                 
        # Bestimmung der Sensor-Zustände der einzelnen Messstrecken
        b1E = ((b1 | bTmp) & bE) | bAll2
        b2E = ((b2 | bTmp) & bE) | bAll2
        b3E = ((b3 | bTmp) & bE) | bAll2
        b1F = ((b1 | bTmp) & bF) | bAll2
        b2F = ((b2 | bTmp) & bF) | bAll2
        b3F = ((b3 | bTmp) & bF) | bAll2

        #bAllSensors = [b1F, b2F, b3F, b1E, b2E, b3E]           # which tickets (rows) contain information about which blades x direction (cols)
        bAllSensors = np.array(pd.concat((b1F, b2F, b3F, b1E, b2E, b3E), axis=1))           # which tickets (rows) contain information about which blades x direction (cols)
        bRes = bAllSensors.any(axis=0)
        
        #iChannels = list(itertools.compress([0,1,2,3,4,5], bAllSensors))
        dictRes = {}
        for iCh in range(6):
            dictRes.update({str(iCh): dfTickets[bAllSensors[:,iCh]]})
                                            
    #return(bAllSensors)
    #return([iChannels, bAllSensors])
    return([dictRes, bRes])
    

