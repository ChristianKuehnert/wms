# -*- coding: utf-8 -*-
"""
function to check if measuring lines are ok
first check "classical way", i.e. from relative signal energy, second check by time series analysis

Created on Tue Mar 26 02:56:04 2019
@author: Christian Kuehnert
@last_modified: 2019-5-16

input:
------
        - db: database name (including 'cmrblba_')
        - tickets: dataframe with tickets for this turbine
        - checks:  booleans of checks
        - issues:  list of issues
        - start_time: start time of interesting period
        - end_time:   end time of interesting period
        - dict_method: dictionary, methods by which the broken measuring lines will be detected and the respective **kwargs
        - power_min: exclude data with low power ('untypical states') from consideration - sometimes turbines show higher signal energy for P<150 kW but not for higher speed/power, so
                            such states can be excluded by setting this parameter to a minimum power value, only data with power_mean above or equal this value will be considered
        
        
        
"""

import pandas as pd
import numpy as np
import datetime as dt

import data as mfdata

from monitor import check_meas_line_classical
from monitor import check_meas_line_ts
from monitor import create_issue
from monitor import create_link
from monitor import get_relevant_tickets

#def check_meas_line(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350, 'meas_len': 16.384}}, power_min=None):
def check_meas_line(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350}}, power_min=None):
    #def check_measLines(self, time_start=None, time_end=None, sMethod = 'classical', sensor_classificator=None):
#    def check_measLines(self, sMethod = 'classical', sensor_classificator=None):
    sDTFormatMsg = '%d.%m.%Y, %H:%M'
    #tShift = 3/24
    tShift = dt.timedelta(hours=6)
    #dStartFreq = 150
    #dEndFreq = 350
    #dMeas_len = 16.384
    sTool = 'SE'
    dict_res = {}
    channels = range(5)         # consider all channels
    dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output

    
    
    for sMethod, kwargs in dict_methods.items():
	
        try:				

            if (sMethod=='classical'):
                dfCycCrit, tmp = check_meas_line_classical(db, channels, start_time, end_time, kwargs['start_freq'], kwargs['end_freq'], power_min=power_min)
                #dfCycCrit, tmp = check_meas_line_classical(db, channels, start_time, end_time, **kwargs, power_min=power_min)

            elif (sMethod=='ts'):
                dfCycCrit, tmp = check_meas_line_ts(db, start_time, end_time, **kwargs)

            else:
                print('unbekannte Methode zur Sensordefekterkennung')
                dfCycCrit, tmp = None, []

            ## add issues to list of issues                
            if tmp:
                for el in tmp:
                    issues.append(el)												                                    
            
        except:
            issues.append(create_issue(db,
                                       sErrorMsg = 'unbekannter Fehler bei check_measLines ' + sMethod, 
                                       sAction = 'manuell pruefen',
                                       sLink = create_link(db, sTool=sTool, start_time=start_time, end_time=end_time),
                                       sTool = sTool))						
            dfCycCrit = None                    
						
        dict_res.append({sMethod: dfCycCrit})


        ## 3) now get info about found critical times and check for existing tickets
        if isinstance(dfCycCrit, pd.DataFrame):
            
            if dfCycCrit.shape[0]>0:
            
                try:                                
    				                
                    # TODO 2019-1-18: combine results from both methods oder gegenseitig ueberpruefen oder sowas, akt. noch ts-methode deaktiviert
                    iCh_crit = np.unique(dfCycCrit.channel)              # critical channels
        		                                                        								
                    dfTicketsCrit = get_relevant_tickets(tickets, sType = 'meas_lines')                     # tickets for measure lines with problems
                    
                    dictChTickets, bChTickets = mfdata.get_channels_from_tickets(dfTicketsCrit)     # find affected channels by the modified titles of the relevant tickets                                
        								
					## vielleicht hier noch anders machen:
					## fuer klassiche Methode pruefen, ob, wenn 2 channels defekt und 1 intakt gefunden werden vielleicht nur der "intakte" defekt ist und die anderen beiden ok:
					## - in class. methode selbst noch vor ge-meltetem dataframe t-tests (oder so) machen, ob 1 von den anderen 2 Kanaelen (pro Richtung) signifikant verschieden ist, wenn derjenige
					## als nicht-defekt bewertet wurde, dann Bewertungen umkehren (dieser ist dann vermutlich der defekte), dabei vorher pruefen, ob genug Datensaetze vorhanden sind (>20 oder so)
					## HIER an dieser Stelle dann:
					##   - zuerst aus (offenen) Tickets die defekten Kanaele herausfinden, dann XOR mit den defekten Kanaelen anhand der Methode, wenn XOR==1 dann vielleicht ebenfalls der als intakt
					##     deklarierte Kanal defekt und umgekehrt
					## ggf. immer hinschreiben, dass nochmal manuell untersucht werden soll
                    if sMethod=='classical':
                        print('hier weiter 2019-2-28')							
										
								
                    # TODO 2018-12-20: noch eleganter, vektorisierter etc. machen!
                    for iCh in iCh_crit:
        							
                        ## critical times for that channel
                        # TODO 2018-12-21: hier koennte man noch testen, ob iPred=1 ueber (fast) den ganzen betrachteten Zeitraum gilt oder nur einen kleinen Teil,
                        # und dann anhand dessen das 'ztw.' hinzufuegen oder weglassen
                        # TODO 2019-1-25: ausserdem testen, ob Beginn des Defekts vielleicht noch weiter zurueckliegt und entsprechende Zeit herausfinden
                        dtCrit = dfCycCrit[dfCycCrit.channel==iCh].create_time                                                  
                        sTmp = 'Channel ' + str(iCh) + ' (' + dictMap_output[iCh] + ') (ztw.) defekt seit mindestens ' + min(dtCrit).strftime(sDTFormatMsg)
        			
                        ## look for related tickets
                        #dfTC = dictChTickets[str(iCh)]                      # tickets for that channel
                        dfTC = dictChTickets[iCh]                      # tickets for that channel
        							
                        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets for that channel
                        if dfOpen.shape[0]>0:
                            sTmp += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                            issues.append(create_issue(db,
                                                       sErrorMsg=sTmp,
                                                       sAction='', 
                                                       sLink = ''))
        							
                        else:
                            dfClosed = dfTC[dfTC.sStatus=='erledigt']
                            if dfClosed.shape[0]==0:
        																	
                                #sStartLink = str(np.floor((min(dtCrit) - tShift).timestamp())*1000)
                                #sEndLink = str(np.floor(dt.now().timestamp())*1000)
        													   
                                #HIER WEITER 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN                              
                                issues.append(create_issue(db, 
                                                           sErrorMsg=sTmp,
                                                           sAction='Ticket anlegen, ggf. Kanal deaktivieren',
                                                           sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                                           sTool = sTool))
        																		
                            else:
                                dfT = mfdata.get_ticket_times(dfClosed)                 # start and end times for the closed tickets
        									
                                ## herausfinden, ob es iPred=1-Zeiten nach Ende der Tickets gibt, falls nein:
                                bAllIn = False
                                for idx, row in dfT.iterrows():
                                    bAllIn = bAllIn & all(dtCrit <= row['stop'])                                
        									
                                    if bAllIn:
                                        sTmp = sTmp + ' - alles noch durch Ticket ' + ','.join(dfT.sTicketID) + ' (jetzt geschlossen) abgedeckt'
                                        issues.append(create_issue(db,
                                                                   sErrorMsg=sTmp,
                                                                   sAction='beobachten',
                                                                   sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                                                   sTool = sTool))
                                        
                                    else:             ## ansonsten 
                                        sTmp = sTmp + ', anscheinend schonmal aufgetreten (Ticket ' + ','.join(dfT.sTicketID) + ')'
                                        issues.append(create_issue(db,
                                                                   sErrorMsg=sTmp,
                                                                   sAction='altes Ticket wieder oeffnen oder neues Ticket anlegen',
                                                                   sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                                                   sTool=sTool))
    		
                except:
                    issues.append(create_issue(db, 
                                               sErrorMsg='unbek. Fehler bei Check auf Sensordefekte (bei Ticketzuordnung)',
                                               sAction='manuell ansehen',
                                               sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                               sTool=sTool))
					
    return(dict_res)

