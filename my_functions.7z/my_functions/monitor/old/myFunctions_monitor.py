# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 16:32:04 2019

@author: w012028
"""

import re
import os
import ast
import sys
#from collections import OrderedDict as odict
import pandas as pd
import numpy as np
import datetime as dt
import win32com.client as win32

from dateutil import parser


sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\functions')        # path to modules  
sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\automatic_monitoring')
import myFunctions_data as mfdata
import class_turbine as ctb
from class_issue import issue   #import class_turbine_mon as ctum
from class_hd5Nodes import hd5Nodes as sNodes





"""
read parameter file and save result in dictionary

@author: Christian Kuehnert
@last_modified: 2019-2-20
"""
# TODO 2019-2-20: evtl. noch default-dict uebergeben mit allen Parametern, die benoetigt werden, und dort dann nur diejenigen ersetzen, die in der Parameter-Datei gefunden werden
def read_parameter_file(sFN):

    dfPar = pd.read_csv(sFN, index_col=['parameter'], sep=';', header=0)  # sPathCurr + '\\' + sFN_parameter
    res = {}
    res.update({'sWC_wt': ast.literal_eval(dfPar.loc['sWC_wt'].value)})
    res.update({'sPathSaveMain': ast.literal_eval(dfPar.loc['sPathSaveMain'].value)})
    res.update({'sPathData': ast.literal_eval(dfPar.loc['sPathData'].value)})
    res.update({'sPathTemplates': ast.literal_eval(dfPar.loc['sPathTemplates'].value)})
    res.update({'sPathClassificators': ast.literal_eval(dfPar.loc['sPathClassificators'].value)})
    
    try:
        bNoFileUpdate = not(ast.literal_eval(dfPar.loc['bUpdateDataFile'].value))
    except:
        bNoFileUpdate = True
    res.update({'bNoFileUpdate': bNoFileUpdate})   
     
    try:
        dtTimeStart = parser.parse(ast.literal_eval(dfPar.loc['sTimeStart'].value))
        #bNoTimeStart = False
    except:
        dtTimeStart = None
        #bNoTimeStart = True
    #res.update({'dtTimeStart': dtTimeStart})
    res.update({'start_time': dtTimeStart})
    #res.update({'bNoTimeStart': bNoTimeStart})

    try:
        dtTimeEnd = parser.parse(ast.literal_eval(dfPar.loc['sTimeEnd'].value))
    except:
        dtTimeEnd = None
    res.update({'end_time': dtTimeEnd})


    return(res)
    
    
    







"""
get basic information and combine them to strings for text and for name parts of files and folders
    
@author: Christian Kuehnert
@last_modified: 2019-2-20
"""
def get_turbine_info(tb):
    
    sFarm = tb['sFarm'].__str__()
    sName = tb['sName'].__str__()
    sDB = tb['sDB'].__str__()
    
    sInfoText = sFarm + ', ' + sName + ' (' + sDB + ')'
    sInfoFN = sFarm + '__' + sName + '__' + sDB
    sInfoFN.replace(' ', '_').replace('(','_').replace('(','_').replace(',','_')
        
    return sInfoText, sInfoFN
        





"""
get basic information and combine them to strings for text and for name parts of files and folders
    
@author: Christian Kuehnert
@last_modified: 2019-2-20
"""
def get_start_time(tb):
    sTmp = tb['dtLastMonitoring']
    if sTmp:
        sLastMon =re.sub(r'(:[a-zA-ZäöüßÄÖÜ0-9: ]+)]*','', sTmp)
        time_last_mon = parser.parse(sLastMon)
    else:            
        time_last_mon = tb['dtStartCollectData']
  
    return(time_last_mon)





"""
function to set the checks with the given keys to False

@author: Christian Kuehnert
@last_modified: 2019-2-21

"""
def set_checks_to_false(checks, listKeys):
    ## change checks only when it is dict, this is in order that the check-functions can be used by command line too without thinking about checks-input-variable
    ## (which in this case can just be set to None or some other non-dictionary-type value)
    if isinstance(checks, dict):
        for k in listKeys:
            checks[k] = False


       
        
        
"""
get preferences

Christian Kuehnert, 2019-2-21
"""
def get_preferences(db):    
    tmp = mfdata.query_MySQL2(db, 'SELECT name, value FROM preferences;')
    return(dict(tmp))
    
    
    
    
    




       
"""
function to find the last datetime with non-fix data in the given table in the
given database, after this date either no new data were stored or they are fix

@author: Christian Kuehnert, 2019-2-22

Parameters:
-----------

sDB:              database name
sTabName:         table name
sColTime:         name of the column containing the time
sColNames:        columns of the table (except time)
sColsToTest:      names of the columns that should be analysed for fixed/missing data
#t0:               end time
#tAllowedDelay:    allowed time intervall

Results:
--------

bDataFix:
tLastData:
tLastDataNotFix:  
dfTimes:       DataFrame with columns 1) name, containing the names of the columns (i.e. sColsToTest), 2) bDataFix: boolean flag indicating 
                  if the data are fix/missing for this column, 3) tLastData: 
sMsg:             result/error message

"""
#def getTimesLastNonFixData(db, sTable, sTimeStart=None, sTimeEnd=None, col_time = 'create_time', sColsToTest = None, bExclNaN=True): 
def getTimesLastData(db, table, sEndTime=None, col_time='create_time', cols_to_test=None): 
    
    last_times_not_ok = {}   #None
    
    if len(cols_to_test)>0:

        if not(sEndTime):
            sEndTime = dt.datetime.now().strftime('%Y%m%d%H%M%S')
            
        if len(cols_to_test)>0:
            cTmp = ["select '" + col + "',max(t2." + col_time + ") " + 
                    "from " + table + " t2 " + 
                    "where not(t2." + col_time + " is NULL) and not(t2." + col + " is NULL) and (t2." + col_time + "<='" + sEndTime + "') and (t2." + col + "<>" + 
                        "(select t." + col + " " + 
                        "from " + table + " t " + 
                        "where t." + col_time + "=(" + 
                            "select max(tm." + col_time + ") " + 
                            "from " + table + " tm " + 
                            "where not(tm." + col_time + " is NULL) and not(tm." + col + " is NULL) and (tm." + col_time + "<='" + sEndTime + "')) limit 1))" for col in cols_to_test]
            
            sQuery = ' union '.join(cTmp) + ';'
            last_times_not_ok = dict(mfdata.query_MySQL2(db, sQuery))
            
    return(last_times_not_ok)
          
        





       
"""
function to find the last datetime with (non-fix) data in the given table in the
given database, after this date either no new data were stored or they have been fix

@author: Christian Kuehnert, 2019-2-22

Parameters:
-----------

sDB:              database name
sTabName:         table name
sColTime:         name of the column containing the time
sColNames:        columns of the table (except time)
sColsToTest:      names of the columns that should be analysed for fixed/missing data
#t0:               end time
#tAllowedDelay:    allowed time intervall

Results:
--------

bDataFix:
tLastData:
tLastDataNotFix:  
dfTimes:       DataFrame with columns 1) name, containing the names of the columns (i.e. sColsToTest), 2) bDataFix: boolean flag indicating 
                  if the data are fix/missing for this column, 3) tLastData: 
sMsg:             result/error message

"""
#def getMissingData(sDB, sTable, time_end, time_delta_allowed=dt.timedelta(days=1), col_time='create_time', cols_to_test=None, bExclNaN=True):
def getMissingData(db, table, end_time, time_delta_allowed=dt.timedelta(days=1), col_time='create_time', cols_to_test=None):
    
    sMsg = ''
    sFormatDT = '%Y%m%d%H%M%S'
    last_times_not_ok = {}   #None
    bOk = True
    
    n_cols = len(cols_to_test)            # number of columns to test
	                
    if (n_cols == 0):        
        sMsg = 'keine Spalten zum Testen ausgewaehlt'
        
    else:
        
        ## first: query if there are at least two distinct values during the allowed period for all columns to test
        try:
#HIER WEITER 2019-2-22
            tmp = end_time - time_delta_allowed
            sStartTime = tmp.strftime(sFormatDT)                                                        # starting time for first test
            sEndTime = end_time.strftime(sFormatDT)
            
            tmp = [f"count(distinct {col})" for col in cols_to_test]                        
            sQuery = "select " + ','.join(tmp) + f" from {table} where not({col_time} is NULL) and ({col_time}>='{sStartTime}') and ({col_time}<='{sEndTime}')"
            res1 = mfdata.query_MySQL2(db, sQuery)[0]

            btmp = [x < 2 for x in res1]                               

            cols_not_ok = list(pd.Series(cols_to_test)[btmp])
        
            if len(cols_not_ok)>0:
                last_times_not_ok = getTimesLastData(db, table, sEndTime=sEndTime, col_time='create_time', cols_to_test=cols_not_ok)
                                                  
        except Exception as e:            
            #sMsg = 'Zugriffsproblem ' + db + '.' + table + ', ' + logger.error(repr(e))
            sMsg = 'Zugriffsproblem ' + db + '.' + table + ', ' + str(e)
            bOk = False        


    return(last_times_not_ok, sMsg, bOk)
          
    
    






"""
get tickets by special keywords/text parts

Christian Kuehnert, 2019-2-25
"""
def get_relevant_tickets(dfTickets, sType = ''):
    
    
    if dfTickets.shape[0]>0:
            
        sT = dfTickets.loc[:,'sTitle'].copy()

        if sType=='meas_lines':
            # TODO 2018-12-18: zunaechst 1:1-Nachbildung der Matlab-Fkt. 'getSensorStates.m', spaeter vereinfachen/eleganter/anders machen            
            sT = dfTickets.loc[:,'sTitle'].copy()
            sT.replace('(Eissensor Rotorblatt)(cmrbl)(100)(BLADEcontrol)(bladecontrol)(Bladecontrol)', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            
            #dfT.strip(inplace=True)
            
            sT.replace('([rR][bB][lL])', 'RBL', regex=True, inplace=True)
            sT.replace('([fF][lL][aA][pP])', 'Flap', regex=True, inplace=True)
            sT.replace('([eE][dD][gG][eE])', 'Edge', regex=True, inplace=True)
            
            sT.replace('(((vorrangig)(vor\sallem)(v\.a\.)(v\.\sa\.))(\s)*((Edge)(Flap)))', '', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
#                
            sT.replace('((Rotorblatt)(Blade:*))', 'RBL', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            sT.replace('(R\-1\/2\/3)', 'RBL1,RBL2,RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)(RBL)R)(\s|\-)?1)', 'RBL1', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)(RBL)R)(\s|\-)?2)', 'RBL2', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            sT.replace('(((Blatt)(RBL)R)(\s|\-)?3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis
            #dfT.replace('([(Blatt)|(RBL)|(RBL\-)|(R)|(R\-)]\s*3)', 'RBL3', regex=True, inplace=True)         # delete some substrings that cause problems with further analysis

            # Reduktion des cellarray mit den Ticket-Titeln auf die
            # Elemente, die relevante strings enthalten
            bI = sT.str.contains('(((RBL)(alle )( allen))(Sensoren )?((falsch angeschlossen)(vertausch)))', regex=True, case=False)
#
#                % Tickets mit wenigstens einem der folgenden Ausdrücke
#                % werden ignoriert:
            sTmp = '(Falscheismeldung .*Peak ung.*nstig)' \
                + '((alle )[0-9]*.?(ECU))' \
                + '(alle Messprogramme)' \
                + '(alle WEA ohne Eis am RBL)' \
                + '((ECU).*(alle) ((im WP)(im PW))?(gleichzeitig))' \
                + '(neue Werte alle)' \
                + '((falsche Zeit).*( alle))' \
                + '(nach Stromabschaltung)' \
                + '((Datenl)((ue)(ü))(cken))' \
                + '(keine externals)' \
                + '(geringes Signal\-Rausch)' \
                + '((Zuordnung).*(<->).*(Firewall vertauscht))' \
                + '((alle)n?( WEA))'
                                    
            bI2 = sT.str.contains(sTmp, case=False, regex=True)
            
            bI3 = sT.str.contains('((RBL).*(def))', case=False, regex=True)
            
            bTmp = ~(bI | bI2) & bI3
            
            dfRel = dfTickets[bTmp]                                     # relevant tickets
                        

        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach
        elif sType =='data_fix':
            
            #sPatternRegEx = '(ext.*fix)|( n\.e)|( externals )|(nicht erreichbar)|(mi[(ss)|ß]t nicht)|(keine externals)|(eingefrorene Betriebsdaten)|(Betriebsdaten eingefroren)'
            sPatternRegEx = '(?:ext.*fix)|(?: n\.e)|(?: externals )|(?:nicht erreichbar)|(?:mi[(ss)|ß]t nicht)|(?:keine externals)|(?:eingefrorene Betriebsdaten)|(?:Betriebsdaten eingefroren)'
            bTmp = ~sT.isnull() & sT.str.contains(sPatternRegEx, regex=True, case=False)                
            dfRel = dfTickets[bTmp]                                      # relevant tickets
                            
    
    
        # TODO 2018-12-20: noch weiter implementieren, hier erstmal allererster approach        
        elif sType == 'low_pass':
            
            sPatternRegEx = '((rbl|rotorbl*).*(def|tpv|tiefpass))'        
            bTmp = sT.str.contains(sPatternRegEx, regex=True, case=False)                
            dfRel = dfTickets[bTmp]                                     # relevant tickets
    
        else:
            print('unknown check-Type for Ticket finding, return no tickets')
            dfRel = pd.DataFrame(columns = dfTickets.columns)

    else:
        dfRel = pd.DataFrame(columns = dfTickets.columns)
        
        
    return(dfRel)
    
    
 
    
    
    
    
    
    
    
    
    
        
"""
creates instance of the issue class
    
@author: Christian Kuehnert
@last_modified: 2019-2-21
"""          
def create_issue(sDB, sErrorMsg = '', sAction = '', sLink = '', sTool = '', sTypeMail=None, sLinkMail = '', bShort = True):
    return(issue(sDB = sDB, sErrorMsg = sErrorMsg, sAction = sAction, sLink = sLink, sTool = sTool, sTypeMail = sTypeMail, sLinkMail = sLinkMail, bShort = bShort))




"""
function to check if database exists
TODO 2019-2-21: later also check if this database contains the required tables

@author: Christian Kuehnert
@last_modified: 2019-2-25

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_db(db, tickets, checks, issues):
    
    #issues = []
    
    bTmp = isinstance(db, str)
    if bTmp:
        bTmp = (len(db.strip())>0)
            
    if not(bTmp):
        issues.append(create_issue(db, sErrorMsg = 'kein DB-Name im PIT eingetragen', sAction = ''))
        set_checks_to_false(checks, checks.keys())
        #for key in checks.keys():
        #    checks[key] = False
        

    if checks['db']:
        try:                
            sTablesDB = pd.DataFrame(data=np.array(mfdata.query_MySQL2(db, 'SHOW TABLES;'))).infer_objects().iloc[:,0].tolist()
            
            #bTabOk = any([(s.find('ba_',0,3)>-1) for s in sTablesDB])                
            #if bTabOk:
                
            ## check for special required tables
            if not (('ba_cycle_measurement_cycle' in sTablesDB) or ('ba_cycle_measurement_cycle_state' in sTablesDB)):                        
                #checks['db'] = False
                #checks['meas_line'] = False
                #checks['low_pass'] = False
                set_checks_to_false(checks, ['db', 'meas_line', 'low_pass'])
                issues.append(create_issue(sErrorMsg = 'kein Check auf Sensor TPV/defekt möglich, Tab.n ba_cycle_measurement_cycle oder ba_cycle_measurement_cycle_state fehlen in DB',
                                 sAction = ''))
                    						                    
            if not ('ba_cycle_measurement_cycle' in  sTablesDB):
                #check['ice_eval'] = False
                set_checks_to_false(checks, ['db', 'ice_eval'])
                issues.append(create_issue(sErrorMsg = 'kein Check auf no ice eval möglich, Tab.n ba_cycle_measurement_cycle fehlt in DB',
                                 sAction = ''))
						                                               
            if not('ba_cycle_status' in sTablesDB):
                #check['db'] = False
                #check['imp_ext'] = False
                #check['data_fix'] = False
                set_checks_to_false(checks, ['db', 'imp_ext', 'data_fix'])
                issues.append(create_issue(sErrorMsg = 'kein Check auf improper externals und Produktionsdaten fix möglich, Tabelle ba_cycle_status fehlt in DB',
                                 sAction = ''))
                    
            if not('ba_cycle_externals' in sTablesDB):
                #check['db'] = False
                #check['data_fix'] = False
                set_checks_to_false(checks, ['db', 'data_fix'])
                issues.append(create_issue(sErrorMsg = 'kein Check auf externals fix möglich, Tabelle ba_cycle_externals fehlt in DB',
                                 sAction = ''))
                                                                                  
            if not('ba_cycle_icing_peak', sTablesDB):
                #check['db'] = False
                #check['ice_eval'] = False
                set_checks_to_false(checks, ['db', 'ice_eval'])
                issues.append(create_issue(sErrorMsg = 'kein Check auf ice evaluation möglich, Tabelle ba_cycle_icing_peak fehlt in DB',
                                 sAction = ''))
                                                                                                                                  
            if not('preferences', sTablesDB):
                #check['prefs'] = False
                #check['ice_eval'] = False
                set_checks_to_false(checks, ['db', 'prefs', 'ice_eval'])
                issues.append(create_issue(sErrorMsg = 'kein Check auf preferences und ice evaluation möglich, Tabelle preferences fehlt in DB',
                                 sAction = ''))
                                                                      
            #else:
#               #     self.lErrClass.append(?)
            #    lIssues.append(issue(sFarm = self.sFarm, sWT = self.sName, sDB = self.sDB, sErrorMsg = 'DB enthaelt keine Tab. mit \'ba_\'', iErrorClass = 12, sAction = '', sLink = '', bShort = True))
                                                                    
        except:

            set_checks_to_false(checks, checks.keys())
            issues.append(create_issue(sErrorMsg = 'DB n.e., SSHport: ' + db['sSSH_port'].__str__(), sAction = ''))
       
    
    #return issues







"""
function to check if preferences can be read and are ok

@author: Christian Kuehnert
@last_modified: 2019-2-21

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_prefs(db, tickets, checks, issues):
    #issues = []   
                             
    lMsg = []
                        
    prefs = get_preferences(db)
        
    bMaskEval = (mfdata.getBit(prefs['Turbine@UseDefaultSVEval'].replace(' ',''), 9) == 1)    # Bit fuer Maskierung eval-bit                                
    if bMaskEval:
        lMsg.append('ice-eval-Bit maskiert')
                                   
    bMaskAlarm = (mfdata.getBit(prefs['Turbine@UseDefaultSVAlarm'].replace(' ',''), 10) == 1)   # Bit fuer Maskierung Alarm-Bit
    if bMaskAlarm:
        lMsg.append('ice-alarm-Bit maskiert')
        
    bMaskWarning = (mfdata.getBit(prefs['Turbine@UseDefaultSVWarning'].replace(' ', ''), 10) == 1)
    if bMaskWarning:
        lMsg.append('ice-warning-Bit maskiert')
        
        
    if bMaskEval or bMaskAlarm or bMaskWarning:        
        issues.append(create_issue(sErrorMsg = ', '.join(lMsg), sAction = 'demasikieren', sLink = ''))                         
    
    #return issues





"""
function to check if data are fix

@author: Christian Kuehnert
@last_modified: 2019-2-21

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_data_fix(db, tickets, checks, issues, start_time, end_time, ssh_port):
    
    tAllowedDelay = dt.timedelta(days=1)
    
    #issues = []    
    
    sFormatDT_out = '%d.%m.%Y %H:%M'
        
    
    #sAction = ''
    #bShort = True
    sTool = 'GH'
    dict_cols_gh = None
    
    #sColTime = 'create_time'
    #sColsProd = ['omega_mean','wind_mean','power_mean','pitch_mean','azimuth_mean','temperature_mean','cyc_status_system','cyc_status_eval']
    sColsProd = ['omega_mean','wind_mean','power_mean','pitch_mean','temperature_mean']
    #sColsExt = ['create_time', 'omega', 'wind', 'power', 'pitch', 'azimuth', 'temperature']
    sColsExt = ['wind', 'power', 'pitch']
    prefs = get_preferences(db)
    
    # TODO 2019-3-1: folgendes noch generischer machen - dynamisch die relevanten keys herausfinden 
    # (viell. anhand von Suche nach 'azimuth' und 'ambienttemperature' in den keys) und diese verwenden
    tmp = prefs.keys()
    if 'UseAmbientTemperature' in tmp:
        if bool(int(prefs['UseAmbientTemperature'])):
            sColsExt.append('temperature')
    
    if 'AzimuthAvailable' in tmp:
        if bool(int(prefs['AzimuthAvailable'])):
            sColsExt.append('azimuth')
                          
    try:
        times_prod = getMissingData(db, 'ba_cycle_status', end_time, tAllowedDelay, 'create_time', sColsProd)
        times_ext = getMissingData(db, 'ba_cycle_externals', end_time, tAllowedDelay, 'create_time', sColsExt)
                                                    
        lMsg = []
        dict_tmp = {'Betriebsdaten': [sColsProd, times_prod, 'ba_cycle_status'],
                   'Ext.': [sColsExt, times_ext, 'ba_cycle_externals']}
        
        
        bFix = []
        tMin = []
        dict_cols_gh = {}
        for key, val in dict_tmp.items():
                
            cols = val[0]
            ctimes, sTmp, bOk = val[1]

            # if there is a message, append it to the list of messages
            if sTmp:
                lMsg.append(sTmp)
                
            # Ausgabe fuer missing prod/ext
            if len(ctimes)>0:
                bFix.append(True)
                dict_cols_gh.update({val[2]: list(ctimes.keys())})
                
                times_notNone = [t for t in list(ctimes.values()) if t is not None]
                if len(times_notNone)==0:
                    sTimeMin = 'Beginn'

                else:
                    tmp = min(times_notNone)
                    tMin.append(tmp)
                    sTimeMin = tmp.strftime(sFormatDT_out)
            
            
                if len(val)==len(cols):
                    lMsg.append(key + ' fehlen/sind fix seit ' + sTimeMin)
                        
                else:
                    lMsg.append('folgende ' + key + ' fehlen/sind fix seit ' + sTimeMin + ': ' + ', '.join(ctimes.keys()))
                    
            else:
                bFix.append(False)
                
        
        if len(dict_cols_gh)==0:
            dict_cols_gh = None
            
        #bNoPort = (ssh_port == '0.0')                # entspricht 'Tunnel: Port ist 0!'
        bNoPort = (ssh_port==0)
        bNoProd = bFix[0]
        bNoExt = bFix[1]
        
        
        tEndLink = end_time + dt.timedelta(hours = 6)
        if len(tMin)>0:
            tStartLink = max([min(tMin), end_time - dt.timedelta(days=30)]) - dt.timedelta(hours=6)
        else:
            tStartLink = end_time - dt.timedelta(days=30) - dt.timedelta(hours=6)
            
        #bCheckImpExt = all(not(isna(dTimeLast_prod))) & all(not(isnan(dTimeLastNotFix_prod))) & (min(dTimeLast_prod) >= tLastMon) & (min(dTimeLastNotFix_prod) >= tLastMon)

        bFixed = bNoProd | bNoExt                    # true if at least one of externals or production data are fix or missing
        bECUne = bNoProd & bNoExt & bNoPort
        bHMUne = bNoProd & ~bNoExt & ~bNoPort


        if bECUne:
            #lMsg[-1] += ', vermutlich ECU n.e.'
            lMsg.append('vmtl. ECU n.e.')
            #lMsg = ['ECU n.e.']
            set_checks_to_false(checks, ['ice_eval'])

        if bHMUne:
            #sMonRes = [sMonRes, ', vermutlich HMU n.e. seit ', datestr(min(tLastNotFixProd), sDateTimeFormatOutput)];	
            lMsg.append('vmtl. HMU n.e.')
            #lMsg = ['vmtl. HMU n.e.']
            set_checks_to_false(checks, ['ice_eval'])


        # TODO 2017-12-8: Hier nochmal mit DB sprechen, wann welche Probleme auftreten
        ## if problems are found, create link
        if bFixed:
            ## TODO 2017-12-8: noch Fall abfangen, dass der Zeitraum zu lang wird, dann nur Ende mit den letzten Daten darstellen 
            sLink = create_link(db, sTool = sTool, cols_gh = dict_cols_gh, start_time = tStartLink, end_time = tEndLink)


        ## find and analyse suitable tickets
        dfTC = get_relevant_tickets(tickets, sType = 'data_fix')    # tickets for measure lines with problems                                                            
        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets
            
        ## consider open tickets
        if dfOpen.shape[0]>0:
            
            if bFixed:
                lMsg[-1] += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                #lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = '', sLink = ''))
                issues.append(create_issue(db,
                                           sErrorMsg = ', '.join(lMsg),
                                           sAction = 'beobachten', 
                                           sLink = sLink,
                                           sTool = sTool,
                                           bShort=False))

            else:
                #tS = max(tLastProd, tLastExtNotFix)
                # TODO 2019-2-22: noch herausfinden, seit wann die Daten wieder vorhanden sind, und hier entsprechend eintragen, Beginn vom Link entsprechend anpassen                 
                #if (tMin is pd.NaT):
                #    tS = tLastMon
                #else:
                #    tS = tMin
                #sMsg = 'Daten wieder vorhanden seit ' + tS.strfrmtime(sFormatDTOutput)                
                sMsg = 'Daten wieder vorhanden'
                sAction = 'Ticket ' + ', '.join(dfOpen.TicketID) + ' schliessen'                    
                #sLink = create_link(sTool = sTool, time_start = tS - dt.timedelta(hours = 4), time_end = dt0 + dt.timedelta(hours = 2))
                sLink = create_link(db, sTool = sTool, cols_gh = None, start_time = tStartLink, end_time = tEndLink)
                                           
                issues.append(create_issue(db,
                                           #sErrorMsg = ', '.join(lMsg), 
                                           sErrMsg = sMsg,
                                           sAction = sAction,
                                           sLink = sLink,
                                           sTool = sTool))
                  
        else:
            if bFixed:
                dfClosed = dfTC[dfTC.sStatus=='erledigt']
                # TODO 2019-3-1: nur Tickets betrachten, die noch nicht allzulange zurueckliegen (sonst ist es nicht mehr
                # wirklich ein NACHFOLGEticket)
                #dfClosed = dfTC[dfTC.sStatus=='erledigt' & dfTC.dtClosed-tMin<dt.timedelta(days=30)]
                sMsg = ', '.join(lMsg)                        

                if dfClosed.shape[0]==0:                        
                    sAction = 'Ticket anlegen'
                
                else:
                    dfClosed.sort_values(['sTicketID'], axis=0, ascending=False, inplace=True)
                    sTmp = ', '.join(dfClosed.head(3).sTicketID)
                    sMsg += ', schon früher aufgetreten (Tickets ' + sTmp + ')'
                    sAction = 'Nachfolgeticket für ' + dfClosed.sTicketID.max() + ' anlegen'
# TODO 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN   
                if bECUne:
                    mail_type = 'ECUne'
                else:
                    mail_type = 'missing_data'                    
                           
                issues.append(create_issue(db,
                                           sErrorMsg = ', '.join(lMsg), 
                                           sAction = sAction,
                                           sLink = sLink,
                                           sTypeMail = mail_type,
                                           sTool = sTool))
                            
    except:
        
        issues.append(create_issue(db,
                                   sErrorMsg = 'unbek. Fehler bei Check auf fix data', 
                                   sAction = 'manuell ansehen', 
                                   sLink = ''))
    
    
    #return issues






"""
function to check if improper externals occur

@author: Christian Kuehnert
@last_modified: 2019-2-21

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_improper_ext(db, tickets, checks, issues, start_time, end_time):
    #issues = []    
    pass
    #return issues






"""
function to check if ice evaluation is working

@author: Christian Kuehnert
@last_modified: 2019-2-20

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_ice_eval(db, tickets, checks, issues, start_time, end_time):
    #issues = []
    
    sDTFormatDB='%Y%m%d%H%M%S'
                
    # TODO 2018-12-6: noch Tickets auswerten, ob schon entsprechendes vorhanden!            
    try:
        
        prefs = get_preferences(db)

        if 'MinWindLevel' in prefs.keys():                                       
            sMinWindLevel = prefs['MinWindLevel']
            if len(sMinWindLevel.strip())==0:
                sMinWindLevel = '3'
        else:
            sMinWindLevel = '3'    
                        
        if 'Turbine@StopMinPitchAngle' in prefs.keys():                                       
            sPitchMax = prefs['Turbine@StopMinPitchAngle']
            if len(sPitchMax.strip())==0:
                sPitchMax = '75'
        else:
            sPitchMax = '75'    
                                    
        if 'Turbine@OmegaMinFreq' in prefs.keys():                                       
            sOmegaMin = prefs['Turbine@OmegaMinFreq']
            if len(sOmegaMin.strip())==0:
                sOmegaMin = '0.05'
        else:
            sOmegaMin = '0.05'    
                
        sStartTime = start_time.strftime(sDTFormatDB)
        sEndTime = end_time.strftime(sDTFormatDB)
                
        bOld = False
        if bOld:
            sQuery = 'select count(distinct create_time) ' \
                    + 'from ba_cycle_status ' \
                    + 'where (create_time>=\'' + sStartTime + '\') and (create_time<=\'' + sEndTime + '\') ' \
                    + 'and (wind_mean>' + sMinWindLevel + ') and (omega_mean>=' + sOmegaMin + ') and (pitch_mean<=' + sPitchMax + ');'                      
            iCtStatus = mfdata.query_MySQL2(db, sQuery)[0][0]

# TODO 2018-12-14: funktioniert so nicht, ba_cycle_icing_peak hat keine Spalten wind_mean, omega_mean, pitch_mean etc.
            sQuery = 'select count(distinct create_time) ' \
                    + 'from ba_cycle_icing_peak ' \
                    + 'where (create_time>=\'' + sStartTime + '\') and (create_time <= \''  + sEndTime + '\') ' \
                    + 'and (wind_mean>' + sMinWindLevel + ') and (omega_mean>=' + sOmegaMin + ') and (pitch_mean<=' + sPitchMax + ') ' \
                    + 'and (actual_freq > 0);'
            iCtIcingPeak = mfdata.query_MySQL2(db, sQuery)[0][0]

        else:
                                
            # TODO 2018-12-14: alles noch testen
            
            sHeadersKeys = ['create_time','ID']
            # TODO 2018-12-14: evtl. alles mit einer Abfrage erledigen und gleich die beiden Counts ausgeben
            sQuery = 'select distinct create_time,ID ' \
                    + 'from ba_cycle_status ' \
                    + 'where (create_time>=\'' + sStartTime + '\') and (create_time<=\'' + sEndTime + '\') ' \
                    + 'and (wind_mean>' + sMinWindLevel + ') and (omega_mean>=' + sOmegaMin + ') and (pitch_mean<=' + sPitchMax + ');'                      
                    
            tupTmp = mfdata.query_MySQL2(db, sQuery)
            if len(tupTmp)>0:                                                    
                dfStatus = pd.DataFrame(data=np.array(tupTmp), columns=sHeadersKeys).infer_objects()                        
            else:
                dfStatus = pd.DataFrame(columns=sHeadersKeys)                        
                
            iCtStatus = dfStatus.shape[0]
            
            
            sQuery = 'select distinct create_time,cycle_id  ' \
                    + 'from ba_cycle_icing_peak ' \
                    + 'where (create_time>=\'' + sStartTime + '\') and (create_time <= \''  + sEndTime + '\') ' \
                    + 'and (actual_freq > 0);'
                
            tupTmp = mfdata.query_MySQL2(db, sQuery)
            if len(tupTmp)>0:
                dfIcingPeak = pd.DataFrame(data=np.array(tupTmp), columns=sHeadersKeys).infer_objects()
                iCtIcingPeak = mfdata.intersect_df(dfStatus, dfIcingPeak, sHeadersKeys).shape[0]
            else:
                iCtIcingPeak = 0

        if (iCtStatus > 0) and (iCtIcingPeak == 0):
            #sStartLink = str(int(np.floor((dt_time_start - dt.timedelta(hours = 6)).timestamp())*1000))
            #sEndLink = str(int(np.floor((dt_time_end + dt.timedelta(hours = 3)).timestamp())*1000))
            #sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + self.sDB + r'&s=' + sStartLink + r'&e=' + sEndLink + \
            #         r'&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'
            sLink = create_link(db, start_time = start_time - dt.timedelta(hours=6), end_time = end_time + dt.timedelta(hours=3))
            issues.append(create_issue(db, sErrorMsg = 'Problem mit Eisauswertung! status=' + str(iCtStatus) + ', icing peak=' + str(iCtIcingPeak), sAction = '', sLink = sLink, sTool = 'IV'))
                                     
    except:
        #sStartLink = str(int(np.floor((dt_time_start - dt.timedelta(hours = 6)).timestamp())*1000))
        #sEndLink = str(int(np.floor((dt_time_end + dt.timedelta(hours = 3)).timestamp())*1000))
        #sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + self.sDB + r'&s=' + sStartLink + r'&e=' + sEndLink + \
        #         r'&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'
        sLink = create_link(db, start_time = start_time - dt.timedelta(hours=6), end_time = end_time + dt.timedelta(hours=3))                    
        issues.append(create_issue(db, sErrorMsg = 'unbek. Fehler bei Check auf Eisauswertung', sAction = '', sLink = sLink, sTool = 'IV'))
                                           
    #return issues




"""
function to calculate the relative signal energy from the given absolute SE for the column names in the given list of lists

@author: Christian Kuehnert
@last_modified: 2019-2-27

"""
def get_relative_se(dfSE, col_names):

    dTmp = dfSE.loc[:, col_names].values
    dSE_mean = np.mean(dTmp, axis=1)
    dSE_rel = dTmp /  np.tile(dSE_mean.reshape((len(dSE_mean),1)), (1,len(col_names)))
    
    return(dSE_rel)
        
        




"""
function to check if measuring line are ok by classical method
@author: Christian Kuehnert
@last_modified: 2019-2-27


example:
import numpy as np
import pandas as pd
import datetime as dt
import sys

sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\functions')        # path to modules  
import myFunctions_data as mfdata
import myFunctions_monitor as mfmon

db = 'cmrblba_bc_t_02758'
channels = [3,4,5]
start_time = dt.datetime(2018,12,2,4,0,0)
end_time = start_time + dt.timedelta(days=2)
dfRes, issues = mfmon.check_meas_line_classical(db, channels, start_time, end_time)

"""
#def check_meas_line_classical(db, channels, start_time, end_time, start_freq=150, end_freq=350, meas_len=16.384, power_min=None):
# TODO 2019-2-28: noch modifizierte Variante anlegen, die die Erkennung eines abweichenden Sensors verbessert
def check_meas_line_classical(db, channels, start_time, end_time, start_freq=150, end_freq=350, power_min=None):
	
    issues = []
    sTool = 'SE'
    sFormatDT = '%Y%m%d%H%M%S'
    
    ## first map channel numbers (0..5) to channel names ('e_101_edge' etc.)
    # TODO 2019-1-18: generisch machen!, now only first approach
    #dictMap_class = mapChannels(self.sDB, self.sPathData)
    #dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
    map_channels = {3: 'e_101_edge', 4: 'e_102_edge', 5: 'e_103_edge', 0: 'e_101_flap', 1: 'e_102_flap', 2: 'e_103_flap'}
    map_channels_inv = {value: key for key, value in map_channels.items()}
	
    #get thresholds from preferences
    # TODO 2019-1-25: sind Sensitivities schon beruecksichtigt? Offsets auf jeden Fall noch nicht!
    try:            
        lFlap = [map_channels[key] for key in [0,1,2]]
        lEdge = [map_channels[key] for key in [3,4,5]]        
        lDirs = lFlap + lEdge

        ## thresholds for alarm levels for all channels
        dictTmp = get_preferences(db)
        #dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel'): s for s in lDirs}
# TODO 2019-2-27: noch fuer beides (warning und alarm) machen und dann issue entsprechend anpassen
        dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapWarnLevel').replace('_edge', 'EdgeWarnLevel'): s for s in lDirs}
        dfSE_thres = pd.DataFrame.from_records([{key: pd.to_numeric(dictTmp[key], errors='coerce') for key in dictPrefCols.keys()}], coerce_float=True)
        dfSE_thres.rename(columns = dictPrefCols, inplace=True)

        ## get offsets
        dictPrefOS = {s.replace('e_', 'Sda').replace('_flap', 'FlapOffset').replace('_edge', 'EdgeOffset'): s for s in lDirs}
        dfOS = pd.DataFrame.from_records([{key: pd.to_numeric(dictTmp[key], errors='coerce') for key in dictPrefOS.keys()}], coerce_float=True)
        dfOS.rename(columns = dictPrefOS, inplace=True)
                
        sColNames = list(map_channels.values())
        sSelectChannels = ','.join(['SUM(se.' + s + ')' for s in sColNames])
        
        sChannels = {key: map_channels[key] for key in channels}

        

        sF1 = str(start_freq)
        sF2 = str(end_freq)
        sStartTime = start_time.strftime(sFormatDT)
        sEndTime = end_time.strftime(sFormatDT)
        
        # TODO 2019-2-27: evtl. gleich im SQL den Test nach Ueberschreiten der Warnschwelle machen und nur die kritischen Werte zurueckliefern, dann muss aber noch Test eingebaut
        # werden, ob ueberhaupt Daten fuer den betreffenden Zeitraum vorhanden sind (sonst Warnung o.ae. ausgeben)
#               if power_min:
#            sFilter = ' mc.power_mean>=' + str(power_min) + ' AND'
#        else:
#            sFilter = ''                        

#        sQuery = f"SELECT mc.create_time,mc.ba_id,mc.power_mean,{sSelectChannels}" + \
#                 "FROM ba_cycle_measurement_cycle mc STRAIGHT_JOIN sig_energies se ON (mc.ba_id = se.cycle_id) " + \
#                 "WHERE{sFilter} mc.create_time IS NOT NULL and mc.available_data>=2 AND se.cycle_id IS NOT NULL AND se.start_f>={sF1} AND se.start_f<= {sF2} " + \
#                 "AND mc.create_time>={sStartTime} AND mc.create_time<={sEndTime} " + \
#                 "GROUP BY se.cycle_id " + \
#                 "ORDER BY mc.create_time;"
        ## find out if necessary tables occur in database
        # TODO 2019-2-27: noch eleganter und sicherer machen!
        sQuery = 'SHOW TABLES'
        lT = mfdata.query_MySQL2(db, sQuery)
        if ('ba_cycle_sig_energies',) in lT:
            sTabSE = 'ba_cycle_sig_energies'
        else:
            sTabSE = 'sig_energies'                
        
        ## TODO 2019-2-27: Fall abfangen, dass dieselbe ID zu verschiedenen Zeiten vorkommt
        sQuery = f"SELECT mc.create_time,mc.ID,mc.power_mean,{sSelectChannels} " + \
                 f"FROM ba_cycle_measurement_cycle mc INNER JOIN {sTabSE} se ON (mc.ID = se.cycle_id and mc.create_time = se.create_time) " + \
                 f"WHERE mc.create_time IS NOT NULL and mc.available_data>=2 AND se.cycle_id IS NOT NULL AND se.start_f>={sF1} AND se.start_f<={sF2} " + \
                 f"AND mc.create_time>='{sStartTime}' AND mc.create_time<='{sEndTime}' " + \
                 "GROUP BY se.cycle_id " + \
                 "ORDER BY mc.create_time;"
              
        dfSE = pd.DataFrame(data=np.array(mfdata.query_MySQL2(db, sQuery, params=None)), columns=['create_time', 'cycle_id', 'power_mean']+sColNames).infer_objects()        
        dfSE.dropna(axis=0, how='all', subset=list(map_channels.values()), inplace=True)
                            
        #now distinguish between systems that collect full (2Hz-wise) spectra and those that contain only sum from 150-350 Hz                                
        if dfSE.shape[0]==0:                
		
            issues.append(create_issue(db,
                                       sErrorMsg = 'keine SE-Daten vorhanden', 
                                       sAction = 'manuell pruefen',
                                       sLink = create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time), end_time = end_time),
                                       sTool = sTool))   
        else:                                    
				
            # if minimal value for power is given, remove the other values (this is done here and not e.g. in the sql-query
            # in order to easily check if there are se-values at all
            if power_min:
                dfSE = dfSE[dfSE.power_mean<power_min]
                        
            ## now compare with the thresholds    
            if dfSE.shape[0]>0:            
                
                lErr = []
                for lList in [lFlap, lEdge]:

                    # TODO 2019-1-17: hier ggf. Sensitivities beachten!
                    relSE = get_relative_se(dfSE, lList)
                    #dOS = np.tile(dfOS.loc[:, lList].values, (relSE.shape[0],1))                # array of offsets
                    #relSE = relSE + dOS                                        
                    #dThres = np.tile(dfSE_thres.loc[:, lList].values, (relSE.shape[0],1))
                    dThres = np.tile(dfSE_thres.loc[:, lList].values - dfOS.loc[:, lList].values, (relSE.shape[0],1))           # offsets und thresholds gleich zusammengefasst

                    dfTmp = pd.DataFrame((relSE > dThres), columns=lList)		
                    lErr.append(dfTmp)
        				
                dfErr = pd.concat(lErr, axis=1).loc[:, list(sChannels.values())]                ## combine results and take only desired channels
                bTmp = dfErr.any(axis=1)
                dfCyc_cl = pd.concat((dfSE[bTmp].loc[:,['create_time', 'cycle_id']], dfErr[bTmp].set_index(dfSE[bTmp].index)), axis=1)
        									   
                dfCyc_cl.rename(columns = map_channels_inv, inplace=True)
                dfCyc_cl = pd.melt(dfCyc_cl, id_vars=['create_time', 'cycle_id'], value_vars = list(sChannels.keys()), var_name = 'channel', value_name = 'fail')
                dfCyc_cl = dfCyc_cl[dfCyc_cl.fail]
                # reformat 
                # find cycles (create_time, cycle_id) of the times of the errors
                #dfCyc_cl = dfCyc_cl.assign(origin = pd.Series(np.tile('classic', (dfCyc_cl.shape[0],))).values)           # add column with origin (classical method or ts method)				
    
    except:
        dfCyc_cl = None
        issues.append(create_issue(db,
                                   sErrorMsg='unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode',
                                   sAction='manuell ansehen',
                                   sLink=create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), end_time = end_time+dt.timedelta(hours=4))))

    return dfCyc_cl, issues











"""
function to check if measuring line are ok by ts method
@author: Christian Kuehnert
@last_modified: 2019-2-28


example:
--------
  
import numpy as np
import pandas as pd
import datetime as dt
import sys

sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\functions')        # path to modules  
import myFunctions_data as mfdata
import myFunctions_monitor as mfmon
sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\sensor_classification')
import class_sensor_classificator as csc
   

db = 'cmrblba_bc_t_02758'
channels = [3,4,5]
start_time = dt.datetime(2018,12,2,4,0,0)
end_time = start_time + dt.timedelta(days=2)
sPathData = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\data\hd5_files'
sc = csc.classifierTemplate(name = 'asym', param=None, feat_fct = mfdata.asym_feat, feat_kwargs = {'iOrderDiff': 1, 'dQ': 0.99}, predict_fct = mfdata.asym_predict, predict_kwargs = {'dThreshold': 0.0015})
#sc = csc.classifierTemplate(name = 'ts', ... param=None, feat_fct = mfdata.ts_feat, feat_kwargs = {'iOrderDiff': 1, 'dQ': 0.99}, predict_fct = mfdata.asym_predict, predict_kwargs = {'dThreshold': 0.0015})
dfRes, issues = mfmon.check_meas_line_ts(db, channels, start_time, end_time, sPathData=sPathData, sensor_classificator=sc)

"""
def check_meas_line_ts(db, channels, start_time, end_time, sPathData = '', sensor_classificator = None):
	
    issues = []
    sTool = 'SE'
    
    #bUpdate = True
	
    # TODO 2019-2-28: spaeter ersetzen durch Abfrage von Dirks hd5-file
#    if bUpdate:
    mfdata.update_cdef(db, sPathData, time_start=start_time, time_end=end_time)
    mfdata.update_ts(db, sPathData, time_start=start_time, time_end=end_time)
    
    lWC = []
    lWC.append(mfdata.whereClause_from_timeInterval(time_start=start_time, time_end=end_time))
    
    if (channels is None):
        lWC.append('channel<6')
    else:
        lWC.append('channel in ' + str(channels).replace('[', '(').replace(']', ')'))
    
    dfCyc = mfdata.get_data(db, sPathData, [[sNodes.ts_startstop, ' and '.join(lWC)]], ['create_time', 'ID', 'channel','start','stop'])    
    
#	else:						## ohne update:
#		lWC = [get_wc_from_time_interval(start_time, end_time), 
#				"available_data>=3", 
#				"cycle_id IS NOT NULL", 
#				"create_time IS NOT NULL", 
#				"channel<6"]				
#		sWC = " AND ".join(lWC)
#		dfCyc = get_data_fromDB(db, 'ba_cycle_measurement_cycle', sWC)
						
						
    if dfCyc.shape[0]==0:
        issues.append(create_issue(db,
                                   sErrorMsg='keine Zeitdaten gefunden',
                                   sAction='manuell ansehen',
                                   sLink=create_link(db, sTool=sTool, 
                                                     start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), 
                                                     end_time = end_time+dt.timedelta(hours=4)),
                                                     sTool=sTool))
    else:
								
        try:
            tb =  ctb.turbine(sPathData=sPathData) 
            tb.init_from_db(db)
            iPred, dfFeat = tb.predict_sensor_state(dfCyc, sensor_classificator)
								
            # TODO 2019-1-17: stimmt das so???
            bCrit = [i==1 for i in iPred]
								
            # if any errornous channels were detected ..
            #if any(bCrit):									
            dfCyc = dfCyc[bCrit]
            dfCyc = dfCyc.assign(origin=pd.Series(np.tile('ts', (dfCyc.shape[0],))).values)          # add column with method (ts)
														
        except:
            issues.append(create_issue(db,
                                       sErrorMsg='unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode',
                                       sAction='manuell ansehen',
                                       sLink=create_link(db, sTool=sTool, 
                                                         start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), 
                                                         end_time = end_time+dt.timedelta(hours=4)),
                                                         sTool=sTool))
                        
            #print('unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode')
            dfCyc = None
								    
    return dfCyc, issues








"""
function to check one single time series/measuring data row for sensor defect
@author: Christian Kuehnert
@last_modified: 2019-3-12

"""
sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\sensor_classification'
sys.path.append(sModulePath)
#import class_sensor_classifier as csc
import class_classifier_ts as csc

def check_sensor_one_date(db, check_date, name_cls, path_cls):
    
    try:
        ## load classifier
        sc = csc.sensor_classifier(name=name_cls, pickle_path=path_cls)
        sc.load()
        iPred = sc.predict_for_periode(db, start_time=check_date)
        
        ## predict for this time point
    except Exception as ex:
        print('error occurred in function check_sensor_date')
        iPred = None
    
    return(iPred)


#
#"""
#function to check if measuring lines are ok
#first check "classical way", i.e. from relative signal energy, second check by time series analysis
#
#@author: Christian Kuehnert
#@last_modified: 2019-2-27
#
#input:
#------
#        - db: database name (including 'cmrblba_')
#        - tickets: dataframe with tickets for this turbine
#        - checks:  booleans of checks
#        - issues:  list of issues
#        - start_time: start time of interesting period
#        - end_time:   end time of interesting period
#        - dict_method: dictionary, methods by which the broken measuring lines will be detected and the respective **kwargs
#        - power_min: exclude data with low power ('untypical states') from consideration - sometimes turbines show higher signal energy for P<150 kW but not for higher speed/power, so
#                            such states can be excluded by setting this parameter to a minimum power value, only data with power_mean above or equal this value will be considered
#        
#        
#        
#"""
##def check_meas_line(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350, 'meas_len': 16.384}}, power_min=None):
#def check_meas_line(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350}}, power_min=None):
#    #def check_measLines(self, time_start=None, time_end=None, sMethod = 'classical', sensor_classificator=None):
##    def check_measLines(self, sMethod = 'classical', sensor_classificator=None):
#    sDTFormatMsg = '%d.%m.%Y, %H:%M'
#    #tShift = 3/24
#    tShift = dt.timedelta(hours=6)
#    #dStartFreq = 150
#    #dEndFreq = 350
#    #dMeas_len = 16.384
#    sTool = 'SE'
#    dict_res = {}
#    channels = range(5)         # consider all channels
#    dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
#
#    
#    
#    for sMethod, kwargs in dict_methods.items():
#	
#        try:				
#
#            if (sMethod=='classical'):
#                dfCycCrit, tmp = check_meas_line_classical(db, channels, start_time, end_time, kwargs['start_freq'], kwargs['end_freq'], power_min=power_min)
#                #dfCycCrit, tmp = check_meas_line_classical(db, channels, start_time, end_time, **kwargs, power_min=power_min)
#
#            elif (sMethod=='ts'):
#                dfCycCrit, tmp = check_meas_line_ts(db, start_time, end_time, **kwargs)
#
#            else:
#                print('unbekannte Methode zur Sensordefekterkennung')
#                dfCycCrit, tmp = None, []
#
#            ## add issues to list of issues                
#            if tmp:
#                for el in tmp:
#                    issues.append(el)												                                    
#            
#        except:
#            issues.append(create_issue(db,
#                                       sErrorMsg = 'unbekannter Fehler bei check_measLines ' + sMethod, 
#                                       sAction = 'manuell pruefen',
#                                       sLink = create_link(db, sTool=sTool, start_time=start_time, end_time=end_time),
#                                       sTool = sTool))						
#            dfCycCrit = None                    
#						
#        dict_res.append({sMethod: dfCycCrit})
#
#
#        ## 3) now get info about found critical times and check for existing tickets
#        if isinstance(dfCycCrit, pd.DataFrame):
#            
#            if dfCycCrit.shape[0]>0:
#            
#                try:                                
#    				                
#                    # TODO 2019-1-18: combine results from both methods oder gegenseitig ueberpruefen oder sowas, akt. noch ts-methode deaktiviert
#                    iCh_crit = np.unique(dfCycCrit.channel)              # critical channels
#        		                                                        								
#                    dfTicketsCrit = get_relevant_tickets(tickets, sType = 'meas_lines')                     # tickets for measure lines with problems
#                    
#                    dictChTickets, bChTickets = mfdata.get_channels_from_tickets(dfTicketsCrit)     # find affected channels by the modified titles of the relevant tickets                                
#        								
#					## vielleicht hier noch anders machen:
#					## fuer klassiche Methode pruefen, ob, wenn 2 channels defekt und 1 intakt gefunden werden vielleicht nur der "intakte" defekt ist und die anderen beiden ok:
#					## - in class. methode selbst noch vor ge-meltetem dataframe t-tests (oder so) machen, ob 1 von den anderen 2 Kanaelen (pro Richtung) signifikant verschieden ist, wenn derjenige
#					## als nicht-defekt bewertet wurde, dann Bewertungen umkehren (dieser ist dann vermutlich der defekte), dabei vorher pruefen, ob genug Datensaetze vorhanden sind (>20 oder so)
#					## HIER an dieser Stelle dann:
#					##   - zuerst aus (offenen) Tickets die defekten Kanaele herausfinden, dann XOR mit den defekten Kanaelen anhand der Methode, wenn XOR==1 dann vielleicht ebenfalls der als intakt
#					##     deklarierte Kanal defekt und umgekehrt
#					## ggf. immer hinschreiben, dass nochmal manuell untersucht werden soll
#                    if sMethod=='classical':
#                        print('hier weiter 2019-2-28')							
#										
#								
#                    # TODO 2018-12-20: noch eleganter, vektorisierter etc. machen!
#                    for iCh in iCh_crit:
#        							
#                        ## critical times for that channel
#                        # TODO 2018-12-21: hier koennte man noch testen, ob iPred=1 ueber (fast) den ganzen betrachteten Zeitraum gilt oder nur einen kleinen Teil,
#                        # und dann anhand dessen das 'ztw.' hinzufuegen oder weglassen
#                        # TODO 2019-1-25: ausserdem testen, ob Beginn des Defekts vielleicht noch weiter zurueckliegt und entsprechende Zeit herausfinden
#                        dtCrit = dfCycCrit[dfCycCrit.channel==iCh].create_time                                                  
#                        sTmp = 'Channel ' + str(iCh) + ' (' + dictMap_output[iCh] + ') (ztw.) defekt seit mindestens ' + min(dtCrit).strftime(sDTFormatMsg)
#        			
#                        ## look for related tickets
#                        #dfTC = dictChTickets[str(iCh)]                      # tickets for that channel
#                        dfTC = dictChTickets[iCh]                      # tickets for that channel
#        							
#                        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets for that channel
#                        if dfOpen.shape[0]>0:
#                            sTmp += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
#                            issues.append(create_issue(db,
#                                                       sErrorMsg=sTmp,
#                                                       sAction='', 
#                                                       sLink = ''))
#        							
#                        else:
#                            dfClosed = dfTC[dfTC.sStatus=='erledigt']
#                            if dfClosed.shape[0]==0:
#        																	
#                                #sStartLink = str(np.floor((min(dtCrit) - tShift).timestamp())*1000)
#                                #sEndLink = str(np.floor(dt.now().timestamp())*1000)
#        													   
#                                #HIER WEITER 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN                              
#                                issues.append(create_issue(db, 
#                                                           sErrorMsg=sTmp,
#                                                           sAction='Ticket anlegen, ggf. Kanal deaktivieren',
#                                                           sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
#                                                           sTool = sTool))
#        																		
#                            else:
#                                dfT = mfdata.get_ticket_times(dfClosed)                 # start and end times for the closed tickets
#        									
#                                ## herausfinden, ob es iPred=1-Zeiten nach Ende der Tickets gibt, falls nein:
#                                bAllIn = False
#                                for idx, row in dfT.iterrows():
#                                    bAllIn = bAllIn & all(dtCrit <= row['stop'])                                
#        									
#                                    if bAllIn:
#                                        sTmp = sTmp + ' - alles noch durch Ticket ' + ','.join(dfT.sTicketID) + ' (jetzt geschlossen) abgedeckt'
#                                        issues.append(create_issue(db,
#                                                                   sErrorMsg=sTmp,
#                                                                   sAction='beobachten',
#                                                                   sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
#                                                                   sTool = sTool))
#                                        
#                                    else:             ## ansonsten 
#                                        sTmp = sTmp + ', anscheinend schonmal aufgetreten (Ticket ' + ','.join(dfT.sTicketID) + ')'
#                                        issues.append(create_issue(db,
#                                                                   sErrorMsg=sTmp,
#                                                                   sAction='altes Ticket wieder oeffnen oder neues Ticket anlegen',
#                                                                   sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
#                                                                   sTool=sTool))
#    		
#                except:
#                    issues.append(create_issue(db, 
#                                               sErrorMsg='unbek. Fehler bei Check auf Sensordefekte (bei Ticketzuordnung)',
#                                               sAction='manuell ansehen',
#                                               sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
#                                               sTool=sTool))
#					
#    return(dict_res)


  


"""
function to check if measuring lines are ok
first check "classical way", i.e. from relative signal energy, second check by time series analysis

@author: Christian Kuehnert
@last_modified: 2019-2-27

input:
------
        - db: database name (including 'cmrblba_')
        - tickets: dataframe with tickets for this turbine
        - checks:  booleans of checks
        - issues:  list of issues
        - start_time: start time of interesting period
        - end_time:   end time of interesting period
        - dict_method: dictionary, methods by which the broken measuring lines will be detected and the respective **kwargs
        - power_min: exclude data with low power ('untypical states') from consideration - sometimes turbines show higher signal energy for P<150 kW but not for higher speed/power, so
                            such states can be excluded by setting this parameter to a minimum power value, only data with power_mean above or equal this value will be considered
        
        
        
"""
#def check_meas_line(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350, 'meas_len': 16.384}}, power_min=None):
def check_meas_line(db, tickets, checks, issues, start_time, end_time, dict_methods = {'classical': {'start_freq': 150, 'end_freq': 350}}, power_min=None):
    #def check_measLines(self, time_start=None, time_end=None, sMethod = 'classical', sensor_classificator=None):
#    def check_measLines(self, sMethod = 'classical', sensor_classificator=None):
    sDTFormatMsg = '%d.%m.%Y, %H:%M'
    #tShift = 3/24
    tShift = dt.timedelta(hours=6)
    #dStartFreq = 150
    #dEndFreq = 350
    #dMeas_len = 16.384
    sTool = 'SE'
    dict_res = {}
    channels = range(5)         # consider all channels
    dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output

    
    
    for sMethod, kwargs in dict_methods.items():
	
        try:				

            if (sMethod=='classical'):
                dfCycCrit, tmp = check_meas_line_classical(db, channels, start_time, end_time, kwargs['start_freq'], kwargs['end_freq'], power_min=power_min)
                #dfCycCrit, tmp = check_meas_line_classical(db, channels, start_time, end_time, **kwargs, power_min=power_min)

            elif (sMethod=='ts'):
                dfCycCrit, tmp = check_meas_line_ts(db, start_time, end_time, **kwargs)

            else:
                print('unbekannte Methode zur Sensordefekterkennung')
                dfCycCrit, tmp = None, []

            ## add issues to list of issues                
            if tmp:
                for el in tmp:
                    issues.append(el)												                                    
            
        except:
            issues.append(create_issue(db,
                                       sErrorMsg = 'unbekannter Fehler bei check_measLines ' + sMethod, 
                                       sAction = 'manuell pruefen',
                                       sLink = create_link(db, sTool=sTool, start_time=start_time, end_time=end_time),
                                       sTool = sTool))						
            dfCycCrit = None                    
						
        dict_res.append({sMethod: dfCycCrit})


        ## 3) now get info about found critical times and check for existing tickets
        if isinstance(dfCycCrit, pd.DataFrame):
            
            if dfCycCrit.shape[0]>0:
            
                try:                                
    				                
                    # TODO 2019-1-18: combine results from both methods oder gegenseitig ueberpruefen oder sowas, akt. noch ts-methode deaktiviert
                    iCh_crit = np.unique(dfCycCrit.channel)              # critical channels
        		                                                        								
                    dfTicketsCrit = get_relevant_tickets(tickets, sType = 'meas_lines')                     # tickets for measure lines with problems
                    
                    dictChTickets, bChTickets = mfdata.get_channels_from_tickets(dfTicketsCrit)     # find affected channels by the modified titles of the relevant tickets                                
        								
					## vielleicht hier noch anders machen:
					## fuer klassiche Methode pruefen, ob, wenn 2 channels defekt und 1 intakt gefunden werden vielleicht nur der "intakte" defekt ist und die anderen beiden ok:
					## - in class. methode selbst noch vor ge-meltetem dataframe t-tests (oder so) machen, ob 1 von den anderen 2 Kanaelen (pro Richtung) signifikant verschieden ist, wenn derjenige
					## als nicht-defekt bewertet wurde, dann Bewertungen umkehren (dieser ist dann vermutlich der defekte), dabei vorher pruefen, ob genug Datensaetze vorhanden sind (>20 oder so)
					## HIER an dieser Stelle dann:
					##   - zuerst aus (offenen) Tickets die defekten Kanaele herausfinden, dann XOR mit den defekten Kanaelen anhand der Methode, wenn XOR==1 dann vielleicht ebenfalls der als intakt
					##     deklarierte Kanal defekt und umgekehrt
					## ggf. immer hinschreiben, dass nochmal manuell untersucht werden soll
                    if sMethod=='classical':
                        print('hier weiter 2019-2-28')							
										
								
                    # TODO 2018-12-20: noch eleganter, vektorisierter etc. machen!
                    for iCh in iCh_crit:
        							
                        ## critical times for that channel
                        # TODO 2018-12-21: hier koennte man noch testen, ob iPred=1 ueber (fast) den ganzen betrachteten Zeitraum gilt oder nur einen kleinen Teil,
                        # und dann anhand dessen das 'ztw.' hinzufuegen oder weglassen
                        # TODO 2019-1-25: ausserdem testen, ob Beginn des Defekts vielleicht noch weiter zurueckliegt und entsprechende Zeit herausfinden
                        dtCrit = dfCycCrit[dfCycCrit.channel==iCh].create_time                                                  
                        sTmp = 'Channel ' + str(iCh) + ' (' + dictMap_output[iCh] + ') (ztw.) defekt seit mindestens ' + min(dtCrit).strftime(sDTFormatMsg)
        			
                        ## look for related tickets
                        #dfTC = dictChTickets[str(iCh)]                      # tickets for that channel
                        dfTC = dictChTickets[iCh]                      # tickets for that channel
        							
                        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets for that channel
                        if dfOpen.shape[0]>0:
                            sTmp += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                            issues.append(create_issue(db,
                                                       sErrorMsg=sTmp,
                                                       sAction='', 
                                                       sLink = ''))
        							
                        else:
                            dfClosed = dfTC[dfTC.sStatus=='erledigt']
                            if dfClosed.shape[0]==0:
        																	
                                #sStartLink = str(np.floor((min(dtCrit) - tShift).timestamp())*1000)
                                #sEndLink = str(np.floor(dt.now().timestamp())*1000)
        													   
                                #HIER WEITER 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN                              
                                issues.append(create_issue(db, 
                                                           sErrorMsg=sTmp,
                                                           sAction='Ticket anlegen, ggf. Kanal deaktivieren',
                                                           sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                                           sTool = sTool))
        																		
                            else:
                                dfT = mfdata.get_ticket_times(dfClosed)                 # start and end times for the closed tickets
        									
                                ## herausfinden, ob es iPred=1-Zeiten nach Ende der Tickets gibt, falls nein:
                                bAllIn = False
                                for idx, row in dfT.iterrows():
                                    bAllIn = bAllIn & all(dtCrit <= row['stop'])                                
        									
                                    if bAllIn:
                                        sTmp = sTmp + ' - alles noch durch Ticket ' + ','.join(dfT.sTicketID) + ' (jetzt geschlossen) abgedeckt'
                                        issues.append(create_issue(db,
                                                                   sErrorMsg=sTmp,
                                                                   sAction='beobachten',
                                                                   sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                                                   sTool = sTool))
                                        
                                    else:             ## ansonsten 
                                        sTmp = sTmp + ', anscheinend schonmal aufgetreten (Ticket ' + ','.join(dfT.sTicketID) + ')'
                                        issues.append(create_issue(db,
                                                                   sErrorMsg=sTmp,
                                                                   sAction='altes Ticket wieder oeffnen oder neues Ticket anlegen',
                                                                   sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                                                   sTool=sTool))
    		
                except:
                    issues.append(create_issue(db, 
                                               sErrorMsg='unbek. Fehler bei Check auf Sensordefekte (bei Ticketzuordnung)',
                                               sAction='manuell ansehen',
                                               sLink=create_link(db, sTool=sTool, start_time=min(dtCrit)-tShift, end_time=end_time+tShift),
                                               sTool=sTool))
					
    return(dict_res)


  



"""
function to check if low-pass behaviour occurs

@author: Christian Kuehnert
@last_modified: 2019-2-20

input:
------
        - db: database name (including 'cmrblba_')
"""
def check_low_pass(db, tickets, checks, issues, start_time, end_time):
    pass
    #issues = []    
    
    #return issues





#
#"""
#frame-function for checking
#
#@author: Christian Kuehnert
#@last_modified: 2019-2-21
#
#input:
#------
#        - turbine:      dictionary of turbine, must contain database, farm, name etc.
#        - check_name:   string, name of the test to be conducted
#        - do_check:     boolean, do this test (True) or not (False)
#        - list_issues:  list of issues, to be updated (if the test is conducted) 
#                        by the resulting issues of this test
#                        
#output:
#-------
#        - (implicit): updated list list_issues
#        - ok:           result of test (True -> continue with further tests)
#        
#"""
#def check_properties(turbine, tickets, check_name, start_time, end_time, checks, list_issues):
#
#    db = turbine['sDB']
#    issues = []
#    
#    if (check_name == 'db'):
#        if checks['db']:
#            issues = check_db(db, tickets, checks)
#    
#    elif (check_name == 'prefs'):
#        if checks['prefs']:
#            issues = check_prefs(db, tickets, checks)
#    
#    elif (check_name == 'data_fix'):
#        if checks['data_fix']:
#            port = turbine['ssh_port']
#            issues = check_data_fix(db, tickets, checks, start_time, end_time, port)
#    
#    elif (check_name == 'improper_ext'):
#        if checks['improper_ext']:
#            issues = check_improper_ext(db, tickets, checks, start_time, end_time)
#    
#    elif (check_name == 'ice_eval'):
#        if checks['ice_eval']:
#            issues = check_ice_eval(db, tickets, checks, start_time, end_time)
#
#    elif (check_name == 'meas_line'):
#        if checks['meas_line']:
#            issues = check_meas_line(db, tickets, checks, start_time, end_time)                        
#    
#    elif (check_name == 'low_pass'):
#        if checks['low_pass']:
#            issues = check_low_pass(db, tickets, checks, start_time, end_time)
#    
#    else:
#        # unknown check-type
#        issues = create_issue('unknown check-type ' + check_name)
#        set_checks_to_false(checks, checks.keys())
#
#
#    # Note: not just list_issues + list in order to change the list_issues also outside the scope of this function
#    #if issues:
#    sFarm = turbine['sFarm']
#    sWT = turbine['sName']
#    
#    for el in issues:
#        el.__setattr__('farm', sFarm)
#        el.__setattr__('wt', 'sName')
#
#        if el.dict_customer_mail:
#            sRecipients = tb['Empfaenger_Schadensmeldung']
#            sRecipientsCC = tb['CC']
#            
#            sFN_mc = create_email(el.dict_mail['check_type'], el.dict_mail['language'], sFarm, sWT, sRecipients, sRecipientsCC)
#                    # dict_customer_mail: {'check_type': 'data_fix', 'mailtype': 'ECU_n_e', 'language': 'eng'}
#
#        list_issues.append(el)
#  
# 
    
    

"""
function to save issues in .csv-file
@author: Christian Kuehnert
@last_modified: 2019-2-25

"""
def save_issues(lIssues, sFN):
    
    ## save as .csv
    if len(lIssues)==0:
        print('no issues found')
        
    else:
        dfIssues = pd.DataFrame([vars(s) for s in lIssues])                                 # cast issues to a dataframe
        dfIssues.sort_values(axis=0, by=['farm','wt'], inplace=True)                        # sort issues by farm, wt and error message
        
        dfIssues.to_csv(sFN, 
                        sep=';', 
                        index=False, 
                        columns=['farm', 'wt', 'db', 'error_msg', 'action', 'link', 'link_mail'], 
                        header=['Windpark','WEA','DB','Fehler','Vorschlag', 'Link', 'Kunden-Email'], 
                        encoding='cp1252')
    
    
  



"""
creates link to turbine data in webVis

input:
------
        - ...
        - cols_gh:            dictionary with table and variables to be displayed in graphical history, only relevant for sTool=='GH' (will be ignored for all other tools)
        

@author: Christian Kuehnert
@last_modified: 2019-2-22

"""          
def create_link(db, sTool = 'IV', cols_gh = None, start_time = dt.datetime.now()-dt.timedelta(days=30), end_time = dt.datetime.now() + dt.timedelta(hours=3)):
            
    sStartLink = str(int(np.floor((max(end_time - dt.timedelta(days=30), start_time)).timestamp())*1000))
    sEndLink = str(int(np.ceil(end_time.timestamp())*1000))

    # TODO 2019-1-27: links noch fuer alle 3 (oder mehr) tools richtig machen
    if (sTool == 'GH'):
        if not cols_gh:
            # use standard representation
            cols_gh = {'ba_cycle_status': ['omega_mean', 'power_mean', 'pitch_mean', 'wind_mean'], 
                     'ba_cycle_externals': ['err_code']}

        sTmp = [[key + '%3A' + val for val in cols_gh[key]] for key in cols_gh.keys()]
        sTmp2 = '&col%5B%5D='.join([s for sl in sTmp for s in sl])                               
        sLink = r'https://10.41.52.54/WebVis/gr_hist?dbName=' + db + f'&s={sStartLink}&e={sEndLink}&col%5B%5D={sTmp2}'

    elif (sTool == 'SE'):
        sLink = r'https://10.41.52.54/WebVis/se_chart?dbName=' + db + f'&s={sStartLink}&e={sEndLink}&fmn=150&fmx=350&n=3BM&rmn=&rmx=&wmn=&wmx=&pimn=&pimx=&pomn=&pomx=&tmn=&tmx=&wmn2=&wmx2=&pimn2=&pimx2=&pomn2=&pomx2=&tmn2=&tmx2=&rmn2=&rmx2=&o=default'
        
    else:
        #print('konnte Tool-Kuerzel nicht einordnen, verwende IceVis fuer Link')
        sLink = r'https://10.41.52.54/WebVis/ice_peaks?dbName=' + db + f'&s={sStartLink}&e={sEndLink}&it%5B%5D=R1F0&it%5B%5D=R2F0&it%5B%5D=R3F0&it%5B%5D=R1F1&it%5B%5D=R2F1&it%5B%5D=R3F1&it%5B%5D=R1F2&it%5B%5D=R2F2&it%5B%5D=R3F2'

    return(sLink)










"""
creates mail for customers
TODO 2019-2-25: eleganter und generischer machen!

Christian Kuehnert, 2019-2-26
"""        
#def create_mail(tb, sType, sRecipients, sRecipientsCC):
def create_email(sFarm, sWT, sRecipients, sRecipientsCC, sPath_oft, sType='data_fix', sLanguage='deu'):
                
    ## TODO 2019-2-25: hier evtl. header-dictionary definieren
    #dict_header = {'ECUne_eng':  ...}
    sMailType = sType + '__' + sLanguage
    
    
    sFN = sPath_oft + '\\' + sMailType + '.htm'
    if os.path.isfile(sFN):    
    
        outlook = win32.Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
                
        if sRecipients:
            mail.To = sRecipients
            
        if sRecipientsCC:
            mail.CC = sRecipientsCC
    
        sText = ''
        with open(sFN, 'r') as f_template:
            sText = f_template.read()            
            mail.HtmlBody = sText.replace('<REPLACE_FARM>', sFarm).replace('<REPLACE_TURBINE>', sWT)
            
    else:
        mail = None

    return(mail)
    

