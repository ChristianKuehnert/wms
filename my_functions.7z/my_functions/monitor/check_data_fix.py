# -*- coding: utf-8 -*-
"""
function to check if data are fix

Created on Tue Mar 26 02:27:38 2019

@author: Christian Kuehnert
@last_modified: 2019-5-23

input:
------
        - db: database name (including 'cmrblba_')
"""

import datetime as dt
#from monitor import get_missing_data, create_issue, set_checks_to_false, get_relevant_tickets, create_link
#from data import get_preferences
import monitor as mfmon
import data as mfdata





"""
function to get the last entry after for the given columns in the given table
of the given database after the given time

Created on Wed Jul 24 10:40:59 2019


@author: Christian Kuehnert
@modified: 2019-7-24

"""
def get_last_entries(db, table, cols, last_time_ok):

    tmp = [(f"select '{c}',{c} from {table} where create_time>'{last_time_ok}' "
            "limit 1") for c in cols]

    sQuery = " union ".join(tmp) + ";"

    last_entries = dict(mfdata.query_MySQL2(db, sQuery))

    return(last_entries)
    




"""
function that returns TRUE if the state vector is valid (plausible), otherwise
FALSE

2020-1-17

"""
def state_vector_valid(omega, power, pitch, prefs):
    
    max_pitch_rot = prefs['max_pitch_rot']
    min_omega = prefs['omega_min']
        
    valid = ((omega < min_omega) & (power < 0) & (pitch > max_pitch_rot) |# standing or idling
             (omega >= min_omega) & (pitch <= max_pitch_rot) & (power >= 0))  # rotating
    
    return(valid)
    

#HIER WEITER 20200118, ARB.ZT. 20200118, 1:20-1:40






"""

@modified: 2019-7-30

"""
def check_data_fix(db, tickets, checks, issues, start_time, end_time, ssh_port):
    
    tAllowedDelay = dt.timedelta(days=1)
    
    #issues = []    
    
    sFormatDT_out = '%d.%m.%Y %H:%M'
        
    
    #sAction = ''
    #bShort = True
    sTool = 'GH'
    dict_cols_gh = None
    
    #sColTime = 'create_time'
    #sColsProd = ['omega_mean','wind_mean','power_mean','pitch_mean','azimuth_mean','temperature_mean','cyc_status_system','cyc_status_eval']
    sColsProd = ['omega_mean','wind_mean','power_mean','pitch_mean','temperature_mean']
    #sColsExt = ['create_time', 'omega', 'wind', 'power', 'pitch', 'azimuth', 'temperature']
    sColsExt = ['wind', 'power', 'pitch']
    
    ## columns to check in order to decide if fixed data are due to standing
    ## turbine or due to issue
    #cols_stand_prod = ['omega_mean', 'pitch_mean']
    #cols_stand_ext = ['pitch']
    
    
    # TODO 2019-5-16: evtl. mit uebergeben, wird ja ggf. vorher schonmal ausgelesen (oder vielleicht nur dann hier nochmal bestimmen, wenn None uebergeben wird)
    prefs = mfdata.get_preferences(db)
    
    # TODO 2019-3-1: folgendes noch generischer machen - dynamisch die relevanten keys herausfinden 
    # (viell. anhand von Suche nach 'azimuth' und 'ambienttemperature' in den keys) und diese verwenden
    tmp = prefs.keys()
    if 'UseAmbientTemperature' in tmp:
        if bool(int(prefs['UseAmbientTemperature'])):
            sColsExt.append('temperature')
    
    if 'AzimuthAvailable' in tmp:
        if bool(int(prefs['AzimuthAvailable'])):
            sColsExt.append('azimuth')
                          
    try:
        times_prod = mfmon.get_missing_data(db, 'ba_cycle_status', end_time, tAllowedDelay, 'create_time', sColsProd)
        times_ext = mfmon.get_missing_data(db, 'ba_cycle_externals', end_time, tAllowedDelay, 'create_time', sColsExt)
                       
        ## check if data are fix due to standing wtg, not due to issue
        # TODO 2019-7-24: in einem naechsten Iterationsschritt evtl. nochmal
        # die get_missing_data so aendern, dass zwischen letztem Zeitpunkt mit
        # Nicht-NULL-Werten und mit fixen Werten unterschieden wird, dann
        # bei NULL-Werten doch als issue ansehen, nur bei fixen Werten nicht
#        set_pd = {s[0] for s in dict_tmp['Betriebsdaten']}
#        set_ext = {s[0] for s in dict_tmp['Externals']}
#        
#        b_stand = (len(set_pd + set_ext - \
#                       set(cols_stand_prod + cols_stand_ext))==0)
#        
#        # if this is true, do detailed check if all values are consistent
#        if b_stand:
#            # check if omega_mean == 0 and power_mean, power <= 0 and pitch,
#            # pitch_mean >= rot
#            # TODO 2019-7-24: get_missing_data so anpassen, dass auch gleich
#            # die letzten Werte ausgegeben werden                                      
#                        
#            s_last_time =
#            last_prod = get_last_entries(db, 'ba_cycle_status',cols_stand_prod)
#            last_ext = get_last_entries(db,'ba_cycle_externals',cols_stand_ext)
#        
#            if 
#        
        b_stand = False
        if b_stand:
            times_prod = {}
        
                                     
        lMsg = []
        dict_tmp = {'Betriebsdaten': [sColsProd, times_prod, 'ba_cycle_status'],
                   'Externals': [sColsExt, times_ext, 'ba_cycle_externals']}
        
        
        bFix = []
        tMin = []
        dict_cols_gh = {}
        for key, val in dict_tmp.items():
                
            cols = val[0]
            ctimes, sTmp, bOk = val[1]

            # if there is a message, append it to the list of messages
            if sTmp:
                lMsg.append(sTmp)
            
            
            # Ausgabe fuer missing prod/ext
            if bOk:
            
                if len(ctimes)>0:
                    bFix.append(True)
                    dict_cols_gh.update({val[2]: list(ctimes.keys())})
                    
                    times_notNone = [t for t in list(ctimes.values()) if t is not None]
                    if len(times_notNone)==0:
                        sTimeMin = 'Beginn'
    
                    else:
                        tmp = min(times_notNone)
                        tMin.append(tmp)
                        sTimeMin = tmp.strftime(sFormatDT_out)
                
                
                    if len(val)==len(cols):
                        lMsg.append(key + ' fehlen/sind fix seit ' + sTimeMin)
                            
                    else:
                        lMsg.append('folgende ' + key + ' fehlen/sind fix seit ' + sTimeMin + ': ' + ', '.join(ctimes.keys()))
                        
                else:
                    bFix.append(False)

            else:
                bFix.append(True)
                            
        
        if len(dict_cols_gh)==0:
            dict_cols_gh = None
            
        #bNoPort = (ssh_port == '0.0')                # entspricht 'Tunnel: Port ist 0!'
        bNoPort = (ssh_port==0)
        bNoProd = bFix[0]
        bNoExt = bFix[1]
        
        
        tEndLink = end_time + dt.timedelta(hours = 6)
        if len(tMin)>0:
            tStartLink = max([min(tMin), end_time - dt.timedelta(days=30)]) - dt.timedelta(hours=6)
        else:
            tStartLink = end_time - dt.timedelta(days=30) - dt.timedelta(hours=6)
            
        #bCheckImpExt = all(not(isna(dTimeLast_prod))) & all(not(isnan(dTimeLastNotFix_prod))) & (min(dTimeLast_prod) >= tLastMon) & (min(dTimeLastNotFix_prod) >= tLastMon)

        bFixed = bNoProd | bNoExt                    # true if at least one of externals or production data are fix or missing
        bECUne = bNoProd & bNoExt & bNoPort
        bHMUne = bNoProd & ~bNoExt & ~bNoPort


        if bECUne:
            #lMsg[-1] += ', vermutlich ECU n.e.'
            lMsg.append('vmtl. ECU n.e.')
            #lMsg = ['ECU n.e.']
            mfmon.set_checks_to_false(checks, ['ice_eval'])

        if bHMUne:
            #sMonRes = [sMonRes, ', vermutlich HMU n.e. seit ', datestr(min(tLastNotFixProd), sDateTimeFormatOutput)];	
            lMsg.append('vmtl. HMU n.e.')
            #lMsg = ['vmtl. HMU n.e.']
            mfmon.set_checks_to_false(checks, ['ice_eval'])


        # TODO 2017-12-8: Hier nochmal mit DB sprechen, wann welche Probleme auftreten
        ## if problems are found, create link
        if bFixed:
            ## TODO 2017-12-8: noch Fall abfangen, dass der Zeitraum zu lang wird, dann nur Ende mit den letzten Daten darstellen 
            sLink = mfmon.create_link(db, sTool = sTool, cols_gh = dict_cols_gh, start_time = tStartLink, end_time = tEndLink)


        ## find and analyse suitable tickets
        tmp = mfmon.get_relevant_tickets(tickets, sType = 'data_fix')    # tickets for measure lines with problems                                                            
        dfTC = tmp[0]
        dfOpen = dfTC[~(dfTC.sStatus=='erledigt')]            # open tickets
            
        ## consider open tickets
        if dfOpen.shape[0]>0:
            
            if bFixed:
                lMsg[-1] += ' - vermutlich durch Ticket ' + ' oder '.join(dfOpen.sTicketID) + ' erfasst'
                #lIssues.append(self.create_issue(sErrorMsg = sTmp, sAction = '', sLink = ''))
                issues.append(mfmon.create_issue(db,
                                           sErrorMsg = ', '.join(lMsg),
                                           sAction = 'beobachten', 
                                           sLink = sLink,
                                           sTool = sTool,
                                           bShort=False))

            else:
                #tS = max(tLastProd, tLastExtNotFix)
                # TODO 2019-2-22: noch herausfinden, seit wann die Daten wieder vorhanden sind, und hier entsprechend eintragen, Beginn vom Link entsprechend anpassen                 
                #if (tMin is pd.NaT):
                #    tS = tLastMon
                #else:
                #    tS = tMin
                #sMsg = 'Daten wieder vorhanden seit ' + tS.strfrmtime(sFormatDTOutput)                
                sMsg = 'Daten wieder vorhanden'
                sAction = 'Ticket ' + ', '.join(dfOpen.sTicketID) + ' schliessen'                    
                #sLink = create_link(sTool = sTool, time_start = tS - dt.timedelta(hours = 4), time_end = dt0 + dt.timedelta(hours = 2))
                sLink = mfmon.create_link(db, sTool = sTool, cols_gh = None, start_time = tStartLink, end_time = tEndLink)
                                           
                issues.append(mfmon.create_issue(db,
                                           #sErrorMsg = ', '.join(lMsg), 
                                           sErrorMsg = sMsg,
                                           sAction = sAction,
                                           sLink = sLink,
                                           sTool = sTool))
                  
        else:
            if bFixed:
                dfClosed = dfTC[dfTC.sStatus=='erledigt']
                # TODO 2019-3-1: nur Tickets betrachten, die noch nicht allzulange zurueckliegen (sonst ist es nicht mehr
                # wirklich ein NACHFOLGEticket)
                #dfClosed = dfTC[dfTC.sStatus=='erledigt' & dfTC.dtClosed-tMin<dt.timedelta(days=30)]
                sMsg = ', '.join(lMsg)                        

                if dfClosed.shape[0]==0:                        
                    sAction = 'Ticket anlegen'
                
                else:
                    dfClosed.sort_values(['sTicketID'], axis=0, ascending=False, inplace=True)
                    sTmp = ', '.join(dfClosed.head(3).sTicketID)
                    sMsg += ', schon früher aufgetreten (Tickets ' + sTmp + ')'
                    sAction = 'Nachfolgeticket für ' + dfClosed.sTicketID.max() + ' anlegen'
# TODO 2019-1-17: Email fuer Kunden erstellen mit den RICHTIGEN ("OFFIZIELLEN") EMAILVORLAGEN FUER DIE MAILS AN DIE KUNDEN   
                if bECUne:
                    mail_type = 'ECUne'
                else:
                    mail_type = 'missing_data'                    
                           
                issues.append(mfmon.create_issue(db,
                                           sErrorMsg = ', '.join(lMsg), 
                                           sAction = sAction,
                                           sLink = sLink,
                                           sTypeMail = mail_type,
                                           sTool = sTool))
                            
    except:
        
        issues.append(mfmon.create_issue(db,
                                   sErrorMsg = 'unbek. Fehler bei Check auf fix data', 
                                   sAction = 'manuell ansehen', 
                                   sLink = ''))
    
    
    #return issues
