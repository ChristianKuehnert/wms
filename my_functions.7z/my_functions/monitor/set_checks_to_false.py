# -*- coding: utf-8 -*-
"""
function to set the checks with the given keys to False

Created on Tue Mar 26 01:46:32 2019

@author: Christian Kuehnert
@last_modified: 2019-3-26

"""
def set_checks_to_false(checks, listKeys):
    ## change checks only when it is dict, this is in order that the check-functions can be used by command line too without thinking about checks-input-variable
    ## (which in this case can just be set to None or some other non-dictionary-type value)
    if isinstance(checks, dict):
        for k in listKeys:
            checks[k] = False


     