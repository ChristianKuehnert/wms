# -*- coding: utf-8 -*-
"""
function to check if measuring line are ok by classical method

Created on Tue Mar 26 02:35:41 2019

@author: Christian Kuehnert
@last_modified: 2019-5-29


example:
import numpy as np
import pandas as pd
import datetime as dt
import sys

sys.path.append(r'C:\Repositories\python\functions')        # path to modules  
import myFunctions_data as mfdata
import myFunctions_monitor as mfmon

db = 'cmrblba_bc_t_02758'
channels = [3,4,5]
start_time = dt.datetime(2018,12,2,4,0,0)
end_time = start_time + dt.timedelta(days=2)
dfRes, issues = mfmon.check_meas_line_classical(db, channels, start_time, end_time)

"""
import datetime as dt
import pandas as pd
import numpy as np
import data as mfdata
import monitor as mfmon

#from data import get_preferences
#from monitor import create_link, create_issue

#def check_meas_line_classical(db, channels, start_time, end_time, start_freq=150, end_freq=350, meas_len=16.384, power_min=None):
# TODO 2019-2-28: noch modifizierte Variante anlegen, die die Erkennung eines abweichenden Sensors verbessert
def check_meas_line_classical(db, channels, start_time, end_time, start_freq=150, end_freq=350, power_min=None):
	
    issues = []
    sTool = 'SE'
    sFormatDT = '%Y%m%d%H%M%S'
    
    ## first map channel numbers (0..5) to channel names ('e_101_edge' etc.)
    # TODO 2019-1-18: generisch machen!, now only first approach
    #dictMap_class = mapChannels(self.sDB, self.sPathData)
    #dictMap_output = {0: 'RBL1 Flap', 1: 'RBL2 Flap', 2: 'RBL3 Flap', 3: 'RBL1 Edge', 4: 'RBL2 Edge', 5: 'RBL3 Edge'}           # dict for names of channels in output
    map_channels = {3: 'e_101_edge', 4: 'e_102_edge', 5: 'e_103_edge', 0: 'e_101_flap', 1: 'e_102_flap', 2: 'e_103_flap'}
    map_channels_inv = {value: key for key, value in map_channels.items()}
	
    #get thresholds from preferences
    # TODO 2019-1-25: sind Sensitivities schon beruecksichtigt? Offsets auf jeden Fall noch nicht!
    try:            
        lFlap = [map_channels[key] for key in [0,1,2]]
        lEdge = [map_channels[key] for key in [3,4,5]]        
        lDirs = lFlap + lEdge

        ## thresholds for alarm levels for all channels
        dictTmp = mfdata.get_preferences(db)
        #dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapAlarmLevel').replace('_edge', 'EdgeAlarmLevel'): s for s in lDirs}
# TODO 2019-2-27: noch fuer beides (warning und alarm) machen und dann issue entsprechend anpassen
        dictPrefCols = {s.replace('e_', 'Sda').replace('_flap', 'FlapWarnLevel').replace('_edge', 'EdgeWarnLevel'): s for s in lDirs}
        dfSE_thres = pd.DataFrame.from_records([{key: pd.to_numeric(dictTmp[key], errors='coerce') for key in dictPrefCols.keys()}], coerce_float=True)
        dfSE_thres.rename(columns = dictPrefCols, inplace=True)

        ## get offsets
        dictPrefOS = {s.replace('e_', 'Sda').replace('_flap', 'FlapOffset').replace('_edge', 'EdgeOffset'): s for s in lDirs}
        dfOS = pd.DataFrame.from_records([{key: pd.to_numeric(dictTmp[key], errors='coerce') for key in dictPrefOS.keys()}], coerce_float=True)
        dfOS.rename(columns = dictPrefOS, inplace=True)
                
        sColNames = list(map_channels.values())
        sSelectChannels = ','.join(['SUM(se.' + s + ')' for s in sColNames])
        
        sChannels = {key: map_channels[key] for key in channels}

        

        sF1 = str(start_freq)
        sF2 = str(end_freq)
        sStartTime = start_time.strftime(sFormatDT)
        sEndTime = end_time.strftime(sFormatDT)
        
        # TODO 2019-2-27: evtl. gleich im SQL den Test nach Ueberschreiten der Warnschwelle machen und nur die kritischen Werte zurueckliefern, dann muss aber noch Test eingebaut
        # werden, ob ueberhaupt Daten fuer den betreffenden Zeitraum vorhanden sind (sonst Warnung o.ae. ausgeben)
#               if power_min:
#            sFilter = ' mc.power_mean>=' + str(power_min) + ' AND'
#        else:
#            sFilter = ''                        

#        sQuery = f"SELECT mc.create_time,mc.ba_id,mc.power_mean,{sSelectChannels}" + \
#                 "FROM ba_cycle_measurement_cycle mc STRAIGHT_JOIN sig_energies se ON (mc.ba_id = se.cycle_id) " + \
#                 "WHERE{sFilter} mc.create_time IS NOT NULL and mc.available_data>=2 AND se.cycle_id IS NOT NULL AND se.start_f>={sF1} AND se.start_f<= {sF2} " + \
#                 "AND mc.create_time>={sStartTime} AND mc.create_time<={sEndTime} " + \
#                 "GROUP BY se.cycle_id " + \
#                 "ORDER BY mc.create_time;"
        ## find out if necessary tables occur in database
        # TODO 2019-2-27: noch eleganter und sicherer machen!
        sQuery = 'SHOW TABLES'
        lT = mfdata.query_MySQL2(db, sQuery)
        if ('ba_cycle_sig_energies',) in lT:
            sTabSE = 'ba_cycle_sig_energies'
        else:
            sTabSE = 'sig_energies'                
        
        ## TODO 2019-2-27: Fall abfangen, dass dieselbe ID zu verschiedenen Zeiten vorkommt
        sQuery = f"SELECT mc.create_time,mc.ID,mc.power_mean,{sSelectChannels} " + \
                 f"FROM ba_cycle_measurement_cycle mc INNER JOIN {sTabSE} se ON (mc.ID = se.cycle_id and mc.create_time = se.create_time) " + \
                 f"WHERE mc.create_time IS NOT NULL and mc.available_data>=2 AND se.cycle_id IS NOT NULL AND se.start_f>={sF1} AND se.start_f<={sF2} " + \
                 f"AND mc.create_time>='{sStartTime}' AND mc.create_time<='{sEndTime}' " + \
                 "GROUP BY se.cycle_id " + \
                 "ORDER BY mc.create_time;"

        tmp = mfdata.query_MySQL2(db, sQuery, params=None)
        if len(tmp)==0:
            dfSE = pd.DataFrame()
        else:
            dfSE = pd.DataFrame(data=np.array(tmp), columns=['create_time', 'cycle_id', 'power_mean']+sColNames).infer_objects()        
            dfSE.dropna(axis=0, how='all', subset=list(map_channels.values()), inplace=True)
                            
        #now distinguish between systems that collect full (2Hz-wise) spectra and those that contain only sum from 150-350 Hz                                
        if dfSE.shape[0]==0:                
		
            dfCyc_cl = None
            issues.append(mfmon.create_issue(db,
                                       sErrorMsg = 'keine SE-Daten vorhanden', 
                                       sAction = 'manuell pruefen',
                                       sLink = mfmon.create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time), end_time = end_time),
                                       sTool = sTool))   
        else:                                    
				
            # if minimal value for power is given, remove the other values (this is done here and not e.g. in the sql-query
            # in order to easily check if there are se-values at all
            if power_min:
                dfSE = dfSE[dfSE.power_mean<power_min]
                        
            ## now compare with the thresholds    
            if dfSE.shape[0]==0:            
                dfCyc_cl = None
            
            else:
                
                lErr = []
                for lList in [lFlap, lEdge]:

                    # TODO 2019-1-17: hier ggf. Sensitivities beachten!
                    relSE = mfdata.get_relative_se(dfSE, lList)
                    #dOS = np.tile(dfOS.loc[:, lList].values, (relSE.shape[0],1))                # array of offsets
                    #relSE = relSE + dOS                                        
                    #dThres = np.tile(dfSE_thres.loc[:, lList].values, (relSE.shape[0],1))
                    dThres = np.tile(dfSE_thres.loc[:, lList].values - dfOS.loc[:, lList].values, (relSE.shape[0],1))           # offsets und thresholds gleich zusammengefasst

                    dfTmp = pd.DataFrame((relSE > dThres), columns=lList)		
                    lErr.append(dfTmp)
        				
                dfErr = pd.concat(lErr, axis=1).loc[:, list(sChannels.values())]                ## combine results and take only desired channels
                bTmp = dfErr.any(axis=1)
                dfCyc_cl = pd.concat((dfSE[bTmp].loc[:,['create_time', 'cycle_id']], dfErr[bTmp].set_index(dfSE[bTmp].index)), axis=1)
        									   
                dfCyc_cl.rename(columns = map_channels_inv, inplace=True)
                dfCyc_cl = pd.melt(dfCyc_cl, id_vars=['create_time', 'cycle_id'], value_vars = list(sChannels.keys()), var_name = 'channel', value_name = 'fail')
                #dfCyc_cl = dfCyc_cl[dfCyc_cl.fail]
                dfCyc_cl = dfCyc_cl[dfCyc_cl.fail].drop(columns='fail')
                # reformat 
                # find cycles (create_time, cycle_id) of the times of the errors
                #dfCyc_cl = dfCyc_cl.assign(origin = pd.Series(np.tile('classic', (dfCyc_cl.shape[0],))).values)           # add column with origin (classical method or ts method)				
    
    except:
        dfCyc_cl = None
        issues.append(mfmon.create_issue(db,
                                   sErrorMsg='unbek. Fehler bei Check auf Sensordefekte mittels ts-Methode',
                                   sAction='manuell ansehen',
                                   sLink=mfmon.create_link(db, sTool=sTool, start_time=max(end_time - dt.timedelta(days=30), start_time)-dt.timedelta(days=1), end_time = end_time+dt.timedelta(hours=4))))

    return dfCyc_cl, issues

