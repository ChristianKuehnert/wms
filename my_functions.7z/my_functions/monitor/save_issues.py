# -*- coding: utf-8 -*-
"""

@author: christian
"""



"""

function to save issues in .csv-file

Created on Tue Mar 26 02:57:42 2019

@author: Christian Kuehnert
@last_modified: 2020-1-24

"""

import pandas as pd

def save_issues(lIssues, sFN):
    
    ## save as .csv
    if len(lIssues)>0:
        #print('no issues found')
        
    #else:
        dfIssues = pd.DataFrame([vars(s) for s in lIssues])                                 # cast issues to a dataframe
        dfIssues.sort_values(axis=0, by=['farm','wt'], inplace=True)                        # sort issues by farm, wt and error message
        
        dfIssues.to_csv(sFN, 
                        sep=';', 
                        index=False, 
                        columns=['farm', 'wt', 'db', 'revision', 
                                 'contract_status', 
                                 'error_msg', 'action', 'link', 'link_mail'], 
                        header=['Windpark','WEA','DB', 'Version', 
                                'Auftragsstatus', 
                                'Fehler','Vorschlag', 'Link', 'Kunden-Email'], 
                        encoding='cp1252')
    
    
  
