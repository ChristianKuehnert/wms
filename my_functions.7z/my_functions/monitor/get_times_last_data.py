# -*- coding: utf-8 -*-     
"""
function to find the last datetime with non-fix data in the given table in the
given database, after this date either no new data were stored or they are fix

Created on Tue Mar 26 01:54:46 2019

@author: Christian Kuehnert
@modified: 2019-3-26

Parameters:
-----------

    db:              database name
    table:           table name
    str_end_time:    end time as string
    col_time:        name of the column containing the time, must not be None
    cols_to_test:    names of the columns that should be analysed for fixed or
                     missing data


Results:
--------

bDataFix:
tLastData:
tLastDataNotFix:  
dfTimes:     DataFrame with columns 1) name, containing the names of the 
             columns (i.e. sColsToTest), 2) bDataFix: boolean flag indicating 
             if the data are fix/missing for this column, 3) tLastData: 
sMsg:        result/error message

"""

#import datetime as dt
import data as mfdata  


#def getTimesLastNonFixData(db, sTable, sTimeStart=None, sTimeEnd=None, 
# col_time = 'create_time', sColsToTest = None, bExclNaN=True): 
def get_times_last_data(db, table, str_end_time=None, col_time='create_time', 
                        cols_to_test=None): 
    

    last_times_not_ok = {}   #None
    
    if len(cols_to_test)>0:

        if (str_end_time is None):
            #str_end_time = dt.datetime.now().strftime('%Y%m%d%H%M%S')
#            cTmp = ["select '" + col + "',max(t2." + col_time + ") " + 
#                    "from " + table + " t2 " + 
#                    "where not(t2." + col_time + " is NULL) and not(t2." + col 
#                                + " is NULL) and (t2." + col + "<>" + 
#                        "(select t." + col + " " + 
#                        "from " + table + " t " + 
#                        "where t." + col_time + "=(" + 
#                            "select max(tm." + col_time + ") " + 
#                            "from " + table + " tm " + 
#                            "where not(tm." + col_time + " is NULL) and not(tm." + col + " is NULL)) limit 1))" for col in cols_to_test]                                    

            cTmp = [(f"(select '{col}', max({col_time}) from {table} group by "
                    f"{col} order by max({col_time}) desc limit 1,1)") 
                    for col in cols_to_test]
            
            
        else:
            cTmp = ["select '" + col + "',max(t2." + col_time + ") " + 
                    "from " + table + " t2 " + 
                    "where not(t2." + col_time + " is NULL) and not(t2." + col + " is NULL) and (t2." + col_time + "<='" + str_end_time + "') and (t2." + col + "<>" + 
                        "(select t." + col + " " + 
                        "from " + table + " t " + 
                        "where t." + col_time + "=(" + 
                            "select max(tm." + col_time + ") " + 
                            "from " + table + " tm " + 
                            "where not(tm." + col_time + " is NULL) and not(tm." + col + " is NULL) and (tm." + col_time + "<='" + str_end_time + "')) limit 1))" for col in cols_to_test]

            
        sQuery = ' union '.join(cTmp) + ';'
        last_times_not_ok = dict(mfdata.query_MySQL2(db, sQuery))
            
    return(last_times_not_ok)
          
        
