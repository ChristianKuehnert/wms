"""
functions etc. for mode detection

Funktionen und anderes zur Sondermode-Detektion

@modified: 2020-5-26
"""

import pandas as pd
import numpy as np
#import matplotlib.pyplot as plt
#from sklearn.model_selection import KFold
from sklearn.preprocessing import PolynomialFeatures
#from sklearn import linear_model
from base_model import base_model










"""
function to cluster the aoa-values 

parameters:
-----------
    - df:         pd.DataFrame, must contain at least columns for aoa and wind
    - col_aoa:    str, column name for aoa in df
    - col_wind:   str, column name for wind in d
    - wind_max:   float, max. wind speed that should be considered
    
    
@modified: 2020-5-26

"""
def cluster_aoa(df, wind_max = 10.5, col_aoa = 'aoa', col_wind = 'wind_mean'):
    
    # aoa values for wind speed below given threshold
    aoa = df[df.loc[:, col_wind]<=wind_max].loc[:, col_aoa].values
    
    # cluster aoa's
    cluster_algorithm = cluster.KMeans(n_clusters=n_clusters, n_init=2)
    classes = cluster_algorithm.fit_predict(aoa)
    cluster_center_indices = cluster_algorithm.cluster_centers_indices_    
    
    # calculate statistical quantities
    



    # assign the rows of df to the clusters
    
    # return clusters, statistical quantities and assignment of the rows of df
    # to the clusters (i.e. one column called "mode" that contains the mode)
    return(res)
    
    





"""
function to display the modi in the data by varying the background color

parameters:
-----------
    - df:       pd.DataFrame, must contain at least one 








class phyModel(base_model):

    def __init__(self, raw_df, target = 'power_mean', 
                 features=['wind_mean', 'pitch_mean', 'temperature_mean', 
                           'omega_mean', 'pitch_sigma', 'azimuth_sigma'],
                model_idx = 4):
        
        base_model.__init__(self, raw_df, target = target, features = features)
                            
        #self.poly_degree = poly_degree
        self.model = PolynomialFeatures(degree=1)
        self.model_idx = model_idx
        #self.model = phy_mod
        self.legend_str = f'physical model no. {model_idx}'







    ## function to prepare the X and y arrays of the physical model
    def fit(self):

        #X = self.model.fit_transform(create_vars(self.raw_df))
        #print(X.shape)
        X, _s = create_vars(self.raw_df, self.model_idx)
        y = self.raw_df[self.target]
        
        self.reg.fit(X, y)
        return(self.reg.score(X, y))
        
        
        
        
        
        
    def pred(self, df):
        tmp, _s = create_vars(df.loc[:, self.features], self.model_idx)
        #poly_fit = self.model.fit_transform(tmp)
        
        # print(type(self.reg.predict(poly_fit)))
        # pwr_pred = pd.Series(self.reg.predict(poly_fit), index=df.index)
        # pwr_pred.columns = ["power_pred"]

        #return self.reg.predict(poly_fit)
        return self.reg.predict(tmp)




    def score(self, df):
        X, _s = create_vars(df.loc[:, self.features], self.model_idx)
        y = df.loc[:, self.target]
        return(self.reg.score(X, y))



