# -*- coding: utf-8 -*-
"""
Created on Fri Jun 28 08:52:05 2019

@author: w012028
"""

import re
import os
import sys
import gc
import pandas as pd
import numpy as np
from datetime import datetime as dt
import matplotlib.pyplot as plt


try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle

#from dateutil.relativedelta import *
from dateutil.relativedelta import relativedelta
from dateutil import parser
#from textwrap import wrap
from textwrap import fill

#sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian')
#from wms.dbs import weadbs

#sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions')        # path to modules
import data as mfdata
from .data import filter_data
from .plot.myFunctions_plot import provideColors





#import pathlib
#
#import re
#
#
#import pandas as pd
#import numpy as np
#import seaborn as sns
#import statsmodels.formula.api as smf
#            
#from sklearn import datasets, linear_model
#
#import datetime as dt
#
#
#import monitor as mfmon
#from plot import myFunctions_plot as mfplot
#from plot.myFunctions_plot import myplot_fast


 
# TODO 2019-6-27: erstmal auskommentiert, da hierfuer update/Installation in conda noetig ist, was aber ohne admin-Rechte nicht geht
#import model

#sepath = pathlib.Path('D:') / 'schraeganstroemung' / 'energies'
#path_data = r'C:\Users\w012028\Documents\CK\data\data__aerodynic_imbalance'
#path_img = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht\material'





### function to collect ext data for the given db
## TODO 2019-7-19: gleich Fkt. ist auch in stick_slip_effect.py, von dort und
## von hier noch entfernen und unter data speichern und von dort importieren
#def store_cdef_data(db, path_data, table = 'externals', columns = None):
#
#    fn_pkl = f'{path_data}\\{db}_{table}.pkl'
#
#    try:
#        if not os.path.isfile(fn_pkl):
#            #df_ext = mfdata.get_data_from_db(db, 'ba_cycle_externals',
#            #                                 where_clause=None, columns=None)
#            print(f'{db}: table {table} -> {fn_pkl}')
#
#            period = ('1970-01', '2020-01')
#            df_ext = weadbs.cdef_query(db, limit=[], cycle=table,
#                                        columns=columns, debug=False,
#                                        where={'create_time': period})
#
#            df_ext.to_pickle(fn_pkl)               # pickle result
#
#        ok = True
#
#
#    except:
#        print(f'{db}:   error retrieving/saving data from {table}')
#        ok = False
#
#    return(ok, fn_pkl)






"""
function to get all db-names for given farm(s)

-> eigentlich obsolet, nur drin gelassen, falls es doch irgendwann mal
   gebraucht werden sollte

@author: Christian Kuehnert
@modified: 2019-8-13
"""
def get_dbs(farms):
    
    sql = ("select Datenbankname from VIEW_Windkraftanlagen where not "
           "((Datenbankname is NULL) or (Datenbankname = ''))")
    
    if farms is None:
        sql = sql+";"
        
    elif isinstance(farms, str):
        sql = sql+f" and Windpark_WEA#Windparkname='{farms}';"
    
    else:
        sql = sql+f" and Windpark_WEA#Windparkname in ('{'',''.join(farms)}');"
        
    df = mfdata.query_pit(sql)
    return(df.Datenbankname.values)
       



"""
function to calculate the relative signal energy

@author: Christian Kuehnert
@modified: 2019-7-21
"""
def calc_se_aeroImb(df_se, band):
    
    df_res = df_se.copy()
    for sdir in ['edge', 'flap']:
        cols = [f'e_10{i}_{sdir}' for i in range(1,4)]      
        for c in cols:
            c_tmp = list(set(cols)-{c})
            m = df_se.loc[:, c_tmp].mean(axis=1)
            v = df_se.loc[:, cols] / m
            df_res.loc[:, c] = v

    return(df_res)









"""
simple plotting function for fast plots (mainly interactive)

@author: Christian Kuehnert
@modified: 2019-8-2

"""
def myplot_aeroImb(dX, s_title = None, legend = None, y_lim = None):
                 
    iAxisLabelSize = 16
    iLegendSize = 16

    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
           
    if y_lim:
        plt.ylim(y_lim)

    
    ## dX must be list of tuples (x, y, dict_plot_layout)
    for (x, y, dict_plot) in dX:
        plt.plot(x, y, **dict_plot)

    if legend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        #llegend = [str(i) for i in range(iN)]
        plt.legend(legend, fontsize=iLegendSize)


    if s_title:
        iFontSizeTitle = 22
        title = ax.set_title(fill(s_title, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    
    plt.show()
    #plt.close(fh)
                        
      
    
    
    
    
    
"""
function to load the data from the multiple hd5-files and combine them and 
-if this option is selected- adjust the signal energy

Properties:
-----------
    - path_data_multiple:       str, folder with split hd5-files
    - db:                       str, name of the database
    - channels:                 list of strings (channel names like 
                                'e_101_edge' etc.) - names of the channels to
                                retrieve the data for
    - cols_cdef:                list of strings, the names of the requested 
                                cdef-columns
    - band:                     tuple of floats, the integrated signal energy 
                                for the given band is returned
    - filters:                  dictionary {cdef-column name: (upper limit,
                                lower limit)}, filter criteria
#    - limit_se:                 tuple of floats, if given, the total se will
#                                be filtered for that criterion
    - b_adjust_se:              boolean, if True the se for older versions of
                                the measuring programm will be adjusted (i.e. 
                                divided by 5)
    - how:                      str, if None no na-s will be dropped, otherwise
                                the rows with na-s will be dropped for 'all' or
                                'any' occurring na
                                

@author: Christian Kuehnert
@modified: 2019-11-28

"""
def load_data_multiple_hd5files(path_data_multiple, db, channels, cols_cdef, 
                                periods=[], band = [150,350], filters = {}, 
                                limit_se = None, 
                                b_adjust_se = True, 
                                how = 'any'):
    
    bw = band[1]-band[0]
    list_df = list()
    list_problem_files = list()
            
    if (periods is None):
        periods = list()

    if (filters is None):
        filters = dict()

    # get all hd5-se-files for that database
    all_files = os.listdir(path_data_multiple)
    spat = f'(({db}_se\.hd5)$|({db}_se.+\.hd5)$)'
    files_db = [s for s in all_files if re.search(spat, s)]


    files_se = dict()
#    all_dates = list() 
#    all_rel_pers = list()
    for fn in files_db:
        [sstart, send] = fn.replace(f'{db}_se_', '').replace('.hd5', '').split('_')
        start_fn, end_fn = dt.strptime(sstart, "%Y%m"), dt.strptime(send, "%Y%m")
        rel_pers = list()
        for per in periods:
            if overlap((start_fn, end_fn), per):
                rel_pers.append(per)
#                all_rel_pers.append(per)
        files_se.update({fn: rel_pers})
#        all_dates.append(start_fn)
#        all_dates.append(end_fn)
                
    ## loop through files that contain (parts of) the data
    for fn, relevant_periods in files_se.items():
        fn_hd5 = f'{path_data_multiple}\\{fn}'
        
        try:    
            cls_sed = weadbs.SEData.from_hdf(fn_hd5)
            df_cdef = cls_sed[1].loc[:, cols_cdef]            
            # drop na if requested
            if how:
                df_cdef.dropna(how=how, inplace=True)

            # filter by periods
            # TODO 2020-8-7: eleganter machen!
            for per in relevant_periods:
                if not(per[0] is None):
                    df_cdef = df_cdef[df_cdef.index>=per[0]]
                if not(per[1] is None):
                    df_cdef = df_cdef[df_cdef.index<=per[1]]
                    
            # filter data
            #if len(filters)>0:
            #    
            #    filters_cdef = {k: v for k, v in filters.items() if k in 
            #                    df_cdef.columns}
            #    
            #    btmp = pd.concat([df_cdef.loc[:, k].between(v[0], v[1]) for k,v in 
            #                      filters_cdef.items()], axis=1).all(axis=1)
            #    df_cdef = df_cdef[btmp]
            df_cdef, _s = filter_data(df_cdef, filters)
            
            if df_cdef.shape[0]>0:
                            
                df_se = cls_sed.agg_freq(band).se.dropna() / bw
                # filter for limit se
                if limit_se:
                    df_tmp = cls_sed.agg_freq([0,500]).se / 498
                    btmp = df_tmp.loc[:, channels].between(limit_se[0]/498, limit_se[1]/498).any(axis=1)
                    df_se = df_se[btmp]
                    
                df_se.columns = df_se.columns.levels[0]

                # filter se-data
                df_se, _s = filter_data(df_se, filters)                # append to list of df for each file
                
                list_df.append(pd.merge(df_cdef.loc[:, cols_cdef], df_se.loc[:, channels], 
                                        on='create_time'))    #  'j' for 'joined'
                
        except:
            #print(f'Problem beim Einlesen von {fn_hd5}')
            list_problem_files.append(fn_hd5)  # koennte ggf. noch ausgegeben werden, erstmal weggelassen


    if len(list_problem_files)>0:
        print('Problem beim Einlesen von ' + ', '.join(list_problem_files))
        
        
    ## combine all data from the files with parts of the data
    if len(list_df)>0:
        df = pd.concat(list_df)

        if b_adjust_se:
            df = adjust_se(db, df)

    else:
        df = pd.DataFrame(columns = cols_cdef + channels)
        
    del list_df                
    gc.collect()
    
    
    #return(df, list_problem_files)            
    return(df)         
   
    
    
    
    
#"""
#function to load the data from the multiple hd5-files and combine them and 
#-if this option is selected- adjust the signal energy
#
#Properties:
#-----------
#    - path_data_multiple:       str, folder with split hd5-files
#    - db:                       str, name of the database
#    - channels:                 list of strings (channel names like 
#                                'e_101_edge' etc.) - names of the channels to
#                                retrieve the data for
#    - cols_cdef:                list of strings, the names of the requested 
#                                cdef-columns
#    - band:                     tuple of floats, the integrated signal energy 
#                                for the given band is returned
#    - filters:                  dictionary {cdef-column name: (upper limit,
#                                lower limit)}, filter criteria
#    - limit_se:                 tuple of floats, if given, the total se will
#                                be filtered for that criterion
#    - b_adjust_se:              boolean, if True the se for older versions of
#                                the measuring programm will be adjusted (i.e. 
#                                divided by 5)
#    - how:                      str, if None no na-s will be dropped, otherwise
#                                the rows with na-s will be dropped for 'all' or
#                                'any' occurring na
#                                
#
#@author: Christian Kuehnert
#@modified: 2020-1-2
#    
#
#
#TODO 2020-1-2: nur, falls sich die hd5-Umstellung noch weiter verzoegert:
#       - hier schon files vorauswaehlen, die in die period passen
#       - in weadbs.SEData.from_hdf noch Moeglichkeit einbauen, nur ausgewaehlte channels zurueckzugeben
#       - mit Funktion load_data_multiple_hd5files kombinieren (dort z.B. geeignete Funktion zur 
#         Berechnung der SE uebergeben, wenn diese None ist, dann werden die Originalspektren ausgegeben o.ae.)
#
#"""
#def load_data_multiple_hd5files_spec(path_data_multiple, db, channels, cols_cdef, 
#                                     period=None, filters = {}):
#    
#    list_problem_files = []
#            
#    all_files = os.listdir(path_data_multiple)
#                
#    spat = f'(({db}_se\.hd5)$|({db}_se.+\.hd5)$)'
#    files_se = [s for s in all_files if re.search(spat, s)]
#
#    list_df = []
#    
#        
#    ## loop through files that contain (parts of) the data
#    for fn in files_se:
#        fn_hd5 = f'{path_data_multiple}\\{fn}'
#        
#        try:    
#            ## TODO 2019-11-26: eleganter machen
#            if (period is None):
#                cls_sed = weadbs.SEData.from_hdf(fn_hd5)
#            else:
#                if (period == (None, None)):
#                    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
#                else:
#                    # TODO 2019-9-19: Zeitauswahl vorverlegen vor die multiple files und nur die auswaehlen, die im Zeitraum liegen!
#                    cls_sed = weadbs.SEData.from_hdf(fn_hd5, 
#                                                     where={'create_time': 
#                                                         period})
#                
#            df_cdef = cls_sed[1].loc[:, cols_cdef]
#                        
#            # filter data
#            if len(filters)>0:
#                btmp = pd.concat([df_cdef.loc[:, k].between(v[0], v[1]) for 
#                                  k,v in filters.items()], axis=1).all(axis=1)
#                df_cdef = df_cdef[btmp]
#            
#            if df_cdef.shape[0]>0:
#                            
#                df_se = cls_sed.se.dropna()
#                #df_se.columns = df_se.columns.levels[0]
#
#                # append to list of df for each file
#                list_df.append(pd.merge(df_se, df_cdef.loc[:, cols_cdef], 
#                                        left_index=True, right_index=True))    #  'j' for 'joined'
#                
#        except:
#            #print(f'Problem beim Einlesen von {fn_hd5}')
#            list_problem_files.append(fn_hd5)  # koennte ggf. noch ausgegeben werden, erstmal weggelassen
#
#
#    if len(list_problem_files)>0:
#        print('Problem beim Einlesen von ' + ', '.join(list_problem_files))
#        
#        
#    ## combine all data from the files with parts of the data
#    if len(list_df)>0:
#        df = pd.concat(list_df)
#
#    else:
#        df = pd.DataFrame(columns = cols_cdef + channels)
#        
#    del list_df                
#    gc.collect()
#    
#    
#    #return(df, list_problem_files)            
#    return(df)            
#   
    
    
    
    
    
   
"""
function to load the data from the multiple hd5-files and combine them 


except for the few lines with the code for calculating the scaled se this
function is identical to the function 'load_data_multiple_hd5files'
It is just a copy and no effort of combining them or so is made, because
hopefulle the hd5-data will be available, so that then the auxiliary functions
for data collection and loading will be outdated anyway


Properties:
-----------
    - path_data_multiple:       str, folder with split hd5-files
    - db:                       str, name of the database
    - channels:                 list of strings (channel names like 
                                'e_101_edge' etc.) - names of the channels to
                                retrieve the data for
    - cols_cdef:                list of strings, the names of the requested 
                                cdef-columns
    - band:                     tuple of floats, the integrated signal energy 
                                for the given band is returned
    - filters:                  dictionary {cdef-column name: (upper limit,
                                lower limit)}, filter criteria
    - limit_se:                 tuple of floats, if given, the total se will
                                be filtered for that criterion
    - b_adjust_se:              boolean, if True the se for older versions of
                                the measuring programm will be adjusted (i.e. 
                                divided by 5)
    - how:                      str, if None no na-s will be dropped, otherwise
                                the rows with na-s will be dropped for 'all' or
                                'any' occurring na
                                

@author: Christian Kuehnert
@modified: 2020-1-20

"""
def load_se(path_data_multiple, db, channels, cols_cdef, 
            period=None, band = [26,35], filters = {}, how = 'any',
            show_msgs = False):
    
    bw = band[1]-band[0]

    list_problem_files = []
            
    all_files = os.listdir(path_data_multiple)
                
    spat = f'(({db}_se\.hd5)$|({db}_se.+\.hd5)$)'
    files_se = [s for s in all_files if re.search(spat, s)]

    list_df = []
    
    set_cdef = set(cols_cdef).union(filters.keys())  # set of list cols_cdef for faster intersection
    
    ## loop through files that contain (parts of) the data
    for fn in files_se:
        fn_hd5 = f'{path_data_multiple}\\{fn}'
        
        try:    
            ## TODO 2019-11-26: eleganter machen
            if (period is None):
                cls_sed = weadbs.SEData.from_hdf(fn_hd5)
            else:
                if (period == (None, None)):
                    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
                else:
                    # TODO 2019-9-19: Zeitauswahl vorverlegen vor die multiple files und nur die auswaehlen, die im Zeitraum liegen!
                    cls_sed = weadbs.SEData.from_hdf(fn_hd5, where={'create_time': period})
            
            df_tmp = cls_sed.st
            
            if df_tmp.shape[0]>0:
                    
                df_cdef = df_tmp.loc[:, set_cdef.intersection(df_tmp.columns)]
                
                # drop na if requested
                if how:
                    df_cdef.dropna(how=how, inplace=True)
                                
                # filter data
                if len(filters)>0:
                    btmp = pd.concat([df_cdef.loc[:, k].between(v[0], v[1]) for 
                                      k,v in filters.items()], axis=1).all(
                                                                        axis=1)
                    df_cdef = df_cdef[btmp]
            
                if df_cdef.shape[0]>0:
    
                    #df_se = cls_sed.agg_freq(band).se.dropna() / bw
                    #df_tmp = cls_sed.agg_freq([0,500]).se / 498
                   
                    df_se = cls_sed.agg_freq(band).se.dropna() / bw
                        
                    df_se.columns = df_se.columns.levels[0]
    
                    # append to list of df for each file
                    list_df.append(pd.merge(df_cdef.loc[:, cols_cdef], 
                                            df_se.loc[:, channels], 
                                            on='create_time'))
                
        except:
            #print(f'Problem beim Einlesen von {fn_hd5}')
            list_problem_files.append(fn_hd5)  # koennte ggf. noch ausgegeben werden, erstmal weggelassen


    if show_msgs & (len(list_problem_files)>0):
        print('Problem beim Einlesen von ' + ', '.join(list_problem_files))
        
        
    ## combine all data from the files with parts of the data
    if len(list_df)>0:
        df = pd.concat(list_df)

    else:
        df = pd.DataFrame(columns = cols_cdef + channels)
        
    del list_df                
    gc.collect()
    
    
    #return(df, list_problem_files)            
    return(df)            
   
   
    
   
"""
function to load the data from the multiple hd5-files, combine them and 
calculate the scaled signal energy (SE(band)/SE_total)

except for the few lines with the code for calculating the scaled se this
function is identical to the function 'load_data_multiple_hd5files'
It is just a copy and no effort of combining them or so is made, because
hopefulle the hd5-data will be available, so that then the auxiliary functions
for data collection and loading will be outdated anyway


Properties:
-----------
    - path_data_multiple:       str, folder with split hd5-files
    - db:                       str, name of the database
    - channels:                 list of strings (channel names like 
                                'e_101_edge' etc.) - names of the channels to
                                retrieve the data for
    - cols_cdef:                list of strings, the names of the requested 
                                cdef-columns
    - band:                     tuple of floats, the integrated signal energy 
                                for the given band is returned
    - band_tot:                 tuple of floats, the integrated signal energy 
                                for the given band is used for normalization
    - filters:                  dictionary {cdef-column name: (upper limit,
                                lower limit)}, filter criteria
    - limit_se:                 tuple of floats, if given, the total se will
                                be filtered for that criterion
    - b_adjust_se:              boolean, if True the se for older versions of
                                the measuring programm will be adjusted (i.e. 
                                divided by 5)
    - how:                      str, if None no na-s will be dropped, otherwise
                                the rows with na-s will be dropped for 'all' or
                                'any' occurring na
                                

@author: Christian Kuehnert
@modified: 2020-1-21

"""
def load_scaled_se(path_data_multiple, db, channels, cols_cdef, 
                   period=None, band = [26,35], band_tot = [0,500], 
                   filters = {}, how = 'any',
                   show_msgs = False):
    
    
    list_problem_files = []
            
    all_files = os.listdir(path_data_multiple)
                
    spat = f'(({db}_se\.hd5)$|({db}_se.+\.hd5)$)'
    files_se = [s for s in all_files if re.search(spat, s)]

    list_df = []
    
    set_cdef = set(cols_cdef).union(filters.keys())  # set of list cols_cdef for faster intersection
    
    ## loop through files that contain (parts of) the data
    for fn in files_se:
        fn_hd5 = f'{path_data_multiple}\\{fn}'
        
        try:    
            ## TODO 2019-11-26: eleganter machen
            if (period is None):
                cls_sed = weadbs.SEData.from_hdf(fn_hd5)
            else:
                if (period == (None, None)):
                    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
                else:
                    # TODO 2019-9-19: Zeitauswahl vorverlegen vor die multiple files und nur die auswaehlen, die im Zeitraum liegen!
                    cls_sed = weadbs.SEData.from_hdf(fn_hd5, where={'create_time': period})
            
            df_tmp = cls_sed.st
            
            if df_tmp.shape[0]>0:
                    
                df_cdef = df_tmp.loc[:, set_cdef.intersection(df_tmp.columns)]
                
                # drop na if requested
                if how:
                    df_cdef.dropna(how=how, inplace=True)
                                
                # filter data
                if len(filters)>0:
                    btmp = pd.concat([df_cdef.loc[:, k].between(v[0], v[1]) for 
                                      k,v in filters.items()], axis=1).all(
                                                                        axis=1)
                    df_cdef = df_cdef[btmp]
            
                if df_cdef.shape[0]>0:
    
                    #df_se = cls_sed.agg_freq(band).se.dropna() / bw
                    #df_tmp = cls_sed.agg_freq([0,500]).se / 498
                   
                    df_band = cls_sed.agg_freq(band).se.dropna()
                    df_tot = cls_sed.agg_freq(band_tot).se
                        
                    df_band.columns = df_band.columns.levels[0]
                    df_tot.columns = df_tot.columns.levels[0]
    
                    df_se = df_band/df_tot
    
                    # append to list of df for each file
                    list_df.append(pd.merge(df_cdef.loc[:, cols_cdef], 
                                            df_se.loc[:, channels], 
                                            on='create_time'))
                
        except:
            #print(f'Problem beim Einlesen von {fn_hd5}')
            list_problem_files.append(fn_hd5)  # koennte ggf. noch ausgegeben werden, erstmal weggelassen


    if show_msgs & (len(list_problem_files)>0):
        print('Problem beim Einlesen von ' + ', '.join(list_problem_files))
        
        
    ## combine all data from the files with parts of the data
    if len(list_df)>0:
        df = pd.concat(list_df)

    else:
        df = pd.DataFrame(columns = cols_cdef + channels)
        
    del list_df                
    gc.collect()
    
    
    #return(df, list_problem_files)            
    return(df)            
   
    
    
    
"""
function to load the data from the multiple hd5-files and combine them and 
-if this option is selected- adjust the signal energy

TODO 2019-8-21: falls die Fkt. weiter verwendet wird, dann den Filter nach power
noch generischer machen; vmtl. werden aber eher die .hd5-Files verfuegbar sein


@author: Christian Kuehnert
@modified: 2019-8-21

"""
def load_data_multiple_hd5files_old(path_data_multiple, db, channels, power, 
                                band = [54, 66], b_adjust_se = True, how = 'any'):
    
    bw = band[1]-band[0]
    list_problem_files = []
    
    cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                 'wind_mean', 'omega_sigma', 'power_sigma', 
                 'pitch_sigma', 'cyc_status_eval']
        
    all_files = os.listdir(path_data_multiple)
            
    
    spat = f'(({db}_se\.hd5)$|({db}_se.+\.hd5)$)'
    files_se = [s for s in all_files if re.search(spat, s)]

    list_df = []
    
    ## loop through files that contain (parts of) the data
    for fn in files_se:
        fn_hd5 = f'{path_data_multiple}\\{fn}'
        
        try:
            
            cls_sed = weadbs.SEData.from_hdf(fn_hd5)

            df_cdef = cls_sed[1].loc[:, cols_cdef].dropna(how=how)        
            df_cdef = df_cdef[(df_cdef.power_mean >= power[0]) 
                            & (df_cdef.power_mean <= power[1])]
                            #& (df_cdef.cyc_status_eval <= 14500)]

            if df_cdef.shape[0]>0:
                df_se = cls_sed.agg_freq(band).se.dropna() / bw
                df_se.columns = df_se.columns.levels[0]

                # append to list of df for each file
                list_df.append(pd.merge(df_cdef.loc[:, cols_cdef], df_se.loc[:, channels], 
                                        on='create_time'))    #  'j' for 'joined'
                
        except:
            #print(f'Problem beim Einlesen von {fn_hd5}')
            list_problem_files.append(fn_hd5)  # koennte ggf. noch ausgegeben werden, erstmal weggelassen
        
    ## combine all data from the files with parts of the data
    if len(list_df)>0:
        df = pd.concat(list_df)

        if b_adjust_se:
            df = adjust_se(db, df)

    else:
        df = pd.DataFrame(columns = cols_cdef + channels)
        
    del list_df                
    gc.collect()
    
    
    #return(df, list_problem_files)            
    return(df)            
   
    
    
    




"""
function to check if the interval_to_check (of times) is overlapping with the 
interval (of times)
Note: if at least one of the intervals contains a None the return will be True

@modified: 2020-8-6
"""
def overlap(interval_to_check, interval):
    
    (start, end) = interval_to_check
    (s,e) = interval

    if None in [start, end, s, e]:
        return(True)
        
    else:
        return(not((e<start) | (end<s)))
    


"""
function to check if the interval_to_check is overlapping with at least one
of the interval in intervals

@modified: 2020-8-6
"""
def overlap_multiple(interval_to_check, intervals):
    bOL = False
    for interval in intervals:
        bOL = bOL | overlap(interval_to_check, interval)

    return(bOL)
    
    


    
#"""
#function to collect the data and store them in (split) hd5-files
#
#@author: Christian Kuehnert
#@modified: 2019-9-19
#
#"""
#def collect_hd5_data(path_data_multiple, db, period = (None, None)):
#       
#    ## check for which turbines hd5-files already exist and exclude them, it is
#    ## assumed that if there exist at least one file the data for this wtg are
#    ## already collected
#    all_files = os.listdir(path_data_multiple)
#               
#    months = range(1, 12, 2)
#                
#    (start_date_min, end_date_max) = period
#    
#    if end_date_max is None:
#        end_date_max = dt.datetime.now()
#
#    if start_date_min is None:
#
#        # first try simple version, if this fails then the more advanced which
#        # takes much longer
#        ## TODO 2019-10-16: eleganter machen
#        try:
#            
#            sql = ("select min(tmp.dct) "
#                   "from ("
#                       "select distinct(bas.create_time) as dct "
#                       "from ba_cycle_sig_energies bas "
#                       "order by bas.create_time "
#                       "limit 5) tmp "
#                   "where substring_index(tmp.dct, 1, 2)>'19';")
#            
#            start_date_min = mfdata.query_MySQL2(db, sql)[0][0]
#            bOk = isinstance(start_date_min, dt.datetime)
#        except:
#            bOk = True
#            
#        if not bOk:
#            print("can't get start date generically, use enddate minus 1 year")                        
#            start_date_min = end_date_max - relativedelta(months=12)
#
#    
#    years = range(start_date_min.year, end_date_max.year+1, 1)
#    
#    start_dates = ((m, y) for m in months for y in years)
#    for (month, year) in start_dates:
#            
#        start_date = dt.datetime(year, month,1,0,0,0)
#        end_date = start_date + relativedelta(months=+2)
#        
#        if overlap_multiple((start_date, end_date), periods):
#        
#        #if (start_date <=end_date_max) & (end_date >= start_date_min):
#                    
#            fn = f'{db}_se_{start_date.strftime("%Y%m")}_{end_date.strftime("%Y%m")}.hd5'                
#            if not(fn in all_files):
#
#                fn_hd5 = f'{path_data_multiple}\\{fn}'
#                                    
#                try:
#                    # TODO 2019-10-16: ganze Funktion streamlinen!
#                    if False:
#                        if isinstance(start_date, dt.datetime):
#                            start_date = np.float64(start_date.timestamp())
#    
#                        if isinstance(end_date, dt.datetime):
#                            end_date = np.float64(end_date.timestamp())
#                        
#                    weadbs.SEData.from_db(db, where={'create_time': (start_date, end_date)}, hdfpath = fn_hd5)
#                except:
#                    print(f'   problem with se data between {start_date}, {end_date}')
                


    
    
"""
function to calculate the minimal begin time and the maximal end time of the
given list of periods

@modified: 2020-8-6
"""
def get_begin_end(periods):
            
    if len(periods)==0:
        return(None, None)
        
    else:   
        df_tmp = pd.DataFrame.from_records(periods, columns = ['start', 'end'])
            
        if df_tmp.start.isna().any():
            # oder begin IB?
            start_time = None
        else:
            start_time = df_tmp.start.min()
    
        if df_tmp.end.isna().any():
            end_time = None
        else:
            end_time = df_tmp.end.max()
        
        return(start_time, end_time)
    
    
    





"""
plot signal energy
"""
def myPlot_se(sFN, dX, dictY, s_title='', sXLabel='index', sYLabel='', dXLim = None, y_lim = None, colors = None, legend = True):

    iAxisLabelSize = 16
    iLegendSize = 16

    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    colors = provideColors()
    
    if y_lim:
        plt.ylim(y_lim)

    if isinstance(dX, tuple) or isinstance(dX, list):            
#        if len(dX)>2:
#            for idx in range(1,len(dX)):
#                # TODO 2019-4-3: funktioniert noch nicht richtig
#                plt.plot(dX[0], dX[idx], color=colors[idx])
#        else:
#            plt.plot(dX[0], dX[1])
        iN = len(dX)
        for idx in range(1,iN):
            plt.plot(dX[0], dX[idx], color = colors[idx])                

            #llegend.append(str(idx))


    elif isinstance(dX, pd.DataFrame):
        iN = dX.shape[1]
        plt.plot(dX.iloc[:,0], dX.iloc[:,1:].values)        
                
    else:        
        
        bMulti = False
        if len(dX.shape)>1:
            iN = dX.shape[1]
            if (iN>0):
                bMulti = True
        else:
            iN = 1
                
        if bMulti:
            plt.plot(dX[:,0], dX[:,1:])

        else:
            dI = pd.Series(range(dX.shape[0]))
            plt.plot(dI, dX)


    if legend:
        #plt.legend(llegend, fontsize=iLegendSize, loc=2)
        #llegend = [str(i) for i in range(iN)]
        plt.legend(legend, fontsize=iLegendSize)


    if s_title:
        iFontSizeTitle = 22
        title = ax.set_title(fill(s_title, int(round(120/iFontSizeTitle*12))), fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    
    plt.show()
    #plt.close(fh)
                        
 
    
    
    
"""
function to create interactive plot for regression results of multivariate 
regression with dummy variables

parameters:
-----------

    - data: np.arrays containing with (wtg, blade) as index, x-variable as 
            1st column and y-variable as 2nd column
        
    - 

@author: Christian Kuehnert
@modified: 2019-8-27

"""      
def plot_regress(data, model):
    pass
    

    
    # plot original data and regression lines
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
"""
function to get the datetime when the measuring program was changed so that
the factor (in most cases this factor is 5) to calculate the se is taken into
account correctly

NOTE: the change in the signal energy can happen some time BEFORE the resulting
      datetime value (cf. example of db='cmrblba_bc_01528', one can see this
      if one takes a look as the se joined with ba_cycle_status)
      So be careful when using the result of this function to data not from
      ba_cycle_status


@author: Christian Kuehnert
@modified: 2019-8-20

"""
def get_datetime_factor_change(db):

    # TODO 2019-8-20: um das ganz sicher fuer alle Faelle zu machen, muesste
    # man eigentlich besser nach min(create_time) fuer alle 
    # Messprogramm-Varianten suchen, die NICHT in den Varianten vor dem 
    # Faktorwechsel liegen (ansonsten koennen ja neue hinzukommen und ggf. 
    # Wechsel von der falsche-Faktor-Variante zu so einer superneuen erfolgen)
    sql = ("select min(create_time) "
           "from ba_cycle_measurement_cycle "
           "where (appendix like 'cmrbl2.4.46 %') "
           "or (appendix like 'cmrbl2.4.53 %');")
    time_correct_factor = mfdata.query_MySQL2(db, sql)[0][0]
    return(time_correct_factor)
    






"""
function to correct the wrongly calculated signal energies

TODO 2019-8-21: Faktor noch generisch aus den Daten bestimmen!

@author: Christian Kuehnert
@modified: 2019-8-21

"""
def adjust_se(db, 
              df, 
              channels = ['e_101_edge', 'e_102_edge', 'e_103_edge', 
                                  'e_101_flap', 'e_102_flap', 'e_103_flap'], 
              factor = 5):
    
    
    time_changed = get_datetime_factor_change(db)
    cols = list(set(df.columns) & set(channels))
    if time_changed is None:
        df.loc[:, cols] = df.loc[:, cols] / factor
    
    else:
        btmp = (df.index < time_changed)        
        df.loc[btmp, cols] = df.loc[btmp, cols] / factor

    return(df)








## Methode aus weadbs SED uebernommen und modifiziert
def plot_se(df, freq, ori='both', by=None, fmt=None, axes=None,
                **norm_kws):
        """Webvis-style plotting of signal energies.

        Parameters
        ----------
        freq : float, tuple
            if float, a single frequency band will be plotted; if tuple, all
            frequency bands inside the given range will be summed and the
            result will be plotted; Note that, if frequency bands in the se are
            defined as pd.Interval, often the right edge of the interval is
            inclusive, i.e., (low, high]. Then, having (2, 4] and (4, 6] in se
            and choosing `freq=(4, 6)` will select both of these intervals
            whereas `freq=(2, 4)` will select only the first.
        ori : str
            sensor orientation; either 'edge', 'flap' or both
        by : str or None
            variable to plot as x-axis; if None, uses index, otherwise looks
            for fitting variable in st
        fmt : str or None
            format string defining line styles; if None, default is '.-' for
            plot by index and '.' for plot by st variables
        axes : Axis, iterable of axis or None
            for plotting into existing axis; if None, new figure will be
            created

        if remaining kwargs exist, data will be normalised and kwargs will be
        passed to `normalise`, see there for more information

        Returns
        -------
        axes : Axis or iterable of axis
            the axis into which the signal energies were plotted
        """
        if ori == 'both':
            oris = ['edge', 'flap']
        else:
            oris = [ori]

        freqi = freq
        if isinstance(freq, tuple):
            freq = slice(*freq)
        # handles slices as input
        if isinstance(freq, slice):
            freqi = pd.Interval(freq.start, freq.stop, closed='both')

        title = '{} Hz'.format(freqi)

        ylabel = ('signal energy\n(relative to blade-mean)' if norm_kws
                  else 'signal energy')

        se = self.se.loc[:, (slice(None), freq)].groupby(
                level='channel', axis=1).sum()
        se.columns = pd.MultiIndex.from_product(
                [se.columns, [freqi]], names=['channel', 'freq'])
        # se should only be 0, when all ses of the chosen frequencies were NaN
        # for that time point; so replace the 0s with NaNs - this removes them
        # from the plot and reduces clutter from irrelevant information (I
        # tried to let NaNs pass through the grouped aggregation, but I didn't
        # find a way - pandas by default ignores NaNs during aggregation on
        # GroupBy objects and I didn't find a way around this.)
        se[se == 0] = np.nan
        sed = SEData(se, self.st)

        if norm_kws:
            sed.normalise(inplace=True, **norm_kws)

        plotdata = []
        for ori in oris:
            channels = [channel for channel
                        in self.se.columns.get_level_values('channel').unique()
                        if ori in channel]

            plotdata.append(sed.se.loc[:, channels].droplevel(1, axis=1))

        if by is None:
            X = self.se.index
            by = self.se.index.name
            if fmt is None:
                fmt = '.-'
        else:
            if by not in self.st.columns:
                byalts = [by.replace('_mean', ''), by + '_mean']
                by = None
                for byalt in byalts:
                    if byalt in self.st.columns:
                        by = byalt
                        warnings.warn('plotting by "{}"'.format(by))
                        break

                if by is None:
                    raise ValueError(
                            "Could not find variable for plotting 'by'!")

            X = self.st[by]
            if fmt is None:
                fmt = '.'

        if axes is None:
            _, axes = plt.subplots(len(oris), 1, sharex=True, squeeze=False)
            axes = axes[:, 0]
        else:
            try:
                len(axes)
            except TypeError:
                axes = [axes]

        for ax, pdata, ori in zip(axes, plotdata, oris):
            for channel in pdata.columns.sort_values():
                ax.plot(X, pdata[channel], fmt, lw=1, label='blade {}'.format(
                        re.match(r'.*10(\d).*', channel).group(1)))

            ax.set_ylabel('{}\n{}'.format(ori, ylabel))

        axes[0].legend()
        axes[0].set_title(title)
        axes[-1].set_xlabel(by)

        return axes


