# -*- coding: utf-8 -*-
"""
function to check one single time series/measuring data row for sensor defect

Created on Tue Mar 26 02:53:38 2019

@author: Christian Kuehnert
@last_modified: 2019-3-26

"""
import os
import datetime as dt

#import class_classifier_ts as csc

def generate_init_file(folder_name, path_name = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'):
    
    try:

        sT0 = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        #files = [s for s in os.listdir(f'{path_curr}\\{folder_name}) if not os.path.isdir(folder_name + '\\' + s)]
        files = [s for s in os.listdir(f'{path_name}\\{folder_name}') if not os.path.isdir(s)]
        files = list(set(files)-{'__init__.py'})        # get list of files without '__init__.py'         
        files = [s.replace('.py', '') for s in files]
        files.sort()
        
        
        text0 = f'# -*- coding: utf-8 -*-\n"""\nCreated on {sT0}\n\n@author: Christian Kuehnert\n"""\n\n\n'
        
        text1= "__all__ = ['" + "',\n\t\t\t'".join(files) + "']"
        
        text2 = '\n'.join(['from .' + s + ' import ' + s for s in files])
        
        # save to new init-file
        fn_init = f'{path_name}\\{folder_name}\\__init__.py_{sT0}'
        
        f = open(fn_init, 'a')
        f.write(text0)
        f.write(text1)
        f.write('\n\n\n\n\n')
        f.write(text2)                            
        f.close()        
        bOK = True
        
        ## predict for this time point
    except Exception as ex:
        print('error occurred in function generate_init_file.py')
        bOK = False

    return(bOK)
