in this folder/package are functions to deal with the python functions themselves,
e.g. find out in which package/function a given function is importet or called as subfunction etc.