# -*- coding: utf-8 -*-
"""
package of meta-function

in this folder/package are functions to deal with the python functions themselves,
e.g. find out in which package/function a given function is importet or called as subfunction etc.

Created on Thu Jul 18 11:51:07 2019

@author: Christian Kuehnert
"""



"""
find all functions into which a given function is importet

parameters:
-----------

            - name:    name of the function to search for in other functions
            - path:    main path (all beneath will be searched too) to search
                       for the given function


@author: Christian Kuehnert
@modified: 2019-7-18

@example: tmp = find_calling_functions('whereClause_from_timeInterval')

"""
import os
import sys
import pathlib


def find_calling_functions(name, search_path=r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'):
    
    list_callers = []

    pattern = f'{name}'  
    
    ## if path is None then search the current path and (and all beneath)
    if (search_path is None):
        search_path = sys.argv[0]
        
        
    # get all .py-files in all folders below
    # TODO 2019-7-18: hier evtl. nach f'{name}(' suchen, allerdings kann 
    # function name ja auch an andere function uebergeben werden, dann wuerde
    # das nicht gefunden.
    # Auf jeden Fall aber noch die Kommentarzeilen ausschliessen (evtl. mit
    # regex, aber vielleicht schneller ohne?
    list_files = []    
    for p, s, f in os.walk(search_path):        
        if not('__pyache__' in p):
            for fn in f:
                if len(fn)>3:
                    if '.py' in fn[-3:]:
                        list_files.append(pathlib.PurePath(p, fn))
    
    for fn in list_files:              # loop through list
        
        with open(fn, 'r') as f:
            #data = f.read().replace('\n', '')       # read in file contents
            text = f.read()                          # read in file contents
            
            if pattern in text:
                list_callers.append(fn)    # store superfunction-name and 
                                           # path if pattern was found
                
    return(list_callers)
    

    
 