# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 10:30:24 2019

@author: christian
"""

#  meta__example_script


import sys
sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions')
#sys.path.append(r'C:\Users\christian\Documents\arbeit\selbstaendigkeit\Projekte\WeidmuellerMonitoringSystems\entwicklung\repository\python\my_functions_newVersionNotYetReleased')
from meta import find_calling_functions


#s_def = 'update_hd5Table'
#s_def = 'get_data_from_db'
s_def = 'update_meas'
#search_path=r'C:\Users\christian\Documents\arbeit\selbstaendigkeit\Projekte\WeidmuellerMonitoringSystems\entwicklung\repository\python\my_functions_newVersionNotYetReleased'
search_path = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'

tmp = find_calling_functions(s_def, search_path = search_path)



