# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 13:59:52 2019

@author: w012028
@modified: 2019-10-23

"""
import gc
import sys
import pandas as pd
import numpy as np
from datetime import datetime as dt
from datetime import timedelta
#import traceback
import matplotlib.pyplot as plt
#import statsmodels.formula.api as smf
from statsmodels.formula.api import ols
from scipy.signal import savgol_filter
import matplotlib.dates as mdates
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap, BoundaryNorm
from textwrap import fill


sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions')        # path to modules
import data as mfdata
from data.class_hd5Nodes import hd5Nodes as nodes
import plot.myFunctions_plot as mfplot
from data.filter_data import filter_data

from data.whereClause_from_timeInterval import whereClause_from_timeInterval
from data.myprint import myprint

#import monitor as mfmon
import monitor.class_turbine_offset as ctu




"""
set some parameters

"""



"""
collect sda-data from .csv.gz files

@modified: 2019-10-24

"""
def collect_data(db, 
                 path_data = (r'C:\Users\w012028\Documents\CK\data\data__'
                              'bearing_damage'),
                 start_time = dt(2016,1,1),
                 end_time = dt(2018,1,1)):
                
    try:
        ## for one wtg:
        mfdata.update_cdef(db, path_data, time_start=start_time, 
                           time_end=end_time)
    except:
        print(f'problem with updateting cdef data for {db}')
        
    try:
        mfdata.update_sda(db, path_data, time_start=start_time, 
                          time_end=end_time, bSloppy=True)
    
    except:
        print(f'problem with updateting sda data for {db}')

    ## TODO 2019-10-24: noch konsistent machen mit Funktionen, so dass der
    ## filename zum verwendeten File sicher passt, ist aber sehr nachrangig        
    return(f'{path_data}\\{db}.hd5')





"""
load cdef data

@modified: 2019-10-24

"""
def load_cdef(db, 
              path_data = (r'C:\Users\w012028\Documents\CK\data\data__'
                 'bearing_damage')):
    fn_hd5 = f'{path_data}\\{db}.hd5'

    df_cdef = None    
    sNode_cdef = nodes.cdef
    with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
        if sNode_cdef in f:

            #sWhere = whereClause_from_timeInterval(time_start=time_start, time_end = time_end, sFormat = sDTFormat_hd5)                                
            #if sWhere:
            #    lWhere.append(sWhere)                
            #sWhere = ' and '.join(lWhere)
                        
            #df_cdef = f.select(key=sNode_cdef, where=sWhere).copy()
            df_cdef = f.select(key=sNode_cdef).copy()
                    
    return(df_cdef)




"""
identity function

@modified 2019-10-24

"""
def id_fct(df_sda):
    return(df_sda.a_f.values)



"""
load sda data for the given cycles

parameters:
-----------
            - tup_fct:    tuple (fct, kwargs, col_names) with fct the function to be
                          applied to the sda-data, column_names the names to
                          be used for the columns of the resulting dataframe
                          if None, the sda will be returned unmodified and the
                          columns will contain the frequencies
            
            - channels:   list of channels which are given in tuples 
                          (blade, direction), e.g. (1, 'edge')
            
@modified: 2019-10-24

"""
def merge_sda(db, df_cycles = None, channels = None, tup_fct = None,
              path_data = (r'C:\Users\w012028\Documents\CK\data\data__'
                 'bearing_damage'), bprint = False):

    
    fn_hd5 = f'{path_data}\\{db}.hd5'

    try:
        
        if (tup_fct is None):
            fct = id_fct
            kwargs = {}
            #col_names = [str(i/16.384) for i in range(8192)]  # 16.384s = Messdauer
            col_names = [f'f{i}' for i in range(8192)]
    
        else:
            fct = tup_fct[0]
            kwargs = tup_fct[1]
            col_names = tup_fct[2]
                        
        node_data = nodes.sda_data
        node_startstop = nodes.sda_startstop
        
        if (channels is None):
            channels = [(1, 'edge'), (2, 'edge'), (3, 'edge'), 
                        (1, 'flap'), (2, 'flap'), (3, 'flap')]
    
        tmp = ' | '.join([f'(blade={bl} & direction={di})' for bl, di in channels])
        
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:
            dfCycSDA = f.select(key=node_startstop, where = tmp)
    
        df = pd.merge(dfCycSDA, df_cycles, on = ['create_time', 'ID'], 
                      right_index=True)        
                                                
        n_cyc = df.shape[0]
        count = 0   
        lsda = []
    
        with pd.HDFStore(fn_hd5, 'a', complevel=9, complib='blosc:lz4') as f:    
            for idx, cdef in df.iterrows():
                
                try:
                            
                    count += 1
            
                    if bprint & (count % 20 == 0):
                        print(f'{count}/{n_cyc}')
                                        
                    sda = f.select(key=node_data, start=cdef['start'], 
                                   stop=cdef['stop'], columns=['idx', 'a_f'])
                    
                    lsda.append(fct(sda, **kwargs))
                    
                except:
                    print(f"problem at {cdef['create_time']}, {cdef['ID']}, {cdef['blade']}, {cdef['direction']}")
                                                                    
        df_sda = pd.DataFrame(lsda, columns = col_names, 
                                  index = df.index)
        df.reset_index(drop=True, inplace=True)
        df_sda.index = df.index
            
        del(lsda)                
        gc.collect()
            
        df_res = pd.concat((df, df_sda), axis=1)
        
    except:
        print('problem in load_sda.py')
        df_res = None
        
    return(df_res)
    
    
    
    
    
    
    
    
    
"""
function to plot a comparison between data from two periods
the data will be binned by the given power bins


@modified: 2019-12-10
"""
def plot_compare_periods(dict_comp, ch, power_bins, title=None, xlabel= None,
                         ylabel = None, ylim = None, fn = None):
                         
    iAxisLabelSize = 16
    iLegendSize = 16
    iFontSize = 18

    #default_dict_style = {'linestyle': '-', 'marker': 'None'}    
    #with plt.figure(figsize=(12,9)) as fh:
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                                
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    if isinstance(xlabel, str):
        ax.xlabel(xlabel, fontsize = iFontSize)
        
    if isinstance(ylabel, str):
        ax.ylabel(ylabel, fontsize = iFontSize)
       
    if ylim:
        ax.ylim(ylim)
    

    ## now create the single curves
    legend = []
    for tag, [df, color] in dict_comp.items():

        dfg=(df.loc[:,[ch]].assign(binned=pd.cut(df['power_mean'], power_bins))
                            .groupby(['binned'], observed = True, sort=True))
            
        # descriptive statistics over the bins
        #dfg = df.groupby(['binned'], observed = True, sort=True)
            
        ## TODO 2019-12-10: eleganter machen!
        #stat_min = dfg.min()
        stat_q05 = dfg.quantile(q=0.05, interpolation='linear').sort_index()
        stat_mean = dfg.mean().sort_index()
        stat_q95 = dfg.quantile(q=0.95, interpolation='linear').sort_index()
        
        x = stat_q05.index.mid.values   # mid points of the intervals
        
        ax.fill_between(x, stat_q05.loc[:, ch].values, 
                         stat_q95.loc[:, ch].values, color=color, alpha=0.3)
        
        ax.plot(x, stat_mean, color=color, lw=3, marker = 'None')
        
        legend.append(f'{tag} (n={df.shape[0]})')
        
    ax.grid(True)
    
    ax.legend(legend, fontsize=iLegendSize)

    if not(title is None):
        iFontSizeTitle = 22
        title = ax.set_title(fill(title, int(round(120/iFontSizeTitle*12))), 
                             fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    if (fn is None):
        fh.show()
    else:
        fh.savefig(fn, dpi=200)
        #fh.close(fh)
    
    plt.close(fig = fh)
    del fh


 

    
    
    
   
    
"""
function to plot a comparison between data from two periods with boxplot
the data will be binned by the given power bins


@modified: 2019-12-12
"""
def plot_compare_periods_boxplot(dict_comp, ch, title=None, xlabel= None, 
                                 ylim = None, show_fliers = False, fn = None):
                         
    sFormat = '%d.%m.%Y'
    iAxisLabelSize = 16
    #iLegendSize = 16
    #iFontSize = 18


    ## plot boxplot for comparison
    list_plot = []
    list_labels = []
    list_colors = []
    for tag, [df, color] in dict_comp.items():

        s_min = df.index.min().strftime(sFormat)
        s_max = df.index.max().strftime(sFormat)
                    
        list_plot.append(df.loc[:, ch].values)
        list_labels.append(f'{ch}, {s_min}-{s_max} (n={df.shape[0]})')
        list_colors.append(color)
        

    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)

    if not(title is None):
        iFontSizeTitle = 22
        title = ax.set_title(fill(title, int(round(120/iFontSizeTitle*12))), 
                             fontsize=iFontSizeTitle)    
        title.set_y(1.05)

    bplot = ax.boxplot(list_plot, notch=True, labels = list_labels, 
                       showfliers = show_fliers, patch_artist = True)
    # set colors
    for patch, col in zip(bplot['boxes'], list_colors):
        patch.set_facecolor(col)
                       
    ax.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    if (fn is None):
        fh.show()
    else:
        fh.savefig(fn, dpi=200)
    
    plt.close(fig = fh)
    del fh
    
    
    
    
    
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 13:35:14 2019

function to display the fail times of the sensors
TODO 2019-12-9: at present the fail time data are read in from an 
.xlsx-file, later they should be checked automatically from the tickets of 
the turbine    
TODO 2019-12-9: verbessern, Beschriftung y-Achse noch schoen machen u.ae.

parameters:
-----------
    - dbs:            list of database names
    - fn_fail_times:  name of (excel) file containing the fail times, must 
                      contain the columns ['db', 'name', 'channel', 'start', 
                      'end']

    - fn_img:         if None, the resulting image will be shown, otherwise
                      it will be stored in a file with the given name

@modified: 2019-12-9
"""
def plot_sensor_fail_times(dbs, fn_fail_times, start_time=None, end_time=None, 
                           fn_img = None, dict_channels = {'edge': 
                               ['e_101_edge', 'e_102_edge', 'e_103_edge'],
                        'flap': ['e_101_flap', 'e_102_flap', 'e_103_flap']}):
    
    cmap = ListedColormap(['g', 'b', 'r'])
    norm = BoundaryNorm([-1, .5, 0.5, 2], cmap.N)

    # plotting position and related tickmark
    y = 0
                
    yticklabels = []
    yticks = []
    

    df_tsf=pd.read_excel(open(fn_fail_times, 'rb')).sort_values(by='start')

    if (start_time is None):
        start_time = df_tsf.start.min()
    
    if (end_time is None):
        end_time = df_tsf.end.min()

    fig = plt.figure(figsize=(16,9))
    ax=plt.subplot(111)

    for db in dbs:
                
        tb = ctu.turbine_offset.from_db(db)
        turbine_info, turbine_info_fn = tb.get_info()
        yticks.append(y)
        yticklabels.append(turbine_info)
        print(turbine_info)

        y -= 3

        tb.set_times(start_time, end_time)

        ## erstmal simple nur '1' dartsellen, spaeter evtl. 3-blatt-vgl.
        df = df_tsf.fillna(dt.now())
        df = df[(df.db == db) & (df.end >= start_time)]
        for direction, chs in dict_channels.items():
            
            for ch in chs:
                
                dates = [start_time]
                colors = [0]
                
                df_tmp = df[df.channel == ch]

                # TODO 2019-12-4: eleganter machen (vektorisieren)
                for _i, row in df_tmp.iterrows():
                    tmp0 = row['start']
                    tmp1 = row['end']
                    
                    if tmp0<= start_time:
                        colors[0] = 1
                    else:
                        dates.append(tmp0)
                        colors.append(1)
                                        
                    if tmp1 >= end_time:
                        dates.append(end_time)
                        colors.append(1)
                    else:
                        dates.append(tmp1)
                        colors.append(0)
                
                if dates[-1]<end_time:
                    dates.append(end_time)
                    colors.append(0)
                
                
                yvec = np.zeros(len(dates)) + y
                colorvec = pd.Series(colors)
                
                
                inxval = mdates.date2num(dates)
                points = np.array([inxval, yvec]).T.reshape(-1,1,2)
                segments = np.concatenate([points[:-1],points[1:]], axis=1)
                
                #lc = LineCollection(segments, cmap="plasma", linewidth=5)
                lc = LineCollection(segments, cmap=cmap, norm=norm,linewidth=7)
                # set color to date values
                lc.set_array(colorvec)
                                    
                ax.add_collection(lc)

                yticks.append(y)
                yticklabels.append(ch.replace('e_10', ''))

                y -= 2
                
            y -= 2
            
        y -= 4
                            
    ax.autoscale_view()
    ax.xaxis_date()
    ax.set_xlim([start_time, end_time])
    ax.set_yticks(yticks)
    ax.set_yticklabels(yticklabels)
    #ax.set_ylim([-1,1])
    if (fn_img is None):
        plt.show()
    else:
        fig.savefig(fn_img, dpi=350)



    
    
    
"""
function to calculate the relative SE

@modified: 2019-10-25

"""
def fct_se(dfSDA, band):

    #band = [55,70]
        
    bw = band[1] - band[0]
    meas_len = 16.384
    lim = [band[0]*meas_len, band[1]*meas_len]
            
    se = dfSDA[((dfSDA.idx>=lim[0]) & (dfSDA.idx<lim[1]))].a_f.sum() / bw
    
    return(se)
    
    
    
    
    
"""
function to calculate the criteria for bearing damage detection

@modified: 2019-10-28

"""
def fct_bearing_damage(dfSDA, band):
    
    bw = band[1] - band[0]
    meas_len = 16.384
    lim = [band[0]*meas_len, band[1]*meas_len]
            
    #df_sum = dfSDA.af.sum(axis=1)/500
    #df_band = dfSDA.a_f.loc[:, cols_band].sum(axis=1) / bw
    #df_norm = df_band/df_sum
    norm = dfSDA[((dfSDA.idx>=lim[0]) & (dfSDA.idx<lim[1]))].a_f.sum() / dfSDA.a_f.sum() * 500 / bw
            
    return(norm)
    
    
    
"""
restructure sda-dataframes:

@modified: 2019-10-24

"""
def restructure(df, dict_rename = {'temperature_mean': 'T', 'power_mean': 'P'}):
    
    df.rename(columns = dict_rename, inplace=True)
    df.reset_index(index=['create_time'], drop=True, inplace=True)
    
    return(df)

    




"""
checking for bearing damage

@modified: 2019-10-24

"""
def check_bearing_damage(df_ok, df_bls, channels):

    # TODO 2019-10-24: ueberlegen: koennte man auch channel-weise machen, falls 
    # channels NaN-Werte haben, die man durch dropna() entfernt, ist aber vmtl.
    # 1. selten der Fall und 2. sehr unsignifikant
    sFormat = '%d.%m.%Y'
    
    s_ok_min = df_ok.index.min().strftime(sFormat)
    s_ok_max = df_ok.index.max().strftime(sFormat)

    s_bls_min = df_bls.index.min().strftime(sFormat)
    s_bls_max = df_bls.index.max().strftime(sFormat)
    
    for ch in channels:
        
        s_model = f'{ch} ~ T + P'
        
        # TODO 2019-10-24: noch klaeren, ob '/5' Relikt von frueherem Messprogrammbug oder etwas ernsthaftes
        df_ok[ch] = df_ok[ch]/5
        
        df = df_ok.loc[:, ['T', 'P', ch]]
        
        fit = ols(formula = s_model, data = df).fit()
        
        #print(f'{s_model}:')
        #print(fit.summary())        
        x_ok = df.loc[:, ch] - fit.predict(df.loc[:, ['T', 'P']])
        x_bls = df_bls.loc[:, ch] - fit.predict(df_bls.loc[:, ['T', 'P']])
        
        ## plot
        mfplot.myplot_fast2([(df_ok.loc[:,'P'].values, x_ok, {'ls': 'none', 'marker': '*', 'color': 'green'}),
                            (df_bls.loc[:, 'P'].values, x_bls, {'ls': 'none', 'marker': '*', 'color': 'orange'})],
                            s_title=f'{ch}')
        
        mfplot.myplot_fast2([(df_ok.loc[:,'T'].values, x_ok, {'ls': 'none', 'marker': '*', 'color': 'green'}),
                            (df_bls.loc[:, 'T'].values, x_bls, {'ls': 'none', 'marker': '*', 'color': 'orange'})],
                            s_title=f'{ch}')
    #    mfplot.myplot_fast2([(df_ok.index, df_ok.loc[:, ch], {'ls': 'none', 'marker': '*', 'color': 'green'}),
    #                        (df_bls.index.values, df_bls.loc[:, ch], {'ls': 'none', 'marker': '*', 'color': 'orange'})])
        #fn_plot = f'{path_work}\\{ch}_boxplot3.png'
        _myfig = plt.figure()
        #bplot = plt.boxplot([df_ok.loc[:, ch], df_bls.loc[:, ch]], labels = [f'{ch}, {s_ok_min}-{s_ok_max}', f'{ch}, {dt_change.strftime(sFormat)}-{dt_end.strftime(sFormat)}'], showfliers=True)    
        _bplot = plt.boxplot([x_ok.values, x_bls.values], labels = [f'{ch}, {s_ok_min}-{s_ok_max}', f'{ch}, {s_bls_min}-{s_bls_max}'], showfliers=True)
        plt.gca().set_ylim(-5,20)
        plt.gca().set_title(f'{ch}')
        plt.show()

# TODO 2019-10-24: hier auch noch anova machen, scatterplots usw.



## correct data by sensitivities - hier unnoetig, da nur innerhalb der channels
## verglichen wird
## muesste ggf. in die Funktion zur Berechnung der Kriterien mit eingebaut 
## werden
if False:
    dict_sens = {'edge': [tb.sens_e1, tb.sens_e2, tb.sens_e3],
                 'flap': [tb.sens_f1, tb.sens_f2, tb.sens_f3]}
    
    for direction, sens in dict_sens.items():
        sens_mean = np.mean(sens)
        chs = dict_directions[direction]
        dict_fac = {chs[i]: sens[i]/sens_mean for i in range(3)}
    
        for col in chs:
            df_ok[col] = df_ok[col] * dict_fac[col]
            df_bls[col] = df_bls[col] * dict_fac[col]
        



"""

frueherer Versuch fuer Kandrich mit Auslesen der .hd5-Datein von W:, 
verbessern und weiterfuehren

"""
if False:
    ## new try 2019-8-30: load comparison data from hd5-file
    path_hd5 = r'W:\en_gda_00656\_current'
    cols_cdef = ['wind_mean', 'power_mean', 'temperature_mean']
    
    loader = hdf5.SDALoader(path_hd5, fband=None)
    cls_sed = loader.load(('2000-01-01', dt_change.strftime('%Y-%m-%d')))
    
    df_se = cls_sed.agg_freq(band).se / bw
    df_se.columns = df_se.columns.levels[0]   
    
    df_cdef = cls_sed[1].loc[:, cols_cdef].dropna().rename(columns = {
                                             'temperature_mean': 'T',
                                             'power_mean': 'P'})            
    df_cdef = df_cdef[(df_cdef.P >= power[0]) & (df_cdef.P <= power[1])]
        
    df_ok = pd.merge(df_cdef, df_se, on='create_time')
    df_ok.rename(columns = {'101_edge': 'e_101_edge',
                            '102_edge': 'e_102_edge',
                            '103_edge': 'e_103_edge',
                            '101_flap': 'e_101_flap',
                            '102_flap': 'e_102_flap',
                            '103_flap': 'e_103_flap'}, inplace=True)
    
    
    ## correct data by sensitivities - hier unnoetig, da nur innerhalb der channels
    ## verglichen wird
    if False:
        dict_sens = {'edge': [tb.sens_e1, tb.sens_e2, tb.sens_e3],
                     'flap': [tb.sens_f1, tb.sens_f2, tb.sens_f3]}
        
        for direction, sens in dict_sens.items():
            sens_mean = np.mean(sens)
            chs = dict_directions[direction]
            dict_fac = {chs[i]: sens[i]/sens_mean for i in range(3)}
        
            for col in chs:
                df_ok[col] = df_ok[col] * dict_fac[col]
                df_bls[col] = df_bls[col] * dict_fac[col]
            
            
            
    sFormat = '%d.%m.%Y'
    s_ok_min = df_ok.index.min().strftime(sFormat)
    s_ok_max = df_ok.index.max().strftime(sFormat)
    
    
    
    ## do model for each channel seperately
    for ch in channels:
        s_model = f'{ch} ~ T + P'
        df_ok[ch] = df_ok[ch]/5
        
        df = df_ok.loc[:, ['T', 'P', ch]]
        
        fit = ols(formula = s_model, data = df).fit()
        
        #print(f'{s_model}:')
        #print(fit.summary())
        
        x_ok = df.loc[:, ch] - fit.predict(df.loc[:, ['T', 'P']])
        x_bls = df_bls.loc[:, ch] - fit.predict(df_bls.loc[:, ['T', 'P']])
        
        ## plot
        mfplot.myplot_fast2([(df_ok.loc[:,'P'].values, x_ok, {'ls': 'none', 'marker': '*', 'color': 'green'}),
                            (df_bls.loc[:, 'P'].values, x_bls, {'ls': 'none', 'marker': '*', 'color': 'orange'})],
                            s_title=f'{ch}')
        
        mfplot.myplot_fast2([(df_ok.loc[:,'T'].values, x_ok, {'ls': 'none', 'marker': '*', 'color': 'green'}),
                            (df_bls.loc[:, 'T'].values, x_bls, {'ls': 'none', 'marker': '*', 'color': 'orange'})],
                            s_title=f'{ch}')
    #    mfplot.myplot_fast2([(df_ok.index, df_ok.loc[:, ch], {'ls': 'none', 'marker': '*', 'color': 'green'}),
    #                        (df_bls.index.values, df_bls.loc[:, ch], {'ls': 'none', 'marker': '*', 'color': 'orange'})])
        #fn_plot = f'{path_work}\\{ch}_boxplot3.png'
        myfig = plt.figure()
        #bplot = plt.boxplot([df_ok.loc[:, ch], df_bls.loc[:, ch]], labels = [f'{ch}, {s_ok_min}-{s_ok_max}', f'{ch}, {dt_change.strftime(sFormat)}-{dt_end.strftime(sFormat)}'], showfliers=True)    
        bplot = plt.boxplot([x_ok.values, x_bls.values], labels = [f'{ch}, {s_ok_min}-{s_ok_max}', f'{ch}, {dt_change.strftime(sFormat)}-{dt_end.strftime(sFormat)}'], showfliers=True)
        plt.gca().set_ylim(-5,20)
        plt.gca().set_title(f'{ch}')
    
        #myfig.savefig(fn_plot)
        
        ## checking assumptions
        #levene = stats.levene(x_ok, x_bls)
        #shapiro_ok = stats.shapiro(x_ok)
        #shapiro_bls = stats.shapiro(x_bls)
        
        ## anova
        #anova = stats.f_oneway(x_ok, x_bls)
        
        #print(f'{ch}: {anova}')
        
    
    
    
    
        
### 2019-12-6: compare periods before and after blade bearing exchange or,
### alternatively, the times immediately after blade change and later
def calc_se_part(df):

    
    
        for band, filters in dict_bands.items():
            
            sband = f'{band[0]}-{band[1]} Hz'
   
            # try to load the data from a pickled file, if not existing then pickle
            path_tmp = f'{path_save}\\intermediate_data'
            fn_pkl = f'{db}__band{band[0]}_{band[1]}.pkl'
            if fn_pkl in os.listdir(path_tmp):
                df0 = pd.read_pickle(f'{path_tmp}\\{fn_pkl}')
            else:
                tb.set_times(start_time, end_time)                        
                tb.band = band
                ## TODO 2019-11-26: Ticketzeiten ausschliessen schon in class turbine_offset verlagern
                tb.load_data_from_hd5()
                df0 = tb.df_se.copy()
                df0.to_pickle(f'{path_tmp}\\{fn_pkl}')               # pickle result


            ## filter data (if required)
            if len(filters)>0:                
                btmp = pd.concat([df0.loc[:, k].between(v[0], v[1]) for k,v
                                    in filters.items()], axis=1).all(axis=1)
                df0 = df0[btmp]

                                        
            power_step = 10
            if ('power_mean' in filters.keys()):
                power_start = power[0]
                power_end = power[1]
                                
            else:                                    
                power_start = 0
                power_end = 2600
                
            power_bins = range(power_start, power_end, power_step)


            ## exclude times of active tickets            
            df_db = df_tsf[df_tsf.db == db]
            for direction, chs in dict_channels.items():
                
                list_plot = []
                leg = []
                
                cols = list(set(df0.columns)-set(channels))    # columns of se dataframe
                                                        # without channel headers            
                for ch in chs:
                                   
                    df = df0.loc[:, cols+[ch]]
                    
                    ## drop data during tickets
                    # TODO 2019-12-4: eleganter machen (vektorisieren)
                    idx = []
                    df_tmp = df_db[df_db.channel == ch].fillna(end_time)
                    for _i, row in df_tmp.fillna(end_time).iterrows():
                        #idx.append(df0[(df0.index>=row['start']) & \
                        #         (df0.index<=row['end'])].index)
                        df.drop(df[(df.index>=row['start']) & \
                                   (df.index<=row['end'])].index, inplace=True)
    

                    ## now take times before and after blade exchange and begin times and 
                    ## compare them regarding bearing damage        
                    #dt_regress = dt.datetime(2017,1,1)
                    #dt_regress = 
                    tmp = dict_exchange_times[db]
                    dt_rep_start, dt_rep_end = tmp[0], tmp[1]
                    
                    # TODO 2019-10-25: fuer Vgl. Anfg-BLTausch noch Temp.korrektur 
                    # anwenden, fuer Vgl. vor/nach BLS nicht notwendig
        
                    # only useful if the repair period was during the considered period 
                    #if dt_rep_start > df.index.min():
                        #s_part = 'repair date within data period'                
                    if before_after:
                    
                        spart = 'before_after'

                        df_ok = df[(df.index>=dt_rep_end) & \
                                   (df.index<=dt_rep_end + timedelta(days=ndays))]
                        
                        df_bls = df[(df.index<=dt_rep_start) & \
                                    (df.index>=dt_rep_start - timedelta(days=ndays))]
                                     
                        if (df_ok.shape[0]>10) & (df_bls.shape[0]>10):
                            #s_title = f'{turbine_info}, {ch}, {sband}, {s_part}'
                            s_title = (f'{turbine_info}, {ch}, {sband}, '
                                       f'Zeitraum={ndays} d')
                                
                            dict_comp = {f'vor BL-Tausch ({dt_rep_start})': 
                                                            [df_bls, 'orange'], 
                                         f'nach BL-Tausch ({dt_rep_end})': 
                                                             [df_ok, 'green']}
                        else:
                            dict_comp = None

                    
                    else:
                   
                        spart = 'begin_end'
                        
                        dt_comp = dict_periods_comp[db]
                        
                        df_after = df[(df.index>=dt_rep_end) & \
                                (df.index<=dt_rep_end + timedelta(days=ndays))]
                        
                        df_later = df[(df.index<=dt_comp) & \
                                    (df.index>=dt_comp-timedelta(days=ndays))]
                                                                                     
                        if (df_after.shape[0]>10) & (df_later.shape[0]>10):
                            #s_title = f'{turbine_info}, {ch}, {sband}, {s_part}'
                            s_title = (f'{turbine_info}, {ch}, {sband}, '
                                       f'Zeitraum={ndays} d')
                                                            
                            dict_comp = {f'nach BL-Tausch ({dt_rep_end})': 
                                                        [df_after, 'green'], 
                                         f'Zeitraum ab {dt_comp}': 
                                                         [df_later, 'orange']}
                        else:
                            dict_comp = None

                    #TODO 2019-12-11: hier noch die Betriebsdaten(verteilungen)
                    #fuer die beiden Vergleichszeitraeume vergleichen
                                
                                
                    ## plot comparison, first with binned data, second with
                    ## boxplots
                    if not(dict_comp is None):
                        fn_img = (f'{path_save}\\diagrams\\{spart}\\'
                                  f'{turbine_info_fn}__{sband}__{ch}__{ndays}'
                                  f'days__{spart}.png') 
                        mbf.plot_compare_periods(dict_comp, ch, power_bins, 
                        title=s_title+' (gefuellter Bereich: q(0.05)-q(0.95))', 
                                                 xlabel = None,
                                                 ylabel = None, fn=fn_img)
        
                        ## plot boxplot for comparison                            
                        fn_img = (f'{path_save}\\diagrams\\{spart}\\'
                                  f'{turbine_info_fn}__{sband}__{ch}__{ndays}'
                                  f'days__{spart}__boxplot.png')
                        mbf.plot_compare_periods_boxplot(dict_comp, ch, 
                                                         title=s_title, 
                                                         #xlabel= None, 
                                                         ylim = None, 
                                                         show_fliers=False, 
                                                         fn = fn_img)
                
                
            ## do anova for comparison


    
"""
function to exclude times of active tickets            

TODO 2020-1-2: in turbine-class uebernehmen

parameters:
-----------
    - db:                database name
    - ch:                channel name
    - df:                dataframe, must contain 'create_time' as index
    - fn_exclude_times:  full name of Excel-File with the times to be excluded


@modified: 2020-1-7

"""
def exclude_ticket_times(df, db, ch, fn_exclude_times):
                
    df_tsf= pd.read_excel(open(fn_exclude_times, 'rb')).sort_values(by='start')

    df_excl = df_tsf[(df_tsf.db == db) & (df_tsf.channel == ch)]
                    
    ## drop data during exclude times
    # TODO 2019-12-4: eleganter machen (vektorisieren)
    df_res = df.copy()
    for _i, row in df_excl.fillna(dt.now()).iterrows():
        df_res.drop(df_res[(df_res.index>=row['start']) & \
                  (df_res.index<=row['end'])].index, inplace=True)
    
    return(df_res)
    
    
  

"""
plot ts of relative signal energy
2019-10-25

"""
def plot_ts_rel(df, direction, title, band, path_save, fn_img,
                wdw_size = None):

    cols_se = df.columns
    
    colormap = {'e_101_edge': 'red',
                'e_102_edge': 'blue',
                'e_103_edge': 'green',
                'e_101_flap': 'red',
                'e_102_flap': 'blue',
                'e_103_flap': 'green'}
    
    # diagram for se without offsets
    fn_img_full = f'{path_save}\\{fn_img}'
    sband = f'{band[0]}-{band[1]} Hz'


    # TODO 2019-10-25: noch nach create_time sortieren!

    if (wdw_size is None):
    
        list_se = [(df.index, df.loc[:, c].values, 
                {'ls': '-', 'color': colormap[c]}) for c in cols_se]

    else:
        list_se = [(df.index, savgol_filter(df.loc[:, c].values, wdw_size, 2), 
                {'ls': '-', 'color': colormap[c]}) for c in cols_se]

        title = f'{title}, geglaettet mit window-size={wdw_size}'


    mfplot.myplot(fn_img_full, list_se, s_title = title, 
                  legend = cols_se.to_list(), 
                  y_lim = [0, 2],
                  sYLabel = f'relative SE({sband}), {direction}')
    
 
    
    
    
    
"""
function to plot ok and bls periods

@modified: 2019-10-25

"""
# TODO 2019-10-25: verbessern, bzgl. Titel und ylabel flexibler machen, ggf. auch uebereinander darstellen lassen (dann ohne die "richtigen" Zeiten)
def plot_ok_bls(df_ok, df_bls, direction, title, band, path_save, fn_img, 
                wdw_size = None, ylim=None):

    cols_ok = [f'{c}, ok' for c in df_ok.columns]
    cols_bls = [f'{c}, bls' for c in df_bls.columns]
    
    colormap = {'e_101_edge': 'red',
                'e_102_edge': 'blue',
                'e_103_edge': 'green',
                'e_101_flap': 'red',
                'e_102_flap': 'blue',
                'e_103_flap': 'green'}
    
    # diagram for se without offsets
    fn_img_full = f'{path_save}\\{fn_img}'
    #title = f'SE {direction}, with {mode} offsets'
    sband = f'{band[0]}-{band[1]} Hz'

    # TODO 2019-10-25: noch nach create_time sortieren!


    if (wdw_size is None):
    
        list_se = [(df_ok.index, df_ok.loc[:, c].values, 
                {'ls': '-', 'color': colormap[c]}) for c in df_ok.columns] + \
            [(df_bls.index, df_bls.loc[:, c].values, 
                {'ls': '--', 'color': colormap[c]}) for c in df_bls.columns]

    else:
        list_se = [(df_ok.index, savgol_filter(df_ok.loc[:, c].values, wdw_size, 2), 
                {'ls': '-', 'color': colormap[c]}) for c in df_ok.columns] + \
            [(df_bls.index, savgol_filter(df_bls.loc[:, c].values, wdw_size,2), 
                {'ls': '--', 'color': colormap[c]}) for c in df_bls.columns]

        title = f'{title}, geglaettet mit window-size={wdw_size}'

    if (ylim is None):
        mfplot.myplot(fn_img_full, list_se, s_title = title, 
                      legend = cols_ok + cols_bls, 
                      #y_lim = [0, 2],
                      sYLabel = f'SE({sband})/SE_gesamt, {direction}')
    
    else:
        mfplot.myplot(fn_img_full, list_se, s_title = title, 
                      legend = cols_ok + cols_bls, 
                      y_lim = ylim,
                      sYLabel = f'SE({sband})/SE_gesamt, {direction}')
    





"""
plot ts of relative signal energy
2020-2-24

"""
def plot_rel_se(df, fn, wdw_size=None, 
                x_lim = None, y_lim = None, title=None, ylabel = None):

    if df.shape[0] > 0:
        ctime = df.index
        cols_se = df.columns
        
        colormap = {'e_101_edge': 'red',
                    'e_102_edge': 'blue',
                    'e_103_edge': 'green',
                    'e_101_flap': 'red',
                    'e_102_flap': 'blue',
                    'e_103_flap': 'green'}
        
        # diagram for se without offsets
        #fn_img_full = f'{path_save}\\{fn_img}'
        #title = f'SE {direction}, {mode} offsets (n={df.shape[0]})'
            
        if not((wdw_size is None) or (wdw_size==1)):
            
            try:
                tmp = savgol_filter(df, wdw_size, 2, axis=0)
                
            except:
                print('problem with savgol filtering, use raw data instead')
                tmp = df.values

            list_se = [(ctime, tmp[:,i], 
                    {'ls': '-', 'color': colormap[df.columns[i]]}) for i 
                        in range(len(df.columns))]
        else:
            list_se = [(ctime, df.loc[:, c].values, 
                    {'ls': '-', 'color': colormap[c]}) for c in df.columns]

        if (title is None):
            title = f'rel. Signalenergie'
            if not(wdw_size is None):
                title = title + f', geglaettet mit window size = {wdw_size}'

        if (ylabel is None):
            ylabel = f'rel. SE'

        mfplot.myplot(fn, list_se, s_title = title, 
                      legend = cols_se.to_list(), 
                      y_lim = y_lim, x_lim = x_lim,
                      sYLabel = ylabel)
    


"""
function to find peak and snr for given series (is supposed to be spectral
series but could be sth. else too)

@modified: 2020-2-25
"""
#from pyampd.ampd import find_peaks
#from random import randint
from scipy.signal import savgol_filter
def find_peak(a_f):
    
    #peaks = find_peaks(a_f, scale = 5)
    #bOk = (len(peaks)==1)
    #peak = peaks[0]        
    wdw_size = 11
    width_neighbours = 3
    af = savgol_filter(a_f, wdw_size, 4)

    #peak, snr = 10 + randint(-1,1), 4 + randint(-1,1)
    #snr = 4 + randint(-1000,1000)/10000
    ipeak = np.argmax(af)
    #amp = max(af)
    #outer = list(af[:max(0, ipeak-3)]) + list(af[min(len(af), ipeak+3):])
    snr = af[ipeak] / np.mean(list(af[:max(0, ipeak-width_neighbours)]) + \
                            list(af[min(len(af), ipeak+width_neighbours):]))
    
    return(ipeak, snr)
    #return(peak, snr, bOk)
    





## returning dataframe with same index and column names
## TODO 2020-3-9: eleganter machen
def calc_diff_to_mean(df_se, col_names):
    
    dse = df_se.loc[:, col_names].values
    dse_rel = dse.copy()
    
    set_c = set(range(len(col_names)))
    for ic in set_c:
        dse_rel[:, ic] = dse[:, list(set_c - {ic})].mean(axis=1)-dse_rel[:, ic]

    return(pd.DataFrame(dse_rel, columns = col_names, index = df_se.index))



## returning dataframe with same index and column names
## TODO 2020-3-9: eleganter machen, ausserdem noch RICHTIG fuer <=3 blades
## implementieren
def calc_diff_pairs(df_se, col_names):
    
    dse = df_se.loc[:, col_names].values
    dse_rel = dse.copy()
    
#    set_c = set(range(len(col_names)))        
#    for ic in set_c:
#        dse_rel[:, ic] = dse[:, list(set_c - {ic})].mean(axis=1)-dse_rel[:, ic]

    dse_rel[:, 0] = dse[:, 1]-dse[:, 2]
    dse_rel[:, 1] = dse[:, 2]-dse[:, 0]
    dse_rel[:, 2] = dse[:, 0]-dse[:, 1]

    return(pd.DataFrame(dse_rel, columns = col_names, index = df_se.index))





"""
function to calculate the indices belonging to the given bands

@modified 2020-5-15
"""
#HIER WEITER 2020-5-15: NOCH RICHTIG MACHEN!, STIMMT NOCH NICHT GANZ
def get_band_idx(band, interval_type = '[]', f_max = 500, length = 8192):
    
    left = interval_type[0]
    right = interval_type[1]
    if left=='[':
        c_start = 0
    elif left == '(':
        c_start = 1
    else:
        c_start = np.nan  # unknown open-symbol
            
    if right==']':
        c_end = 0
    elif right == ')':
        c_end = 1
    else:
        c_end = np.nan  # unknown close-symbol

    return([int(np.floor(band[0]/f_max*length))+c_start, 
            int(np.ceil(band[1]/f_max*length))-c_end])
            
            
            


"""
function to prepare data for aml tool
@modified: 2020-6-13

TODO 2020-6-13: war vorher nicht als Extrafunktion sondern im Skript integriert,
als eigene Funktion noch nicht getestet
"""
def prepare_for_aml(db, path_data, list_bands, start_time, end_time, 
                    path_save = None):  

    sDTFormat_hd5='%Y%m%d%H%M%S'
        
    fn = f'{path_data}\\{db}.hd5'
    
    dict_bands = {band: get_band_idx(band, interval_type = '[)') for band in list_bands}
    cols_se = [f'se_{b[0]}_{b[1]}' for b in dict_bands.keys()]
    records = list()
    with pd.HDFStore(fn, 'a', complevel=9, complib='blosc:lz4') as f:
        
        #select cdef data
        sWhere = whereClause_from_timeInterval(time_start=start_time, time_end = end_time, sFormat = sDTFormat_hd5)
        df_cdef = f.select(key=nodes.cdef, where=sWhere).copy()

        # select sda data
        df_ss = f.select(key=nodes.sda_startstop, where=sWhere).copy()
        
        count = 1
        for idx, row in df_ss.iterrows():
            if count % 10 == 0:
                myprint(f'{count}/{df_ss.shape[0]}')
            sda = f.select(key=nodes.sda_data, start=row['start'], stop=row['stop'])
            
            list_se = [row['create_time'], row['blade'], row['direction']]
            for band, idx_band in dict_bands.items():
                list_se.append(sda[(sda.idx>=idx_band[0]) & (sda.idx<=idx_band[1])].a_f.sum()/(band[1]-band[0]))
                
            records.append(list_se)
            count += 1
            
    df_se = pd.DataFrame.from_records(records, columns = ['create_time', 'blade', 'direction'] + cols_se)
    df1 = df_cdef.merge(df_se, on = 'create_time')

    # loeschen ueberfluessiger Spalten und Zeilen
    df2 = df1[df1.accu_count!=0]
    df2 = df2.drop(columns = ['ba_id', 'eval_id', 'event_id', 'sample_rate', 
                              'pitch_mean_2', 'pitch_sigma_2', 'pitch_mean_3', 
                              'pitch_sigma_3', 'operation_mode', 
                              'main_version', 'version', 'backup_time', 
                              'real_backup_time', 'sample_count', 
                              'accu_count', 'appendix', 'last_changed', 
                              'azimuth_mean', 'azimuth_sigma', 'range_id', 
                              'available_data', 'timezone', 
                              'process_runtime', 'wea_type', 
                              'turbine_status']).dropna(axis=0, how='any')
    
    # set labels by periods
    period_stiffener = (dt(2019,5,23), dt(2019,5,26))  # Einbauperiode stiffener
    
    df2 = df2[(df2.create_time < period_stiffener[0]) | (df2.create_time >= period_stiffener[1])]
    df2 = df2.assign(label = pd.Series(data=map(int, df2.create_time >= period_stiffener[1]), index=df2.index))
    
    list_df_res = list()
    for blade in range(1,4): 
        #df2 = df2[df2.blade==blade]#.drop(columns= 'blade')
        cols_idx = list(set(df2.columns) - set(cols_se) - \
                        {'direction', 'blade'})
        # pivot geht irgendwie nicht mit allen Index-Spalten, deshalb hier etwas
        # umstaendlicher
        df3 = df2[df2.blade==blade].drop(columns='blade').pivot(index = 'create_time', 
                                              columns = 'direction', 
                                              values = cols_se)
    
        # reduce column header levels
        df3.columns = [f'blade{blade}_' + '_'.join(col).strip() for col in 
                       df3.columns.values]
        df4 = df2.loc[:, cols_idx].drop_duplicates()
        df_res = df3.merge(df4, how='inner', on='create_time')
        
        df_res = df_res.rename(columns = {'create_time': 'DateTime'}).dropna(axis=1, 
                              how='all')
        
        list_df_res.append(df_res)
        if not(path_save is None):
            fn_res = f'{path_save}\\{db}__blade{blade}__input_aml.csv'        
            df_res.to_csv(fn_res, sep=';', header=True, index=False, 
                          date_format='%Y-%m-%d %HH:%MM:%ss',
                          encoding="utf-8")

        
    return(list_df_res)





            
"""
function to load data from csv file (which must be an aml-input file), filter them
by the filter dictionary given and restore them with new name

@modified: 2020-9-18
"""
def filter_aml_file(path, list_fn, filters, drop_cols = None, add_name = None):
    list_res = list()
    for fn in list_fn:
        fn_full = f'{path}\\{fn}'
        
        try:
            # load df from file
            df = pd.read_csv(fn_full, sep=';')
            
            df2, s_f = filter_data(df, filters)
            
            if not(drop_cols is None):
                df2.drop(columns = drop_cols, inplace=True)
            
            if not(add_name is None):
                s_f = add_name
            else:
                s_f = s_f.replace('(', '_').replace(')', '_').replace('>=', '_ge_').replace('<=', '_le_').replace(' ', '').replace('.', 'c')
                
            fn_res = f'{fn_full[:-4]}__{s_f}.csv'
            df2.to_csv(fn_res, sep=';', index=None, encoding="utf-8")
            print(f'{fn}, {s_f}: {df2.shape[0]}')
            list_res.append((df2, s_f))
        except:
            print(f'file {fn} could not be processed, return unfiltered df')
            list_res.append((df, ''))
            
    return(list_res)
            
    



#
#
### version control: create save folder in results-directory and store current version of program and functions there
#dtT00 = dt.datetime.now()
#sT00 = dtT00.strftime('%Y%m%d_%H%M%S')
#sDate00 = dtT00.strftime('%d.%m.%Y')
#path_save = path_save_main + '\\' + sT00
#mfdata.create_folder(path_save)    
#
#
#
### version control: create save folder in results-directory and store current version of program and functions there
#dtT00 = dt.datetime.now()
#sT00 = dtT00.strftime('%Y%m%d_%H%M%S')
#sDate00 = dtT00.strftime('%d.%m.%Y')
#print('start program: ' + sT00)
#
#
#### Special query from DB from 2019-10-23, see emails: collect af-data for
#### der bc_t_00917 
#
#db = 'cmrblba_bc_t_00917'
#
#
#
#
#
#
#
#    
#print('end')