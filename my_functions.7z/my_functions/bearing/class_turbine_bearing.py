# -*- coding: utf-8 -*-
"""
class for turbine for bearing damage investigations

Created on Thu Dec  6 2018
last modified: 2020-1-2

@author: Christian Kuehnert (w012028)


Properties:
-----------
    
    
"""

    
#from myFunctions_data import combine_filters\
import pandas as pd
import numpy as np
import datetime as dt
import gc
import sys
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from mpl_toolkits.axes_grid1 import make_axes_locatable
from scipy.signal import savgol_filter
from statsmodels.formula.api import ols



sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\von_Sebastian\wms\dbs'
sys.path.append(sModulePath)
from wms.dbs import hdf5

#sModulePath = r'D:\arbeit\selbstaendigkeit\projekte\WeidmuellerMonitoringSystems\entwicklung\python_repository\functions'
sModulePath = r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\Repositories\python\my_functions'
sys.path.append(sModulePath)    

import data as mfdata
from class_turbine import turbine
import monitor as mfmon
#import plot as mfplot
import plot.myFunctions_plot as mfplot

sys.path.append(r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\aerodynUnwucht')
from functions_aeroImb import collect_hd5_data, load_data_multiple_hd5files


#dict_channels = {'edge': ['e_101_edge', 'e_102_edge', 'e_103_edge'],
#                 'flap': ['e_101_flap', 'e_102_flap', 'e_103_flap']}

#all_channels = [item for sublist in dict_channels.values() for item in sublist]



"""
class for calculating the offset values

2019-9-24
"""

TODO 2020-7-6: an neue Version der turbine-Klasse anpassen!!!
class turbine_bearing(turbine):

    dict_channels = {'edge': ['e_101_edge', 'e_102_edge', 'e_103_edge'],
                     'flap': ['e_101_flap', 'e_102_flap', 'e_103_flap']}

    stf = '%d.%m.%Y %H:%M:%S'   # datetime string format


    """
    initialization
    
    Christian Kuehnert, 2019-9-19
    
    for offset calculation some more information are necessary then for e.g. 
    sensor failure classification
    
    """
    def __init__(self,
                 farm = None,
                 name = None,
                 db = None,
                 begin_data = None,
                 begin_operational = None,
                 manufacturer = None,
                 wtg_type = None,                    # WEA-Typ
                 system_type = None,              # Systemart (BC, V, ...)
                 tickets = pd.DataFrame(), 
                 path_hd5 = '',
                 band = [150, 350],
                 map_channels = {0: 'e_101_flap',
                                 1: 'e_102_flap',
                                 2: 'e_103_flap',
                                 3: 'e_101_edge',
                                 4: 'e_102_edge',
                                 5: 'e_103_edge'},                
                 start_time = None,
                 end_time = None,
                 cols_cdef = ['omega_mean', 'pitch_mean', 'power_mean', 'temperature_mean', 
                              'wind_mean', 'omega_sigma', 'power_sigma', 
                              'pitch_sigma', 'cyc_status_eval']):
                                
        turbine.__init__(self, farm = farm, name = name, db = db, 
                         wtg_type = wtg_type, manufacturer = manufacturer,
                         begin_data = begin_data, 
                         begin_operational = begin_operational,
                         tickets = tickets, path_hd5 = path_hd5,
                         map_channels = map_channels)
        
        #self.current_prefs = self.get_current_prefs()
        self.get_sens_status()

        self.band = band         # frequency range for which the offset will
                                 # be calculated
        self.df_se = None
        self.content = {}
        
        self.start_time = start_time            
        self.end_time = end_time
        
        self.cols_cdef = cols_cdef
        self.exclude_channels = []
        
        self.exclude_periods = {}

        #self.offsets_old = []
        
        
        
        
    """
    set times
    2019-9-19
    """
    def set_times(self, start_time, end_time):
        self.start_time = start_time
        self.end_time = end_time
 


    """
    set exclusion periods (e.g. periods of sensors failures)
    2020-1-2
    """
    def set_exclude_periods(self, dict_exclude_periods):
        self.exclude_periods = dict_exclude_periods
 
    

    """
    exclude channels
    2019-9-24
    """
    def exclude_channels(self, exclude):
        self.exclude_channels = exclude




    """
    function to get list of channels from channel dictionary
    2019-9-24
    """
    def get_channel_list(self, dict_channels=dict_channels):        
        return([el for sublist in dict_channels.values() for el in sublist])


    
    """
    function to return dictionary with the not-exluded channels
    2019-9-24
    """
    def remaining_channels(self):
#        exc = self.exclude_channels
#        dci = self.dict_channels.items()
#        tmp = {k: list(set(v)-set(exc)) for k, v in dci}
#        
        return({k: sorted(list(set(v)-set(self.exclude_channels))) for k, v in 
                self.dict_channels.items()})
        
        



    """
    get relevant prefs
    
    Christian Kuehnert, 2019-9-24
    """
    def get_sens_status(self, include_all=True):
        
        #dict_prefs = mfdata.get_preferences(db)
        try:
            self.get_preferences()
            
            if include_all:
                chs = self.get_channel_list(self.dict_channels)
            else:
                chs = self.get_channel_list(self.remaining_channels())
                
            
            #'e_101_edge'
            activity = [self.prefs[f"Sensor.Blade#{ch.replace('e_10','').replace('_edge', '.Edge').replace('_flap', '.Flap')}@Activity"] for ch in chs]
            #offsets = [self.prefs[f"Sensor.Blade#{ch.replace('e_10','').replace('_edge', '.Edge').replace('_flap', '.Flap')}@Offset"] for ch in chs]
            offsets = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}Offset"] for ch in chs]
            warnlevel = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}WarnLevel"] for ch in chs]
            alarmlevel = [self.prefs[f"Sda10{ch.replace('e_10','').replace('_edge', 'Edge').replace('_flap', 'Flap')}AlarmLevel"] for ch in chs]
                        
            #activity = [self.prefs[f'Sensor.Blade#{i}.Edge@Activity'] for i in range(1,4)] + [self.prefs[f'Sensor.Blade#{i}.Flap@Activity'] for i in range(1,4)]
            #offsets = [self.prefs[f'Sensor.Blade#{i}.Edge@Offset'] for i in range(1,4)] + [self.prefs[f'Sensor.Blade#{i}.Flap@Offset'] for i in range(1,4)]
            #warnlevel = [self.prefs[f'Sda10{i}EdgeWarnLevel'] for i in range(1,4)] + [self.prefs[f'Sda10{i}FlapWarnLevel'] for i in range(1,4)]
            #alarmlevel = [self.prefs[f'Sda10{i}EdgeAlarmLevel'] for i in range(1,4)] + [self.prefs[f'Sda10{i}FlapAlarmLevel'] for i in range(1,4)]
            #self.offsets_old = dict(zip(chs, offsets))
                               
            df = pd.DataFrame({'activity': activity, 
                               'offsets': offsets,
                               'warnlevel': warnlevel,
                               'alarmlevel': alarmlevel}, 
                                index=chs)
        
            self.sens_status = df
            
        except Exception:
            self.sens_status = None
            #self.offsets_old = {}
#        
#        return(df)
    


        
        
    """    
    get the relevant tickets for the offset data period and the channels, for 
    which these tickets are relevant 
    
    2019-9-24
    """
    def check_channels(self, include_all=True):

        map_inv = {v:k for k,v in self.map_channels.items()}

        if include_all:
            chs = self.get_channel_list()

        else:
            chs = self.get_channel_list(self.remaining_channels())
            map_inv = {k:v for k,v in map_inv.items() if k in chs}
            
        
        res = {ch: None for ch in chs}
        
        ## get tickets for the channels without regarding the period
        dfTksCrit, dict_ch_tks = mfmon.get_relevant_tickets(self.tickets, 
                                                    sType = 'all_rbl_related')
                                                        
        for ch in chs:
            [bFail, dfRelTickets] = dict_ch_tks[map_inv[ch]]
            if bFail:
                df = dfRelTickets[((dfRelTickets.dtFirstOcc <= self.end_time) & \
                        (~(dfRelTickets.sStatus=='erledigt')) | \
                        (dfRelTickets.dtErrorFixed >= self.start_time))]
            
                if df.shape[0]>0:
                    res[ch] = df
                                    
        return(res, dfTksCrit)






#    """
#    save sda-data to split hd5-files
#    
#    @modified: 2019-9-19
#    """
#    def collect_data_hd5(self):
#                
#        collect_hd5_data(self.path_hd5, self.db, 
#                         period = (self.start_time, self.end_time))
        



#    """
#    function to load the data from the multiple hd5-files and combine them and 
#    -if this option is selected- adjust the signal energy   
#    
#    @modified: 2019-12-5
#    
#    """
#    def load_data_from_hd5(self, channels=None, filters={}):
#                
#        if channels is None:
#            channels = self.get_channel_list(self.remaining_channels())    
#        
#        self.df_se = load_data_multiple_hd5files(self.path_hd5, self.db, 
#                                                 channels, self.cols_cdef,
#                                                 (self.start_time, 
#                                                  self.end_time),
#                                                 filters = filters, 
#                                                 band = self.band)
#
    
  
    
    """
    function to collect and combine the se and status data for offenbach 
    for GE challange from 2019-12-9
    -one part of the data is in the hd5-files on W: drive created by DS
    -another part of the data is collected by a script by SB on 2019-12-9
    
    Here both will be loaded, filtered, band-filtered, combined, duplicates 
    deleted.

    
    dict_folder: dictionary like {'W:/db/_current': ('2016-01-01, '2017-5-3')}
    containing the folders and the period for which the data should be retrieved
    from that folder, duplicates will be dropped anyway, but a good selection
    of periods may save time

    
    @author: CK
    @modified: 2019-12-9
    
    """
#    def load_data_from_hd5_analysisOffenbach20191119(self, dict_folders, 
#                                                     band = [150,349],
#                                                     filters = None):
#    
#        bw = band[1]-band[0]
#
#        for folder_hd5, time_interval in dict_folders:
#            loader = hdf5.SDALoader(folder_hd5, fband=fband)
#            tmp = loader.load(time_interval)
## HIER WEITER 2019-12-9            df = 
# 
#
#        
#        try:    
#            ## TODO 2019-11-26: eleganter machen
#            if (period is None):
#                cls_sed = weadbs.SEData.from_hdf(fn_hd5)
#            else:
#                if (period == (None, None)):
#                    cls_sed = weadbs.SEData.from_hdf(fn_hd5)
#                else:
#                    # TODO 2019-9-19: Zeitauswahl vorverlegen vor die multiple files und nur die auswaehlen, die im Zeitraum liegen!
#                    cls_sed = weadbs.SEData.from_hdf(fn_hd5, where={'create_time': period})
#                
#            df_cdef = cls_sed[1].loc[:, cols_cdef]
#            
#            # drop na if requested
#            if how:
#                df_cdef.dropna(how=how, inplace=True)
#                
#            
#            # filter data
#            if len(filters)>0:
#                btmp = pd.concat([df_cdef.loc[:, k].between(v[0], v[1]) for k,v in 
#                                  filters.items()], axis=1).all(axis=1)
#                df_cdef = df_cdef[btmp]
#            
#            if df_cdef.shape[0]>0:
#                            
#                df_se = cls_sed.agg_freq(band).se.dropna() / bw
#                # filter for limit se
#                if limit_se:
#                    df_tmp = cls_sed.agg_freq([0,500]).se / 498
#                    btmp = df_tmp.loc[:, channels].between(limit_se[0]/498, limit_se[1]/498).any(axis=1)
#                    df_se = df_se[btmp]
#                    
#                df_se.columns = df_se.columns.levels[0]
#
#                # append to list of df for each file
#                list_df.append(pd.merge(df_cdef.loc[:, cols_cdef], df_se.loc[:, channels], 
#                                        on='create_time'))    #  'j' for 'joined'
#                
#        except:
#            #print(f'Problem beim Einlesen von {fn_hd5}')
#            list_problem_files.append(fn_hd5)  # koennte ggf. noch ausgegeben werden, erstmal weggelassen
#
#
#    if len(list_problem_files)>0:
#        print('Problem beim Einlesen von ' + ', '.join(list_problem_files))
#        
#        
#    ## combine all data from the files with parts of the data
#    if len(list_df)>0:
#        df = pd.concat(list_df)
#
#        if b_adjust_se:
#            df = adjust_se(db, df)
#
#    else:
#        df = pd.DataFrame(columns = cols_cdef + channels)
#        
#    del list_df                
#    gc.collect()
#    
#    
#
#
#
#       
#        return(res)

        
        

    """
    function to compare the times before and after the blade bearing exchanges
    
    @modified: 2019-12-9    
    """
    def plot_comparison_exchange():
        pass
    
    


    
    """
    function to calculate parameters for regression model
    SE ~ P, T, t
    
    @modified: 2019-12-9
    """
    def reg_model(df, list_regressors, period, channels):

        s_regressors = '+'.join(list_regressors)
        
        # if time is regressor then create column with time
        if 't' in list_regressors:
            df = df.assign(t=df.index)
                                                
        # regression for all channels
        dict_res = {}
        for ch in channels:
                
            s_model = f'{ch} ~ {s_regressors}'
            #df_ok[ch] = df_ok[ch]/5
                
            df = df.loc[:, list_regressors + [ch]]
    
            fit = ols(formula = s_model, data = df).fit()
                
            dict_res.update({ch: fit.summary})
    
    
        return(dict_res)
    



        
        
    """
    plot ts of relative signal energy
    2019-12-5
    
    """
    def plot_ts_rel(self, df, direction, sband,path_save, fn_img, 
                    wdw_size=None, x_lim = None, y_lim = None, title=None):

        if df.shape[0] > 0:
            ctime = df.index
            cols_se = df.columns
            
            colormap = {'e_101_edge': 'red',
                        'e_102_edge': 'blue',
                        'e_103_edge': 'green',
                        'e_101_flap': 'red',
                        'e_102_flap': 'blue',
                        'e_103_flap': 'green'}
            
            # diagram for se without offsets
            fn_img_full = f'{path_save}\\{fn_img}'
            #title = f'SE {direction}, {mode} offsets (n={df.shape[0]})'
                
            if not(wdw_size is None):
                tmp = savgol_filter(df, wdw_size, 2, axis=0)
    
                list_se = [(ctime, tmp[:,i], 
                        {'ls': '-', 'color': colormap[df.columns[i]]}) for i 
                            in range(len(df.columns))]
            else:
                list_se = [(ctime, df.loc[:, c].values, 
                        {'ls': '-', 'color': colormap[c]}) for c in df.columns]
    

            if (title is None):
                title = f'SE {direction}, {sband}, without offsets'
                if not(wdw_size is None):
                    title = title + f', window size = {wdw_size}'

    
            mfplot.myplot(fn_img_full, list_se, s_title = title, 
                          legend = cols_se.to_list(), 
                          y_lim = y_lim, x_lim = x_lim,
                    sYLabel = f'SE({sband}), {direction}, without offsets')
        
 
