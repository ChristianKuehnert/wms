# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 07:55:58 2019

@author: christian
"""

    

from numpy import cumsum
from collections import Counter

def detect_plateaus(series, value):
    
    indicators = list(map(int, [not(at==value) for at in [value-1] + series]))
    groups = cumsum([i for i in indicators])
    lengths = [v-1 for v in dict(Counter(groups)).values() if v>1]
        
    return(lengths)
