# -*- coding: utf-8 -*-
"""
function to detect plateaus at the minimal or maximal values of a series
NOTE: at present designed for integer series because == not uses tolerance 
(which might cause problems in case of float values)



Created on Wed Mar 20 15:05:49 2019

@author: w012028
@modified: 2019-3-21

"""
from . import detect_plateaus

def detect_extreme_plateaus(time_series, bInt = True):
    
    if bInt:
        time_series = time_series.astype(int)
        
    # for max-values:    
    v_min = min(time_series)
    v_max = max(time_series)
    
    plateaus_min = detect_plateaus(time_series, v_min)
    plateaus_max = detect_plateaus(time_series, v_max)
    
    
    if len(plateaus_min)==0:
        longest_plateau_min = 0
        count_min = 0
    else:
        longest_plateau_min = max(plateaus_min)
        count_min = sum(plateaus_min)
        
        
    if len(plateaus_max)==0:
        longest_plateau_max = 0
        count_max = 0    
    else:
        longest_plateau_max = max(plateaus_max)
        count_max = sum(plateaus_max)
        
    
    #return({v_min: detect_plateaus(time_series, v_min), v_max: detect_plateaus(time_series, v_max)})
    return([len(time_series), v_min, longest_plateau_min, count_min, v_max, longest_plateau_max, count_max])    
    