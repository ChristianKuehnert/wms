# -*- coding: utf-8 -*-
"""
function to create a column that labels if the time series belongt to time after repair (1) or not (0)


# example for dict_repair_date:
dict_repair_date = {('cmrblba_bc_t_02848', 0): dt.datetime(2019,2,26,11,35),
                    ('cmrblba_bc_t_02803', 2): dt.datetime(2019,3,1,16,30)}


Created on Wed Mar 20 17:40:47 2019

@author: w012028

"""
import numpy as np
def set_label_repaired(df, dict_repair_date):
    
    ## set label for 'is repaired or not', if no repair date is given, the label will be set to None
    if not('label_repaired' in df.columns):
        df = df.assign(label_repaired = np.tile(None, (df.shape[0],1)))
        
        for (db, ch), dt_change in dict_repair_date:
            df = df[(df.database==db) & (df.channel==ch)]            
            label = (df.create_time >= dt_change)
            
            # TODO 2019-3-18: durch aktuelle Methode ersetzen, set_value deprecated
            df.set_value(df.index, 'label_repaired', label)
            
    return(df)
