# -*- coding: utf-8 -*-
"""
function to detect plateaus at the minimal or maximal values of a series
NOTE: at present designed for integer series because == not uses tolerance 
(which might cause problems in case of float values)



Created on Wed Mar 20 15:05:49 2019

@author: w012028
"""
from detect_plateaus import detect_plateaus

def detect_extreme_plateaus(time_series):
    
    # for max-values:    
    v_min = min(time_series)
    v_max = max(time_series)
    
    return({v_min: detect_plateaus(time_series, v_min), v_max: detect_plateaus(time_series, v_max)})
    
    
    

    