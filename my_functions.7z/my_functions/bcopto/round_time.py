# -*- coding: utf-8 -*-
"""
function to round the 'time' in the given df to the given precision


@author: Christian Kuehnert
@last_modified: 2019-4-4


"""
import datetime as dt

def round_time(df, time_column = 'time', precision = 10):
	return(df.loc[:, time_column].apply(lambda x: dt.datetime.fromtimestamp(round(x.replace(tzinfo=dt.timezone.utc).timestamp()*precision)/precision, tz=dt.timezone.utc)))

    