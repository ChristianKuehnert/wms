# -*- coding: utf-8 -*-
"""
function to smooth the data by savgol filtering

Created on Tue Nov  5 17:26:03 2019
@author: w012028
@modified: 2019-11-5

"""
from scipy.signal import savgol_filter

def smooth_data(df, wdw_size = 1001):

    df['data'] = savgol_filter(df['data'], wdw_size, 2)
    return(df)
