# -*- coding: utf-8 -*-
"""
function to combine the data in the in separated files for each variable and store all in a new hd5-file


Created on Tue Mar 26 00:59:40 2019

@author: christian kuehnert
@last modified: 2019-11-5

"""

import os
import h5py
import pandas as pd
import gc
from data import read_hd5_attributes


def combine_data(path_data, file_names=None, db='cmrblba_bc_t_skw001'):
   
    #sInfo = 'Husum, Prototyp SkyWind (001 AccelMems) (' + sDB + ')'
            
    # NOCH GENERISCHER:
    # - GENERELL ALLES AUF DIE CHANNEL-NAMEN (HS_Px) USW. UMSTELLEN!
    # - ERSTMAL ALLE KEYS BESTIMMEN SAMT STARTZEITPUNKTEN UND FILES
    # - UNION UEBER ALLE KEYS MACHEN
    # - DANN LOOP UEBER DIE KEYS, FILES SORTIEREN NACH STARTZEITPUNKT, DATUM ANHAENGEN
    # - DANN ABSPEICHERN IN KEY
    # TODO 2019-5-10: evtl. statt nach key nach der channel_info gruppieren und zusammenfassen, aber vielleicht ist es besser so!?
    if file_names is None:
        file_names = [s for s in os.listdir(path_data) if not os.path.isdir(path_data + '\\' + s)]    
        
    file_names_full = [path_data + '\\' + s for s in file_names]
    dict_hd5_stores = {s: h5py.File(s) for s in file_names_full}      # create stores and save in dictionary to avoid open repeatedly again later


    ## TODO 2019-5-10: noch vektorisieren   
    attrs = []
    for fn in file_names_full:
        channel_attrs = read_hd5_attributes(f'{fn}', plain=False)        # channel attributes of the current hd5-file
        tmp = [(k, fn, channel_attrs[(k, fn)]['idx'], channel_attrs[(k, fn)]['channel info'], channel_attrs[(k, fn)]['freq'], channel_attrs[(k, fn)]['start time stamp']) for (k, fn) in channel_attrs.keys()]
        df = pd.DataFrame.from_dict(tmp)
        attrs.append(df.rename(columns={0: 'channel', 1:'fn_hd5', 2: 'idx', 3: 'channel_info', 4: 'freq', 5: 'start_time'}))
        
    df_attrs = pd.concat(attrs, axis=0, ignore_index=True)
    df_attrs['start_time'] = pd.to_datetime(df_attrs['start_time'], errors='coerce')
    df_attrs['channel'] = df_attrs['channel'].astype(str)
    df_attrs['fn_hd5'] = df_attrs['fn_hd5'].astype(str)
    df_attrs['idx'] = df_attrs['idx'].astype(int)
    df_attrs['channel_info'] = df_attrs['channel_info'].astype(str)
    df_attrs['freq'] = df_attrs['freq'].astype(int)
    
    fn_attrs = f'{path_data}\\attributes.csv'      # name of file to save
    try:
        df_attrs.to_csv(fn_attrs, sep=';', index=False, encoding='cp1252')
    except:
        print(f'could not save attributes file {fn_attrs}')

    #groups_attr = df_attrs.groupby(['channel_info'], axis=0)
    groups_attr = df_attrs.groupby(['channel'], axis=0)

    # TODO 2019-5-10: Hier noch testen, ob die df-s in den Gruppen auch homogen bzgl. channel_info, index usw. sind!, ggf. abbrechen
    
    
    fn_res = f'{path_data}\\{db}__combined__{df_attrs.start_time.min().strftime("%Y%m%d_%H%M%S")}.hd5'
    with pd.HDFStore(fn_res, 'a', complevel=9, complib='blosc:lz4') as g:        # create empty hd5-file                    
        
        # save parameters etc.
        gk = g.keys()
        if not('attributes_original_files' in gk):
            g.put('attributes_original_files', df_attrs, format='table')
                             
        
        lKeys = list(set(groups_attr.groups.keys()) - set(['attributes_original_files']))
        
        # TODO 2019-5-10: besser waere folgendes, aber noch richtigen weg dazu finden
        #lKeys = list(set(groups_attr.groups.keys()) - set(gk))
        #groups_attr = [groups_attr[k] for k in lKeys]
        #for gr, df_gr in groups_attr:

        j=0
        sN = str(len(lKeys))
        for key in lKeys:        
                                               
            j += 1        
            print(f'{j}/{sN}: {key}')
                                                    
            ## if the key not yet exists
            if ('ch'+key in g.keys()):
                print('   already exists')
            
            else:
                
                lTmp = []
                lTime = []
                iN = 0
                df_gr = groups_attr.get_group(key)
                
                #df_gr.sort_values(by=['start_time'], inplace=True)
                #for i, row in df_gr.iterrows():
                for i, row in df_gr.sort_values(by=['start_time']).iterrows():
                    fn = row['fn_hd5']
                    freq = row['freq']
                    start_time = row['start_time']
                        
                    f = dict_hd5_stores[fn]
                    #tmp = f[key].value
                    tmp = f[key][()]
                    #tmp = dict_hd5_stores[fn][key].value
                    n = tmp.shape[0]
                    iN += n
                    time = start_time + pd.to_timedelta(pd.Series(range(n))/freq, unit='s')
                    lTmp.append(pd.Series(tmp[:,0]))
                    lTime.append(time)
                                        
                values = pd.concat(lTmp, axis=0, ignore_index=True).reset_index(drop=True)
        
                df = pd.DataFrame.from_records({'time': pd.concat(lTime).reset_index(drop=True),
                                                'data': values}).loc[:, ['time', 'data']]
                #df['time'] = pd.to_datetime(df['time'], errors='coerce')                                                                                  
                            
                del time
                del tmp
                del lTime
                del lTmp
                
                g.put('ch' + str(key), df, format='table', data_columns=True, index=False)
                #g.append('ch'+key, df, format='table', data_columns = True, index=False)
                                
                del df
                del values
                gc.collect()
    
    [dict_hd5_stores[s].close() for s in file_names_full]      # create stores and save in dictionary to avoid open repeatedly again later
