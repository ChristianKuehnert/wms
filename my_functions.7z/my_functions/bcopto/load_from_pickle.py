# -*- coding: utf-8 -*-
"""

function to load pickled data
NOT very generic function, implemented for BCOpto

Created on Tue Apr  2 13:58:12 2019

@author: w012028
"""

import pandas as pd
try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle


def load_from_pickle(file_name, list_cols=None, start_time=None, end_time=None):
    df = pd.read_pickle(file_name)
        
    
    if isinstance(list_cols, str):
        list_cols = [list_cols]
    
    if list_cols:
        if not('create_time' in list_cols):
            list_cols = ['create_time'] + list_cols
        
        df = df.loc[:, list_cols]
    
    
    if start_time:
        df = df[df.create_time>=start_time]
        
    if end_time:
        df = df[df.create_time<=end_time]
        
    return(df)
