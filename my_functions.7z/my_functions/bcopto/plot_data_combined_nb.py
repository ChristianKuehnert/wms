# -*- coding: utf-8 -*-
   
"""
function to plot the data for the given channels in one diagram

Created on Wed Feb 20 10:42:37 2019

@author: Christian Kuehnert
@last_modified: 2019-11-4


# Bsp:
fn_hd5 = 'cmrblba_bc_t_skw001__combined__20190302_020917.hd5'


"""
import pandas as pd
import numpy as np
import gc
import matplotlib.pyplot as plt  
#from textwrap import wrap
from textwrap import fill
from sklearn.preprocessing import minmax_scale
from scipy.signal import savgol_filter


#import fnmatch
#from os import listdir
from plot import myFunctions_plot as mfplot
from bcopto import get_data_simpleVersion
from bcopto import get_data_scaled
#import bcopto.get_data_simpleVersion


def plot_data_combined_nb(fn_hd5, dict_channels, dict_rates, 
                       list_channels=None,
                       start_time = None,
                       end_time = None,
                       bRemoveOutliers=False,                                             
                       bScale = None,
                       wdw_size = None,   # window-size (must be odd) for smoothing with savgol
                       fn_img = None, 
                       title = 'Husum, Prototyp SkyWind',
                       ylabel = '',
                       ylim = [],
                       colors = None):

                         
    iAxisLabelSize = 16
    iLegendSize = 16
    iFontSize = 18

    #default_dict_style = {'linestyle': '-', 'marker': 'None'}
    
    
    dThresFactor = 3           # prefactor (with sigma) to exclude outliers, only relevant if bRemoveOuliers==True
                
    leg = []
    
    
    if bRemoveOutliers:
        sOL = ', w/o outliers'
    else:
        sOL = ', with outliers'

    sXLabel = 't'

    if (colors is None):
        colors = mfplot.provideColors()


    bSmooth = not(wdw_size is None)
    if bSmooth:
        sOL = f'{sOL}, smoothed with window size {wdw_size}'


    
    with pd.HDFStore(fn_hd5, mode="a", complevel=9, complib='blosc:lz4') as f:            #f = h5py.File(sFN_hd5)
        lKeys = list(f.keys())
            
    if not(list_channels is None):
        tmp = ['/ch' + str(c) for c in list_channels]
        lKeys = [k for k in tmp if k in lKeys]
    else:                              
        lKeys = list(set(lKeys)-{'/file_names','/dict_channels','/dict_rates'})
    #lKeys = list(set(lKeys)-set(['/ch'+str(x) for x in [0,1,2,10,11,18]]))

    sN = str(len(lKeys))
    i=0
    
    #list_data = []
    
    
    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111)
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    if isinstance(sXLabel, str):
        plt.xlabel(sXLabel, fontsize = iFontSize)
        
    if isinstance(ylabel, str):
        plt.ylabel(ylabel, fontsize = iFontSize)
   
    
    if len(ylim)==2:
        plt.ylim(ylim)

    
    for chkey in lKeys:
    
        key = chkey.replace('ch', '').replace('/', '')
        
        sKey = ' ('.join(dict_channels[key][2:0:-1]) + ')'
        
        #senstype = dict_channels[key][1]            
        #fac = dict_rates[senstype]['rate']
        #unit = dict_rates[senstype]['unit']
        #freq = dict_rates[senstype]['freq']
        unit = dict_channels[key][0]
        
        #leg.append(f'{key}, {sKey}')     # append current channel with 
        #                                    # unit to legend
        leg.append(f'{key}, {unit}, {sKey}')     # append current channel with 
                                            # unit to legend
        if bScale:
            df = get_data_scaled(fn_hd5, key, start_time, end_time,
                                 dict_channels=dict_channels,
                                 dict_rates=dict_rates)
        else:                                                
            df = get_data_simpleVersion(fn_hd5, key, start_time, end_time)
       


        values = df.data
        time = df.time

        del df
        gc.collect()
        
        ## remove outliers if required
        # TODO 2019-10-22: vielleicht innerhalb des df machen, um doppelte
        # Daten zu vermeiden
        if bRemoveOutliers:        
            btmp = (abs(values - np.mean(values)) <= dThresFactor * 
                    np.std(values))
            #btmp = (tmp >= np.percentile(tmp, 0.5)) & (tmp <= np.percentile(tmp, 99.5))
            values = values[btmp]
            time = time[btmp]

            del btmp
            gc.collect()


        if bSmooth:
            values = savgol_filter(values, wdw_size, 2)

        plt.plot(time.dt.time, values, **{'color': colors[i], 'marker': 'o', 
                                        'linestyle': '-', 'markersize': 2, 
                                        'linewidth': 1})

        del values
        del time
        gc.collect()
             
        print(str(i) + '/' + sN + ': ' + key + ', ' + sKey)
        i += 1        
                
    plt.legend(leg, fontsize=iLegendSize)


    if not(title is None):
        iFontSizeTitle = 22
        title = ax.set_title(fill(title, int(round(120/iFontSizeTitle*12))), 
                             fontsize=iFontSizeTitle)    
        title.set_y(1.05)
        #fh.subplots_adjust(top=0.8)
        fh.subplots_adjust(top=0.9)
        fh.tight_layout()
        
        
    plt.grid(True)
        
    plt.tick_params(axis='both', which='major', labelsize=iAxisLabelSize)

    fh.subplots_adjust(top=0.9)
    fh.tight_layout()
    
    #mpl.rcParams['agg.path.chunksize'] = 10000
    if not(fn_img is None):
        fh.savefig(fn_img, dpi=350)
        plt.close(fh)
    else:        
        plt.show()
                        
      






