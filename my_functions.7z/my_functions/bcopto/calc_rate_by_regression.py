# -*- coding: utf-8 -*-
"""

function that calculates the rate between the given values by regression
y = \beta_0 + \beta_1 * t

The first column of df must contain the time in a format to which .dt.seconds is applicable


Created on Tue Apr 30 16:10:00 2019

@author: w012028
"""

# e aus den Betriebsdaten
# Details-Darstellung bei 'Pitch, Details 2'
#import pandas as pd
import statsmodels.api as sm
#import datetime as dt


def calc_rate_by_regression(df):
    
#HIER WEITER 2019-4-30 - RICHTIG MACHEN (GGF. NOCH GENERISCHER, Z.B. 'creata_time' als default-Wert uebergeben und fuer die anderen Groessen dann die Raten berechnen (entweder getrennt oder optional auch gemeinsam))    
    #print(type(df))
    tmp = df.iloc[:, 0]
    #print(type(tmp))
    X = (tmp - tmp.iloc[0]).dt.total_seconds()
    
    X = sm.add_constant(X)
    
    model = sm.OLS(df.iloc[:, [1]], X)
    
    results = model.fit()
    #print(results.summary())

    rate = results.params[1]    # rate
    
    return({'rate': rate, 
            'results': results})
#   return(1)