# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import gc
   
"""
function to plot the data for the given channels in one diagram

Created on Wed Feb 20 10:42:37 2019

@author: Christian Kuehnert
@last_modified: 2019-4-30


"""
import fnmatch
from os import listdir
from plot import myFunctions_plot as mfplot
import bcopto.get_data_simpleVersion

def plot_data_combined(dict_channels, dict_rates, path_data, path_save, db='cmrblba_bc_t_skw001', farm='Husum', turbine='Prototyp SkyWind', int_list_channels=None, bTable=False, bRemoveOutliers=False):

    dThresFactor = 3                                # prefactor (with sigma) to exclude outliers, only relevant if bRemoveOuliers==True
    
    info = farm + ', ' + turbine + '(' + db + ')'
                    
    sFN = fnmatch.filter(listdir(path_data), db + '__combined__*.hd5')[0] 
    # TODO 2019-3-6: evtl. noch Fall ausschliessen, dass mehrere solche Files im Verzeichnis vorkommen
        
    if sFN:
        
        print(sFN)
                                                                        
        sFN_hd5 = path_data + '\\' + sFN
                           
        with pd.HDFStore(sFN_hd5, mode="a", complevel=9, complib='blosc:lz4') as f:            #f = h5py.File(sFN_hd5)
            lKeys = list(f.keys())
            
            if int_list_channels:
                tmp = ['/ch' + str(c) for c in int_list_channels]
                lKeys = [k for k in tmp if k in lKeys]
            else:                              
                lKeys = list(set(lKeys)-{'/file_names', '/dict_channels', '/dict_rates'})
            #lKeys = list(set(lKeys)-set(['/ch'+str(x) for x in [0,1,2,10,11,18]]))

            sN = str(len(lKeys))
            i=0
            
            if bTable:
                lTab = []

            dict_data = {}
            for chkey in lKeys:

                i += 1        
                
                key = chkey.replace('ch', '').replace('/', '')
                
                sKey = ' ('.join(dict_channels[key][2:0:-1]) + ')'
                print(str(i) + '/' + sN + ': ' + key + ', ' + sKey)
                
                senstype = dict_channels[key][1]            
                #fac = dict_rates[senstype]['rate']
                unit = dict_rates[senstype]['unit']
                #freq = dict_rates[senstype]['freq']
                                            
                df = mfbco.get_data_simpleVersion(sFN_hd5, chkey)
                #df = get_data(sFN_hd5, chkey)
                                
                values = df.data
                time = df.time
                #n = values.shape[0]
                                   
                ## remove outliers if required
                if bRemoveOutliers:
                    sOL = ', w/o outliers'
                    btmp = (abs(values - np.mean(values)) <= dThresFactor * np.std(values))
                    #btmp = (tmp >= np.percentile(tmp, 0.5)) & (tmp <= np.percentile(tmp, 99.5))
                    values = values[btmp]
                    time = time[btmp]
                    del btmp
                    gc.collect()
                    
                else:
                    sOL = ', with outliers'

                                                    
                #values = values / fac                
                #print(str(type(tmp)) + ', shape=' + str(tmp.shape))
                #dictKeys.update({key: sKey, 'length': tmp.shape[0]})
                if bTable:
                    lTab.append([key, sKey, values.shape[0]])


                    
                #sFN_img = sPathData + '\\' + sFN_full.split(sep=".")[0] + '_key' + key + '.png'
                sFN_img = path_save + '\\' + sFN.replace('\\', '__').replace('.hd5','') + '__key' + key + '.png'
                #dX = pd.Series(range(len(values)))/freq
                sTitle = info + ', ch.' + key + ': ' + sKey + sOL
                sXLabel = 't'
                sYLabel = 'ch.' + key + ': ' + sKey + ' [' + unit + ']'
                #dXLim = []
                #dYLim = []
                #dXTicks = []
                #dYTicks = []
                #sLineTypes = []
                #sLegends = 'key ' + str(key)
                #lColors = ['green']

                #dict_data.update({key: [time.dt.time, values, {'color': 'green', 'marker': 'o', 'linestyle': '-', 'marker_size': 2, 'line_width': 1}]})
                dict_data = {key: [time.dt.time, values, {'color': 'green', 'marker': 'o', 'linestyle': '-', 'markersize': 2, 'linewidth': 1}]}

                #mfplot.myPlot(sFN_img, time.dt.time, {key: values}, sTitle=sTitle, sXLabel=sXLabel, sYLabel=sYLabel, colors = lColors, bLegend = False)
                mfplot.myPlot(sFN_img, dict_data, sTitle=sTitle, sXLabel=sXLabel, sYLabel=sYLabel, dXLim = None, dYLim = None, bLegend = True)

                del values
                del time
                gc.collect()
    
    
    
    
            if bTable:
                #dfKeys = pd.DataFrame.from_records([dictKeys])
                dfKeys = pd.DataFrame.from_records(lTab, columns = ['Kanal', 'Variable', 'n'])
                
                #dfIssues.sort_values(axis=0, by=['farm','wt'], inplace=True)          # sort issues by farm, wt and error message
            
                sFN_keys = path_save + '\\' + sFN.replace('\\', '__').replace('.hd5','') + '__keys.csv'                          # name of file to save
                dfKeys.to_csv(sFN_keys, 
                              sep=';', 
                              index=False, 
                              encoding='cp1252')

    