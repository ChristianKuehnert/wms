# -*- coding: utf-8 -*-
"""
Created on Mon May 13 16:08:50 2019

function to read data from hd5-file and to rescale them by the factor given in the given dicts


@author: Christian Kuehnert
@last_modified: 2019-4-30
"""
#import pandas as pd
#import sys

import bcopto.get_data_simpleVersion

#from myfunctions.data import whereClause_from_timeInterval

def get_data_scaled(file_name_hd5, channel, start_time=None, end_time=None, dict_channels=None, dict_rates=None):

    df = bcopto.get_data_simpleVersion(file_name_hd5, channel, start_time, end_time)
    
    if (not(dict_channels is None) and not(dict_rates is None)):
    
        sens_type = dict_channels[channel][1]
        scaler = dict_rates[sens_type]['rate']        

        df['data'] = df['data'] / scaler

    return(df)        
        
 