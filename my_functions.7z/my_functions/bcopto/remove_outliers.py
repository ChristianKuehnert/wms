# -*- coding: utf-8 -*-
"""
function to remove outliers from the given series

Created on Tue Nov  5 17:26:03 2019
@author: w012028
@modified: 2019-11-5

"""
import numpy as np

def remove_outliers(df, dThresFactor = 3):

    btmp = (abs(df.data - np.mean(df.data)) <= dThresFactor * np.std(df.data))
    #btmp = (tmp >= np.percentile(tmp, 0.5)) & (tmp <= np.percentile(tmp, 99.5))

    return(df[btmp])
