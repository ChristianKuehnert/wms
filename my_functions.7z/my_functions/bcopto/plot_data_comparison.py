# -*- coding: utf-8 -*-
"""

function to plot the selected data (ts and externals) for the given time interval in order to compare them


Created on Mon Apr  1 17:13:57 2019

@author: Christian Kuehnert
@modified: 2019-11-13

example:
list_channels = [0,1,2,7]    # channels of ts-data (of BCOpto-sensors)    

dict_time_intervals = {'Azimuth, Detail': ([dt.datetime(2019,3,2,3,8,25), dt.datetime(2019,3,2,3,8,41)], {'ba_cycle_externals': ['pitch', 'azimuth']}, [2, 71]),
                       'Pitch, Detail 1': ([dt.datetime(2019,3,2,3,8,55), dt.datetime(2019,3,2,3,8,57)], {'ba_cycle_externals': ['pitch', 'azimuth']}, list_channels)}
  


parameters:
-----------

- start_time:     Startzeit
- end_time:       Endzeit
- dict_ext:       dictionary mit den Externals in der Form {Tabellenname: [Spaltennamen]}
- list_channels:  list der zu zeichnenden BCOpto-TS-Kanaele
- dict_channels:  dictionary mit zu den BCOpto-TS-Kanaelen

"""

import gc
import pandas as pd
try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle

from scipy.signal import savgol_filter


#import data as mfdata
from plot import myFunctions_plot as mfplot
from plot.plot_multiple import plot_multiple
#from bcopto import get_data_simpleVersion
from bcopto import get_data_scaled


def plot_data_comparison(name_period, start_time, end_time, dict_ext, 
                         list_channels_ts, dict_channels, dict_rates, 
                         path_data, s_start= '20190302_020924', 
                         db='cmrblba_bc_t_skw001',  wdw_size = 101):

    info = f'Husum, Prototyp SkyWind (001 AccelMems) ({db})'
    file_name_hd5 = f'{path_data}\\20190302\\{db}__combined__{s_start}.hd5'
        
    
    # colors to plot        
    dict_color_map = {'Nabe': 'peru', 'HS': 'peru',
                      '1': 'orangered', 'S1': 'orangered',
                      '2': 'dodgerblue', 'S2': 'dodgerblue',
                      '3': 'lime', 'S3': 'lime'}                                                

    list_plot_data = []
    
    ## now loop through variables to be plotted
    ## 1) external data
    ## loop through ext. data
    for tab, cols in dict_ext.items():            
        df = pd.read_pickle(path_data + '\\' + db + '__' + tab + '.pkl')
        df = df[(df.create_time>=start_time) & (df.create_time<=end_time)].loc[:, ['create_time'] + cols]
        
        for col in cols:
            #list_plot_data.append([name_period + ', ' + col, {name_period + ', ' + col: [df.create_time.dt.time, df.loc[:, col], {'color': 'black', 'marker': 'o'}]}])
            list_plot_data.append([name_period + ', ' + col, {name_period + ', ' + col: [df.create_time.dt.time, df.loc[:, col], {'color': 'black', 'marker': 'None'}]}])


    ## loop through ts data
    #for ch  in list_channels_ts:      
    for key  in list_channels_ts:      
        
        dict_tmp = {}
        
        #key = str(ch)
        
        pos, senstype, sens_name = dict_channels[key]
        
        color_diag = dict_color_map[pos]
            
        ## load sensor data
        #df_sens = get_data_simpleVersion(file_name_hd5, key, 
        #                            start_time=start_time, end_time=end_time)
        df_sens = get_data_scaled(file_name_hd5, key, start_time=start_time, 
                                  end_time=end_time, 
                                  dict_channels=dict_channels, 
                                  dict_rates=dict_rates)
    
        ylabel = 'ch.' + key + ': ' + ' ' + pos + ', ' + senstype + sens_name + ' [' + dict_rates[senstype]['unit'] + ']'
        dict_tmp.update({'orig.': [df_sens.time.dt.time, df_sens.data, {'color': color_diag, 'marker': 'None', 'linestyle': '-', 'linewidth': 1}]})

        if (wdw_size is None):
            title = info + ', ' + ylabel + ' (' + color_diag + ': original data)'
        
        else:            
            title = info + ', ' + ylabel + ' (' + color_diag + ': original data, black: smoothed with window size ' + str(wdw_size) + ')'
            dict_tmp.update({'smoothed (n=' + str(wdw_size) + ')': [df_sens.time.dt.time, savgol_filter(df_sens.data, wdw_size, 2), {'color': 'black', 'marker': 'None', 'linestyle': '-', 'linewidth': 1}]})

                
        list_plot_data.append([title, dict_tmp])


        del df_sens
        gc.collect()
                    

    ## first display externals, then channels                        
    #sFN_img = f'{path_save}\\{db}__{name_period}.png'
    ##sTitle = info + ', ' + tab + ', ' + col + ' vs. ' + pos + ', ' + senstype + ', ' + sOL
    #plot_multiple(sFN_img, list_plot_data,  't [' + start_time.strftime('%Y-%m-%d') + ']' , x_lim=None, bLegend = False)
    plot_multiple(list_plot_data,  't [' + start_time.strftime('%Y-%m-%d') + ']' , x_lim=None, bLegend = False)
            
    del list_plot_data
    gc.collect()
            

