# -*- coding: utf-8 -*-
"""
Created on Sat Mar  9 00:51:13 2019

@author: christian_2
@modified: 2019-11-11
"""

__all__ = ['combine_data',
           'combine_exp_data',
           'get_data_scaled',
           'get_data_simpleVersion',
           'get_dict_channels',
           'load_from_pickle',
           'pickle_data',
           'plot_data_combined',
           'plot_data_combined_nb',
           'plot_data_comparison',
           'plot_data_comparison_comprehensive',
           'remove_outliers',
           'round_time',
           'smooth_data',
           'calc_rate_by_regression',
           'calc_cross_correlations']


from .combine_data import combine_data
from .combine_exp_data import combine_exp_data
from .get_data_simpleVersion import get_data_simpleVersion
from .get_data_scaled import get_data_scaled
from .get_dict_channels import get_dict_channels
from .load_from_pickle import load_from_pickle
from .pickle_data import pickle_data
from .plot_data_combined import plot_data_combined
from .plot_data_combined_nb import plot_data_combined_nb
from .plot_data_comparison import plot_data_comparison
from .plot_data_comparison_comprehensive import plot_data_comparison_comprehensive
from .remove_outliers import remove_outliers
from .round_time import round_time
from .smooth_data import smooth_data
from .calc_rate_by_regression import calc_rate_by_regression
from .calc_cross_correlations import calc_cross_correlations



