# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 10:56:09 2019

function to:
    - bin the data to the given angular bin width
    - calculate the given function of the data for each bin        
    - create polar plot of the resulting bin values


parameters:
-----------
    - phi:           angle, given in degrees
    - list_data:     list of data to be displayed, each element must have the
                     same length as phi
    - bin_width:     width of the bins in degrees
    - fct:           functions to be applied to the elements in list_data (the
                     results will be plottet in the polar diagram too)
    



@author: w012028
@modified: 2019-11-15
"""
import numpy as np
import pandas as pd

def create_polar_plot(phi, dict_data, bin_width_deg = 1, fct = None):
    
    pi2 = 2 * np.pi

    # reduce phi to range [0,2pi]
    if max(abs(phi))>pi2:
        phi = (phi + pi2) % pi2 - pi2
    
    dict_tmp = {'phi': phi}.update(dict_data)
    
    df = pd.DataFrame.from_records(dict_tmp)

    bwr = np.deg2rad(bin_width_deg)      
    bins = np.arange(0, pi2 + bwr, bwr)


    
    df['range'] = pd.cut(df.phi, bins, include_lowest = True)
          
    for k in dict_data.keys():
        df[f'{key}_mean'] = df.groupby('range')[key].mean()
        df[f'{key}_min'] = df.groupby('range')[key].min()
        df[f'{key}_max'] = df.groupby('range')[key].max()


HIER WEITER 2019-11-15        
    # bin values    
#    a, b = np.histogram(phi, bins=np.arange(0, 360+bin_width, bin_width))
#    centers = np.deg2rad(np.ediff1d(b)//2 + b[:-1])
    a, b = np.histogram(phi, bins=np.arange(0, pi2 + bwr, bwr))
    centers = np.ediff1d(b)//2 + b[:-1]

    fh = plt.figure(figsize=(12,9))
    ax=plt.subplot(111, projection = 'polar')
                            
    ax.get_xaxis().tick_bottom()  
    ax.get_yaxis().tick_left()   
        
    colors = mfplot.provideColors()

    #ax.bar(centers, a, width=np.deg2rad(bin_size), bottom=0.0, color='.8', edgecolor='k')
    ax.plot(centers, a, color='.8', marker = '*')
    
    #ax.set_theta_zero_location("N")
    #ax.set_theta_direction(-1)
    plt.show()
    
    



    
    list_plot = [(phi_rot_main/180*np.pi, phi1/phi1.abs().max(), color = colors[1]),
                 (phi_rot_main[mask]/180*np.pi, phi2[mask]/phi2[mask].abs().max(), color = colors[2])]
    
    list_legend = ['phi1', 'phi2']
    
    mfplot.myplot_fast(list_plot, legend = list_legend)
    
    
