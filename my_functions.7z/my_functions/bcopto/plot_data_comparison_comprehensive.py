# -*- coding: utf-8 -*-
"""

function to plot the selected externals data together with the selected time series data in order to compare them


Created on Mon Apr  1 17:13:57 2019

@author: Christian Kuehnert
@modified: 2019-11-1

"""
import gc
import pandas as pd
from collections import defaultdict
from scipy.signal import savgol_filter

from plot import myFunctions_plot as mfplot
from plot import plot_multiple
from bcopto import get_data_scaled


def plot_data_comparison_comprehensive(dict_time_intervals, dict_channels,
                                       dict_rates,
                                       fn_hd5,
                                       fn_pkl,
                                       db='cmrblba_bc_t_skw001',  
                                       wdw_size=101,
                                       path_save=None):
                 
    dict_color_map = {'Nabe': 'peru',
                      '1': 'orangered',
                      '2': 'dodgerblue',
                      '3': 'lime'}                    
                        
    # restructure the channels dictionary    
    dict_ch = defaultdict(list)
    for c,[p,t,v] in dict_channels.items():
        #if not(t is 'Temperatur') and (p in ['2','3']):
        if (t != 'Temperatur'):
            dict_ch[(p,t)].append(c)
    # TODO 2019-3-8: noch omega_mean aus measurement-cycle dazunehmen

    #list_columns = ['power', 'pitch', 'azimuth']
    info = f'Husum, Prototyp SkyWind'       

    ## create dictionary with external data in order not to unpickle them in each loop
    dict_ext = {}
    for name_period, ([start_time, end_time], dict_tabs) in dict_time_intervals.items():
        ## loop through ext. data
        for tab, cols in dict_tabs.items():            
            df = pd.read_pickle(fn_pkl)
            dict_ext.update({(name_period, tab): df[(df.create_time>=start_time) & (df.create_time<=end_time)].loc[:, ['create_time'] + cols]})


    ## now loop through variables to be plotted
    for name_period, ([start_time, end_time], dict_tabs) in dict_time_intervals.items():
        
        for (pos, senstype), list_channels in dict_ch.items():

            list_plot_data = []

            color_diag = dict_color_map[pos]
            
            ## load sensor data
            dict_data_sens = {}
            for ch in list_channels:
                #tmp = mfbco.get_data_scaled(fn_hd5, ch, 
                tmp = get_data_scaled(fn_hd5, ch, 
                                      start_time=start_time, 
                                      end_time=end_time, 
                                      dict_channels = dict_channels, 
                                      dict_rates = dict_rates)  # old version, later bcopto.get_data replaced by bcopto.get_data_simpleVersion
                
                dict_data_sens.update({ch: tmp})
                del tmp
                gc.collect()
                
            ## loop through ext. data
           
            for tab, cols in dict_tabs.items():
                df = dict_ext[(name_period, tab)]    
                for col in cols:
                    #list_plot_data.append([df.create_time.dt.time, df.loc[:, col], color_diag, col, col])
                    list_plot_data.append([name_period + ', ' + col, 
                                           {name_period + ', ' + col: 
                                               [df.create_time.dt.time, 
                                                df.loc[:, col], 
                                                {'color': color_diag}]}])
                    
                    
            for key, df_sens in dict_data_sens.items():
                            
                dict_tmp = {}
    
                ylabel = 'ch.' + key + ': ' + ' ' + pos + ', ' + senstype + \
                dict_channels[key][2] + ' [' + dict_rates[senstype]['unit'] + ']'
                
                title = info + ', ' + ylabel
                
                dict_tmp.update({'orig.': [df_sens.time.dt.time, df_sens.data, 
                                           {'color': color_diag, 
                                            'marker': 'None', 
                                            'linestyle': '-', 
                                            'linewidth': 1}]})
                
                if not(wdw_size is None):
                    title = title + ' (' + color_diag + ': original data, ' + \
                    'black: smoothed with window size ' + str(wdw_size) + ')'
                                    
                    #sOL = ', geglaettet mit window_size ' + str(wdw_size)
                    dict_tmp.update({'smoothed (n=' + str(wdw_size) + ')': 
                        [df_sens.time.dt.time, savgol_filter(df_sens.data, 
                                                             wdw_size, 2), 
                                                        {'color': 'black', 
                                                         'marker': 'None', 
                                                         'linestyle': '-', 
                                                         'linewidth': 1}]})
                
                list_plot_data.append([title, dict_tmp])

                del df_sens
                gc.collect()
                    
            ## first display externals, then channels                        
            if (path_save is None):
                sFN_img = None
            else:
                sFN_img = f'{path_save}\\{db}__{name_period}__{col}_vs_{pos}_{senstype}.png'
                
            #sTitle = info + ', ' + tab + ', ' + col + ' vs. ' + pos + ', ' + \
            #        senstype + ', ' + sOL
            plot_multiple(list_plot_data,  't [' + start_time.strftime(
                    '%Y-%m-%d') + ']' , x_lim=None, bLegend = False, 
                                file_name = sFN_img)

        del list_plot_data
        gc.collect()
        
        del dict_data_sens
        gc.collect()
            
     