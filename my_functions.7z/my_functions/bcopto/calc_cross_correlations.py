# -*- coding: utf-8 -*-
"""
Created on Tue May  7 13:20:36 2019

function to calculate and plot the cross correlations between the channels (grouped by sensor
types in order to get synchronous time series without too much effort) by the
data in the given hd5-file


@author: w012028
@modified: 2019-5-14

"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn


import bcopto.get_data_simpleVersion

# TODO 2019-10-22: so erweitern, dass channels mit unterschiedlicher Abtastrate miteinander korreliert werden koennen (werden jetzt zwar uebergeben,
# aber Korrelation wird -natuerlicherweise- nicht gebildet)
def calc_cross_correlations(fn_hd5, dict_channels, start_time = None, end_time = None, bPlot = True):
    
    ## group channels by sensor type in order to have identical times
    dfch = pd.DataFrame.from_dict(dict_channels, orient='index')
    dfch.reset_index(inplace=True)
    dfch.rename(columns={'index': 's_ch', 0: 'pos', 1: 'sens_type', 2: 'var'}, inplace=True)
    
    dict_corr = {}

    if bPlot:
        fig, ax = plt.subplots(2,2, figsize=[12,12])
        #map_sp = {0: [0, 0], 1: [0, 1], 2: [1, 0], 3: [1, 1]}

    ## loop through each group and load data for that group
    i = 0
    groups = dfch.groupby(['sens_type'])
    for gr, elements in groups:
                        
        ## combine all data from this group
        tmp = {'ch' + s_ch: bcopto.get_data_simpleVersion(fn_hd5, s_ch, start_time=start_time, end_time=end_time) for s_ch in elements.s_ch}
        
        ## attention: here assumption that all times are synchronous!
        tmp2= {k: tmp[k].data for k in tmp.keys()}
            
        df = pd.DataFrame.from_records(tmp2)
        
        df_corr = df.corr(method='pearson')
        dict_corr.update({gr: df_corr})
#        df_corr = pd.DataFrame(np.random.randint(-1,1,size=(10, 10)))
        
        
        
        if bPlot:
            ## the following code is from here:
            ## http://www.tradinggeeks.net/2015/08/calculating-correlation-in-python/, from 2019-5-7                     
            mask = np.zeros_like(df_corr)
            mask[np.triu_indices_from(mask)] = True
            # Create the heatmap using seaborn library. 
            # List if colormaps (parameter 'cmap') is available here: http://matplotlib.org/examples/color/colormaps_reference.html
            #ax[map_sp[i][0], map_sp[i][1]] = seaborn.heatmap(df_corr, cmap='RdYlGn_r', vmax=1.0, vmin=-1.0 , mask = mask, linewidths=2.5)                
            seaborn.heatmap(df_corr, cmap='RdYlGn_r', vmax=1.0, vmin=-1.0 , mask = mask, linewidths=2.5, ax=ax.flat[i])                            

            # Show the plot we reorient the labels for each column and row to make them easier to read.
            plt.yticks(rotation=0) 
            plt.xticks(rotation=90) 
            ax.flat[1].title.set_text('correlations ' + gr)
            #plt.show()
    
            i+= 1

    # TODO 2019-5-14: Anordnung der subplots noch richtig machen!        
    if bPlot:
        fig.show()

            
    return(dict_corr)