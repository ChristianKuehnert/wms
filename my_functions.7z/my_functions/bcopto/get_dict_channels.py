# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 16:22:07 2019

function to read in the attributes saved in the given file (which must have 
certain columns and can only contain certain values, not arbitrary entries) 
and transform them into the proper dictionary for further analysis

@author: w012028
@modified: 2019-11-11
"""
import pandas as pd

def get_dict_channels(fn_attributes):
    
    df = pd.read_csv(fn_attributes, sep=';', encoding = 'cp1252')
    df = df.loc[:, ['idx', 'channel_info', 'freq']].drop_duplicates()
    dict_channels = {}
    for idx, row in df.iterrows():
        ci = (row['channel_info'].replace('x', '_x').replace('y', '_y')
                                .replace('z', '_z').replace('_P', '_Piezo')
                                .replace('_M', '_MEMS, Accel.')
                                .replace('_G', '_MEMS, Gyro.')
                                .replace('_T', '_Temperatur_Temperatur')
                                .split('_'))
        
        dict_channels.update({str(row['idx']): ci})
    
    
    return(dict_channels)
    
    
    
    
    



