# -*- coding: utf-8 -*-
"""
function to read data from database and pickle them locally

Created on Tue Mar 26 01:06:19 2019

@author: Christian Kuehnert
@last_modified: 2019-4-30

TODO 2019-3-7: noch verbessern, so dass auch neue Daten appended werden koennen, vielleicht lieber alles in hd5-file schreiben!?

"""
from os.path import isfile
from os import remove
from data import query_tableData

def pickle_data(db='cmrblba_bc_t_skw001', path_data=r'M:\03-Projekte\Eis-Algorithmus-Eispeakeinstellung\500_Arbeitsunterlagen\Transfer_CK\BCOpto\data', list_tables=['ba_cycle_status', 'ba_cycle_externals', 'ba_cycle_measurement_cycle'], bOverwrite=False):   #listDBs = ['cmrblba_bc_t_skw001', 'cmrblba_bc_t_skw002', 'cmrblba_bc_t_skw003']

    dictTypes={'cycle_id': int}
    file_names = []
    for tab in list_tables:
                   
        print(tab)
                
        # pickle ba_cycle_status-Werte    
        file = path_data + '\\' + db + '__' + tab + '.pkl'
        
        try:
        
            b_do = False
            if isfile(file):
                if bOverwrite:
                    b_do = True
                    remove(file)
            else:
                b_do = True
    
                
            if b_do:
                df, sTmp = query_tableData(db, tab)
                df.dropna(axis=1, how='all', inplace=True)                
                
                ## set types, if some type dictionary is given                                        
                if dictTypes:
                    for field, ftype in dictTypes.items():
                        if field in df.columns:
                            df[field] = df[field].astype(ftype)
                
                df.to_pickle(file)               # pickle result
                
            file_names.append(file)
            
        except Exception as ex:
            print('   ...nicht gefunden')
        
    return(file_names)
    
    