# -*- coding: utf-8 -*-
"""
function to read data from hd5-file for experiments


Created on Tue Mar 26 01:02:59 2019

@author: Christian Kuehnert
@last_modified: 2019-4-30
"""
import pandas as pd
#import sys

from data import whereClause_from_timeInterval
#from myfunctions.data import whereClause_from_timeInterval

def get_data(file_name_hd5, channel, start_time=None, end_time=None):

    with pd.HDFStore(file_name_hd5, mode="a", complevel=9, complib='blosc:lz4') as f:
        
        sWC = whereClause_from_timeInterval(time_start=start_time, time_end = end_time, sFormat = '%Y%m%d%H%M%S', sTimeCol='time')
        if sWC:
            return(f.select(key=channel, where=sWC))
        else:        
            return(f.select(key=channel))
        
        
 