# -*- coding: utf-8 -*-
"""
Created on Wed Feb 20 10:42:37 2019

@author: w012028
"""


## import necessary libraries
import re
import ast
import sys
#import scipy.io
#import numpy as np
import pandas as pd
import datetime as dt
import h5py
#import scipy as sp
#import os
#import os.path
#import win32com.client as win32
import gc

#from collections import namedtuple
#from dateutil import parser
#from shutil import copy
#from scipy.integrate import simps

#try:
#    import cPickle as pickle
#except ModuleNotFoundError:
#    import pickle





#sModulePath = r'C:\Repositories\python\functions'
#sys.path.append(sModulePath)
  
#import myFunctions_data as mfdata
#import myFunctions_plot as mfplot
#from class_hd5Nodes import hd5Nodes as sNodes





"""
function to combine the data in the in separated files for each variable and store all in a new hd5-file

@author: Christian Kuehnert
@last modified: 2019-3-6

"""
#import datetime as dt
import numpy as np
#import h5py

def combine_data_old(path_data, file_names, dict_channels, dict_rates, start_times = None):
   
    sDB = 'cmrblba_bc_t_skw001'
    #sInfo = 'Husum, Prototyp SkyWind (001 AccelMems) (' + sDB + ')'

    if not start_times:
        #listStartTimes = [dt.datetime.strptime(s.split('\\')[-1].replace(sDB.replace('cmrblba_',''), '').replace('-',''), '%Y%m%d%H%M%S') for s in listFiles[:2]]        
        start_times = [dt.datetime.fromtimestamp(float(fn.split('-')[-1])) for fn in file_names]

    # TODO 2019-3-6: folgendes noch eleganter machen!
    sort_index = np.argsort(start_times)
    file_names = [file_names[i] for i in sort_index]
    lTmp = []
    for i in sort_index:
        lTmp.append(start_times[i])        
    start_times = lTmp

    listH5Stores = [h5py.File(path_data + '\\' + s) for s in file_names]
            
    lKeys = list(listH5Stores[0].keys())

    idx = range(len(file_names))
    
    sFN_hd5 = path_data + '\\' + sDB + '__combined__' + np.min(start_times).strftime('%Y%m%d_%H%M%S') + '.hd5'
    with pd.HDFStore(sFN_hd5, 'a', complevel=9, complib='blosc:lz4') as g:        # create empty hd5-file                    
        
        # save parameters etc.
        gk = g.keys()
        if not('file_names' in gk):
            tmp = pd.DataFrame.from_records({'file': file_names})            
            g.put('file_names', tmp, format='table')
            #g.append('file_names', tmp, format='table', data_columns=True, index=False)
        
        if not('dict_channels' in gk):
            tmp = pd.DataFrame.from_dict(dict_channels, orient='index', columns=['location', 'senstype', 'variable'])
            tmp.reset_index(drop=False, inplace=True)
            tmp.rename(columns={'index': 'channel'})
            g.put('dict_channels', tmp, format='table')
        
        if not('dict_rates' in gk):
            tmp = pd.DataFrame.from_dict(dict_rates, orient='index')
            tmp.reset_index(drop=False, inplace=True)
            tmp.rename(columns={'index': 'senstype'})
            g.put('dict_rates', tmp)
        
        lKeys = list(set(lKeys)-{'file_names', 'dict_channels', 'dict_rates'})
                        
        j=0
        sN = str(len(lKeys))
        for key in lKeys:

            j += 1 
        
            #sKey = ', '.join(dictChannels[key][[2,1]])                    
            print(str(j) + '/' + sN + ': ' + key)
            
            ## if the key not yet exists
            if ('ch'+key in g.keys()):
                print('   already exists')
                
            else:
        
                lTmp = []
                lTime = []
               
                senstype = dict_channels[key][1]                                 
                fac = dict_rates[senstype]['rate']
                unit = dict_rates[senstype]['unit']
                freq = dict_rates[senstype]['freq']
                                                                                                
                                                             
                ## get data and create_time
                iN = 0
                for i in idx:

                    f = listH5Stores[i]
                    tmp = f[key].value
                    n = tmp.shape[0]
                    iN += n
                    time = start_times[i] + pd.to_timedelta(pd.Series(range(n))/freq, unit='s')
                    #time.reset_index(inplace=True, drop=True)
                    lTmp.append(pd.Series(tmp[:,0]))
                    #lTime.append(time.dt.time)            
                    lTime.append(time)
                            
                #time = pd.concat(lTime).reset_index(inplace=True, drop=True)
                values = pd.concat(lTmp).reset_index(drop=True) / fac

                df = pd.DataFrame.from_records({'time': pd.concat(lTime).reset_index(drop=True), 
                                                'data': values}).loc[:, ['time', 'data']]
                #df['time'] = pd.to_datetime(df['time'], errors='coerce')                                                                                  
                
                del time
                del tmp
                del lTime
                del lTmp
                gc.collect()        
    
                g.put('ch' + str(key), df, format='table', data_columns=True, index=False)
                #g.append('ch'+key, df, format='table', data_columns = True, index=False)
                
                del df
    
        
        
        

    